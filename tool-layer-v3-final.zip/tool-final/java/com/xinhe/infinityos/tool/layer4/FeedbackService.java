// ============================================================
// FeedbackService.java  (v3.2·修复遗漏1)
// 修复：反思后补充任务必须执行完，再收集输出，再综合分析
// 用 @Lazy 注入 ToolOrchestrator 防止循环依赖
// ============================================================
package com.xinhe.infinityos.tool.layer4;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xinhe.infinityos.tool.enhance.SynthesisAndReflectionService;
import com.xinhe.infinityos.tool.enhance.SynthesisAndReflectionService.ReflectionResult;
import com.xinhe.infinityos.tool.enhance.SynthesisAndReflectionService.SupplementalTask;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class FeedbackService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;
    @Autowired private SynthesisAndReflectionService synthesisService;

    // 修复遗漏1：注入 ToolOrchestrator 以便触发补充任务执行
    // @Lazy 防止循环依赖（FeedbackService ↔ ToolOrchestrator）
    @Autowired @Lazy
    private com.xinhe.infinityos.tool.orchestrator.ToolOrchestrator toolOrchestrator;

    // ── 任务完成回调 ─────────────────────────────────────────
    public void onTaskCompleted(String requestId, String taskId, String agentId,
                                 Map<String, Object> taskOutput, boolean success) {
        updateCreditScore(agentId, requestId, success, success ? "任务成功" : "任务失败");
        triggerDependentTasks(requestId, taskId);
        if (isRequestCompleted(requestId)) {
            finalizeRequest(requestId);
        }
    }

    // ── 审批管理（v3原有）────────────────────────────────────
    public String createApprovalRequest(String requestId, String taskId, String agentId,
                                         String actionType, String actionSummary,
                                         Map<String, Object> actionDetail, String riskLevel,
                                         int authLevel, String requiredApprover, String plainReason) {
        String approvalId = "APR_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        int expireHours = switch (authLevel) { case 1->2; case 2->8; case 3->48; default->4; };
        try {
            jdbc.update(
                "INSERT INTO approval_queue(approval_id,request_id,task_id,agent_id,action_type," +
                "action_summary,action_detail,risk_level,auth_level,required_approver,plain_reason,expires_at) " +
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                approvalId, requestId, taskId, agentId, actionType, actionSummary,
                mapper.writeValueAsString(actionDetail), riskLevel, authLevel,
                requiredApprover, plainReason,
                new java.sql.Timestamp(System.currentTimeMillis() + (long) expireHours * 3600_000)
            );
        } catch (Exception e) { throw new RuntimeException("创建审批失败", e); }
        return approvalId;
    }

    public void onApprovalGranted(String approvalId, String approvedBy) {
        Map<String, Object> approval = getApproval(approvalId);
        if (approval == null) return;
        jdbc.update("UPDATE approval_queue SET status='approved',approved_by=?,decided_at=NOW() WHERE approval_id=?", approvedBy, approvalId);
        String taskId = String.valueOf(approval.get("task_id"));
        jdbc.update("UPDATE agent_task_queue SET auth_required=0,approved_by=?,status='pending' WHERE task_id=?", approvedBy, taskId);
        triggerDependentTasks(String.valueOf(approval.get("request_id")), taskId);
    }

    public void onApprovalRejected(String approvalId, String rejectedBy, String reason) {
        Map<String, Object> approval = getApproval(approvalId);
        if (approval == null) return;
        jdbc.update("UPDATE approval_queue SET status='rejected',approved_by=?,decided_at=NOW(),decision_reason=? WHERE approval_id=?", rejectedBy, reason, approvalId);
        jdbc.update("UPDATE agent_task_queue SET status='failed',error_message=? WHERE task_id=?", "审批拒绝:" + reason, approval.get("task_id"));
        updateCreditScore(String.valueOf(approval.get("agent_id")), String.valueOf(approval.get("request_id")), false, "审批拒绝:" + reason);
        if (isRequestCompleted(String.valueOf(approval.get("request_id"))))
            finalizeRequest(String.valueOf(approval.get("request_id")));
    }

    // ── 核心：finalizeRequest（#3+#4）────────────────────────
    private void finalizeRequest(String requestId) {
        // 统计任务结果
        Map<String, Object> stats = jdbc.queryForMap(
            "SELECT COUNT(*) as total, " +
            "SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed, " +
            "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) as failed " +
            "FROM agent_task_queue WHERE request_id=?", requestId
        );
        int total     = ((Number) stats.get("total")).intValue();
        int completed = ((Number) stats.get("completed")).intValue();
        int failed    = ((Number) stats.get("failed")).intValue();
        String finalStatus = failed == 0 ? "success" : completed > 0 ? "partial" : "failed";

        String userQuery = getUserQuery(requestId);

        // ── #4 反思机制 + 修复遗漏1：补充任务执行后再综合 ──
        List<Map<String, Object>> taskOutputs = collectCompletedOutputs(requestId);

        ReflectionResult reflection = synthesisService.reflectBeforeFinalize(
            requestId, userQuery, taskOutputs, 0
        );

        if (reflection.needMore && !reflection.tasks.isEmpty()) {
            // Step A：创建补充任务
            List<String> suppTaskIds = new ArrayList<>();
            for (SupplementalTask st : reflection.tasks) {
                String suppId = createSupplementalTask(requestId, st.agentId, st.taskDesc);
                suppTaskIds.add(suppId);
            }

            // ── 修复遗漏1 核心：触发执行补充任务 ────────────
            // v3错误：创建任务后直接综合，补充任务结果永远不进入最终答案
            // v3.2修复：触发执行 → 等待完成 → 重新收集输出
            toolOrchestrator.executeReadyTasks(requestId);
            waitForSupplementalTasks(suppTaskIds, 60);

            // Step B：重新收集（含补充任务输出）
            taskOutputs = collectCompletedOutputs(requestId);

            // 更新统计
            total     += suppTaskIds.size();
            completed += suppTaskIds.size();
        }

        // ── #3 LLM综合（用完整的taskOutputs，包含补充任务）──
        String finalResponse = synthesisService.synthesizeResults(
            requestId, userQuery, taskOutputs
        );

        // 写入结果汇总
        try {
            jdbc.update(
                "INSERT INTO execution_results(request_id,total_tasks,completed_tasks," +
                "failed_tasks,final_status,final_response,total_latency_ms) VALUES(?,?,?,?,?,?,?)",
                requestId, total, completed, failed, finalStatus,
                finalResponse, calculateTotalLatency(requestId)
            );
        } catch (Exception e) {
            jdbc.update("UPDATE execution_results SET final_response=?,final_status=? WHERE request_id=?",
                finalResponse, finalStatus, requestId);
        }

        jdbc.update(
            "UPDATE trigger_requests SET status=?,completed_at=NOW(),final_response=? WHERE request_id=?",
            "success".equals(finalStatus) ? "completed" : finalStatus, finalResponse, requestId
        );

        checkAndTriggerCascade(requestId, finalResponse);
    }

    // ── 等待补充任务完成（最多N秒）──────────────────────────
    private void waitForSupplementalTasks(List<String> taskIds, int timeoutSec) {
        long deadline = System.currentTimeMillis() + timeoutSec * 1000L;
        while (System.currentTimeMillis() < deadline) {
            try {
                int pending = jdbc.queryForObject(
                    "SELECT COUNT(*) FROM agent_task_queue WHERE task_id IN (" +
                    String.join(",", Collections.nCopies(taskIds.size(), "?")) + ") " +
                    "AND status IN ('pending','running')",
                    Integer.class, taskIds.toArray()
                );
                if (pending == null || pending == 0) return;
                Thread.sleep(500);
            } catch (Exception e) { return; }
        }
    }

    // ── 收集所有已完成任务的输出 ─────────────────────────────
    private List<Map<String, Object>> collectCompletedOutputs(String requestId) {
        return jdbc.queryForList(
            "SELECT agent_id, task_type, output_data, status FROM agent_task_queue " +
            "WHERE request_id=? AND status='completed' ORDER BY sequence_order",
            requestId
        );
    }

    // ── 工具方法（v3原有）────────────────────────────────────
    public void recordUserFeedback(String requestId, String userId, String agentId,
                                    int rating, String feedbackType, String comment) {
        jdbc.update(
            "INSERT INTO user_feedback(request_id,user_id,agent_id,rating,feedback_type,comment) VALUES(?,?,?,?,?,?)",
            requestId, userId, agentId, rating, feedbackType, comment
        );
        updateCreditScore(agentId, requestId, rating >= 4, "用户反馈" + rating + "星");
    }

    private void updateCreditScore(String agentId, String requestId, boolean positive, String reason) {
        double delta = positive ? 1.0 : -5.0;
        try {
            Double before = jdbc.queryForObject("SELECT credit_score FROM agent_memory_profiles WHERE agent_id=?", Double.class, agentId);
            if (before == null) return;
            double after = Math.min(100, Math.max(0, before + delta));
            jdbc.update("UPDATE agent_memory_profiles SET credit_score=? WHERE agent_id=?", after, agentId);
            jdbc.update("INSERT INTO credit_change_log(agent_id,request_id,change_type,delta,score_before,score_after,reason) VALUES(?,?,?,?,?,?,?)",
                agentId, requestId, positive?"correct":"incorrect", delta, before, after, reason);
            if (after < 40 && before >= 40)
                jdbc.update("UPDATE agent_memory_profiles SET current_status='paused' WHERE agent_id=?", agentId);
        } catch (Exception ignored) {}
    }

    private boolean isRequestCompleted(String requestId) {
        try {
            Integer pending = jdbc.queryForObject(
                "SELECT COUNT(*) FROM agent_task_queue WHERE request_id=? AND status IN ('pending','running')",
                Integer.class, requestId
            );
            return pending == null || pending == 0;
        } catch (Exception e) { return false; }
    }

    private void triggerDependentTasks(String requestId, String completedTaskId) {
        // 事件驱动（实际项目用MQ）
    }

    private String getUserQuery(String requestId) {
        try { return jdbc.queryForObject("SELECT raw_input FROM trigger_requests WHERE request_id=?", String.class, requestId); }
        catch (Exception e) { return ""; }
    }

    private String createSupplementalTask(String requestId, String agentId, String taskDesc) {
        String taskId = "SUPP_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        try {
            jdbc.update(
                "INSERT INTO agent_task_queue(task_id,request_id,agent_id,task_type," +
                "sequence_order,input_data,timeout_at,status) VALUES(?,?,?,?,?,?,?,?)",
                taskId, requestId, agentId, "analyze", 99,
                mapper.writeValueAsString(Map.of(
                    "task_desc", taskDesc,
                    "request_id", requestId,
                    "supplemental", true
                )),
                new java.sql.Timestamp(System.currentTimeMillis() + 300_000L),
                "pending"
            );
        } catch (Exception ignored) {}
        return taskId;
    }

    private void checkAndTriggerCascade(String requestId, String response) {
        if (response != null &&
            (response.contains("低于2a") || response.contains("断货") || response.contains("压货"))) {
            try {
                jdbc.update(
                    "INSERT IGNORE INTO cascade_triggers(source_request_id,source_agent," +
                    "triggered_agent,trigger_reason,trigger_data) VALUES(?,?,?,?,?)",
                    requestId, "system", "butterfly", "综合分析发现库存异常",
                    mapper.writeValueAsString(Map.of("source", requestId))
                );
            } catch (Exception ignored) {}
        }
    }

    private int calculateTotalLatency(String requestId) {
        try {
            Integer ms = jdbc.queryForObject(
                "SELECT TIMESTAMPDIFF(SECOND,MIN(started_at),MAX(completed_at))*1000 " +
                "FROM agent_task_queue WHERE request_id=?", Integer.class, requestId
            );
            return ms != null ? ms : 0;
        } catch (Exception e) { return 0; }
    }

    private Map<String, Object> getApproval(String id) {
        try { return jdbc.queryForMap("SELECT * FROM approval_queue WHERE approval_id=?", id); }
        catch (Exception e) { return null; }
    }

    @Scheduled(cron = "0 */30 * * * *")
    public void processExpiredApprovals() {
        jdbc.update("UPDATE approval_queue SET status='expired' WHERE status='pending' AND expires_at < NOW()");
    }

    @Scheduled(cron = "0 0 */1 * * *")
    public void processTimeoutTasks() {
        jdbc.update("UPDATE agent_task_queue SET status='failed',error_message='执行超时' WHERE status='running' AND timeout_at < NOW()");
    }
}
