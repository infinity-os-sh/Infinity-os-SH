// ToolExecutionService.java (v3·接入#5工具结果摘要)
package com.xinhe.infinityos.tool.layer3;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xinhe.infinityos.tool.enhance.ToolSummarizerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.*;

@Service
public class ToolExecutionService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;
    @Autowired private ToolSummarizerService summarizer;  // ← v3新增

    // ── 统一工具调用入口 ─────────────────────────────────────
    public ToolResult executeTool(String taskId, String requestId, String agentId,
                                   String toolId, Map<String, Object> params) {
        String executionId = "EXEC_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        Map<String, Object> tool = getToolDef(toolId);
        if (tool == null) return ToolResult.fail("工具不存在: " + toolId, null);
        if (!isAgentAllowed(agentId, tool)) return ToolResult.fail("Agent无权使用: " + toolId, null);
        if (!checkRateLimit(toolId, agentId, tool)) return ToolResult.fail("调用频率超限: " + toolId, null);

        createExecutionLog(executionId, taskId, requestId, agentId, toolId, params);

        int authLevel = assessAuth(agentId, toolId, params, tool);
        if (authLevel == 5) {
            updateExecutionLog(executionId, "failed", null, "AUTH_BLOCKED", "授权边界拒绝");
            return ToolResult.fail("授权边界拒绝: " + toolId, executionId);
        }
        if (authLevel >= 1) {
            updateExecutionLogStatus(executionId, "pending");
            return ToolResult.pendingApproval(executionId, authLevel);
        }

        long startMs = System.currentTimeMillis();
        updateExecutionLogStatus(executionId, "running");

        try {
            ToolResult result = dispatchTool(toolId, agentId, params);
            int latency = (int)(System.currentTimeMillis() - startMs);

            // ── #5 工具结果摘要（v3新增）──────────────────────
            if (result.isOk() && result.getData() != null) {
                Map<String, Object> summarized = summarizer.summarize(
                    executionId, toolId, result.getData()
                );
                result = ToolResult.ok(summarized);
            }

            updateExecutionLog(executionId, "success", result.getData(), null, null);
            updateLatency(executionId, latency);
            return result;

        } catch (Exception e) {
            return retryTool(executionId, toolId, agentId, params, tool, e);
        }
    }

    // ── 20个工具分发（v2原有，不变）─────────────────────────
    private ToolResult dispatchTool(String toolId, String agentId, Map<String, Object> params) {
        return switch (toolId) {
            case "T01_STORE_INVENTORY"    -> readStoreInventory(params);
            case "T02_DISTRIBUTOR_STOCK"  -> readDistributorStock(params);
            case "T03_DAILY_SALES"        -> readDailySales(params);
            case "T04_STORE_VISITS"       -> readStoreVisits(params);
            case "T05_PRICE_CHECK"        -> readPriceData(params);
            case "T06_PHOTO_SHELF"        -> fetchShelfPhoto(params);
            case "T07_SAP_ORDER"          -> readSapOrders(params);
            case "T08_CITY_STATS"         -> readCityStats(params);
            case "T09_AI_ANALYZE"         -> aiAnalyze(agentId, params);
            case "T10_AI_SUMMARIZE"       -> aiSummarize(params);
            case "T11_SHELF_RECOGNITION"  -> shelfRecognition(params);
            case "T12_PRICE_TAG_OCR"      -> priceTagOcr(params);
            case "T13_WECHAT_PUSH"        -> wechatPush(params);
            case "T14_WECHAT_APPROVAL"    -> wechatApproval(params);
            case "T15_SMS_ALERT"          -> smsAlert(params);
            case "T16_CREATE_ORDER"       -> createOrder(params);
            case "T17_UPDATE_INVENTORY"   -> updateInventory(params);
            case "T18_LOG_ANOMALY"        -> logAnomaly(params);
            case "T19_UPDATE_CB_SCORE"    -> updateCbScore(params);
            case "T20_SYNC_SAP"           -> syncSap(params);
            default -> throw new IllegalArgumentException("未知工具: " + toolId);
        };
    }

    // ── 工具实现（桩，Java团队完善）─────────────────────────
    private ToolResult readStoreInventory(Map<String,Object> p) {
        return ToolResult.ok(Map.of("store_id", p.getOrDefault("store_id","?"), "shelf_stock", 120, "warehouse_stock", 80, "inventory_ratio", 2.5, "water_level", "normal"));
    }
    private ToolResult readDistributorStock(Map<String,Object> p) {
        return ToolResult.ok(Map.of("distributor_id", p.getOrDefault("distributor_id","?"), "current_stock", 5000, "inventory_ratio", 1.8, "water_level", "normal"));
    }
    private ToolResult readDailySales(Map<String,Object> p) {
        return ToolResult.ok(Map.of("entity_id", p.getOrDefault("entity_id","?"), "sales_quantity", 48, "r_value", 1.6, "vs_target", 0.85));
    }
    private ToolResult readStoreVisits(Map<String,Object> p) {
        return ToolResult.ok(Map.of("store_id", p.getOrDefault("store_id","?"), "last_visit_date", "2026-04-10", "compliance_rate", 0.67));
    }
    private ToolResult readPriceData(Map<String,Object> p) {
        return ToolResult.ok(Map.of("current_price", 29.9, "floor_price", 17.0, "is_compliant", true));
    }
    private ToolResult fetchShelfPhoto(Map<String,Object> p) {
        return ToolResult.ok(Map.of("photo_url", "https://sfa.xinhe.com/photos/latest.jpg", "status", "available"));
    }
    private ToolResult readSapOrders(Map<String,Object> p) {
        return ToolResult.ok(Map.of("orders_this_month", 3, "total_amount", 85000.0));
    }
    private ToolResult readCityStats(Map<String,Object> p) {
        return ToolResult.ok(Map.of("city_id", p.getOrDefault("city_id","?"), "total_stores", 127, "coverage_rate", 0.78, "avg_r_value", 1.42));
    }
    private ToolResult aiAnalyze(String agentId, Map<String,Object> p) {
        return ToolResult.ok(Map.of("analysis", "[AI分析·待接入Claude API]", "confidence", 0.85));
    }
    private ToolResult aiSummarize(Map<String,Object> p) {
        return ToolResult.ok(Map.of("summary", "[摘要·待接入Claude API]"));
    }
    private ToolResult shelfRecognition(Map<String,Object> p) {
        return ToolResult.ok(Map.of("sku_count", 8, "brand_coverage", 0.75, "recognition_confidence", 0.82));
    }
    private ToolResult priceTagOcr(Map<String,Object> p) {
        return ToolResult.ok(Map.of("detected_price", 26.8, "is_compliant", true, "ocr_confidence", 0.91));
    }
    private ToolResult wechatPush(Map<String,Object> p) {
        return ToolResult.ok(Map.of("message_id", "MSG_" + System.currentTimeMillis(), "status", "sent"));
    }
    private ToolResult wechatApproval(Map<String,Object> p) {
        return ToolResult.ok(Map.of("approval_id", "APR_" + System.currentTimeMillis(), "status", "pending"));
    }
    private ToolResult smsAlert(Map<String,Object> p) {
        return ToolResult.ok(Map.of("sms_id", "SMS_" + System.currentTimeMillis(), "status", "sent"));
    }
    private ToolResult createOrder(Map<String,Object> p) {
        return ToolResult.ok(Map.of("order_id", "ORD_" + System.currentTimeMillis(), "status", "created"));
    }
    private ToolResult updateInventory(Map<String,Object> p) {
        return ToolResult.ok(Map.of("status", "updated", "water_level_recalculated", true));
    }
    private ToolResult logAnomaly(Map<String,Object> p) {
        String caseId = "CASE_" + System.currentTimeMillis();
        jdbc.update("INSERT INTO anomaly_case_library(case_id,anomaly_type,entity_type,entity_id,detected_at,detected_by,description,severity) VALUES(?,?,?,?,NOW(),?,?,?)",
            caseId, p.getOrDefault("anomaly_type","unknown"), p.getOrDefault("entity_type","store"),
            p.getOrDefault("entity_id","unknown"), p.getOrDefault("detected_by","system"),
            p.getOrDefault("description",""), p.getOrDefault("severity","medium"));
        return ToolResult.ok(Map.of("case_id", caseId, "status", "logged"));
    }
    private ToolResult updateCbScore(Map<String,Object> p) {
        return ToolResult.ok(Map.of("rep_id", p.getOrDefault("rep_id","?"), "status", "updated"));
    }
    private ToolResult syncSap(Map<String,Object> p) {
        return ToolResult.ok(Map.of("sync_id", "SYNC_" + System.currentTimeMillis(), "status", "triggered"));
    }

    // ── 限流+重试+日志（v2原有）─────────────────────────────
    private boolean checkRateLimit(String toolId, String agentId, Map<String,Object> tool) {
        Object rl = tool.get("rate_limit_per_minute");
        if (rl == null) return true;
        int limit = ((Number) rl).intValue();
        try {
            int count = jdbc.queryForObject("SELECT COALESCE(call_count,0) FROM tool_rate_counters WHERE tool_id=? AND agent_id=? AND window_minute >= DATE_FORMAT(NOW(),'%Y-%m-%d %H:%i:00')", Integer.class, toolId, agentId);
            if (count >= limit) return false;
        } catch (Exception ignored) {}
        jdbc.update("INSERT INTO tool_rate_counters(tool_id,agent_id,window_minute,call_count) VALUES(?,?,DATE_FORMAT(NOW(),'%Y-%m-%d %H:%i:00'),1) ON DUPLICATE KEY UPDATE call_count=call_count+1", toolId, agentId);
        return true;
    }

    private int assessAuth(String agentId, String toolId, Map<String,Object> params, Map<String,Object> tool) {
        return ((Number) tool.getOrDefault("min_auth_level", 0)).intValue();
    }

    private ToolResult retryTool(String executionId, String toolId, String agentId, Map<String,Object> params, Map<String,Object> tool, Exception firstError) {
        int maxRetries = ((Number) tool.getOrDefault("max_retries", 3)).intValue();
        for (int i = 1; i <= maxRetries; i++) {
            try {
                Thread.sleep(1000L * i);
                updateExecutionLogStatus(executionId, "retrying");
                ToolResult result = dispatchTool(toolId, agentId, params);
                // #5 也对重试结果摘要
                if (result.isOk() && result.getData() != null)
                    result = ToolResult.ok(summarizer.summarize(executionId, toolId, result.getData()));
                updateExecutionLog(executionId, "success", result.getData(), null, null);
                return result;
            } catch (Exception e) {
                if (i == maxRetries) {
                    updateExecutionLog(executionId, "failed", null, "MAX_RETRY", e.getMessage());
                    return ToolResult.fail("重试" + maxRetries + "次后失败: " + e.getMessage(), executionId);
                }
            }
        }
        return ToolResult.fail(firstError.getMessage(), executionId);
    }

    private Map<String,Object> getToolDef(String toolId) {
        try { return jdbc.queryForMap("SELECT * FROM tool_registry WHERE tool_id=? AND is_active=1", toolId); }
        catch (Exception e) { return null; }
    }

    @SuppressWarnings("unchecked")
    private boolean isAgentAllowed(String agentId, Map<String,Object> tool) {
        Object aj = tool.get("allowed_agents");
        if (aj == null) return true;
        try { List<String> allowed = mapper.readValue(aj.toString(), List.class); return allowed.contains(agentId); }
        catch (Exception e) { return true; }
    }

    private void createExecutionLog(String eid, String tid, String rid, String aid, String toolId, Map<String,Object> params) {
        try { jdbc.update("INSERT INTO tool_execution_log(execution_id,task_id,request_id,agent_id,tool_id,input_params,status) VALUES(?,?,?,?,?,?,?)", eid, tid, rid, aid, toolId, safeJson(params), "pending"); } catch (Exception ignored) {}
    }

    private void updateExecutionLog(String eid, String status, Map<String,Object> output, String ec, String em) {
        try { jdbc.update("UPDATE tool_execution_log SET status=?,output_result=?,error_code=?,error_message=?,completed_at=NOW() WHERE execution_id=?", status, output != null ? safeJson(output) : null, ec, em, eid); } catch (Exception ignored) {}
    }

    private void updateExecutionLogStatus(String eid, String status) {
        jdbc.update("UPDATE tool_execution_log SET status=? WHERE execution_id=?", status, eid);
    }

    private void updateLatency(String eid, int ms) {
        jdbc.update("UPDATE tool_execution_log SET latency_ms=?,started_at=NOW() WHERE execution_id=?", ms, eid);
    }

    private String safeJson(Object o) { try { return mapper.writeValueAsString(o); } catch (Exception e) { return "{}"; } }
}
