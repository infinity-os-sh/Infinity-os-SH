// ToolResult.java - 工具调用结果数据结构
package com.xinhe.infinityos.tool.layer3;

import java.util.Map;

public class ToolResult {
    public enum Status { OK, FAIL, PENDING_APPROVAL }

    private Status status;
    private Map<String, Object> data;
    private String errorMessage;
    private String executionId;
    private int authLevel; // 需要审批时的授权级别

    public static ToolResult ok(Map<String, Object> data) {
        ToolResult r = new ToolResult();
        r.status = Status.OK; r.data = data; return r;
    }
    public static ToolResult fail(String error, String executionId) {
        ToolResult r = new ToolResult();
        r.status = Status.FAIL; r.errorMessage = error; r.executionId = executionId; return r;
    }
    public static ToolResult pendingApproval(String executionId, int authLevel) {
        ToolResult r = new ToolResult();
        r.status = Status.PENDING_APPROVAL; r.executionId = executionId; r.authLevel = authLevel; return r;
    }

    public boolean isOk() { return status == Status.OK; }
    public boolean isFailed() { return status == Status.FAIL; }
    public boolean isPendingApproval() { return status == Status.PENDING_APPROVAL; }

    public Status getStatus() { return status; }
    public Map<String, Object> getData() { return data; }
    public String getErrorMessage() { return errorMessage; }
    public String getExecutionId() { return executionId; }
    public int getAuthLevel() { return authLevel; }
}
