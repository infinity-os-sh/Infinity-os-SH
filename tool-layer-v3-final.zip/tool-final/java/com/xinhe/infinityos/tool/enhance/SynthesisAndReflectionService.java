// ============================================================
// SynthesisAndReflectionService.java  (v3.2·修复遗漏2)
// 修复：.toList() → .collect(Collectors.toList())，兼容 Java 11
// （同时保留 v3.1 的 JdbcTemplate 声明修复）
// ============================================================
package com.xinhe.infinityos.tool.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;  // ← 修复遗漏2：补充import

@Service
public class SynthesisAndReflectionService {

    @Value("${anthropic.api.key}")
    private String apiKey;

    @Value("${anthropic.api.model:claude-sonnet-4-20250514}")
    private String model;

    @Autowired private JdbcTemplate jdbc;   // v3.1已修复，保留
    @Autowired private ObjectMapper mapper;

    private final HttpClient http = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10)).build();

    private final Map<String, SseEmitter> sseEmitters = new ConcurrentHashMap<>();

    // ══ #3 LLM综合多Agent结果 ════════════════════════════════

    public String synthesizeResults(String requestId, String userQuery,
                                     List<Map<String, Object>> taskOutputs) {
        if (taskOutputs == null || taskOutputs.isEmpty())
            return "未获取到有效的分析结果，请重试。";

        pushSseEvent(requestId, "synthesis_start", null, null, 0,
            "正在综合多Agent分析结果...", "running");

        StringBuilder agentResults = new StringBuilder();
        int tokenEstimate = 0;

        for (Map<String, Object> task : taskOutputs) {
            String agentId = String.valueOf(task.get("agent_id"));
            Object outputData = task.get("output_data");
            if (outputData == null) continue;

            String outputStr = outputData instanceof String
                ? (String) outputData : safeJson(outputData);
            if (outputStr.length() > 1000)
                outputStr = outputStr.substring(0, 1000) + "...[已截断]";

            agentResults.append("【").append(agentId).append("】\n")
                        .append(outputStr).append("\n\n");
            tokenEstimate += outputStr.length() / 2;
        }

        if (agentResults.length() < 50)
            return buildFallbackSummary(taskOutputs);

        String systemPrompt =
            "你是INFINITY OS的综合分析专家，把多个Agent的分析结果整合为可执行的报告。\n\n" +
            "输出要求：\n" +
            "1. Markdown格式，有标题和列表\n" +
            "2. 交叉分析各维度的关联性（不要简单罗列）\n" +
            "3. 如发现数据矛盾，明确指出并给出可能原因\n" +
            "4. 最后给出2-3条具体可执行的行动建议\n" +
            "5. 每个数据点标注来源Agent（用[Agent名]标注）\n" +
            "6. 语言简洁，不超过400字";

        try {
            String synthesis = callClaude(systemPrompt,
                "用户问题：" + userQuery + "\n\n各Agent分析结果：\n" + agentResults, 800);
            List<String> actionItems = extractActionItems(synthesis);
            updateSynthesisResult(requestId, synthesis, "llm", tokenEstimate, actionItems);
            pushSseEvent(requestId, "pipeline_complete", null, null, 0, "分析完成", "success");
            return synthesis;
        } catch (Exception e) {
            String fallback = buildFallbackSummary(taskOutputs);
            updateSynthesisResult(requestId, fallback, "fallback", 0, Collections.emptyList());
            return fallback;
        }
    }

    // ══ #4 LLM反思机制 ════════════════════════════════════════

    public ReflectionResult reflectBeforeFinalize(String requestId, String userQuery,
                                                   List<Map<String, Object>> taskOutputs,
                                                   int currentRound) {
        if (currentRound >= 2) return ReflectionResult.noMore();

        StringBuilder resultsText = new StringBuilder();
        for (Map<String, Object> task : taskOutputs) {
            resultsText.append("Agent[").append(task.get("agent_id")).append("] ")
                       .append("状态:").append(task.get("status")).append(" ")
                       .append("输出:").append(
                           summarizeOutput(String.valueOf(task.getOrDefault("output_data","null")))
                       ).append("\n");
        }

        String systemPrompt =
            "你是INFINITY OS的质量审查专家。审视多个Agent的执行结果，判断是否需要补充查询。\n\n" +
            "输出格式（严格JSON，无其他内容）：\n" +
            "{\"need_more\":true/false,\"issues\":[\"问题描述\"],\"reasoning\":\"判断理由\"," +
            "\"supplemental_tasks\":[{\"agent_id\":\"...\",\"task_desc\":\"...\"}]}";

        String userPrompt =
            "原始用户问题：" + userQuery + "\n\n" +
            "各Agent执行结果：\n" + resultsText + "\n\n" +
            "判断：1.有Agent返回空数据或错误？2.数据之间有矛盾？3.关键维度未覆盖？" +
            "如需补充，最多建议2个补充任务。";

        long startMs = System.currentTimeMillis();
        try {
            String response = callClaude(systemPrompt, userPrompt, 500);
            Map<?, ?> parsed = mapper.readValue(cleanJson(response), Map.class);
            boolean needMore  = Boolean.TRUE.equals(parsed.get("need_more"));
            List<?> issues    = (List<?>) parsed.getOrDefault("issues", Collections.emptyList());
            String reasoning  = String.valueOf(parsed.getOrDefault("reasoning", ""));
            List<?> suppTasks = (List<?>) parsed.getOrDefault("supplemental_tasks", Collections.emptyList());

            saveReflectionLog(requestId, currentRound + 1, issues, needMore,
                suppTasks, reasoning, (int)(System.currentTimeMillis() - startMs));

            if (!needMore) return ReflectionResult.noMore();

            List<SupplementalTask> tasks = new ArrayList<>();
            for (Object t : suppTasks) {
                Map<?, ?> tm = (Map<?, ?>) t;
                tasks.add(new SupplementalTask(
                    String.valueOf(tm.get("agent_id")),
                    String.valueOf(tm.get("task_desc"))
                ));
            }

            // ── 修复遗漏2：.toList() → .collect(Collectors.toList()) ──
            List<String> issueStrings = issues.stream()
                .map(String::valueOf)
                .collect(Collectors.toList());   // ← 兼容 Java 11

            return ReflectionResult.needMore(tasks, issueStrings);

        } catch (Exception e) {
            return ReflectionResult.noMore();
        }
    }

    // ══ SSE推送 ═══════════════════════════════════════════════

    public void registerSseEmitter(String requestId, SseEmitter emitter) {
        sseEmitters.put(requestId, emitter);
        emitter.onCompletion(() -> sseEmitters.remove(requestId));
        emitter.onTimeout(() -> sseEmitters.remove(requestId));
    }

    public void pushSseEvent(String requestId, String eventType,
                              String agentId, String agentLabel,
                              int durationMs, String outputPreview, String status) {
        try {
            jdbc.update(
                "INSERT INTO sse_progress_events(request_id,event_type,agent_id," +
                "agent_label,status,output_preview,duration_ms) VALUES(?,?,?,?,?,?,?)",
                requestId, eventType, agentId, agentLabel, status, outputPreview, durationMs
            );
        } catch (Exception ignored) {}

        SseEmitter emitter = sseEmitters.get(requestId);
        if (emitter != null) {
            try {
                Map<String, Object> event = new LinkedHashMap<>();
                event.put("type", eventType);
                event.put("agent_id", agentId);
                event.put("agent_label", agentLabel);
                event.put("status", status);
                event.put("output_preview", outputPreview);
                event.put("duration_ms", durationMs);
                emitter.send(SseEmitter.event()
                    .name(eventType)
                    .data(mapper.writeValueAsString(event)));
            } catch (Exception e) {
                sseEmitters.remove(requestId);
            }
        }
    }

    // ══ 工具方法 ══════════════════════════════════════════════

    private String buildFallbackSummary(List<Map<String, Object>> outputs) {
        StringBuilder sb = new StringBuilder("## 分析完成\n\n");
        for (Map<String, Object> t : outputs) {
            sb.append("**").append(t.get("agent_id")).append("**：")
              .append(summarizeOutput(String.valueOf(t.getOrDefault("output_data","无数据"))))
              .append("\n\n");
        }
        return sb.toString();
    }

    private String summarizeOutput(String output) {
        if (output == null || output.equals("null")) return "无数据";
        return output.length() > 200 ? output.substring(0, 200) + "..." : output;
    }

    private List<String> extractActionItems(String synthesis) {
        List<String> items = new ArrayList<>();
        for (String line : synthesis.split("\n")) {
            String t = line.trim();
            if (t.startsWith("- ") || t.startsWith("* ") || t.matches("^\\d+\\..*")) {
                String item = t.replaceFirst("^[-*\\d.]+\\s*", "");
                if (item.length() > 10 && item.length() < 200) items.add(item);
            }
        }
        // 修复遗漏2：同样用 collect(Collectors.toList())
        return items.stream().limit(5).collect(Collectors.toList());
    }

    private void updateSynthesisResult(String requestId, String response,
                                        String method, int tokens,
                                        List<String> actionItems) {
        try {
            jdbc.update(
                "UPDATE execution_results SET final_response=?,synthesis_method=?," +
                "synthesis_tokens=?,action_items=? WHERE request_id=?",
                response, method, tokens,
                mapper.writeValueAsString(actionItems), requestId
            );
        } catch (Exception ignored) {}
    }

    private void saveReflectionLog(String requestId, int round, List<?> issues,
                                    boolean needMore, List<?> suppTasks,
                                    String reasoning, int latencyMs) {
        try {
            jdbc.update(
                "INSERT INTO reflection_log(request_id,reflection_round,issues_found," +
                "need_more,supplemental_tasks,llm_reasoning,latency_ms) VALUES(?,?,?,?,?,?,?)",
                requestId, round,
                mapper.writeValueAsString(issues), needMore ? 1 : 0,
                mapper.writeValueAsString(suppTasks), reasoning, latencyMs
            );
        } catch (Exception ignored) {}
    }

    private String callClaude(String system, String userMsg, int maxTokens) throws Exception {
        Map<String, Object> body = Map.of(
            "model", model, "max_tokens", maxTokens, "system", system,
            "messages", List.of(Map.of("role", "user", "content", userMsg))
        );
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create("https://api.anthropic.com/v1/messages"))
            .header("Content-Type", "application/json")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .timeout(Duration.ofSeconds(60))
            .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
            .build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200) throw new RuntimeException("API error: " + resp.statusCode());
        Map<?, ?> r = mapper.readValue(resp.body(), Map.class);
        return String.valueOf(((Map<?,?>) ((List<?>)r.get("content")).get(0)).get("text"));
    }

    private String cleanJson(String t) {
        return t.replaceAll("```json","").replaceAll("```","").trim();
    }

    private String safeJson(Object o) {
        try { return mapper.writeValueAsString(o); }
        catch (Exception e) { return o.toString(); }
    }

    // ── 数据结构 ─────────────────────────────────────────────
    public static class ReflectionResult {
        public final boolean needMore;
        public final List<SupplementalTask> tasks;
        public final List<String> issues;
        private ReflectionResult(boolean n, List<SupplementalTask> t, List<String> i) {
            needMore=n; tasks=t; issues=i;
        }
        public static ReflectionResult noMore() {
            return new ReflectionResult(false,
                Collections.emptyList(), Collections.emptyList());
        }
        public static ReflectionResult needMore(List<SupplementalTask> t, List<String> i) {
            return new ReflectionResult(true, t, i);
        }
    }

    public static class SupplementalTask {
        public final String agentId, taskDesc;
        public SupplementalTask(String a, String d) { agentId=a; taskDesc=d; }
    }
}
