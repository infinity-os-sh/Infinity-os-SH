// ============================================================
// ToolSummarizerService.java
// #5 工具结果智能摘要
// dispatchTool()返回后，超过阈值的输出自动压缩
// 防止大数据量工具输出撑爆LLM上下文窗口
// ============================================================
package com.xinhe.infinityos.tool.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class ToolSummarizerService {

    private static final int THRESHOLD_CHARS = 3000;  // 超过3000字符触发摘要
    private static final int MAX_ARRAY_ITEMS = 10;    // JSON数组保留前N条
    private static final int MAX_TEXT_CHARS  = 1500;  // 纯文本截断长度

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    /**
     * 主入口：检查并摘要工具输出
     * 在 ToolExecutionService.executeTool() 中，dispatchTool()成功后调用
     *
     * @param executionId 工具调用ID（用于日志）
     * @param toolId      工具ID
     * @param data        原始输出Map
     * @return 摘要后的Map（如果不需要摘要则原样返回）
     */
    public Map<String, Object> summarize(String executionId, String toolId,
                                          Map<String, Object> data) {
        if (data == null || data.isEmpty()) return data;

        // 序列化估算大小
        String serialized;
        try { serialized = mapper.writeValueAsString(data); }
        catch (Exception e) { return data; }

        int originalSize = serialized.length();

        // 未超过阈值，不摘要
        if (originalSize <= THRESHOLD_CHARS) return data;

        // 根据数据类型选择摘要策略
        Map<String, Object> summarized;
        String method;

        if (isArrayResult(data)) {
            summarized = summarizeArray(data);
            method = "array_trim";
        } else if (isDeepObject(data)) {
            summarized = summarizeObject(data);
            method = "key_filter";
        } else {
            summarized = summarizeText(data);
            method = "text_truncate";
        }

        int summarizedSize;
        try { summarizedSize = mapper.writeValueAsString(summarized).length(); }
        catch (Exception e) { summarizedSize = originalSize; }

        // 记录摘要日志
        logSummary(executionId, toolId, originalSize, summarizedSize, method);

        return summarized;
    }

    // ── JSON数组摘要：保留前N条 + 统计摘要 ─────────────────
    @SuppressWarnings("unchecked")
    private Map<String, Object> summarizeArray(Map<String, Object> data) {
        Map<String, Object> result = new LinkedHashMap<>();

        for (Map.Entry<String, Object> entry : data.entrySet()) {
            Object value = entry.getValue();
            if (value instanceof List<?> list && list.size() > MAX_ARRAY_ITEMS) {
                // 保留前N条
                List<?> trimmed = list.subList(0, MAX_ARRAY_ITEMS);
                result.put(entry.getKey(), trimmed);

                // 追加统计摘要
                result.put(entry.getKey() + "_summary", buildArrayStats(list));
                result.put(entry.getKey() + "_total_count", list.size());
                result.put("_data_truncated", true);
                result.put("_original_count", list.size());
                result.put("_shown_count", MAX_ARRAY_ITEMS);
            } else {
                result.put(entry.getKey(), value);
            }
        }
        return result;
    }

    // ── 深层对象摘要：只保留关键字段 ────────────────────────
    @SuppressWarnings("unchecked")
    private Map<String, Object> summarizeObject(Map<String, Object> data) {
        // 优先保留的字段名（业务关键字段）
        Set<String> keyFields = Set.of(
            "store_id", "distributor_id", "city_id", "status", "water_level",
            "inventory_ratio", "r_value", "risk_level", "alert", "amount",
            "total", "count", "rate", "score", "result", "action",
            "store_tier", "channel", "brand", "sku_id", "order_id"
        );

        Map<String, Object> result = new LinkedHashMap<>();
        int charCount = 0;

        for (Map.Entry<String, Object> entry : data.entrySet()) {
            String key = entry.getKey().toLowerCase();
            Object value = entry.getValue();
            String valueStr = String.valueOf(value);

            // 关键字段必须保留
            boolean isKeyField = keyFields.stream().anyMatch(key::contains);

            if (isKeyField || charCount < THRESHOLD_CHARS / 2) {
                // 嵌套对象递归摘要
                if (value instanceof Map<?,?> nested && valueStr.length() > 500) {
                    result.put(entry.getKey(), summarizeObject((Map<String,Object>) nested));
                } else if (value instanceof List<?> list && list.size() > 5) {
                    result.put(entry.getKey(), list.subList(0, 5));
                    result.put(entry.getKey() + "_count", list.size());
                } else {
                    result.put(entry.getKey(), value);
                }
                charCount += valueStr.length();
            }
        }

        result.put("_summarized", true);
        return result;
    }

    // ── 纯文本截断摘要 ───────────────────────────────────────
    private Map<String, Object> summarizeText(Map<String, Object> data) {
        Map<String, Object> result = new LinkedHashMap<>();
        int charCount = 0;

        for (Map.Entry<String, Object> entry : data.entrySet()) {
            String valueStr = String.valueOf(entry.getValue());
            if (charCount + valueStr.length() > MAX_TEXT_CHARS) {
                int remaining = Math.max(0, MAX_TEXT_CHARS - charCount);
                if (remaining > 0) {
                    result.put(entry.getKey(),
                        valueStr.substring(0, remaining) + "...[截断，原始长度" + valueStr.length() + "字符]");
                }
                result.put("_data_truncated", true);
                break;
            }
            result.put(entry.getKey(), entry.getValue());
            charCount += valueStr.length();
        }
        return result;
    }

    // ── 辅助：数组统计摘要 ───────────────────────────────────
    private Map<String, Object> buildArrayStats(List<?> list) {
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("total_items", list.size());

        // 如果是数字列表，计算统计值
        if (!list.isEmpty() && list.get(0) instanceof Number) {
            DoubleSummaryStatistics dss = list.stream()
                .filter(i -> i instanceof Number)
                .mapToDouble(i -> ((Number) i).doubleValue())
                .summaryStatistics();
            stats.put("min", Math.round(dss.getMin() * 100.0) / 100.0);
            stats.put("max", Math.round(dss.getMax() * 100.0) / 100.0);
            stats.put("avg", Math.round(dss.getAverage() * 100.0) / 100.0);
        }

        // 如果是Map列表，统计关键字段的分布
        if (!list.isEmpty() && list.get(0) instanceof Map<?,?>) {
            Map<?,?> sample = (Map<?,?>) list.get(0);
            stats.put("fields", new ArrayList<>(sample.keySet()));
        }
        return stats;
    }

    // ── 类型判断 ─────────────────────────────────────────────
    private boolean isArrayResult(Map<String, Object> data) {
        return data.values().stream().anyMatch(v -> v instanceof List<?>
            && ((List<?>) v).size() > MAX_ARRAY_ITEMS);
    }

    private boolean isDeepObject(Map<String, Object> data) {
        return data.values().stream().anyMatch(v -> v instanceof Map<?,?> || v instanceof List<?>);
    }

    // ── 日志 ─────────────────────────────────────────────────
    private void logSummary(String executionId, String toolId,
                             int originalSize, int summarizedSize, String method) {
        try {
            double ratio = originalSize > 0
                ? Math.round((1.0 - (double) summarizedSize / originalSize) * 10000.0) / 100.0
                : 0;
            jdbc.update(
                "INSERT INTO tool_summary_log(execution_id, tool_id, original_size, " +
                "summarized_size, compression_ratio, summary_method) VALUES(?,?,?,?,?,?)",
                executionId, toolId, originalSize, summarizedSize, ratio, method
            );
        } catch (Exception ignored) {}
    }
}
