// ============================================================
// IntentAndPlannerService.java
// #1 LLM意图识别：关键词未命中时用LLM识别应该交给哪个Agent
// #2 LLM任务拆解：复杂问题动态拆解为1-5个子任务
// 技术路径：Java HttpClient 调用 Claude API（非Python IntentAgent）
// ============================================================
package com.xinhe.infinityos.tool.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;

@Service
public class IntentAndPlannerService {

    @Value("${anthropic.api.key}")
    private String apiKey;

    @Value("${anthropic.api.model:claude-sonnet-4-20250514}")
    private String model;

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    private final HttpClient http = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10)).build();

    // 24个Agent的简要描述（给LLM用于意图识别）
    private static final String AGENT_CATALOG =
        "aio_commander=AIO总指挥·全链调度·战略分析\n" +
        "distributor=经销商全链·进货库存出货·心跳单元a·水位预警\n" +
        "retail_store=零售门店·六级分类S+/S/A/B/C/D·货架库存·铺货率·动销\n" +
        "butterfly=蝴蝶效应·全链异常传导检测·A类压货B类促销扰动C类窜货\n" +
        "omakase=无菜单推单·自动计算补货量·SKU组合\n" +
        "a_calibration=A值校准·日销率r=a÷T·三重验证\n" +
        "shelf_recognition=货架识别·千问VL·陈列合规\n" +
        "inventory_report=库存上报·货架量+仓库量·水位计算\n" +
        "price_tag=价签识别·OCR·底价¥17监控·乱价预警\n" +
        "uber_incentive=Uber激励·CB评分·美顾任务派发\n" +
        "sub_distributor=二批商·P2路径·餐饮渠道·价格管控\n" +
        "consumer_deep=消费者深度·渗透率·复购率·流失预警\n" +
        "food_service=餐饮渠道·B端·菜单绑定率·厨师关系\n" +
        "prism=PRISM精准选点·高价值小区·消费者端\n" +
        "brand_advisor=品牌AI顾问·五品牌矩阵·AIQL\n" +
        "production=生产供应·工厂产能·IPO0-1\n" +
        "xiaohongshu=小红书种草棒·KOC·内容营销\n" +
        "douyin=抖音爆发棒·达人·直播带货\n" +
        "ecommerce=电商转化棒·天猫京东\n" +
        "o2o=O2O即时棒·美团饿了么\n" +
        "warehouse_member=仓储会员棒·山姆Costco\n" +
        "hypermarket=大卖场棒·KA·堆头端架\n" +
        "community=社区超市棒·下沉市场\n" +
        "fresh_advisor=鲜生顾问·高端场景·米其林";

    // ══ #1 LLM意图识别 ════════════════════════════════════════

    /**
     * 主入口：规则优先 + LLM兜底双轨制
     * 在 RoutingService.matchRule() 未命中时调用
     */
    public IntentResult recognizeIntent(String userQuery, List<Map<String,String>> recentHistory) {
        // 1. 查缓存（相同问题不重复调用LLM）
        String queryHash = md5(userQuery.toLowerCase().trim());
        IntentResult cached = getCachedIntent(queryHash);
        if (cached != null) {
            updateCacheHit(queryHash);
            return cached;
        }

        // 2. 构建包含多轮历史的query（支持追问场景）
        String enrichedQuery = buildEnrichedQuery(userQuery, recentHistory);

        // 3. 调用Claude API识别意图
        IntentResult result = callLlmForIntent(enrichedQuery, userQuery);

        // 4. 写缓存
        saveIntentCache(queryHash, userQuery, result);

        return result;
    }

    private IntentResult callLlmForIntent(String enrichedQuery, String originalQuery) {
        String systemPrompt =
            "你是INFINITY OS的意图识别专家。根据用户的问题，判断应该由哪个Agent处理。\n\n" +
            "可用Agent列表：\n" + AGENT_CATALOG + "\n\n" +
            "输出格式（严格JSON，无其他内容）：\n" +
            "{\"agent_id\":\"agent名称\",\"intent_type\":\"query|command|alert\"," +
            "\"confidence\":0.0到1.0,\"is_multi_agent\":true/false," +
            "\"reasoning\":\"一句话说明原因\"}";

        try {
            String response = callClaude(systemPrompt,
                "用户问题：" + enrichedQuery, 200);
            Map<?, ?> parsed = mapper.readValue(cleanJson(response), Map.class);
            return new IntentResult(
                String.valueOf(parsed.get("agent_id")),
                String.valueOf(parsed.get("intent_type")),
                ((Number) parsed.getOrDefault("confidence", 0.7)).doubleValue(),
                Boolean.TRUE.equals(parsed.get("is_multi_agent")),
                String.valueOf(parsed.get("reasoning")),
                "llm"
            );
        } catch (Exception e) {
            // 降级：返回aio_commander兜底
            return new IntentResult("aio_commander", "query", 0.5,
                false, "LLM识别失败，降级到总指挥", "fallback");
        }
    }

    // ══ #2 LLM任务拆解 ════════════════════════════════════════

    /**
     * 将复杂用户问题动态拆解为1-5个子任务
     * 在 RoutingService.route() 规则未命中或问题复杂时调用
     */
    public List<DecomposedTask> decomposeRequest(String requestId, String userQuery,
                                                   List<Map<String,String>> recentHistory) {
        long startMs = System.currentTimeMillis();

        String enrichedQuery = buildEnrichedQuery(userQuery, recentHistory);
        String systemPrompt =
            "你是INFINITY OS的任务规划专家。将用户问题拆解为1-5个子任务，分配给不同Agent并行或顺序执行。\n\n" +
            "可用Agent：\n" + AGENT_CATALOG + "\n\n" +
            "输出格式（严格JSON数组，无其他内容）：\n" +
            "[{\"seq\":1,\"agent_id\":\"agent名\",\"task_desc\":\"该Agent需要做什么\"," +
            "\"depends_on_seq\":null或前置seq数字,\"task_type\":\"analyze|execute|report\"}]";

        List<DecomposedTask> tasks = new ArrayList<>();
        String reasoning = "";

        try {
            String response = callClaude(systemPrompt,
                "请为以下问题制定执行计划：\n" + enrichedQuery, 600);
            String cleanedResponse = cleanJson(response);
            List<?> parsed = mapper.readValue(cleanedResponse, List.class);
            for (Object item : parsed) {
                Map<?, ?> t = (Map<?, ?>) item;
                tasks.add(new DecomposedTask(
                    ((Number) t.get("seq")).intValue(),
                    String.valueOf(t.get("agent_id")),
                    String.valueOf(t.get("task_desc")),
                    t.get("depends_on_seq") != null
                        ? ((Number) t.get("depends_on_seq")).intValue() : null,
                    String.valueOf(t.getOrDefault("task_type", "analyze"))
                ));
            }
            reasoning = "LLM动态拆解，共" + tasks.size() + "个子任务";
        } catch (Exception e) {
            // 降级：单任务给aio_commander
            tasks.add(new DecomposedTask(1, "aio_commander", userQuery, null, "analyze"));
            reasoning = "LLM拆解失败，降级为单任务";
        }

        // 记录拆解日志
        saveDecompositionLog(requestId, userQuery, tasks,
            tasks.size() > 1 ? "llm" : "rule", reasoning,
            (int)(System.currentTimeMillis() - startMs));

        return tasks;
    }

    // ══ 工具方法 ══════════════════════════════════════════════

    private String buildEnrichedQuery(String currentQuery, List<Map<String,String>> history) {
        if (history == null || history.isEmpty()) return currentQuery;
        // 取最近4轮历史作为上下文
        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, history.size() - 4);
        for (int i = start; i < history.size(); i++) {
            Map<String,String> turn = history.get(i);
            sb.append("user".equals(turn.get("role")) ? "用户: " : "AI: ")
              .append(turn.get("content")).append("\n");
        }
        sb.append("用户（当前）: ").append(currentQuery);
        return sb.toString();
    }

    private String callClaude(String system, String userMsg, int maxTokens) throws Exception {
        Map<String, Object> body = Map.of(
            "model", model,
            "max_tokens", maxTokens,
            "system", system,
            "messages", List.of(Map.of("role", "user", "content", userMsg))
        );
        HttpRequest req = HttpRequest.newBuilder()
            .uri(URI.create("https://api.anthropic.com/v1/messages"))
            .header("Content-Type", "application/json")
            .header("x-api-key", apiKey)
            .header("anthropic-version", "2023-06-01")
            .timeout(Duration.ofSeconds(30))
            .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
            .build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200)
            throw new RuntimeException("Claude API error: " + resp.statusCode());
        Map<?, ?> respMap = mapper.readValue(resp.body(), Map.class);
        List<?> content = (List<?>) respMap.get("content");
        return String.valueOf(((Map<?,?>) content.get(0)).get("text"));
    }

    private String cleanJson(String text) {
        // 移除可能的markdown代码块
        return text.replaceAll("```json", "").replaceAll("```", "").trim();
    }

    private String md5(String text) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(text.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return text.substring(0, Math.min(64, text.length())); }
    }

    private IntentResult getCachedIntent(String queryHash) {
        try {
            Map<String, Object> row = jdbc.queryForMap(
                "SELECT recognized_agent, intent_type, confidence, reasoning, method " +
                "FROM intent_recognition_cache WHERE query_hash=? " +
                "AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)",
                queryHash
            );
            return new IntentResult(
                String.valueOf(row.get("recognized_agent")),
                String.valueOf(row.get("intent_type")),
                ((Number) row.get("confidence")).doubleValue(),
                false, String.valueOf(row.get("reasoning")),
                "cached"
            );
        } catch (Exception e) { return null; }
    }

    private void updateCacheHit(String queryHash) {
        jdbc.update("UPDATE intent_recognition_cache SET hit_count=hit_count+1 WHERE query_hash=?", queryHash);
    }

    private void saveIntentCache(String queryHash, String query, IntentResult result) {
        try {
            jdbc.update(
                "INSERT IGNORE INTO intent_recognition_cache" +
                "(query_hash, raw_query, recognized_agent, intent_type, confidence, reasoning, method) " +
                "VALUES(?,?,?,?,?,?,?)",
                queryHash, query, result.agentId, result.intentType,
                result.confidence, result.reasoning, result.method
            );
        } catch (Exception ignored) {}
    }

    private void saveDecompositionLog(String requestId, String query,
                                       List<DecomposedTask> tasks, String method,
                                       String reasoning, int latencyMs) {
        try {
            jdbc.update(
                "INSERT INTO task_decomposition_log(request_id, user_query, decomposed_tasks, " +
                "task_count, llm_reasoning, decompose_method, latency_ms) VALUES(?,?,?,?,?,?,?)",
                requestId, query, mapper.writeValueAsString(tasks),
                tasks.size(), reasoning, method, latencyMs
            );
        } catch (Exception ignored) {}
    }

    // ── 数据结构 ─────────────────────────────────────────────
    public static class IntentResult {
        public final String agentId, intentType, reasoning, method;
        public final double confidence;
        public final boolean isMultiAgent;
        public IntentResult(String agentId, String intentType, double confidence,
                             boolean isMultiAgent, String reasoning, String method) {
            this.agentId = agentId; this.intentType = intentType;
            this.confidence = confidence; this.isMultiAgent = isMultiAgent;
            this.reasoning = reasoning; this.method = method;
        }
    }

    public static class DecomposedTask {
        public final int seq;
        public final String agentId, taskDesc, taskType;
        public final Integer dependsOnSeq;
        public DecomposedTask(int seq, String agentId, String taskDesc,
                               Integer dependsOnSeq, String taskType) {
            this.seq = seq; this.agentId = agentId; this.taskDesc = taskDesc;
            this.dependsOnSeq = dependsOnSeq; this.taskType = taskType;
        }
    }
}
