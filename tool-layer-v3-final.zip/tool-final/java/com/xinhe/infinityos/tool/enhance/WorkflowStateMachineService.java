// ============================================================
// WorkflowStateMachineService.java  (v3.1·修复遗漏2+3)
// 修复遗漏2：runWorkflow()内部调 executeReadyTasks() 驱动任务执行
// 修复遗漏3：JdbcTemplate 声明移至类顶部字段区
// ============================================================
package com.xinhe.infinityos.tool.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.*;
import java.util.concurrent.*;

@Service
public class WorkflowStateMachineService {

    // ── 修复遗漏3：所有字段声明统一在类顶部 ─────────────────
    @Autowired private JdbcTemplate jdbc;                        // ← 移至顶部
    @Autowired private ObjectMapper mapper;
    @Autowired private SynthesisAndReflectionService synthesisService;

    // 修复遗漏2：需要调 ToolOrchestrator.executeReadyTasks()
    // 用 @Lazy 避免循环依赖（ToolOrchestrator → WorkflowStateMachineService → ToolOrchestrator）
    @Autowired @Lazy
    private com.xinhe.infinityos.tool.orchestrator.ToolOrchestrator toolOrchestrator;

    private final ExecutorService executor = Executors.newCachedThreadPool();

    private static final Map<String, String> AGENT_LABELS = Map.ofEntries(
        Map.entry("aio_commander","总指挥调度"), Map.entry("butterfly","蝴蝶效应检测"),
        Map.entry("omakase","推单计算"), Map.entry("retail_store","零售门店定位"),
        Map.entry("distributor","经销商分析"), Map.entry("uber_incentive","激励补货"),
        Map.entry("shelf_recognition","货架识别"), Map.entry("inventory_report","库存上报"),
        Map.entry("a_calibration","A值校准"), Map.entry("price_tag","价签识别"),
        Map.entry("brand_advisor","品牌分析"), Map.entry("prism","精准选点")
    );

    // ── 启动工作流 ───────────────────────────────────────────
    public void startWorkflow(String requestId, List<Map<String, Object>> tasks,
                               String userQuery, SseEmitter emitter) {
        if (emitter != null) synthesisService.registerSseEmitter(requestId, emitter);
        WorkflowState state = new WorkflowState(requestId, tasks, userQuery);
        saveWorkflowState(state, "running");
        executor.submit(() -> runWorkflow(state));
    }

    // ── 工作流主循环 ─────────────────────────────────────────
    private void runWorkflow(WorkflowState state) {
        try {
            int totalSteps = state.tasks.size();
            int completedSteps = 0;

            for (Map<String, Object> task : state.tasks) {
                String taskId  = String.valueOf(task.get("task_id"));
                String agentId = getAgentIdForTask(taskId);
                String label   = AGENT_LABELS.getOrDefault(agentId, agentId);

                // 条件分支：是否跳过此任务
                if (shouldSkipTask(state, taskId, agentId)) {
                    completedSteps++;
                    pushStepEnd(state.requestId, agentId, label,
                        completedSteps, totalSteps, 0, "已跳过", "skipped");
                    continue;
                }

                // #7 步骤开始推送SSE
                pushStepStart(state.requestId, agentId, label, completedSteps + 1, totalSteps);
                updateCheckpoint(state.requestId, "STEP_" + (completedSteps + 1), taskId);

                long startMs = System.currentTimeMillis();

                // ── 修复遗漏2：触发任务实际执行 ──────────────
                // v3错误：只等待任务完成，没有人执行任务
                // v3.1修复：先触发 ToolOrchestrator 执行就绪任务，再等待完成
                toolOrchestrator.executeReadyTasks(state.requestId);

                // 等待此具体任务完成（轮询数据库，最多60秒）
                Map<String, Object> taskResult = waitForTaskCompletion(taskId, 60);
                int duration = (int)(System.currentTimeMillis() - startMs);
                completedSteps++;

                String outputPreview = extractOutputPreview(taskResult);
                String status = "completed".equals(taskResult.get("status")) ? "success" : "failed";

                // #7 步骤完成推送SSE
                pushStepEnd(state.requestId, agentId, label,
                    completedSteps, totalSteps, duration, outputPreview, status);

                // 条件分支：根据输出决定后续路径
                applyBranchDecision(state, agentId, taskResult);
                updateWorkflowProgress(state.requestId, completedSteps, totalSteps);
            }

            saveWorkflowState(state, "completed");

        } catch (Exception e) {
            saveWorkflowState(state, "failed");
            synthesisService.pushSseEvent(state.requestId, "error",
                null, null, 0, "工作流执行出错: " + e.getMessage(), "failed");
        }
    }

    // ── 条件分支判断 ─────────────────────────────────────────
    private boolean shouldSkipTask(WorkflowState state, String taskId, String agentId) {
        try {
            String dependsOn = jdbc.queryForObject(
                "SELECT depends_on_task FROM agent_task_queue WHERE task_id=?",
                String.class, taskId
            );
            if (dependsOn == null || dependsOn.isBlank()) return false;

            Map<String, Object> prevResult = getPrevTaskOutput(dependsOn);
            if (prevResult == null) return false;

            // 前置任务无异常时跳过推单和激励
            if (("omakase".equals(agentId) || "uber_incentive".equals(agentId))
                && Boolean.FALSE.equals(prevResult.get("anomaly_detected"))) {
                recordBranchDecision(state, agentId, "no_anomaly", "skip");
                return true;
            }
            // 价格合规时跳过二批商追踪
            if ("sub_distributor".equals(agentId)
                && Boolean.TRUE.equals(prevResult.get("is_compliant"))) {
                recordBranchDecision(state, agentId, "price_compliant", "skip");
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private void applyBranchDecision(WorkflowState state, String agentId,
                                      Map<String, Object> taskResult) {
        if ("retail_store".equals(agentId) && "critical".equals(taskResult.get("water_level"))) {
            recordBranchDecision(state, "butterfly", "critical_inventory", "add_step");
        }
    }

    // ── SSE进度事件 ──────────────────────────────────────────
    private void pushStepStart(String requestId, String agentId, String label, int cur, int total) {
        synthesisService.pushSseEvent(requestId, "task_start",
            agentId, label + " (" + cur + "/" + total + ")", 0, "执行中...", "running");
    }

    private void pushStepEnd(String requestId, String agentId, String label,
                              int cur, int total, int ms, String preview, String status) {
        synthesisService.pushSseEvent(requestId, "task_end",
            agentId, label + " (" + cur + "/" + total + ")", ms, preview, status);
    }

    // ── 进程重启恢复 ─────────────────────────────────────────
    public void resumeInterruptedWorkflows() {
        List<Map<String, Object>> interrupted = jdbc.queryForList(
            "SELECT workflow_id FROM workflow_states WHERE status='running' AND can_resume=1 " +
            "AND updated_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
        );
        for (Map<String, Object> wf : interrupted) {
            jdbc.update("UPDATE workflow_states SET status='suspended' WHERE workflow_id=?",
                wf.get("workflow_id"));
        }
    }

    // ── SSE Emitter创建 ──────────────────────────────────────
    public SseEmitter createSseEmitter(String requestId) {
        SseEmitter emitter = new SseEmitter(300_000L);
        synthesisService.registerSseEmitter(requestId, emitter);

        // 推送历史未发送事件（前端重连场景）
        executor.submit(() -> {
            try {
                List<Map<String, Object>> pending = jdbc.queryForList(
                    "SELECT * FROM sse_progress_events WHERE request_id=? AND is_sent=0 ORDER BY created_at ASC",
                    requestId
                );
                for (Map<String, Object> event : pending) {
                    emitter.send(SseEmitter.event()
                        .name(String.valueOf(event.get("event_type")))
                        .data(mapper.writeValueAsString(event)));
                    jdbc.update("UPDATE sse_progress_events SET is_sent=1 WHERE id=?", event.get("id"));
                }
            } catch (Exception ignored) {}
        });
        return emitter;
    }

    // ── 工具方法 ─────────────────────────────────────────────
    private String getAgentIdForTask(String taskId) {
        try { return jdbc.queryForObject("SELECT agent_id FROM agent_task_queue WHERE task_id=?", String.class, taskId); }
        catch (Exception e) { return "aio_commander"; }
    }

    private Map<String, Object> waitForTaskCompletion(String taskId, int timeoutSec) {
        long deadline = System.currentTimeMillis() + timeoutSec * 1000L;
        while (System.currentTimeMillis() < deadline) {
            try {
                Map<String, Object> task = jdbc.queryForMap(
                    "SELECT status, output_data FROM agent_task_queue WHERE task_id=?", taskId);
                String status = String.valueOf(task.get("status"));
                if ("completed".equals(status) || "failed".equals(status)) return task;
                Thread.sleep(500);
            } catch (Exception e) { return Map.of("status","failed"); }
        }
        return Map.of("status","timeout");
    }

    private String extractOutputPreview(Map<String, Object> result) {
        Object out = result.get("output_data");
        if (out == null) return "无输出";
        String s = out instanceof String ? (String)out : String.valueOf(out);
        return s.length() > 100 ? s.substring(0, 100) + "..." : s;
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> getPrevTaskOutput(String taskId) {
        try {
            String json = jdbc.queryForObject(
                "SELECT output_data FROM agent_task_queue WHERE task_id=? AND status='completed'",
                String.class, taskId);
            return json != null ? mapper.readValue(json, Map.class) : null;
        } catch (Exception e) { return null; }
    }

    private void saveWorkflowState(WorkflowState state, String status) {
        try {
            jdbc.update(
                "INSERT INTO workflow_states(workflow_id,current_state,state_data,total_steps,status) " +
                "VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE current_state=VALUES(current_state)," +
                "status=VALUES(status),updated_at=NOW()",
                state.requestId, status.toUpperCase(),
                mapper.writeValueAsString(Map.of("userQuery", state.userQuery)),
                state.tasks.size(), status
            );
        } catch (Exception ignored) {}
    }

    private void updateCheckpoint(String requestId, String stateStr, String taskId) {
        jdbc.update("UPDATE workflow_states SET current_state=?,last_checkpoint=NOW() WHERE workflow_id=?",
            stateStr, requestId);
    }

    private void updateWorkflowProgress(String requestId, int completed, int total) {
        jdbc.update("UPDATE workflow_states SET completed_steps=?,total_steps=? WHERE workflow_id=?",
            completed, total, requestId);
    }

    private void recordBranchDecision(WorkflowState state, String agentId,
                                       String condition, String decision) {
        state.branchDecisions.add(Map.of("agent", agentId, "condition", condition, "decision", decision));
        try {
            jdbc.update("UPDATE workflow_states SET branch_decisions=? WHERE workflow_id=?",
                mapper.writeValueAsString(state.branchDecisions), state.requestId);
        } catch (Exception ignored) {}
    }

    private static class WorkflowState {
        final String requestId, userQuery;
        final List<Map<String, Object>> tasks;
        final List<Map<String, Object>> branchDecisions = new ArrayList<>();
        WorkflowState(String r, List<Map<String,Object>> t, String q) { requestId=r; tasks=t; userQuery=q; }
    }
}
