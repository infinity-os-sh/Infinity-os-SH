// ============================================================
// PerceptionService.java
// 层面一：感知层·统一接收所有触发源的请求
// 用户主动 / SFA定时 / Agent间互触发 / Webhook
// ============================================================
package com.xinhe.infinityos.tool.layer1;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PerceptionService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // ══ 入站接口：三类触发源 ══════════════════════════════════

    /**
     * 触发源1：用户主动提问/指令
     * 来自INFINITY OS前端或企微对话
     */
    public String receiveUserRequest(String userId, String sessionId,
                                      String input, String priority) {
        String requestId = buildRequestId("USR");

        // 解析输入：提取上下文线索
        String contextHint = extractContextHint(input);
        Map<String, Object> structured = parseUserInput(input);

        jdbc.update(
            "INSERT INTO trigger_requests(request_id, trigger_source, trigger_type, " +
            "user_id, session_id, raw_input, structured_input, context_hint, priority) " +
            "VALUES(?,?,?,?,?,?,?,?,?)",
            requestId, "user",
            detectTriggerType(input),
            userId, sessionId, input,
            safeJson(structured), contextHint,
            priority != null ? priority : "normal"
        );

        return requestId;
    }

    /**
     * 触发源2：SFA定时上报
     * 由Scheduler调用，数据来自SFA系统
     */
    public String receiveSfaReport(String scheduleId, String reportType,
                                    Map<String, Object> reportData) {
        String requestId = buildRequestId("SFA");

        // 查找对应的目标Agent
        String targetAgent = jdbc.queryForObject(
            "SELECT target_agent FROM sfa_report_schedules WHERE schedule_id=?",
            String.class, scheduleId
        );

        jdbc.update(
            "INSERT INTO trigger_requests(request_id, trigger_source, trigger_type, " +
            "source_agent, raw_input, structured_input, context_hint, priority) " +
            "VALUES(?,?,?,?,?,?,?,?)",
            requestId, "sfa", "report",
            "sfa_system",
            "SFA自动上报·" + reportType + "·" + new java.util.Date(),
            safeJson(reportData),
            "sfa:" + reportType + ":" + scheduleId,
            "normal"
        );

        // 更新调度记录
        jdbc.update(
            "UPDATE sfa_report_schedules SET last_triggered_at=NOW() WHERE schedule_id=?",
            scheduleId
        );

        return requestId;
    }

    /**
     * 触发源3：Agent间互触发
     * 一个Agent完成后触发下一个Agent
     */
    public String receiveAgentTrigger(String sourceAgent, String targetAgent,
                                       String triggerReason, Map<String, Object> triggerData,
                                       String sourceRequestId) {
        String requestId = buildRequestId("AGT");

        jdbc.update(
            "INSERT INTO trigger_requests(request_id, trigger_source, trigger_type, " +
            "source_agent, raw_input, structured_input, context_hint, priority) " +
            "VALUES(?,?,?,?,?,?,?,?)",
            requestId, "agent", "alert",
            sourceAgent,
            triggerReason,
            safeJson(triggerData),
            "agent_cascade:" + sourceAgent + "→" + targetAgent,
            "high"
        );

        // 记录级联关系
        jdbc.update(
            "INSERT INTO cascade_triggers(source_request_id, source_agent, " +
            "triggered_request_id, triggered_agent, trigger_reason, trigger_data, " +
            "status, triggered_at) VALUES(?,?,?,?,?,?,?,NOW())",
            sourceRequestId, sourceAgent, requestId, targetAgent,
            triggerReason, safeJson(triggerData), "triggered"
        );

        return requestId;
    }

    /**
     * 触发源4：外部Webhook推送（SAP/企微/POS）
     */
    public String receiveWebhook(String endpointPath, Map<String, Object> payload) {
        String requestId = buildRequestId("WHK");

        // 验证endpoint
        Map<String, Object> endpoint;
        try {
            endpoint = jdbc.queryForMap(
                "SELECT * FROM webhook_endpoints WHERE endpoint_path=? AND is_active=1",
                endpointPath
            );
        } catch (Exception e) {
            throw new IllegalArgumentException("未知Webhook端点: " + endpointPath);
        }

        String sourceSystem = String.valueOf(endpoint.get("source_system"));

        jdbc.update(
            "INSERT INTO trigger_requests(request_id, trigger_source, trigger_type, " +
            "source_agent, raw_input, structured_input, context_hint, priority) " +
            "VALUES(?,?,?,?,?,?,?,?)",
            requestId, "webhook", "report",
            sourceSystem,
            sourceSystem + "·Webhook推送·" + endpointPath,
            safeJson(payload),
            "webhook:" + endpointPath,
            "high"
        );

        // 更新webhook统计
        jdbc.update(
            "UPDATE webhook_endpoints SET received_count=received_count+1, " +
            "last_received_at=NOW() WHERE endpoint_path=?", endpointPath
        );

        return requestId;
    }

    // ══ 定时任务：触发SFA定时上报 ════════════════════════════

    @Scheduled(cron = "0 0 8 * * *")
    public void triggerDailyInventoryReport() {
        triggerSchedule("SCH_INV_DAILY", "inventory");
    }

    @Scheduled(cron = "0 0 18 * * *")
    public void triggerDailyVisitReport() {
        triggerSchedule("SCH_VISIT_DAILY", "visit");
    }

    @Scheduled(cron = "0 0 9 * * *")
    public void triggerDailyOrderReport() {
        triggerSchedule("SCH_ORDER_DAILY", "order");
    }

    @Scheduled(cron = "0 0 10 * * *")
    public void triggerDailyPhotoReport() {
        triggerSchedule("SCH_PHOTO_DAILY", "photo");
    }

    @Scheduled(cron = "0 0 */4 * * *")
    public void triggerButterflyCheck() {
        triggerSchedule("SCH_BUTTERFLY", "inventory");
    }

    @Scheduled(cron = "0 0 0 * * MON")
    public void triggerWeeklyCalibration() {
        triggerSchedule("SCH_CALIBRATE", "order");
    }

    private void triggerSchedule(String scheduleId, String reportType) {
        // 实际项目从SFA API拉取数据，此处构造空payload
        receiveSfaReport(scheduleId, reportType, Map.of(
            "scheduleId", scheduleId,
            "reportType", reportType,
            "triggeredAt", System.currentTimeMillis()
        ));
    }

    // ══ 工具方法 ══════════════════════════════════════════════

    private String buildRequestId(String prefix) {
        return prefix + "_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();
    }

    private String detectTriggerType(String input) {
        if (input == null) return "query";
        String lower = input.toLowerCase();
        if (lower.contains("推单") || lower.contains("下单") || lower.contains("补货")) return "command";
        if (lower.contains("警报") || lower.contains("预警") || lower.contains("异常")) return "alert";
        return "query";
    }

    private String extractContextHint(String input) {
        if (input == null) return null;
        StringBuilder hint = new StringBuilder();
        // 提取城市名
        String[] cities = {"上海","北京","成都","广州","深圳","杭州","武汉","西安"};
        for (String city : cities) {
            if (input.contains(city)) { hint.append(city).append("·"); break; }
        }
        // 提取门店等级
        String[] tiers = {"S+","S级","A级","B级","KA","大卖场"};
        for (String tier : tiers) {
            if (input.contains(tier)) { hint.append(tier).append("·"); break; }
        }
        // 提取业务关键词
        String[] keywords = {"库存","补货","货架","价格","经销商","动销","铺货"};
        for (String kw : keywords) {
            if (input.contains(kw)) { hint.append(kw); break; }
        }
        return hint.length() > 0 ? hint.toString() : null;
    }

    private Map<String, Object> parseUserInput(String input) {
        // 实际项目可以用NLP或Claude API解析
        // 此处返回简单结构
        return Map.of(
            "raw", input,
            "parsed_at", System.currentTimeMillis()
        );
    }

    private String safeJson(Object obj) {
        try { return mapper.writeValueAsString(obj); }
        catch (Exception e) { return "{}"; }
    }

    // ══ 状态查询 ══════════════════════════════════════════════

    public Map<String, Object> getRequestStatus(String requestId) {
        try {
            return jdbc.queryForMap(
                "SELECT * FROM trigger_requests WHERE request_id=?", requestId
            );
        } catch (Exception e) {
            return null;
        }
    }

    public void updateRequestStatus(String requestId, String status) {
        jdbc.update(
            "UPDATE trigger_requests SET status=? WHERE request_id=?", status, requestId
        );
    }
}
