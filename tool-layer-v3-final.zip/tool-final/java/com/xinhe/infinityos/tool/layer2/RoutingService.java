// ============================================================
// RoutingService.java  (v3·修复版)
// #1 LLM意图识别：关键词未命中→LLM兜底（双轨制）
// #2 LLM任务拆解：复杂问题动态拆解子任务
// ============================================================
package com.xinhe.infinityos.tool.layer2;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xinhe.infinityos.tool.enhance.IntentAndPlannerService;
import com.xinhe.infinityos.tool.enhance.IntentAndPlannerService.IntentResult;
import com.xinhe.infinityos.tool.enhance.IntentAndPlannerService.DecomposedTask;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RoutingService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;
    @Autowired private IntentAndPlannerService intentPlanner;  // ← v3新增

    public List<String> route(String requestId) {
        Map<String, Object> request;
        try {
            request = jdbc.queryForMap("SELECT * FROM trigger_requests WHERE request_id=?", requestId);
        } catch (Exception e) {
            throw new IllegalStateException("请求不存在: " + requestId);
        }

        String rawInput    = String.valueOf(request.get("raw_input"));
        String triggerType = String.valueOf(request.get("trigger_type"));
        String priority    = String.valueOf(request.get("priority"));
        String sessionId   = String.valueOf(request.getOrDefault("session_id", ""));

        // ── Step1：关键词规则匹配（v2原有）──────────────────
        Map<String, Object> matchedRule = matchRuleByKeyword(rawInput, triggerType, priority);
        boolean isDefaultRoute = "DEFAULT".equals(matchedRule.get("rule_id"));

        // ── Step2：#1 关键词未命中→LLM意图识别 ──────────────
        IntentResult intent = null;
        if (isDefaultRoute && "user".equals(request.get("trigger_source"))) {
            List<Map<String, String>> history = getSessionHistory(sessionId, 4);
            intent = intentPlanner.recognizeIntent(rawInput, history);
            if (intent.confidence > 0.6) {
                matchedRule = buildRuleFromIntent(intent);
                isDefaultRoute = false;
            }
        }

        // ── Step3：记录路由决策 ──────────────────────────────
        recordRoutingDecision(requestId, matchedRule, intent);

        // ── Step4：#2 判断是否需要LLM任务拆解 ──────────────
        boolean needLlmDecompose = isDefaultRoute
            || (intent != null && intent.isMultiAgent);

        List<String> taskIds = new ArrayList<>();

        if (needLlmDecompose && "user".equals(request.get("trigger_source"))) {
            List<Map<String, String>> history = getSessionHistory(sessionId, 4);
            List<DecomposedTask> decomposed = intentPlanner.decomposeRequest(requestId, rawInput, history);
            Map<Integer, String> seqToTaskId = new LinkedHashMap<>();
            for (DecomposedTask dt : decomposed) {
                String dependsOnId = dt.dependsOnSeq != null ? seqToTaskId.get(dt.dependsOnSeq) : null;
                Map<String, Object> input = buildTaskInput(request, dependsOnId);
                input.put("task_desc", dt.taskDesc);
                String taskId = createTask(requestId, dt.agentId, dt.taskType, dt.seq, dependsOnId, input);
                seqToTaskId.put(dt.seq, taskId);
                taskIds.add(taskId);
            }
        } else {
            // 静态规则创建任务（v2原有）
            String executionMode   = String.valueOf(matchedRule.get("execution_mode"));
            String primaryAgent    = String.valueOf(matchedRule.get("primary_agent"));
            List<String> secondary = parseJsonList(matchedRule.get("secondary_agents"));
            List<Map<String, Object>> steps = parseJsonMapList(matchedRule.get("pipeline_steps"));
            taskIds = createTasksByMode(requestId, executionMode, primaryAgent, secondary, steps, request);
        }

        jdbc.update("UPDATE trigger_requests SET status='routing', routed_at=NOW() WHERE request_id=?", requestId);
        if (!isDefaultRoute && matchedRule.get("rule_id") != null)
            jdbc.update("UPDATE routing_rules SET hit_count=hit_count+1 WHERE rule_id=?", matchedRule.get("rule_id"));

        return taskIds;
    }

    private Map<String, Object> matchRuleByKeyword(String input, String triggerType, String priority) {
        List<Map<String, Object>> rules = jdbc.queryForList("SELECT * FROM routing_rules WHERE is_active=1 ORDER BY confidence DESC");
        for (Map<String, Object> rule : rules) {
            String rt = (String) rule.get("trigger_type");
            if (rt != null && !rt.equals(triggerType)) continue;
            List<String> kws = parseJsonStringList(rule.get("keyword_patterns"));
            if (!kws.isEmpty()) {
                String lower = input != null ? input.toLowerCase() : "";
                if (kws.stream().noneMatch(kw -> lower.contains(kw.toLowerCase()))) continue;
            }
            return rule;
        }
        return Map.of("rule_id","DEFAULT","execution_mode","single","primary_agent","aio_commander",
            "secondary_agents","[]","pipeline_steps","[]","confidence",0.5);
    }

    private Map<String, Object> buildRuleFromIntent(IntentResult intent) {
        return new LinkedHashMap<>(Map.of(
            "rule_id", "LLM_" + intent.agentId,
            "execution_mode", intent.isMultiAgent ? "parallel" : "single",
            "primary_agent", intent.agentId,
            "secondary_agents", "[]", "pipeline_steps", "[]",
            "confidence", intent.confidence,
            "description", "LLM识别: " + intent.reasoning
        ));
    }

    private List<String> createTasksByMode(String requestId, String mode, String primary,
                                            List<String> secondary, List<Map<String,Object>> steps,
                                            Map<String,Object> request) {
        List<String> ids = new ArrayList<>();
        switch (mode) {
            case "single" -> ids.add(createTask(requestId, primary, "analyze", 0, null, buildTaskInput(request, null)));
            case "parallel" -> {
                ids.add(createTask(requestId, primary, "analyze", 0, null, buildTaskInput(request, null)));
                for (String a : secondary) ids.add(createTask(requestId, a, "analyze", 0, null, buildTaskInput(request, null)));
            }
            case "sequential" -> {
                String prev = null;
                String first = createTask(requestId, primary, "analyze", 1, null, buildTaskInput(request, null));
                ids.add(first); prev = first;
                int seq = 2;
                for (String a : secondary) { String id = createTask(requestId, a, "execute", seq++, prev, buildTaskInput(request, prev)); ids.add(id); prev = id; }
            }
            case "pipeline" -> {
                if (!steps.isEmpty()) {
                    String prev = null; int i = 1;
                    for (Map<String,Object> s : steps) {
                        Map<String,Object> input = buildTaskInput(request, prev);
                        input.put("pipeline_step", i);
                        String id = createTask(requestId, String.valueOf(s.get("agent_id")),
                            String.valueOf(s.getOrDefault("task_type","execute")), i++, prev, input);
                        ids.add(id); prev = id;
                    }
                } else {
                    ids.addAll(createTasksByMode(requestId, "sequential", primary, secondary, Collections.emptyList(), request));
                }
            }
            default -> ids.add(createTask(requestId, "aio_commander", "analyze", 0, null, buildTaskInput(request, null)));
        }
        return ids;
    }

    private String createTask(String requestId, String agentId, String taskType,
                               int seq, String dependsOn, Map<String,Object> input) {
        String taskId = "TASK_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0,6).toUpperCase();
        try {
            jdbc.update("INSERT INTO agent_task_queue(task_id,request_id,agent_id,task_type,sequence_order,depends_on_task,input_data,timeout_at) VALUES(?,?,?,?,?,?,?,?)",
                taskId, requestId, agentId, taskType, seq, dependsOn,
                mapper.writeValueAsString(input), new java.sql.Timestamp(System.currentTimeMillis() + 300_000L));
        } catch (Exception e) { throw new RuntimeException("创建任务失败", e); }
        return taskId;
    }

    private void recordRoutingDecision(String requestId, Map<String,Object> rule, IntentResult intent) {
        try {
            String reason = intent != null ? "LLM[" + intent.method + "]: " + intent.reasoning : "规则: " + rule.getOrDefault("description","默认路由");
            jdbc.update("INSERT INTO routing_decisions(request_id,matched_rule_id,execution_mode,primary_agent,secondary_agents,routing_reason,confidence) VALUES(?,?,?,?,?,?,?)",
                requestId, rule.get("rule_id"), rule.get("execution_mode"), rule.get("primary_agent"),
                mapper.writeValueAsString(rule.getOrDefault("secondary_agents","[]")), reason, rule.get("confidence"));
        } catch (Exception ignored) {}
    }

    public List<Map<String, Object>> getReadyTasks(String requestId) {
        return jdbc.queryForList("SELECT t.* FROM agent_task_queue t WHERE t.request_id=? AND t.status='pending' AND (t.depends_on_task IS NULL OR EXISTS(SELECT 1 FROM agent_task_queue p WHERE p.task_id=t.depends_on_task AND p.status='completed'))", requestId);
    }

    public void markTaskRunning(String taskId) {
        jdbc.update("UPDATE agent_task_queue SET status='running',started_at=NOW() WHERE task_id=?", taskId);
    }

    public void markTaskCompleted(String taskId, Map<String,Object> outputData) {
        try { jdbc.update("UPDATE agent_task_queue SET status='completed',completed_at=NOW(),output_data=? WHERE task_id=?", mapper.writeValueAsString(outputData), taskId); }
        catch (Exception e) { throw new RuntimeException("更新任务失败", e); }
    }

    public void markTaskFailed(String taskId, String error) {
        jdbc.update("UPDATE agent_task_queue SET status='failed',completed_at=NOW(),error_message=? WHERE task_id=?", error, taskId);
    }

    private List<Map<String,String>> getSessionHistory(String sessionId, int limit) {
        if (sessionId == null || sessionId.isBlank() || "null".equals(sessionId)) return Collections.emptyList();
        try {
            return jdbc.queryForList("SELECT role, content FROM conv_turns WHERE session_id=? ORDER BY turn_index DESC LIMIT ?", sessionId, limit)
                .stream().map(r -> Map.of("role", String.valueOf(r.get("role")), "content", String.valueOf(r.get("content")))).toList();
        } catch (Exception e) { return Collections.emptyList(); }
    }

    private Map<String,Object> buildTaskInput(Map<String,Object> request, String prevId) {
        Map<String,Object> input = new LinkedHashMap<>();
        input.put("request_id", request.get("request_id")); input.put("raw_input", request.get("raw_input"));
        input.put("trigger_source", request.get("trigger_source")); input.put("context_hint", request.get("context_hint"));
        input.put("user_id", request.get("user_id")); input.put("session_id", request.get("session_id"));
        if (prevId != null) { try { input.put("prev_task_output", jdbc.queryForObject("SELECT output_data FROM agent_task_queue WHERE task_id=?", String.class, prevId)); } catch (Exception ignored) {} }
        return input;
    }

    @SuppressWarnings("unchecked")
    private List<String> parseJsonList(Object json) { if (json == null) return Collections.emptyList(); try { return mapper.readValue(json.toString(), List.class); } catch (Exception e) { return Collections.emptyList(); } }
    private List<String> parseJsonStringList(Object json) { return parseJsonList(json); }
    @SuppressWarnings("unchecked")
    private List<Map<String,Object>> parseJsonMapList(Object json) { if (json == null) return Collections.emptyList(); try { return mapper.readValue(json.toString(), List.class); } catch (Exception e) { return Collections.emptyList(); } }
}
