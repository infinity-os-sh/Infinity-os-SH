// ============================================================
// ToolOrchestrator.java  (v3.1·修复遗漏3)
// 修复：JdbcTemplate @Autowired 声明移至类顶部字段区
//       去除类底部的错误声明位置
// ============================================================
package com.xinhe.infinityos.tool.orchestrator;

import com.xinhe.infinityos.tool.enhance.SynthesisAndReflectionService;
import com.xinhe.infinityos.tool.enhance.WorkflowStateMachineService;
import com.xinhe.infinityos.tool.layer1.PerceptionService;
import com.xinhe.infinityos.tool.layer2.RoutingService;
import com.xinhe.infinityos.tool.layer3.ToolExecutionService;
import com.xinhe.infinityos.tool.layer3.ToolResult;
import com.xinhe.infinityos.tool.layer4.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.*;

@Service
public class ToolOrchestrator {

    // ── 修复遗漏3：所有依赖统一在类顶部声明 ─────────────────
    @Autowired private JdbcTemplate jdbc;                        // ← 移至顶部
    @Autowired private PerceptionService    perception;
    @Autowired private RoutingService       routing;
    @Autowired private ToolExecutionService execution;
    @Autowired private FeedbackService      feedback;
    @Autowired private SynthesisAndReflectionService synthesisService;
    @Autowired private WorkflowStateMachineService   workflowService;

    // ── 主入口（不带SSE）────────────────────────────────────
    public String handleUserRequest(String userId, String sessionId, String input) {
        return handleUserRequest(userId, sessionId, input, "normal", null);
    }

    // ── 主入口（带SSE）──────────────────────────────────────
    public String handleUserRequest(String userId, String sessionId,
                                     String input, String priority, SseEmitter emitter) {
        String requestId = perception.receiveUserRequest(userId, sessionId, input, priority);
        perception.updateRequestStatus(requestId, "routing");

        List<String> taskIds = routing.route(requestId);
        perception.updateRequestStatus(requestId, "executing");

        String executionMode = getExecutionMode(requestId);
        boolean isComplex = isPipelineOrSequential(executionMode, taskIds);

        if (isComplex && emitter != null) {
            List<Map<String, Object>> tasks = getTaskDetails(taskIds);
            workflowService.startWorkflow(requestId, tasks, input, emitter);
        } else {
            if (emitter != null) synthesisService.registerSseEmitter(requestId, emitter);
            executeReadyTasks(requestId);
        }

        return requestId;
    }

    // ── SSE端点 ──────────────────────────────────────────────
    public SseEmitter createProgressStream(String requestId) {
        return workflowService.createSseEmitter(requestId);
    }

    // ── 同步执行就绪任务（#7进度推送已集成）────────────────
    public void executeReadyTasks(String requestId) {
        List<Map<String, Object>> readyTasks = routing.getReadyTasks(requestId);
        int totalTasks     = getTotalTaskCount(requestId);
        int completedCount = getCompletedTaskCount(requestId);

        for (Map<String, Object> task : readyTasks) {
            String taskId   = String.valueOf(task.get("task_id"));
            String agentId  = String.valueOf(task.get("agent_id"));
            String taskType = String.valueOf(task.get("task_type"));

            routing.markTaskRunning(taskId);
            completedCount++;

            synthesisService.pushSseEvent(requestId, "task_start",
                agentId, getAgentLabel(agentId) + " (" + completedCount + "/" + totalTasks + ")",
                0, "执行中...", "running");

            String toolId = resolveToolId(agentId, taskType, task);
            long startMs  = System.currentTimeMillis();

            try {
                Map<String, Object> inputData = parseInputData(task);
                ToolResult result = execution.executeTool(taskId, requestId, agentId, toolId, inputData);

                if (result.isOk()) {
                    routing.markTaskCompleted(taskId, result.getData());
                    feedback.onTaskCompleted(requestId, taskId, agentId, result.getData(), true);
                    synthesisService.pushSseEvent(requestId, "task_end",
                        agentId, getAgentLabel(agentId) + " (" + completedCount + "/" + totalTasks + ")",
                        (int)(System.currentTimeMillis() - startMs),
                        buildOutputPreview(result.getData()), "success");

                } else if (result.isPendingApproval()) {
                    feedback.createApprovalRequest(requestId, taskId, agentId,
                        toolId, agentId + " 执行 " + toolId, parseInputData(task),
                        resolveRiskLevel(result.getAuthLevel()), result.getAuthLevel(),
                        resolveApprover(result.getAuthLevel()), "需要审批才能执行 " + toolId);
                    synthesisService.pushSseEvent(requestId, "task_end",
                        agentId, getAgentLabel(agentId), 0, "等待审批...", "waiting");

                } else {
                    routing.markTaskFailed(taskId, result.getErrorMessage());
                    feedback.onTaskCompleted(requestId, taskId, agentId,
                        Map.of("error", result.getErrorMessage()), false);
                    synthesisService.pushSseEvent(requestId, "task_end",
                        agentId, getAgentLabel(agentId),
                        (int)(System.currentTimeMillis() - startMs),
                        result.getErrorMessage(), "failed");
                }
            } catch (Exception e) {
                routing.markTaskFailed(taskId, e.getMessage());
                feedback.onTaskCompleted(requestId, taskId, agentId,
                    Map.of("exception", e.getMessage()), false);
                synthesisService.pushSseEvent(requestId, "task_end",
                    agentId, getAgentLabel(agentId), 0, e.getMessage(), "failed");
            }
        }
    }

    // ── 工具方法 ─────────────────────────────────────────────
    private String resolveToolId(String agentId, String taskType, Map<String, Object> task) {
        return switch (agentId) {
            case "retail_store"      -> "T01_STORE_INVENTORY";
            case "distributor"       -> "T02_DISTRIBUTOR_STOCK";
            case "butterfly"         -> "T01_STORE_INVENTORY";
            case "omakase"           -> "T16_CREATE_ORDER";
            case "shelf_recognition" -> "T11_SHELF_RECOGNITION";
            case "inventory_report"  -> "T17_UPDATE_INVENTORY";
            case "price_tag"         -> "T12_PRICE_TAG_OCR";
            case "uber_incentive"    -> "T19_UPDATE_CB_SCORE";
            case "a_calibration"     -> "T03_DAILY_SALES";
            case "production"        -> "T20_SYNC_SAP";
            case "sub_distributor"   -> "T05_PRICE_CHECK";
            default                  -> "T09_AI_ANALYZE";
        };
    }

    private boolean isPipelineOrSequential(String mode, List<String> taskIds) {
        return taskIds.size() >= 3 && ("pipeline".equals(mode) || "sequential".equals(mode));
    }

    private String getExecutionMode(String requestId) {
        try {
            return jdbc.queryForObject(
                "SELECT execution_mode FROM routing_decisions WHERE request_id=? ORDER BY decided_at DESC LIMIT 1",
                String.class, requestId);
        } catch (Exception e) { return "single"; }
    }

    private List<Map<String, Object>> getTaskDetails(List<String> taskIds) {
        List<Map<String, Object>> tasks = new ArrayList<>();
        for (String id : taskIds) tasks.add(Map.of("task_id", id));
        return tasks;
    }

    private int getTotalTaskCount(String requestId) {
        try { Integer r = jdbc.queryForObject("SELECT COUNT(*) FROM agent_task_queue WHERE request_id=?", Integer.class, requestId); return r != null ? r : 1; }
        catch (Exception e) { return 1; }
    }

    private int getCompletedTaskCount(String requestId) {
        try { Integer r = jdbc.queryForObject("SELECT COUNT(*) FROM agent_task_queue WHERE request_id=? AND status='completed'", Integer.class, requestId); return r != null ? r : 0; }
        catch (Exception e) { return 0; }
    }

    private static final Map<String,String> LABELS = Map.ofEntries(
        Map.entry("aio_commander","总指挥"), Map.entry("butterfly","蝴蝶效应检测"),
        Map.entry("omakase","推单计算"), Map.entry("retail_store","零售门店"),
        Map.entry("distributor","经销商分析"), Map.entry("uber_incentive","激励补货"),
        Map.entry("shelf_recognition","货架识别"), Map.entry("a_calibration","A值校准"),
        Map.entry("price_tag","价签识别"), Map.entry("brand_advisor","品牌分析"),
        Map.entry("prism","精准选点"), Map.entry("production","生产供应")
    );

    private String getAgentLabel(String agentId) { return LABELS.getOrDefault(agentId, agentId); }

    private String buildOutputPreview(Map<String, Object> data) {
        if (data == null) return "无输出";
        Object wl = data.get("water_level"); if (wl != null) return "水位:" + wl;
        Object s  = data.get("status"); if (s != null) return String.valueOf(s);
        return "完成";
    }

    private String resolveRiskLevel(int auth) { return switch(auth){case 1->"low";case 2->"medium";case 3->"high";default->"low";}; }
    private String resolveApprover(int auth)  { return switch(auth){case 1->"fast_track_approver";case 2->"manager";case 3->"director";default->"manager";}; }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseInputData(Map<String, Object> task) {
        try {
            Object d = task.get("input_data");
            if (d instanceof Map) return (Map<String,Object>) d;
            if (d != null) return new com.fasterxml.jackson.databind.ObjectMapper().readValue(d.toString(), Map.class);
        } catch (Exception ignored) {}
        return Map.of();
    }
}
