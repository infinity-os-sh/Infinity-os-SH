-- ============================================================
-- 层面三：执行层（工具调用）
-- 20个工具定义·实际调用SAP/SFA/企微/Claude API
-- 在tool-layer-v1基础上补充调用记录和重试机制
-- ============================================================

-- 工具定义注册表：所有可用工具的元数据
CREATE TABLE tool_registry (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    tool_id         VARCHAR(64) NOT NULL UNIQUE,
    tool_name       VARCHAR(128) NOT NULL,
    tool_category   ENUM('data_read','data_write','ai_inference','notification','integration') NOT NULL,
    -- 可调用此工具的Agent列表（null=所有Agent）
    allowed_agents  JSON,
    -- 工具参数schema（JSON Schema格式）
    input_schema    JSON NOT NULL,
    output_schema   JSON,
    -- 授权要求（对应auth-boundary的授权级别）
    min_auth_level  TINYINT NOT NULL DEFAULT 0,            -- 0=自主·1=快速通道·...
    is_reversible   TINYINT(1) NOT NULL DEFAULT 1,
    -- 性能基准
    avg_latency_ms  INT,
    timeout_ms      INT NOT NULL DEFAULT 10000,
    max_retries     INT NOT NULL DEFAULT 3,
    -- 限流
    rate_limit_per_minute INT,
    -- 状态
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    description     VARCHAR(512),
    INDEX idx_category (tool_category),
    INDEX idx_active (is_active)
) COMMENT='工具注册表·20个工具的元数据';

-- 注册20个核心工具
INSERT INTO tool_registry
(tool_id, tool_name, tool_category, allowed_agents, min_auth_level, is_reversible, timeout_ms, description)
VALUES
-- ── 数据读取类（无副作用·自主执行）────────────────────────
('T01_STORE_INVENTORY',    '查询门店库存',        'data_read',
 NULL, 0, 1, 5000, '从SFA/POS读取门店货架+仓库库存量'),
('T02_DISTRIBUTOR_STOCK',  '查询经销商库存',      'data_read',
 NULL, 0, 1, 5000, '从SAP/分销系统读取经销商当前库存'),
('T03_DAILY_SALES',        '查询日销售数据',      'data_read',
 NULL, 0, 1, 5000, '从POS/SAP读取门店/经销商的日销售量'),
('T04_STORE_VISITS',       '查询拜访记录',        'data_read',
 NULL, 0, 1, 5000, '从SFA读取业务员拜访记录和频次'),
('T05_PRICE_CHECK',        '查询价格数据',        'data_read',
 NULL, 0, 1, 5000, '从系统读取当前执行价格和历史价格'),
('T06_PHOTO_SHELF',        '获取货架照片',        'data_read',
 '["shelf_recognition","uber_incentive"]', 0, 1, 8000, '从SFA获取最新上传的货架照片'),
('T07_SAP_ORDER',          '查询SAP订单',         'data_read',
 NULL, 0, 1, 8000, '从SAP ECC 6.0读取经销商订单历史'),
('T08_CITY_STATS',         '查询城市汇总',        'data_read',
 NULL, 0, 1, 8000, '读取城市级别的铺货率/动销率/r值汇总'),

-- ── AI推理类（调用Claude API）──────────────────────────────
('T09_AI_ANALYZE',         'AI分析推理',          'ai_inference',
 NULL, 0, 1, 30000, '调用Claude API对数据进行分析和推理'),
('T10_AI_SUMMARIZE',       'AI摘要压缩',          'ai_inference',
 NULL, 0, 1, 15000, '调用Claude API压缩长文本·用于对话快照'),
('T11_SHELF_RECOGNITION',  '货架AI识别',          'ai_inference',
 '["shelf_recognition","uber_incentive"]', 0, 1, 20000, '调用千问VL识别货架照片'),
('T12_PRICE_TAG_OCR',      '价签OCR识别',         'ai_inference',
 '["price_tag","sub_distributor"]', 0, 1, 15000, '调用千问VL读取价签价格'),

-- ── 通知类（有副作用·需要关注auth）────────────────────────
('T13_WECHAT_PUSH',        '企微消息推送',        'notification',
 NULL, 0, 1, 5000, '通过企业微信推送通知给业务员/管理层'),
('T14_WECHAT_APPROVAL',    '企微审批请求',        'notification',
 NULL, 1, 1, 5000, '创建企业微信审批任务·带批准/拒绝按钮'),
('T15_SMS_ALERT',          '短信紧急告警',        'notification',
 '["aio_commander","butterfly"]', 2, 1, 5000, '发送短信告警·仅限critical级别'),

-- ── 数据写入类（不可逆·需要较高auth）──────────────────────
('T16_CREATE_ORDER',       '创建补货订单',        'data_write',
 '["omakase","aio_commander"]', 2, 0, 10000, '在SAP/分销系统创建经销商补货单'),
('T17_UPDATE_INVENTORY',   '更新库存记录',        'data_write',
 '["inventory_report","retail_store"]', 1, 0, 5000, 'SFA库存上报后更新系统库存记录'),
('T18_LOG_ANOMALY',        '记录异常事件',        'data_write',
 NULL, 0, 1, 5000, '将检测到的异常写入案例库·低风险写操作'),
('T19_UPDATE_CB_SCORE',    '更新CB评分',          'data_write',
 '["uber_incentive"]', 2, 0, 5000, '更新美顾/业务员的CB粘性评分·不可逆'),

-- ── 系统集成类────────────────────────────────────────────
('T20_SYNC_SAP',           'SAP数据同步',         'integration',
 '["aio_commander","production"]', 1, 1, 30000, '触发SAP ECC数据同步到数据湖');

-- 工具调用执行记录：每次工具调用的完整记录
CREATE TABLE tool_execution_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    execution_id    VARCHAR(64) NOT NULL UNIQUE,
    task_id         VARCHAR(64) NOT NULL,                  -- 来自哪个任务
    request_id      VARCHAR(64) NOT NULL,
    agent_id        VARCHAR(64) NOT NULL,
    tool_id         VARCHAR(64) NOT NULL,
    -- 输入输出
    input_params    JSON NOT NULL,
    output_result   JSON,
    -- 授权
    auth_level      TINYINT NOT NULL DEFAULT 0,
    auth_decision   ENUM('autonomous','approved','rejected','hard_blocked'),
    -- 执行状态
    status          ENUM('pending','running','success','failed','timeout','retrying') NOT NULL DEFAULT 'pending',
    retry_count     INT NOT NULL DEFAULT 0,
    error_code      VARCHAR(64),
    error_message   VARCHAR(512),
    -- 时间
    started_at      DATETIME,
    completed_at    DATETIME,
    latency_ms      INT,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_task (task_id),
    INDEX idx_request (request_id),
    INDEX idx_agent_tool (agent_id, tool_id),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) COMMENT='工具调用执行记录·完整的工具调用日志';

-- 工具限流计数器（按分钟窗口）
CREATE TABLE tool_rate_counters (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    tool_id         VARCHAR(64) NOT NULL,
    agent_id        VARCHAR(64) NOT NULL,
    window_minute   DATETIME NOT NULL,                     -- 精确到分钟
    call_count      INT NOT NULL DEFAULT 1,
    UNIQUE KEY uk_tool_agent_window (tool_id, agent_id, window_minute),
    INDEX idx_window (window_minute)
) COMMENT='工具限流计数器·防止Agent滥用工具';

-- 视图：工具调用成功率统计
CREATE VIEW v_tool_performance AS
SELECT
    tool_id,
    agent_id,
    COUNT(*) AS total_calls,
    SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) AS success_count,
    ROUND(100.0 * SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) / COUNT(*), 1) AS success_rate,
    ROUND(AVG(latency_ms), 0) AS avg_latency_ms,
    MAX(latency_ms) AS max_latency_ms,
    SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) AS fail_count,
    MAX(created_at) AS last_called_at
FROM tool_execution_log
WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY tool_id, agent_id
ORDER BY total_calls DESC;
