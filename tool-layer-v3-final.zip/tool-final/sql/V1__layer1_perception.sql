-- ============================================================
-- 层面一：感知层（触发源）
-- 谁来触发调用？用户主动 / SFA定时 / Agent间互触发
-- ============================================================

-- 请求入站总表：所有进入系统的请求统一登记
CREATE TABLE trigger_requests (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(64) NOT NULL UNIQUE,           -- 全局唯一请求ID
    trigger_source  ENUM('user','sfa','scheduler','agent','webhook') NOT NULL,
    trigger_type    ENUM('query','command','alert','report','sync') NOT NULL,
    -- 来源信息
    user_id         VARCHAR(64),                           -- 人工触发时的用户
    session_id      VARCHAR(64),                           -- 对话会话ID
    source_agent    VARCHAR(64),                           -- Agent触发时的来源Agent
    -- 请求内容
    raw_input       TEXT NOT NULL,                         -- 原始输入（问题/指令/数据）
    structured_input JSON,                                 -- 结构化后的输入
    context_hint    VARCHAR(256),                          -- 上下文线索（"上海·S+门店·库存"）
    -- 处理状态
    status          ENUM('received','routing','executing','completed','failed','cancelled') NOT NULL DEFAULT 'received',
    priority        ENUM('low','normal','high','critical') NOT NULL DEFAULT 'normal',
    -- 时间
    received_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    routed_at       DATETIME,
    completed_at    DATETIME,
    -- 结果
    final_response  TEXT,
    error_message   VARCHAR(512),
    INDEX idx_request_id (request_id),
    INDEX idx_source_status (trigger_source, status),
    INDEX idx_received (received_at),
    INDEX idx_priority_status (priority, status)
) COMMENT='请求入站总表·所有触发源统一登记';

-- SFA定时上报配置：哪些数据需要定时从SFA拉取
CREATE TABLE sfa_report_schedules (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    schedule_id     VARCHAR(64) NOT NULL UNIQUE,
    report_type     VARCHAR(64) NOT NULL,                  -- inventory/visit/order/photo
    cron_expression VARCHAR(64) NOT NULL,                  -- "0 8 * * *" = 每天8点
    target_agent    VARCHAR(64) NOT NULL,                  -- 触发哪个Agent处理
    scope           ENUM('global','city','store') DEFAULT 'global',
    scope_ids       JSON,                                  -- 特定城市/门店列表（null=全部）
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    last_triggered_at DATETIME,
    last_success_at   DATETIME,
    fail_count      INT NOT NULL DEFAULT 0,
    description     VARCHAR(256),
    INDEX idx_active (is_active)
) COMMENT='SFA定时上报配置';

-- 初始化SFA定时任务
INSERT INTO sfa_report_schedules (schedule_id, report_type, cron_expression, target_agent, description) VALUES
('SCH_INV_DAILY',   'inventory',  '0 8 * * *',   'retail_store',    '每日8点·SFA库存上报→零售门店Agent'),
('SCH_VISIT_DAILY', 'visit',      '0 18 * * *',  'uber_incentive',  '每日18点·拜访日志→Uber激励Agent'),
('SCH_ORDER_DAILY', 'order',      '0 9 * * *',   'distributor',     '每日9点·经销商订单→经销商全链Agent'),
('SCH_PHOTO_DAILY', 'photo',      '0 10 * * *',  'shelf_recognition','每日10点·货架照片→货架识别Agent'),
('SCH_BUTTERFLY',   'inventory',  '0 */4 * * *', 'butterfly',       '每4小时·全链库存快照→蝴蝶效应Agent'),
('SCH_CALIBRATE',   'order',      '0 0 * * 1',   'a_calibration',   '每周一0点·a值重新校准');

-- Webhook接入配置：外部系统主动推送
CREATE TABLE webhook_endpoints (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    endpoint_id     VARCHAR(64) NOT NULL UNIQUE,
    source_system   VARCHAR(64) NOT NULL,                  -- "SAP","WeChatWork","POS"
    endpoint_path   VARCHAR(128) NOT NULL,                 -- "/webhook/sap/order"
    secret_key      VARCHAR(128),                          -- HMAC验证密钥
    target_agent    VARCHAR(64) NOT NULL,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    received_count  INT NOT NULL DEFAULT 0,
    last_received_at DATETIME,
    INDEX idx_path (endpoint_path),
    INDEX idx_active (is_active)
) COMMENT='Webhook接入配置·外部系统主动推送';

INSERT INTO webhook_endpoints (endpoint_id, source_system, endpoint_path, target_agent) VALUES
('WH_SAP_ORDER',    'SAP',        '/webhook/sap/order',       'distributor'),
('WH_SAP_STOCK',    'SAP',        '/webhook/sap/stock',       'butterfly'),
('WH_WECHAT_APPROVAL','WeChatWork','/webhook/wechat/approval','aio_commander'),
('WH_POS_SALE',     'POS',        '/webhook/pos/sale',        'retail_store');

-- 视图：当前待处理的高优先级请求
CREATE VIEW v_pending_requests AS
SELECT request_id, trigger_source, trigger_type, priority,
       user_id, source_agent, context_hint, received_at,
       TIMESTAMPDIFF(MINUTE, received_at, NOW()) AS waiting_minutes
FROM trigger_requests
WHERE status IN ('received','routing')
ORDER BY
    FIELD(priority,'critical','high','normal','low'),
    received_at ASC;
