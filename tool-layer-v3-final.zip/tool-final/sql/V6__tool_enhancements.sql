-- ============================================================
-- V6__tool_enhancements.sql
-- tool-layer-v3 新增表·支持7个调度层增强功能
-- ============================================================

-- ── #1 LLM意图识别结果缓存 ───────────────────────────────────
CREATE TABLE intent_recognition_cache (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    query_hash      VARCHAR(64) NOT NULL,              -- MD5(normalized_query)
    raw_query       VARCHAR(512) NOT NULL,
    recognized_agent VARCHAR(64) NOT NULL,             -- 识别出的目标Agent
    intent_type     VARCHAR(64),                       -- query/command/alert
    confidence      DECIMAL(4,2) NOT NULL,
    reasoning       VARCHAR(512),                      -- LLM给出的识别理由
    method          ENUM('keyword','llm','hybrid') NOT NULL DEFAULT 'llm',
    hit_count       INT NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_hash (query_hash),
    INDEX idx_created (created_at)
) COMMENT='意图识别结果缓存·#1 避免重复LLM调用';

-- ── #2 LLM任务拆解结果记录 ──────────────────────────────────
CREATE TABLE task_decomposition_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(64) NOT NULL,
    user_query      TEXT NOT NULL,
    decomposed_tasks JSON NOT NULL,                    -- [{agent_id,task_desc,depends_on}]
    task_count      INT NOT NULL,
    llm_reasoning   TEXT,                              -- LLM的拆解思路
    decompose_method ENUM('rule','llm') NOT NULL,      -- 用规则还是LLM拆解的
    latency_ms      INT,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_created (created_at)
) COMMENT='任务拆解日志·#2 记录LLM动态拆解过程';

-- ── #3 多Agent综合分析结果 ──────────────────────────────────
ALTER TABLE execution_results
    ADD COLUMN synthesis_method  ENUM('llm','fallback','empty') DEFAULT 'empty'
        COMMENT '#3 综合方式：llm=真实综合，fallback=降级文案',
    ADD COLUMN synthesis_tokens  INT     COMMENT '综合分析消耗的token数',
    ADD COLUMN action_items      JSON    COMMENT '从综合分析中提取的可执行建议列表';

-- ── #4 LLM反思记录 ──────────────────────────────────────────
CREATE TABLE reflection_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(64) NOT NULL,
    reflection_round TINYINT NOT NULL DEFAULT 1,       -- 第几轮反思（最多2轮）
    issues_found    JSON,                              -- 发现的问题列表
    need_more       TINYINT(1) NOT NULL DEFAULT 0,     -- 是否需要补充任务
    supplemental_tasks JSON,                           -- 追加的补充任务
    llm_reasoning   TEXT,
    latency_ms      INT,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id)
) COMMENT='LLM反思记录·#4 审视结果质量';

-- ── #5 工具结果摘要日志 ──────────────────────────────────────
CREATE TABLE tool_summary_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    execution_id    VARCHAR(64) NOT NULL,
    tool_id         VARCHAR(64) NOT NULL,
    original_size   INT NOT NULL,                      -- 原始输出字节数
    summarized_size INT NOT NULL,                      -- 摘要后字节数
    compression_ratio DECIMAL(4,2),                    -- 压缩比
    summary_method  ENUM('array_trim','key_filter','text_truncate','none') NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_execution (execution_id)
) COMMENT='工具结果摘要日志·#5 记录摘要压缩情况';

-- ── #6 工作流状态持久化（替代LangGraph·Java Spring实现）───
CREATE TABLE workflow_states (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    workflow_id     VARCHAR(64) NOT NULL UNIQUE,       -- 对应 request_id
    current_state   VARCHAR(64) NOT NULL,              -- 当前状态节点
    previous_state  VARCHAR(64),
    state_data      JSON,                              -- 状态携带的数据
    -- 条件分支结果
    branch_decisions JSON,                             -- [{step,condition,result,next_state}]
    -- 执行统计
    total_steps     INT NOT NULL DEFAULT 0,
    completed_steps INT NOT NULL DEFAULT 0,
    -- 容错
    can_resume      TINYINT(1) NOT NULL DEFAULT 1,     -- 进程重启后是否可恢复
    last_checkpoint DATETIME,
    -- 生命周期
    status          ENUM('running','completed','failed','suspended') NOT NULL DEFAULT 'running',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_updated (updated_at)
) COMMENT='工作流状态持久化·#6 进程重启可恢复';

-- ── #7 SSE流式进度事件队列 ──────────────────────────────────
CREATE TABLE sse_progress_events (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(64) NOT NULL,
    event_type      ENUM('task_start','task_end','pipeline_complete',
                         'error','reflection_start','synthesis_start') NOT NULL,
    step_current    TINYINT,                           -- 当前第几步
    step_total      TINYINT,                           -- 总步数
    agent_id        VARCHAR(64),
    agent_label     VARCHAR(64),                       -- 中文标签，如"蝴蝶效应检测"
    status          ENUM('running','success','failed','waiting') NOT NULL,
    output_preview  VARCHAR(256),                      -- 输出摘要（给用户看的）
    duration_ms     INT,
    payload         JSON,
    is_sent         TINYINT(1) NOT NULL DEFAULT 0,     -- 是否已推送给前端
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request_sent (request_id, is_sent),
    INDEX idx_created (created_at)
) COMMENT='SSE进度事件队列·#7 流式进度输出';

-- 视图：调度层健康度
CREATE VIEW v_dispatch_health AS
SELECT
    (SELECT COUNT(*) FROM intent_recognition_cache
     WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)) AS intent_cache_hits_today,
    (SELECT ROUND(AVG(confidence)*100,1) FROM intent_recognition_cache
     WHERE method='llm' AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)) AS avg_intent_confidence_pct,
    (SELECT COUNT(*) FROM task_decomposition_log
     WHERE decompose_method='llm' AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)) AS llm_decompose_today,
    (SELECT COUNT(*) FROM reflection_log
     WHERE need_more=1 AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)) AS reflection_triggered_today,
    (SELECT ROUND(AVG(compression_ratio),2) FROM tool_summary_log
     WHERE created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)) AS avg_compression_ratio,
    (SELECT COUNT(*) FROM workflow_states WHERE status='running') AS active_workflows,
    NOW() AS generated_at;
