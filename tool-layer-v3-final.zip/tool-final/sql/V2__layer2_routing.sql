-- ============================================================
-- 层面二：路由层（AIO总指挥派发器）
-- 判断：哪个Agent处理？单Agent还是多Agent协作？顺序还是并发？
-- ============================================================

-- 路由规则表：AIO总指挥的派发逻辑
CREATE TABLE routing_rules (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    rule_id         VARCHAR(64) NOT NULL UNIQUE,
    -- 匹配条件
    trigger_type    VARCHAR(64),                           -- null=匹配所有类型
    keyword_patterns JSON,                                 -- ["库存","补货","水位"]·关键词命中
    entity_types    JSON,                                  -- ["store","distributor"]·涉及实体类型
    priority_min    ENUM('low','normal','high','critical'), -- 最低优先级才触发
    -- 路由目标
    execution_mode  ENUM('single','sequential','parallel','pipeline') NOT NULL,
    primary_agent   VARCHAR(64) NOT NULL,                  -- 主Agent
    secondary_agents JSON,                                 -- 协同Agent列表
    pipeline_steps  JSON,                                  -- pipeline模式下的执行顺序
    -- 规则属性
    confidence      DECIMAL(4,2) NOT NULL DEFAULT 0.90,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    hit_count       INT NOT NULL DEFAULT 0,
    description     VARCHAR(256),
    INDEX idx_active (is_active),
    INDEX idx_trigger (trigger_type)
) COMMENT='路由规则表·AIO总指挥派发逻辑';

-- 预设路由规则
INSERT INTO routing_rules
(rule_id, trigger_type, keyword_patterns, execution_mode, primary_agent, secondary_agents, description) VALUES
('R_INVENTORY_ALERT', 'alert',
 '["库存","water level","water_level","缺货","断货","压货"]',
 'pipeline', 'butterfly',
 '["retail_store","omakase","uber_incentive"]',
 '库存异常：蝴蝶效应检测→零售门店定位→推单→激励补货'),

('R_ORDER_PUSH', 'command',
 '["推单","补货","下单","reorder"]',
 'sequential', 'omakase',
 '["a_calibration","distributor"]',
 '补货指令：先校准a值→推单计算→经销商接单'),

('R_SHELF_SCAN', 'report',
 '["货架","陈列","photo","照片","扫描"]',
 'pipeline', 'shelf_recognition',
 '["inventory_report","uber_incentive"]',
 '货架照片：识别→库存上报→激励积分'),

('R_BUTTERFLY_CHECK', 'alert',
 '["蝴蝶","传导","失真","distortion","butterfly"]',
 'single', 'butterfly', NULL,
 '蝴蝶效应检测：单Agent直接处理'),

('R_STRATEGY_QUERY', 'query',
 '["战略","分析","为什么","怎么看","趋势"]',
 'parallel', 'aio_commander',
 '["brand_advisor","prism"]',
 '战略分析：总指挥+品牌顾问+PRISM并行分析'),

('R_PRICE_VIOLATION', 'alert',
 '["底价","价格","乱价","违规","¥17"]',
 'sequential', 'price_tag',
 '["sub_distributor","butterfly"]',
 '价格违规：价签识别→二批商追踪→蝴蝶效应记录'),

('R_USER_QUERY', 'query',
 NULL,
 'single', 'aio_commander', NULL,
 '默认兜底路由：所有未匹配的用户问题交给AIO总指挥');

-- 路由决策记录：每次路由的决策过程
CREATE TABLE routing_decisions (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(64) NOT NULL,
    matched_rule_id VARCHAR(64),
    execution_mode  ENUM('single','sequential','parallel','pipeline') NOT NULL,
    primary_agent   VARCHAR(64) NOT NULL,
    secondary_agents JSON,
    routing_reason  VARCHAR(512),                          -- 为什么选这个规则
    confidence      DECIMAL(4,2),
    decided_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_rule (matched_rule_id)
) COMMENT='路由决策记录·每次派发的决策过程';

-- Agent任务队列：路由完成后创建的任务
CREATE TABLE agent_task_queue (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    task_id         VARCHAR(64) NOT NULL UNIQUE,
    request_id      VARCHAR(64) NOT NULL,
    agent_id        VARCHAR(64) NOT NULL,
    task_type       VARCHAR(64) NOT NULL,                  -- analyze/execute/report/sync
    sequence_order  INT NOT NULL DEFAULT 0,                -- pipeline中的顺序（0=并发）
    depends_on_task VARCHAR(64),                           -- 前置任务ID（pipeline）
    input_data      JSON NOT NULL,
    -- 状态
    status          ENUM('pending','running','completed','failed','skipped') NOT NULL DEFAULT 'pending',
    -- auth-boundary结果
    auth_level      TINYINT,                               -- 授权级别
    auth_required   TINYINT(1) NOT NULL DEFAULT 0,        -- 是否需要人工审批
    approved_by     VARCHAR(64),
    -- 执行结果
    output_data     JSON,
    error_message   VARCHAR(512),
    -- 时间
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at      DATETIME,
    completed_at    DATETIME,
    timeout_at      DATETIME,                              -- 超时时间
    INDEX idx_request_agent (request_id, agent_id),
    INDEX idx_status (status),
    INDEX idx_depends (depends_on_task),
    INDEX idx_timeout (timeout_at)
) COMMENT='Agent任务队列·路由后的执行任务';

-- 视图：当前执行中的任务流水线
CREATE VIEW v_active_pipelines AS
SELECT
    t.request_id,
    t.agent_id,
    t.task_type,
    t.sequence_order,
    t.status,
    t.auth_required,
    t.auth_level,
    TIMESTAMPDIFF(SECOND, t.started_at, NOW()) AS running_seconds,
    r.trigger_source,
    r.priority
FROM agent_task_queue t
JOIN trigger_requests r ON t.request_id = r.request_id
WHERE t.status IN ('pending','running')
ORDER BY r.priority DESC, t.sequence_order ASC;
