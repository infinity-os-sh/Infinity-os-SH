-- ============================================================
-- 层面四：反馈层（结果回写）
-- 执行完→写回记忆层→更新信用分→触发下一个Agent→等待人工审批
-- ============================================================

-- 执行结果汇总：每个request_id的完整执行结果
CREATE TABLE execution_results (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(64) NOT NULL UNIQUE,
    -- 执行概要
    total_tasks     INT NOT NULL DEFAULT 0,
    completed_tasks INT NOT NULL DEFAULT 0,
    failed_tasks    INT NOT NULL DEFAULT 0,
    -- 最终结果
    final_status    ENUM('success','partial','failed','awaiting_approval') NOT NULL,
    final_response  TEXT,                                  -- 给用户的最终回答
    response_type   ENUM('text','alert','report','approval_request') DEFAULT 'text',
    -- 关键数据提取（供记忆层使用）
    mentioned_cities  JSON,
    mentioned_stores  JSON,
    key_findings      JSON,                                -- ["发现3家门店低于2a","松江区压货风险"]
    triggered_agents  JSON,                                -- 本次调用了哪些Agent
    -- 时间和性能
    total_latency_ms  INT,
    completed_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_status (final_status),
    INDEX idx_completed (completed_at)
) COMMENT='执行结果汇总·每个请求的最终输出';

-- 人工审批队列：需要人确认才能继续的任务
CREATE TABLE approval_queue (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    approval_id     VARCHAR(64) NOT NULL UNIQUE,
    request_id      VARCHAR(64) NOT NULL,
    task_id         VARCHAR(64) NOT NULL,
    agent_id        VARCHAR(64) NOT NULL,
    -- 审批内容
    action_type     VARCHAR(64) NOT NULL,                  -- "create_order"/"update_score"
    action_summary  VARCHAR(512) NOT NULL,                 -- "为上海松江经销商推单¥28,000"
    action_detail   JSON NOT NULL,                         -- 完整的操作参数
    risk_level      ENUM('low','medium','high','critical') NOT NULL,
    auth_level      TINYINT NOT NULL,                      -- 1=快速通道·2=主管·3=总监
    required_approver VARCHAR(64),                         -- 需要谁审批
    plain_reason    TEXT,                                  -- 为什么需要审批（给审批人看的）
    -- 审批状态
    status          ENUM('pending','approved','rejected','expired','cancelled') NOT NULL DEFAULT 'pending',
    approved_by     VARCHAR(64),
    decided_at      DATETIME,
    decision_reason VARCHAR(512),                          -- 拒绝原因（必填）
    -- 时间
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      DATETIME NOT NULL,                     -- 审批超时时间
    wechat_msg_id   VARCHAR(128),                          -- 企微消息ID，用于更新消息状态
    INDEX idx_request (request_id),
    INDEX idx_status_expires (status, expires_at),
    INDEX idx_approver (required_approver, status)
) COMMENT='人工审批队列·等待人工确认的任务';

-- 信用分变更日志：每次Agent执行后的信用分更新记录
CREATE TABLE credit_change_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id        VARCHAR(64) NOT NULL,
    request_id      VARCHAR(64) NOT NULL,
    change_type     ENUM('correct','incorrect','approved','rejected','auto') NOT NULL,
    delta           DECIMAL(5,2) NOT NULL,                 -- 正数=加分·负数=扣分
    score_before    DECIMAL(5,2) NOT NULL,
    score_after     DECIMAL(5,2) NOT NULL,
    reason          VARCHAR(256) NOT NULL,
    changed_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_agent (agent_id),
    INDEX idx_changed (changed_at)
) COMMENT='信用分变更日志·完整追踪信用分变化';

-- 后续触发记录：执行完成后触发下一个Agent的记录
CREATE TABLE cascade_triggers (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    source_request_id VARCHAR(64) NOT NULL,
    source_agent    VARCHAR(64) NOT NULL,
    triggered_request_id VARCHAR(64),                     -- 触发产生的新请求ID
    triggered_agent VARCHAR(64) NOT NULL,
    trigger_reason  VARCHAR(256) NOT NULL,                 -- "蝴蝶效应检测到A类压货·触发推单"
    trigger_data    JSON,
    status          ENUM('pending','triggered','cancelled') NOT NULL DEFAULT 'pending',
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    triggered_at    DATETIME,
    INDEX idx_source (source_request_id),
    INDEX idx_status (status)
) COMMENT='后续触发记录·Agent完成后触发下一个Agent';

-- 用户反馈收集：用户对Agent回答的评价
CREATE TABLE user_feedback (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(64) NOT NULL,
    user_id         VARCHAR(64) NOT NULL,
    agent_id        VARCHAR(64) NOT NULL,
    rating          TINYINT NOT NULL,                      -- 1-5星
    feedback_type   ENUM('correct','data_wrong','logic_wrong','timing_wrong','unhelpful') NOT NULL,
    comment         VARCHAR(512),
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_agent_rating (agent_id, rating)
) COMMENT='用户反馈·驱动Agent学习闭环';

-- 视图：系统整体执行健康度
CREATE VIEW v_execution_health AS
SELECT
    DATE(completed_at) AS stats_date,
    COUNT(*) AS total_requests,
    SUM(CASE WHEN final_status='success' THEN 1 ELSE 0 END) AS success_count,
    SUM(CASE WHEN final_status='failed' THEN 1 ELSE 0 END) AS fail_count,
    SUM(CASE WHEN final_status='awaiting_approval' THEN 1 ELSE 0 END) AS pending_approval,
    ROUND(AVG(total_latency_ms) / 1000.0, 1) AS avg_latency_seconds,
    (SELECT COUNT(*) FROM approval_queue WHERE status='pending'
     AND expires_at > NOW()) AS current_pending_approvals
FROM execution_results
WHERE completed_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY DATE(completed_at)
ORDER BY stats_date DESC;
