"""
蝴蝶效应 Agent
触发时间:每周一 07:00(在A值校准之后·Omakase之前)

Spec: .kiro/specs/agent-02-butterfly-effect/

职责:检测4类失真
  D类 战略扰动 · 优先(避免误报A/B/C)
  A类 压货失真 · 库存>3a + r持续下降
  B类 促销扰动 · r暴涨 + 库存清空
  C类 窜货失真 · 二批商水位>1.5a
"""
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional
import time
import uuid
from collections import defaultdict
from loguru import logger
from sqlalchemy.orm import Session

from src.models.heartbeat import Heartbeat
from src.models.alert import Alert
from src.models.node import Node
from src.repositories.repos import (
    HeartbeatRepository, AlertRepository, NodeRepository
)


# ============ DTO ============

@dataclass
class DetectionReport:
    """检测总报告"""
    start_time: float = 0
    end_time: float = 0
    total_duration_ms: int = 0
    total_alerts: int = 0
    alerts_by_type: dict[str, int] = field(default_factory=lambda: defaultdict(int))


# ============ Agent ============

class ButterflyEffectAgent:
    """蝴蝶效应 Agent · 4类失真检测"""
    
    def __init__(self, db: Session):
        self.db = db
        self.hb_repo = HeartbeatRepository(db)
        self.alert_repo = AlertRepository(db)
        self.node_repo = NodeRepository(db)
    
    def run_full_detection(self) -> DetectionReport:
        """主入口·扫描所有节点检测失真"""
        logger.info("======================================")
        logger.info(f"蝴蝶效应 Agent 开始 · {date.today()}")
        logger.info("======================================")
        
        report = DetectionReport(start_time=time.time())
        
        # 读取昨日所有心跳数据
        yesterday = date.today() - timedelta(days=1)
        recent = self.hb_repo.find_by_date(yesterday)
        logger.info(f"扫描昨日数据·{len(recent)}条")
        
        # 缓存节点信息
        node_cache: dict[int, Node] = {}
        
        for hb in recent:
            try:
                # 获取节点信息(带缓存)
                node = node_cache.get(hb.node_id)
                if node is None:
                    node = self.node_repo.find_by_id(hb.node_id)
                    if node is None:
                        continue
                    node_cache[hb.node_id] = node
                
                # 按优先级检测·D类优先
                alert = (
                    self._detect_strategic(hb, node)
                    or self._detect_push_inventory(hb, node)
                    or self._detect_promotion(hb, node)
                    or self._detect_cross_region(hb, node)
                )
                
                if alert:
                    self.alert_repo.save(alert)
                    report.alerts_by_type[alert.distortion_type] += 1
                    report.total_alerts += 1
            
            except Exception as e:
                logger.error(f"检测异常: hb_id={hb.id} · {e}")
        
        self.db.commit()
        
        report.end_time = time.time()
        report.total_duration_ms = int((report.end_time - report.start_time) * 1000)
        
        logger.info("======================================")
        logger.info("蝴蝶效应 Agent 完成")
        logger.info(f"  总预警: {report.total_alerts}")
        logger.info(f"  A类压货: {report.alerts_by_type.get('A', 0)}")
        logger.info(f"  B类促销: {report.alerts_by_type.get('B', 0)}")
        logger.info(f"  C类窜货: {report.alerts_by_type.get('C', 0)}")
        logger.info(f"  D类战略: {report.alerts_by_type.get('D', 0)}")
        logger.info(f"  耗时: {report.total_duration_ms}ms")
        logger.info("======================================")
        
        return report
    
    # ============ 4个检测器 ============
    
    def _detect_strategic(self, hb: Heartbeat, node: Node) -> Optional[Alert]:
        """
        D类 · 战略扰动检测(优先)
        TODO: Phase 2接入战略事件表(inf_strategic_events)
        Phase 1暂返回None
        """
        return None
    
    def _detect_push_inventory(self, hb: Heartbeat, node: Node) -> Optional[Alert]:
        """
        A类 · 压货失真检测
        条件:节点是经销商或门店 + 水位>3a + 最近7天r下降>10%
        """
        if node.node_type not in ("DISTRIBUTOR", "STORE"):
            return None
        
        if hb.water_level <= Decimal("3"):
            return None
        
        # 检查最近7天r是否下降
        last_7 = self.hb_repo.find_by_node_sku_recent(
            hb.node_id, hb.sku_code, 7
        )
        if len(last_7) < 5:
            return None
        
        # 简化判断:最近3天平均 < 之前4天平均
        recent_3 = last_7[:3]
        prev_4 = last_7[3:]
        recent_avg = sum(float(h.r_actual) for h in recent_3) / len(recent_3)
        prev_avg = sum(float(h.r_actual) for h in prev_4) / len(prev_4)
        
        if recent_avg >= prev_avg * 0.9:  # 没下降10%
            return None
        
        decline_pct = (1 - recent_avg / prev_avg) * 100 if prev_avg > 0 else 0
        
        return self._create_alert(
            "A", node, hb,
            f"压货失真:水位{hb.water_level}a(>3a) · r从{prev_avg:.1f}降至{recent_avg:.1f}(降{decline_pct:.1f}%)",
            "建议暂停对该节点的Omakase推单 · 联系经销商了解原因",
            "HIGH"
        )
    
    def _detect_promotion(self, hb: Heartbeat, node: Node) -> Optional[Alert]:
        """
        B类 · 促销扰动检测
        条件:最近3天平均r / 过去14天平均r > 2
        """
        last_14 = self.hb_repo.find_by_node_sku_recent(
            hb.node_id, hb.sku_code, 14
        )
        if len(last_14) < 10:
            return None
        
        recent_3 = last_14[:3]
        historic = last_14[3:]
        recent_avg = sum(float(h.r_actual) for h in recent_3) / len(recent_3)
        historic_avg = sum(float(h.r_actual) for h in historic) / len(historic)
        
        if historic_avg == 0:
            return None
        
        ratio = recent_avg / historic_avg
        if ratio < 2.0:
            return None
        
        return self._create_alert(
            "B", node, hb,
            f"促销扰动:r骤升至{recent_avg:.1f}(平时{historic_avg:.1f})·比率{ratio:.1f}x",
            "确认是否有促销活动 · 暂时不调整目标r",
            "MEDIUM"
        )
    
    def _detect_cross_region(self, hb: Heartbeat, node: Node) -> Optional[Alert]:
        """
        C类 · 窜货失真检测
        条件:二批商水位>1.5a(应严控1a)
        """
        if node.node_type != "SUB_DIST":
            return None
        
        if hb.water_level <= Decimal("1.5"):
            return None
        
        return self._create_alert(
            "C", node, hb,
            f"窜货失真:二批商{node.node_name}水位{hb.water_level}a(应严控1a)",
            "立即检查该二批商出货流向 · 与毗邻区域价格对比",
            "CRITICAL"
        )
    
    def _create_alert(
        self,
        distortion_type: str,
        node: Node,
        hb: Heartbeat,
        description: str,
        action: str,
        severity: str
    ) -> Alert:
        """创建Alert对象"""
        return Alert(
            alert_code=f"BFE-{distortion_type}-{uuid.uuid4().hex[:8]}",
            node_id=node.id,
            sku_code=hb.sku_code,
            distortion_type=distortion_type,
            severity=severity,
            description=description,
            recommended_action=action,
            status="OPEN",
            evidence_json={
                "node_name": node.node_name,
                "node_type": node.node_type,
                "sku": hb.sku_code,
                "r_actual": float(hb.r_actual),
                "water_level": float(hb.water_level),
                "data_date": str(hb.data_date),
            },
        )
