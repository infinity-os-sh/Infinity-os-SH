"""
A值校准 Agent
触发时间:每周一 06:00

Spec: .kiro/specs/agent-01-a-value-calibration/

职责:
  1. 读取过去30天r数据
  2. 排除断货日(r=0)和促销日(r > 中位数×3)
  3. 三重验证计算校准后的r
  4. 校验变化≤±15% · 否则人工审核
  5. 更新inf_heartbeat的r_actual
  6. 写入inf_learning_log
"""
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional
import time
from collections import defaultdict
from loguru import logger
from sqlalchemy.orm import Session

from src.models.heartbeat import Heartbeat
from src.models.learning_log import LearningLog
from src.repositories.repos import HeartbeatRepository, LearningLogRepository
from src.utils.heartbeat import (
    tri_validate_calibrate,
    is_reasonable_change,
)
from src.config import settings


# ============ DTO ============

@dataclass
class CalibrationResult:
    """单个组合的校准结果"""
    key: str
    node_id: int
    sku_code: str
    old_r: float
    new_r: float
    change_ratio: float
    needs_human_review: bool
    outliers_excluded: int
    data_points_used: int
    latest_hb_id: int


@dataclass
class CalibrationReport:
    """校准总报告"""
    start_time: float = 0
    end_time: float = 0
    total_duration_ms: int = 0
    auto_approved_count: int = 0
    needs_review_count: int = 0
    failed_count: int = 0
    insufficient_data_count: int = 0
    results: list[CalibrationResult] = field(default_factory=list)


# ============ Agent ============

class AValueCalibrationAgent:
    """A值校准 Agent · 主入口"""
    
    LOOKBACK_DAYS = 30
    
    def __init__(self, db: Session):
        self.db = db
        self.hb_repo = HeartbeatRepository(db)
        self.log_repo = LearningLogRepository(db)
        self.max_change = settings.a_calibration_max_change
    
    def run_full_calibration(self) -> CalibrationReport:
        """主入口·校准所有节点-SKU组合的r值"""
        logger.info("======================================")
        logger.info(f"A值校准 Agent 开始 · {date.today()}")
        logger.info("======================================")
        
        report = CalibrationReport(start_time=time.time())
        
        # 1. 读取过去30天数据
        start_date = date.today() - timedelta(days=self.LOOKBACK_DAYS)
        recent_data = self.hb_repo.find_recent(start_date)
        logger.info(f"读取过去{self.LOOKBACK_DAYS}天数据·共{len(recent_data)}条")
        
        # 2. 按 (node_id, sku_code) 分组
        grouped: dict[tuple[int, str], list[Heartbeat]] = defaultdict(list)
        for hb in recent_data:
            grouped[(hb.node_id, hb.sku_code)].append(hb)
        
        logger.info(f"待校准组合数: {len(grouped)}")
        
        # 3. 逐组校准
        for (node_id, sku_code), hb_list in grouped.items():
            try:
                result = self._calibrate_one(node_id, sku_code, hb_list)
                if result is None:
                    report.insufficient_data_count += 1
                    continue
                
                report.results.append(result)
                
                if result.needs_human_review:
                    report.needs_review_count += 1
                    logger.warning(
                        f"待审: node={node_id} sku={sku_code} "
                        f"old={result.old_r} new={result.new_r} "
                        f"change={result.change_ratio*100:.1f}%"
                    )
                else:
                    report.auto_approved_count += 1
                    # 自动更新r_actual
                    self.hb_repo.update_r_actual(
                        result.latest_hb_id, Decimal(str(result.new_r))
                    )
                
                # 写入learning_log
                self._log_calibration(result)
                
            except Exception as e:
                logger.error(f"校准失败: node={node_id} sku={sku_code} · {e}")
                report.failed_count += 1
        
        # 提交事务
        self.db.commit()
        
        report.end_time = time.time()
        report.total_duration_ms = int((report.end_time - report.start_time) * 1000)
        
        logger.info("======================================")
        logger.info("A值校准 Agent 完成")
        logger.info(f"  总组合: {len(grouped)}")
        logger.info(f"  自动通过: {report.auto_approved_count}")
        logger.info(f"  待审核: {report.needs_review_count}")
        logger.info(f"  数据不足: {report.insufficient_data_count}")
        logger.info(f"  失败: {report.failed_count}")
        logger.info(f"  耗时: {report.total_duration_ms}ms")
        logger.info("======================================")
        
        return report
    
    def _calibrate_one(
        self, node_id: int, sku_code: str, hb_list: list[Heartbeat]
    ) -> Optional[CalibrationResult]:
        """校准单个 (node, sku) 组合"""
        if not hb_list:
            return None
        
        # 找出最新一条
        latest = max(hb_list, key=lambda h: h.data_date)
        
        # 提取r值数组
        r_series = [float(hb.r_actual) for hb in hb_list]
        
        # 三重验证
        new_r, outliers = tri_validate_calibrate(r_series)
        
        if new_r == 0:
            return None  # 数据不足
        
        old_r = float(latest.r_actual)
        
        # 变化率
        change_ratio = 0.0 if old_r == 0 else (new_r - old_r) / old_r
        
        # 合理性校验
        reasonable = is_reasonable_change(old_r, new_r, self.max_change)
        
        return CalibrationResult(
            key=f"{node_id}_{sku_code}",
            node_id=node_id,
            sku_code=sku_code,
            old_r=old_r,
            new_r=new_r,
            change_ratio=round(change_ratio, 4),
            needs_human_review=not reasonable,
            outliers_excluded=outliers,
            data_points_used=len(hb_list) - outliers,
            latest_hb_id=latest.id,
        )
    
    def _log_calibration(self, result: CalibrationResult) -> None:
        """写入学习日志"""
        log = LearningLog(
            agent_name="A_VALUE_CALIBRATION",
            event_type="CALIBRATION_DONE",
            input_json={
                "node_id": result.node_id,
                "sku_code": result.sku_code,
                "old_r": result.old_r,
                "data_points": result.data_points_used,
            },
            decision_json={
                "new_r": result.new_r,
                "outliers_excluded": result.outliers_excluded,
                "change_ratio": result.change_ratio,
                "needs_review": result.needs_human_review,
            },
        )
        self.log_repo.save(log)
