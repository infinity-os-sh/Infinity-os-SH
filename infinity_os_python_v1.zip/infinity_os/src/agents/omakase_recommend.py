"""
Omakase推单 Agent
触发时间:每周一 08:00(在A值校准 + 蝴蝶效应之后)

Spec: .kiro/specs/agent-03-omakase-recommend/

职责:
  1. 扫描所有水位<2a的经销商
  2. 排除有A类压货预警或D类战略事件的节点
  3. 计算推单量 = (3a - 当前库存) × 1.2安全系数
  4. 5万以下自动批 · 5万以上人工审批
  5. 生成PENDING/APPROVED状态的Action
"""
from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal
from typing import Optional
import time
import uuid
from loguru import logger
from sqlalchemy.orm import Session

from src.models.heartbeat import Heartbeat
from src.models.action import Action
from src.models.alert import Alert
from src.models.node import Node
from src.repositories.repos import (
    HeartbeatRepository, ActionRepository,
    AlertRepository, NodeRepository
)
from src.utils.heartbeat import calculate_omakase_qty
from src.config import settings


# ============ DTO ============

@dataclass
class RecommendReport:
    """推单总报告"""
    start_time: float = 0
    end_time: float = 0
    total_duration_ms: int = 0
    recommended_count: int = 0
    skipped_due_to_alert: int = 0
    failed_count: int = 0
    total_amount: Decimal = field(default_factory=lambda: Decimal(0))


# ============ Agent ============

class OmakaseRecommendAgent:
    """Omakase推单 Agent · 智能补货"""
    
    SAFETY_FACTOR = Decimal("1.2")
    DEFAULT_UNIT_PRICE = Decimal("8")  # TODO: 接入SKU价格表后替换
    
    def __init__(self, db: Session):
        self.db = db
        self.hb_repo = HeartbeatRepository(db)
        self.alert_repo = AlertRepository(db)
        self.action_repo = ActionRepository(db)
        self.node_repo = NodeRepository(db)
        self.auto_approve_threshold = Decimal(str(settings.omakase_auto_approve_threshold))
    
    def run_full_recommendation(self) -> RecommendReport:
        """主入口"""
        logger.info("======================================")
        logger.info(f"Omakase推单 Agent 开始 · {date.today()}")
        logger.info("======================================")
        
        report = RecommendReport(start_time=time.time())
        
        # 1. 找出所有水位<2a的经销商
        yesterday = date.today() - timedelta(days=1)
        low_water = self.hb_repo.find_low_water_by_date(
            yesterday, Decimal("2")
        )
        logger.info(f"待推单候选: {len(low_water)}")
        
        node_cache: dict[int, Node] = {}
        
        for hb in low_water:
            try:
                # 获取节点
                node = node_cache.get(hb.node_id)
                if node is None:
                    node = self.node_repo.find_by_id(hb.node_id)
                    if node is None:
                        continue
                    node_cache[hb.node_id] = node
                
                # 只对经销商推单
                if node.node_type != "DISTRIBUTOR":
                    continue
                
                # 排除有A类或D类预警的节点
                if self._has_blocking_alert(node.id, hb.sku_code):
                    logger.debug(f"跳过{node.node_code}:有阻塞性预警")
                    report.skipped_due_to_alert += 1
                    continue
                
                # 创建推单
                action = self._create_recommendation(hb, node)
                if action is None:
                    continue
                
                self.action_repo.save(action)
                report.recommended_count += 1
                report.total_amount += action.recommended_amount or Decimal(0)
            
            except Exception as e:
                logger.error(f"推单失败: hb_id={hb.id} · {e}")
                report.failed_count += 1
        
        self.db.commit()
        
        report.end_time = time.time()
        report.total_duration_ms = int((report.end_time - report.start_time) * 1000)
        
        logger.info("======================================")
        logger.info("Omakase推单 Agent 完成")
        logger.info(f"  候选数: {len(low_water)}")
        logger.info(f"  推单数: {report.recommended_count}")
        logger.info(f"  跳过(有预警): {report.skipped_due_to_alert}")
        logger.info(f"  推单总额: ¥{report.total_amount}")
        logger.info(f"  失败: {report.failed_count}")
        logger.info(f"  耗时: {report.total_duration_ms}ms")
        logger.info("======================================")
        
        return report
    
    def _has_blocking_alert(self, node_id: int, sku_code: str) -> bool:
        """
        检查是否有阻塞性预警
        阻塞:A类压货 + D类战略
        非阻塞:B类促销 + C类窜货(独立处理)
        """
        open_alerts = self.alert_repo.find_open_by_node_sku(node_id, sku_code)
        return any(a.distortion_type in ("A", "D") for a in open_alerts)
    
    def _create_recommendation(
        self, hb: Heartbeat, node: Node
    ) -> Optional[Action]:
        """创建Omakase推单"""
        current_inventory = float(hb.inventory_actual)
        a = float(hb.a_unit)
        
        push_qty = calculate_omakase_qty(
            current_inventory, a, float(self.SAFETY_FACTOR)
        )
        
        if push_qty <= 0:
            return None
        
        # 估算金额(简化:用默认单价 · 真实场景接入SKU价格表)
        amount = Decimal(push_qty) * self.DEFAULT_UNIT_PRICE
        
        # 自动批/人工审 判断
        if amount < self.auto_approve_threshold:
            status = "APPROVED"
            approver = "AUTO_APPROVED_BELOW_50K"
        else:
            status = "PENDING"
            approver = None
        
        action = Action(
            action_code=f"OMK-{uuid.uuid4().hex[:8]}",
            action_type="RECOMMEND_ORDER",
            node_id=node.id,
            sku_code=hb.sku_code,
            agent_source="OMAKASE",
            recommended_amount=amount,
            confidence_score=Decimal("85"),
            status=status,
            approver=approver,
            payload_json={
                "sku": hb.sku_code,
                "qty": push_qty,
                "unit_price": float(self.DEFAULT_UNIT_PRICE),
                "current_inventory": current_inventory,
                "target_inventory": 3 * a,
                "a_unit": a,
                "safety_factor": float(self.SAFETY_FACTOR),
            },
        )
        
        logger.debug(
            f"推单 {node.node_code}: SKU={hb.sku_code} 量={push_qty} "
            f"¥{amount} 状态={status}"
        )
        
        return action
