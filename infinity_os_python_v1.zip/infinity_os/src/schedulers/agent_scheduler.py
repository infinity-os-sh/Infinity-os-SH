"""
Agent调度器 · APScheduler定时触发3个Agent

触发顺序固定不可倒置:
  1. 周一06:00 · A值校准
  2. 周一07:00 · 蝴蝶效应
  3. 周一08:00 · Omakase推单

Spec: .kiro/specs/agent-01/02/03/
"""
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from loguru import logger

from src.models.base import SessionLocal
from src.agents.a_value_calibration import AValueCalibrationAgent
from src.agents.butterfly_effect import ButterflyEffectAgent
from src.agents.omakase_recommend import OmakaseRecommendAgent
from src.config import settings


# 全局Scheduler实例
scheduler = BackgroundScheduler(
    timezone="Asia/Shanghai",
    job_defaults={
        "coalesce": True,
        "max_instances": 1,
        "misfire_grace_time": 3600,  # 1小时容错
    }
)


def run_calibration_job() -> None:
    """周一06:00触发"""
    logger.info("⏰ 调度触发 · A值校准 Agent")
    db = SessionLocal()
    try:
        agent = AValueCalibrationAgent(db)
        report = agent.run_full_calibration()
        logger.info(
            f"✅ A值校准完成 · auto={report.auto_approved_count} "
            f"review={report.needs_review_count}"
        )
    except Exception as e:
        logger.error(f"❌ A值校准失败: {e}")
    finally:
        db.close()


def run_butterfly_job() -> None:
    """周一07:00触发"""
    logger.info("⏰ 调度触发 · 蝴蝶效应 Agent")
    db = SessionLocal()
    try:
        agent = ButterflyEffectAgent(db)
        report = agent.run_full_detection()
        logger.info(
            f"✅ 蝴蝶效应完成 · 总预警{report.total_alerts} "
            f"A={report.alerts_by_type.get('A', 0)} "
            f"B={report.alerts_by_type.get('B', 0)} "
            f"C={report.alerts_by_type.get('C', 0)} "
            f"D={report.alerts_by_type.get('D', 0)}"
        )
    except Exception as e:
        logger.error(f"❌ 蝴蝶效应失败: {e}")
    finally:
        db.close()


def run_omakase_job() -> None:
    """周一08:00触发"""
    logger.info("⏰ 调度触发 · Omakase推单 Agent")
    db = SessionLocal()
    try:
        agent = OmakaseRecommendAgent(db)
        report = agent.run_full_recommendation()
        logger.info(
            f"✅ Omakase推单完成 · 推单{report.recommended_count}笔 "
            f"总额¥{report.total_amount}"
        )
    except Exception as e:
        logger.error(f"❌ Omakase推单失败: {e}")
    finally:
        db.close()


def heartbeat_job() -> None:
    """每小时心跳·确认Scheduler活着"""
    logger.debug(f"💓 INFINITY OS Scheduler alive · {datetime.now()}")


def start_scheduler() -> None:
    """启动调度器"""
    # A值校准:每周一06:00
    scheduler.add_job(
        run_calibration_job,
        CronTrigger.from_crontab(settings.agent_calibration_cron),
        id="a_value_calibration",
        replace_existing=True,
    )
    
    # 蝴蝶效应:每周一07:00
    scheduler.add_job(
        run_butterfly_job,
        CronTrigger.from_crontab(settings.agent_butterfly_cron),
        id="butterfly_effect",
        replace_existing=True,
    )
    
    # Omakase推单:每周一08:00
    scheduler.add_job(
        run_omakase_job,
        CronTrigger.from_crontab(settings.agent_omakase_cron),
        id="omakase_recommend",
        replace_existing=True,
    )
    
    # 心跳:每小时
    scheduler.add_job(
        heartbeat_job,
        "interval",
        hours=1,
        id="heartbeat",
        replace_existing=True,
    )
    
    scheduler.start()
    
    logger.info("✅ Agent Scheduler 已启动")
    logger.info(f"   · A值校准: {settings.agent_calibration_cron}")
    logger.info(f"   · 蝴蝶效应: {settings.agent_butterfly_cron}")
    logger.info(f"   · Omakase推单: {settings.agent_omakase_cron}")


def stop_scheduler() -> None:
    """停止调度器(优雅关闭)"""
    if scheduler.running:
        scheduler.shutdown(wait=True)
        logger.info("Agent Scheduler 已停止")
