"""
INFINITY OS · 心跳公式核心计算工具

核心公式:
  a = r × T          (心跳单元 = 日销率 × 周期)
  水位 = 库存 ÷ a

三层水位标准:
  零售层(STORE):     3a满 → 2a预警 → 1a紧急
  经销商(DISTRIBUTOR): 2a满 → 1a预警 → 0a断货
  二批商(SUB_DIST):   1a严控(P2路径)

Spec: .kiro/specs/agent-01-a-value-calibration/design.md 算法部分
Spec: .kiro/steering/product.md 核心公式部分
"""
import math
import statistics
from enum import Enum
from typing import Optional


class NodeType(str, Enum):
    """节点类型枚举"""
    STORE = "STORE"
    DISTRIBUTOR = "DISTRIBUTOR"
    SUB_DIST = "SUB_DIST"
    WAREHOUSE = "WAREHOUSE"
    FACTORY = "FACTORY"


class WaterStatus(str, Enum):
    """水位状态枚举"""
    OVERFLOW = "OVERFLOW"  # 溢出·库存>阈值上限
    FULL = "FULL"          # 满仓·正常
    WARN = "WARN"          # 预警·需补货
    LOW = "LOW"            # 紧急·快断货
    EMPTY = "EMPTY"        # 断货


# ============ 核心计算 ============

def calculate_a(r: float, t: int) -> float:
    """
    计算心跳单元 a = r × T
    
    Spec: .kiro/specs/agent-01-a-value-calibration/design.md
    
    Args:
        r: 日销率(瓶/天)
        t: 周转周期(天)
    
    Returns:
        a值(瓶 · 保留2位小数)
    
    Raises:
        ValueError: 如果 r<0 或 t<=0
    """
    if r < 0:
        raise ValueError(f"r不能为负数: r={r}")
    if t <= 0:
        raise ValueError(f"t必须>0: t={t}")
    return round(r * t, 2)


def calculate_water_level(inventory: float, a: float) -> float:
    """
    计算水位 = 库存 ÷ a
    
    Args:
        inventory: 当前库存
        a: 心跳单元
    
    Returns:
        水位(单位:a倍)
    """
    if a == 0:
        return 0.0
    return round(inventory / a, 2)


def determine_status(water_level: float, node_type: NodeType) -> WaterStatus:
    """
    判断水位状态
    
    根据节点类型判断水位是否健康
    
    Spec: .kiro/specs/agent-02-butterfly-effect/requirements.md
    """
    if water_level <= 0:
        return WaterStatus.EMPTY
    
    if node_type == NodeType.STORE:
        # 零售层:3a满 / 2a预警 / 1a紧急
        if water_level > 3.5:
            return WaterStatus.OVERFLOW
        if water_level >= 2.0:
            return WaterStatus.FULL
        if water_level >= 1.0:
            return WaterStatus.WARN
        return WaterStatus.LOW
    
    if node_type == NodeType.DISTRIBUTOR:
        # 经销商:2a满 / 1a预警 / 0a断货
        if water_level > 2.5:
            return WaterStatus.OVERFLOW
        if water_level >= 1.0:
            return WaterStatus.FULL
        if water_level > 0.3:
            return WaterStatus.WARN
        return WaterStatus.LOW
    
    if node_type == NodeType.SUB_DIST:
        # 二批商:1a严控
        if water_level > 1.2:
            return WaterStatus.OVERFLOW
        if water_level >= 0.8:
            return WaterStatus.FULL
        if water_level > 0.3:
            return WaterStatus.WARN
        return WaterStatus.LOW
    
    return WaterStatus.FULL


# ============ 校准 · 三重验证算法 ============

def is_outlier(r_value: float, median: float) -> bool:
    """
    判断单个r值是否是异常值
    
    异常定义:
      1. r = 0 (断货日)
      2. r > median × 3 (促销日·r是中位数3倍以上)
    
    Spec: .kiro/specs/agent-01-a-value-calibration/design.md 算法1
    """
    if r_value == 0:
        return True
    if median == 0:
        return False
    if r_value > median * 3:
        return True
    return False


def tri_validate_calibrate(r_series: list[float]) -> tuple[float, int]:
    """
    三重验证校准r值
    
    三重验证:
      1. 剔除0值(断货日)
      2. 计算中位数·剔除 > 中位数×3 的异常值
      3. 剔除超过 mean ± 3*std 的(防极端值)
    
    Spec: .kiro/specs/agent-01-a-value-calibration/design.md 算法2
    
    Args:
        r_series: 历史r值列表
    
    Returns:
        (校准后的r, 排除的异常值数量)
        如果有效数据<5个 · 返回(0, 0)表示数据不足
    """
    if not r_series or len(r_series) < 5:
        return 0.0, 0
    
    # 第一重:剔除0值
    non_zero = [r for r in r_series if r > 0]
    if len(non_zero) < 5:
        return 0.0, 0
    
    # 第二重:剔除中位数3倍以上
    median = statistics.median(non_zero)
    if median == 0:
        return 0.0, 0
    filtered = [r for r in non_zero if r <= median * 3]
    if len(filtered) < 5:
        return 0.0, 0
    
    # 第三重:剔除mean±3*std外的
    mean = statistics.mean(filtered)
    std = statistics.stdev(filtered) if len(filtered) > 1 else 0
    if std > 0:
        final = [r for r in filtered if abs(r - mean) <= 3 * std]
    else:
        final = filtered
    
    if len(final) < 5:
        return 0.0, 0
    
    outliers_count = len(r_series) - len(final)
    new_r = round(statistics.mean(final), 2)
    return new_r, outliers_count


def is_reasonable_change(old_r: float, new_r: float, max_change: float = 0.15) -> bool:
    """
    判断校准变化是否合理(默认±15%以内)
    
    Spec: .kiro/specs/agent-01-a-value-calibration/requirements.md 验收标准
    
    Args:
        old_r: 原r值
        new_r: 新r值
        max_change: 最大允许变化率(默认0.15)
    
    Returns:
        True = 合理(可自动更新) · False = 异常(需人工审)
    """
    if old_r == 0:
        return True  # 首次校准·无对比
    change_ratio = abs(new_r - old_r) / old_r
    return change_ratio <= max_change


# ============ Omakase推单 ============

def calculate_omakase_qty(
    current_inventory: float,
    a: float,
    safety_factor: float = 1.2
) -> int:
    """
    计算Omakase推单量
    
    公式:推单量 = (3a - 当前库存) × 安全系数
    
    Spec: .kiro/specs/agent-03-omakase-recommend/design.md 算法
    
    Args:
        current_inventory: 当前库存
        a: 心跳单元
        safety_factor: 安全系数(默认1.2)
    
    Returns:
        推单量(整数·向上取整)
    """
    target_inventory = 3 * a
    gap = target_inventory - current_inventory
    
    if gap <= 0:
        return 0
    
    push_qty = gap * safety_factor
    return math.ceil(push_qty)


# ============ 演示主函数 ============

if __name__ == "__main__":
    # 测试场景:大润发联洋店 · 六月鲜500ml
    r = 137.0
    t = 7
    inventory = 420.0
    
    a = calculate_a(r, t)
    water_level = calculate_water_level(inventory, a)
    status = determine_status(water_level, NodeType.STORE)
    
    print("=== 心跳公式测试 ===")
    print(f"日销率 r = {r} 瓶/天")
    print(f"周期 T = {t} 天")
    print(f"心跳单元 a = {a} 瓶")
    print(f"当前库存 = {inventory} 瓶")
    print(f"水位 = {water_level}a")
    print(f"状态 = {status}")
    
    push_qty = calculate_omakase_qty(inventory, a)
    print(f"Omakase推单量 = {push_qty} 瓶")
    
    print("\n=== 三重验证测试 ===")
    history = [10, 11, 9, 0, 10, 45, 11, 10, 11, 10, 12, 11, 9, 10, 11]
    new_r, outliers = tri_validate_calibrate(history)
    print(f"原始数据: {history}")
    print(f"校准后r = {new_r}, 排除异常 {outliers} 个")
