"""
INFINITY OS · FastAPI主入口

启动:
  uvicorn src.main:app --reload --port 8080

访问:
  http://localhost:8080/docs       · Swagger API文档
  http://localhost:8080/api/health · 健康检查
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger
import sys

from src.config import settings
from src.api.agent_router import router as agent_router
from src.api.health_router import router as health_router
from src.schedulers.agent_scheduler import start_scheduler, stop_scheduler


# ============ 日志配置 ============

logger.remove()
logger.add(
    sys.stdout,
    level=settings.log_level,
    format="<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
           "<level>{level: <8}</level> | "
           "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - "
           "<level>{message}</level>",
)
logger.add(
    settings.log_file,
    level="INFO",
    rotation="100 MB",
    retention="30 days",
    encoding="utf-8",
)


# ============ 应用生命周期 ============

@asynccontextmanager
async def lifespan(app: FastAPI):
    """启动 + 关闭钩子"""
    # 启动
    logger.info("""
    ╔══════════════════════════════════════════╗
    ║                                          ║
    ║       INFINITY OS · Real Agent V1.0      ║
    ║              欣和SH · 启动成功            ║
    ║                                          ║
    ║   3个Agent调度时间(每周一):              ║
    ║     · 06:00  A值校准                     ║
    ║     · 07:00  蝴蝶效应                     ║
    ║     · 08:00  Omakase推单                 ║
    ║                                          ║
    ╚══════════════════════════════════════════╝
    """)
    
    # 启动调度器
    start_scheduler()
    
    yield
    
    # 关闭
    logger.info("INFINITY OS 正在关闭...")
    stop_scheduler()
    logger.info("INFINITY OS 已关闭")


# ============ FastAPI应用 ============

app = FastAPI(
    title="INFINITY OS",
    description="欣和SH · 战略指挥中台 · Real Agent V1.0",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS(开发环境放开)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(health_router)
app.include_router(agent_router)


@app.get("/")
def root():
    """根路径"""
    return {
        "system": "INFINITY OS",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/api/health",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "src.main:app",
        host="0.0.0.0",
        port=settings.app_port,
        reload=(settings.app_env == "development"),
    )
