"""
Repository层 · 数据访问

把所有Repository放一个文件 · 减少文件数量
每个Repository封装该实体的SQL查询
"""
from datetime import date
from decimal import Decimal
from typing import Optional
from sqlalchemy import select, func, and_, or_
from sqlalchemy.orm import Session

from src.models.node import Node
from src.models.heartbeat import Heartbeat
from src.models.alert import Alert
from src.models.action import Action
from src.models.node_target import NodeTarget
from src.models.learning_log import LearningLog


# ============ NodeRepository ============

class NodeRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def find_by_id(self, node_id: int) -> Optional[Node]:
        return self.db.get(Node, node_id)
    
    def find_by_code(self, code: str) -> Optional[Node]:
        return self.db.scalar(select(Node).where(Node.node_code == code))
    
    def find_by_type(self, node_type: str) -> list[Node]:
        return list(self.db.scalars(select(Node).where(Node.node_type == node_type)))
    
    def find_active(self) -> list[Node]:
        return list(self.db.scalars(select(Node).where(Node.status == 1)))
    
    def count_by_type(self) -> dict[str, int]:
        result = self.db.execute(
            select(Node.node_type, func.count(Node.id)).group_by(Node.node_type)
        )
        return {row[0]: row[1] for row in result}


# ============ HeartbeatRepository ============

class HeartbeatRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def find_recent(self, start_date: date) -> list[Heartbeat]:
        """读取从start_date开始的所有心跳数据"""
        return list(self.db.scalars(
            select(Heartbeat).where(Heartbeat.data_date >= start_date)
        ))
    
    def find_by_node_sku_recent(
        self, node_id: int, sku_code: str, days: int
    ) -> list[Heartbeat]:
        """找出某节点-SKU最近N条数据(按日期倒序)"""
        return list(self.db.scalars(
            select(Heartbeat)
            .where(
                Heartbeat.node_id == node_id,
                Heartbeat.sku_code == sku_code
            )
            .order_by(Heartbeat.data_date.desc())
            .limit(days)
        ))
    
    def find_low_water_by_date(
        self, target_date: date, threshold: Decimal
    ) -> list[Heartbeat]:
        """找出某日水位低于阈值的所有心跳"""
        return list(self.db.scalars(
            select(Heartbeat).where(
                Heartbeat.data_date == target_date,
                Heartbeat.water_level < threshold
            )
        ))
    
    def find_by_date(self, target_date: date) -> list[Heartbeat]:
        return list(self.db.scalars(
            select(Heartbeat).where(Heartbeat.data_date == target_date)
        ))
    
    def update_r_actual(self, hb_id: int, new_r: Decimal) -> None:
        """更新某条心跳的r_actual"""
        hb = self.db.get(Heartbeat, hb_id)
        if hb:
            hb.r_actual = new_r
            self.db.flush()
    
    def save(self, hb: Heartbeat) -> Heartbeat:
        self.db.add(hb)
        self.db.flush()
        return hb


# ============ AlertRepository ============

class AlertRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def save(self, alert: Alert) -> Alert:
        self.db.add(alert)
        self.db.flush()
        return alert
    
    def find_open_by_node_sku(self, node_id: int, sku_code: str) -> list[Alert]:
        """找出某节点+SKU的所有OPEN预警"""
        return list(self.db.scalars(
            select(Alert).where(
                Alert.node_id == node_id,
                Alert.sku_code == sku_code,
                Alert.status == "OPEN"
            )
        ))
    
    def find_open(self) -> list[Alert]:
        return list(self.db.scalars(select(Alert).where(Alert.status == "OPEN")))
    
    def count_by_type(self, since_date: date) -> dict[str, int]:
        result = self.db.execute(
            select(Alert.distortion_type, func.count(Alert.id))
            .where(Alert.created_at >= since_date)
            .group_by(Alert.distortion_type)
        )
        return {row[0]: row[1] for row in result}


# ============ ActionRepository ============

class ActionRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def save(self, action: Action) -> Action:
        self.db.add(action)
        self.db.flush()
        return action
    
    def find_pending(self) -> list[Action]:
        """找出待审批的Action(按金额倒序)"""
        return list(self.db.scalars(
            select(Action)
            .where(Action.status == "PENDING")
            .order_by(Action.recommended_amount.desc())
        ))
    
    def sum_by_agent_since(self, agent_source: str, since_date: date) -> Decimal:
        result = self.db.scalar(
            select(func.coalesce(func.sum(Action.recommended_amount), 0))
            .where(
                Action.agent_source == agent_source,
                Action.created_at >= since_date
            )
        )
        return result or Decimal(0)


# ============ NodeTargetRepository ============

class NodeTargetRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def find_active(
        self, node_id: int, sku_code: str, target_date: date
    ) -> Optional[NodeTarget]:
        """找出某节点+SKU在某日期生效的目标"""
        return self.db.scalar(
            select(NodeTarget)
            .where(
                NodeTarget.node_id == node_id,
                NodeTarget.sku_code == sku_code,
                NodeTarget.effective_from <= target_date,
                or_(
                    NodeTarget.effective_to.is_(None),
                    NodeTarget.effective_to >= target_date
                )
            )
            .order_by(NodeTarget.effective_from.desc())
            .limit(1)
        )


# ============ LearningLogRepository ============

class LearningLogRepository:
    def __init__(self, db: Session):
        self.db = db
    
    def save(self, log: LearningLog) -> LearningLog:
        self.db.add(log)
        self.db.flush()
        return log
    
    def count_by_agent(self, agent_name: str) -> int:
        return self.db.scalar(
            select(func.count(LearningLog.id))
            .where(LearningLog.agent_name == agent_name)
        ) or 0
