"""
INFINITY OS · 配置管理
基于 pydantic-settings · 自动加载 .env 文件

Spec: .kiro/steering/tech.md
"""
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """全局配置 · 单例"""
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore"
    )
    
    # ============ 数据库 ============
    database_url: str = "mysql+pymysql://root:CHANGE_ME@localhost:3306/infinity_os?charset=utf8mb4"
    
    # ============ Redis ============
    redis_url: str = "redis://localhost:6379/0"
    
    # ============ 汉询(外部数据源) ============
    hanxun_url: str = ""
    hanxun_enabled: bool = False
    
    # ============ Dcloud(外部数据源) ============
    dcloud_url: str = ""
    dcloud_enabled: bool = False
    
    # ============ 企微API ============
    wechat_corp_id: str = "CHANGE_ME"
    wechat_agent_id: str = "CHANGE_ME"
    wechat_secret: str = "CHANGE_ME"
    wechat_base_url: str = "https://qyapi.weixin.qq.com"
    wechat_enabled: bool = False
    
    # ============ Agent触发时间(Cron) ============
    agent_calibration_cron: str = "0 6 * * MON"
    agent_butterfly_cron: str = "0 7 * * MON"
    agent_omakase_cron: str = "0 8 * * MON"
    
    # ============ 阈值 ============
    a_calibration_max_change: float = 0.15
    butterfly_alert_max_count: int = 50
    omakase_max_amount: float = 1000000
    omakase_auto_approve_threshold: float = 50000
    
    # ============ 日志 ============
    log_level: str = "INFO"
    log_file: str = "logs/infinity_os.log"
    
    # ============ 应用 ============
    app_port: int = 8080
    app_env: str = "development"


# 全局单例
settings = Settings()
