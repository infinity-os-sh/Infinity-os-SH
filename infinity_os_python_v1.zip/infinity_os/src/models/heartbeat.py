"""
Heartbeat实体 · 对应 inf_heartbeat 表
每个节点每个SKU每天一条
"""
from datetime import date, datetime
from decimal import Decimal
from typing import Optional
from sqlalchemy import String, Integer, BigInteger, DateTime, Date, Numeric
from sqlalchemy.orm import Mapped, mapped_column
from src.models.base import Base


class Heartbeat(Base):
    __tablename__ = "inf_heartbeat"
    
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    node_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    sku_code: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    
    # 心跳数据
    r_actual: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    r_target: Mapped[Optional[Decimal]] = mapped_column(Numeric(10, 2))
    t_period: Mapped[int] = mapped_column(Integer, nullable=False, default=7)
    a_unit: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    
    # 库存与水位
    inventory_actual: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    water_level: Mapped[Decimal] = mapped_column(Numeric(5, 2), nullable=False)
    water_status: Mapped[str] = mapped_column(String(16), nullable=False)
    # OVERFLOW/FULL/WARN/LOW/EMPTY
    
    data_date: Mapped[date] = mapped_column(Date, nullable=False, index=True)
    data_source: Mapped[str] = mapped_column(String(32), nullable=False)
    # HANXUN/DCLOUD/SAP/MANUAL
    
    quality_score: Mapped[int] = mapped_column(Integer, default=100)
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    
    def __repr__(self) -> str:
        return (f"<Heartbeat node={self.node_id} sku={self.sku_code} "
                f"r={self.r_actual} water={self.water_level}a({self.water_status})>")
