"""
Alert实体 · 对应 inf_alerts 表
蝴蝶效应Agent输出
"""
from datetime import datetime
from typing import Optional
from sqlalchemy import String, BigInteger, DateTime, Text, JSON
from sqlalchemy.orm import Mapped, mapped_column
from src.models.base import Base


class Alert(Base):
    __tablename__ = "inf_alerts"
    
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    alert_code: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    
    node_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    sku_code: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    
    distortion_type: Mapped[str] = mapped_column(String(1), nullable=False, index=True)
    # A=压货 / B=促销 / C=窜货 / D=战略
    
    severity: Mapped[str] = mapped_column(String(16), nullable=False)
    # CRITICAL/HIGH/MEDIUM/LOW/INFO
    
    description: Mapped[Optional[str]] = mapped_column(Text)
    evidence_json: Mapped[Optional[dict]] = mapped_column(JSON)
    recommended_action: Mapped[Optional[str]] = mapped_column(Text)
    
    status: Mapped[str] = mapped_column(String(16), default="OPEN")
    # OPEN/CONFIRMED/RESOLVED/FALSE_POSITIVE
    
    assigned_to: Mapped[Optional[str]] = mapped_column(String(64))
    
    pushed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    confirmed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    
    def __repr__(self) -> str:
        return (f"<Alert {self.alert_code} type={self.distortion_type} "
                f"severity={self.severity} status={self.status}>")
