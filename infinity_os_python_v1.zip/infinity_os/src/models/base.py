"""
SQLAlchemy 基类配置
"""
from sqlalchemy.orm import DeclarativeBase, sessionmaker
from sqlalchemy import create_engine
from src.config import settings


class Base(DeclarativeBase):
    """所有Model的基类"""
    pass


# 主数据库引擎
engine = create_engine(
    settings.database_url,
    pool_size=20,
    max_overflow=10,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=False
)

# Session工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db():
    """FastAPI依赖注入用 · yield一个session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
