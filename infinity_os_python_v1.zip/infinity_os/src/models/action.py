"""
Action实体 · 对应 inf_actions 表
Agent输出 + 人工确认 + 执行结果
"""
from datetime import datetime
from decimal import Decimal
from typing import Optional
from sqlalchemy import String, BigInteger, DateTime, JSON, Numeric
from sqlalchemy.orm import Mapped, mapped_column
from src.models.base import Base


class Action(Base):
    __tablename__ = "inf_actions"
    
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    action_code: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)
    action_type: Mapped[str] = mapped_column(String(32), nullable=False)
    # RECOMMEND_ORDER/PROMOTION/CALIBRATE
    
    node_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    sku_code: Mapped[str] = mapped_column(String(64), nullable=False)
    agent_source: Mapped[str] = mapped_column(String(32), nullable=False)
    # OMAKASE/CALIBRATION/BUTTERFLY
    
    payload_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    recommended_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 2))
    confidence_score: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    
    status: Mapped[str] = mapped_column(String(16), default="PENDING")
    # PENDING/APPROVED/REJECTED/EXECUTED
    
    approver: Mapped[Optional[str]] = mapped_column(String(64))
    approved_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    executed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    
    outcome_json: Mapped[Optional[dict]] = mapped_column(JSON)
    feedback_json: Mapped[Optional[dict]] = mapped_column(JSON)
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    def __repr__(self) -> str:
        return (f"<Action {self.action_code} type={self.action_type} "
                f"amount={self.recommended_amount} status={self.status}>")
