"""
Node实体 · 对应 inf_nodes 表

Spec: .kiro/specs/agent-01-a-value-calibration/design.md 数据模型
"""
from datetime import datetime
from typing import Optional
from sqlalchemy import String, Integer, BigInteger, DateTime, CHAR
from sqlalchemy.orm import Mapped, mapped_column
from src.models.base import Base


class Node(Base):
    __tablename__ = "inf_nodes"
    
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    node_code: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    node_type: Mapped[str] = mapped_column(String(32), nullable=False)
    # FACTORY/WAREHOUSE/DISTRIBUTOR/SUB_DIST/STORE/CONSUMER
    
    node_name: Mapped[str] = mapped_column(String(128), nullable=False)
    parent_node_id: Mapped[Optional[int]] = mapped_column(BigInteger)
    ipo_stage: Mapped[int] = mapped_column(Integer, nullable=False)  # 0-13
    
    region: Mapped[Optional[str]] = mapped_column(String(64))
    city: Mapped[Optional[str]] = mapped_column(String(64))
    city_grade: Mapped[Optional[str]] = mapped_column(CHAR(1))  # A/B/C/D
    path: Mapped[str] = mapped_column(String(2), default="P1")  # P1/P2
    
    status: Mapped[int] = mapped_column(Integer, default=1)
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    def __repr__(self) -> str:
        return f"<Node id={self.id} code={self.node_code} type={self.node_type}>"
