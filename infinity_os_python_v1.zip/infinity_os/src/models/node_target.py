"""
NodeTarget实体 · 对应 inf_node_targets 表
业务团队录入的节点目标
"""
from datetime import date, datetime
from decimal import Decimal
from typing import Optional
from sqlalchemy import String, Integer, BigInteger, DateTime, Date, Numeric
from sqlalchemy.orm import Mapped, mapped_column
from src.models.base import Base


class NodeTarget(Base):
    __tablename__ = "inf_node_targets"
    
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    node_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    sku_code: Mapped[str] = mapped_column(String(64), nullable=False)
    
    r_target: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    grade: Mapped[int] = mapped_column(Integer, nullable=False)  # 1/2/3/4
    grade_coefficient: Mapped[Decimal] = mapped_column(Numeric(3, 2), nullable=False)
    # 2.0/1.5/1.0/0.7
    
    expense_ratio_min: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 4))
    expense_ratio_max: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 4))
    
    effective_from: Mapped[date] = mapped_column(Date, nullable=False)
    effective_to: Mapped[Optional[date]] = mapped_column(Date)
    
    created_by: Mapped[str] = mapped_column(String(64), nullable=False)
    approved_by: Mapped[Optional[str]] = mapped_column(String(64))
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now)
    
    def __repr__(self) -> str:
        return f"<NodeTarget node={self.node_id} sku={self.sku_code} r_target={self.r_target}>"
