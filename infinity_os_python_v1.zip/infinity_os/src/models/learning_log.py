"""
LearningLog实体 · 对应 inf_learning_log 表
Agent的"自我进化"基础
"""
from datetime import datetime
from decimal import Decimal
from typing import Optional
from sqlalchemy import String, BigInteger, DateTime, JSON, Numeric
from sqlalchemy.orm import Mapped, mapped_column
from src.models.base import Base


class LearningLog(Base):
    __tablename__ = "inf_learning_log"
    
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    
    agent_name: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    # A_VALUE_CALIBRATION / BUTTERFLY_EFFECT / OMAKASE
    
    event_type: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    # CALIBRATION_DONE / DECISION_MADE / FEEDBACK_RECEIVED / MODEL_UPDATE
    
    input_json: Mapped[Optional[dict]] = mapped_column(JSON)
    decision_json: Mapped[Optional[dict]] = mapped_column(JSON)
    outcome_json: Mapped[Optional[dict]] = mapped_column(JSON)
    feedback_json: Mapped[Optional[dict]] = mapped_column(JSON)
    
    accuracy_score: Mapped[Optional[Decimal]] = mapped_column(Numeric(5, 2))
    
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.now, index=True)
    
    def __repr__(self) -> str:
        return f"<LearningLog agent={self.agent_name} event={self.event_type}>"
