"""
Agent控制器 · 提供手动触发REST接口

用途:
  1. 测试期·不等周一06:00·立刻测试
  2. 紧急情况·临时手动跑Agent
  3. 第三方系统集成·按需触发

路径前缀:/api/agent
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from loguru import logger

from src.models.base import get_db
from src.agents.a_value_calibration import AValueCalibrationAgent
from src.agents.butterfly_effect import ButterflyEffectAgent
from src.agents.omakase_recommend import OmakaseRecommendAgent


router = APIRouter(prefix="/api/agent", tags=["agent"])


@router.post("/calibrate")
def trigger_calibration(db: Session = Depends(get_db)):
    """手动触发A值校准"""
    logger.info("📡 API触发: A值校准")
    try:
        agent = AValueCalibrationAgent(db)
        report = agent.run_full_calibration()
        return {
            "status": "SUCCESS",
            "auto_approved_count": report.auto_approved_count,
            "needs_review_count": report.needs_review_count,
            "insufficient_data_count": report.insufficient_data_count,
            "failed_count": report.failed_count,
            "total_duration_ms": report.total_duration_ms,
        }
    except Exception as e:
        logger.error(f"API触发A值校准失败: {e}")
        raise HTTPException(500, str(e))


@router.post("/butterfly")
def trigger_butterfly(db: Session = Depends(get_db)):
    """手动触发蝴蝶效应"""
    logger.info("📡 API触发: 蝴蝶效应")
    try:
        agent = ButterflyEffectAgent(db)
        report = agent.run_full_detection()
        return {
            "status": "SUCCESS",
            "total_alerts": report.total_alerts,
            "alerts_by_type": dict(report.alerts_by_type),
            "total_duration_ms": report.total_duration_ms,
        }
    except Exception as e:
        logger.error(f"API触发蝴蝶效应失败: {e}")
        raise HTTPException(500, str(e))


@router.post("/omakase")
def trigger_omakase(db: Session = Depends(get_db)):
    """手动触发Omakase推单"""
    logger.info("📡 API触发: Omakase推单")
    try:
        agent = OmakaseRecommendAgent(db)
        report = agent.run_full_recommendation()
        return {
            "status": "SUCCESS",
            "recommended_count": report.recommended_count,
            "skipped_due_to_alert": report.skipped_due_to_alert,
            "total_amount": float(report.total_amount),
            "failed_count": report.failed_count,
            "total_duration_ms": report.total_duration_ms,
        }
    except Exception as e:
        logger.error(f"API触发Omakase推单失败: {e}")
        raise HTTPException(500, str(e))


@router.post("/run-all")
def run_all(db: Session = Depends(get_db)):
    """完整跑一次:校准→蝴蝶→Omakase(测试用)"""
    logger.info("📡 API触发: 完整流程")
    try:
        # 1. 校准
        calib_report = AValueCalibrationAgent(db).run_full_calibration()
        # 2. 蝴蝶
        butterfly_report = ButterflyEffectAgent(db).run_full_detection()
        # 3. Omakase
        omakase_report = OmakaseRecommendAgent(db).run_full_recommendation()
        
        return {
            "status": "SUCCESS",
            "calibration": {
                "auto": calib_report.auto_approved_count,
                "review": calib_report.needs_review_count,
            },
            "butterfly": {
                "alerts": butterfly_report.total_alerts,
                "by_type": dict(butterfly_report.alerts_by_type),
            },
            "omakase": {
                "count": omakase_report.recommended_count,
                "amount": float(omakase_report.total_amount),
            },
        }
    except Exception as e:
        logger.error(f"完整流程失败: {e}")
        raise HTTPException(500, str(e))
