"""
健康检查 + 系统总览

GET /api/health           · 基础健康
GET /api/health/dashboard · 仪表盘
"""
from datetime import datetime, date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from loguru import logger

from src.models.base import get_db
from src.repositories.repos import (
    NodeRepository, HeartbeatRepository, AlertRepository
)


router = APIRouter(prefix="/api/health", tags=["health"])


@router.get("")
def health_check(db: Session = Depends(get_db)):
    """基础健康检查"""
    result = {
        "status": "UP",
        "system": "INFINITY OS",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
    }
    
    try:
        node_repo = NodeRepository(db)
        node_count = len(node_repo.find_active())
        result["database"] = "CONNECTED"
        result["node_count"] = node_count
    except Exception as e:
        result["database"] = "ERROR"
        result["error"] = str(e)
        raise HTTPException(503, detail=result)
    
    return result


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db)):
    """仪表盘 · 综合系统状态"""
    node_repo = NodeRepository(db)
    hb_repo = HeartbeatRepository(db)
    alert_repo = AlertRepository(db)
    
    # 节点统计
    nodes_by_type = node_repo.count_by_type()
    
    # 今日心跳水位分布
    today = date.today()
    today_hb = hb_repo.find_by_date(today)
    water_status_dist: dict[str, int] = {}
    for hb in today_hb:
        water_status_dist[hb.water_status] = water_status_dist.get(hb.water_status, 0) + 1
    
    # 今日预警分布
    alerts_by_type = alert_repo.count_by_type(today)
    
    return {
        "timestamp": datetime.now().isoformat(),
        "nodes_by_type": nodes_by_type,
        "total_nodes": sum(nodes_by_type.values()),
        "today_water_status": water_status_dist,
        "today_alerts_by_type": alerts_by_type,
    }
