"""
单元测试 · 心跳公式核心

Spec: .kiro/specs/agent-01-a-value-calibration/requirements.md
"""
import pytest
from src.utils.heartbeat import (
    NodeType, WaterStatus,
    calculate_a, calculate_water_level, determine_status,
    is_outlier, tri_validate_calibrate, is_reasonable_change,
    calculate_omakase_qty,
)


class TestCalculateA:
    """心跳单元 a = r × T"""
    
    def test_normal_case(self):
        """正常输入"""
        assert calculate_a(10, 7) == 70
    
    def test_zero_r(self):
        """r=0 (断货日)"""
        assert calculate_a(0, 7) == 0
    
    def test_decimal_r(self):
        """小数r"""
        assert calculate_a(10.5, 7) == 73.5
    
    def test_negative_r_raises(self):
        """r<0 抛异常"""
        with pytest.raises(ValueError):
            calculate_a(-1, 7)
    
    def test_zero_t_raises(self):
        """t=0 抛异常"""
        with pytest.raises(ValueError):
            calculate_a(10, 0)


class TestCalculateWaterLevel:
    """水位 = inventory ÷ a"""
    
    def test_normal(self):
        assert calculate_water_level(150, 50) == 3.0
    
    def test_zero_a(self):
        """a=0时水位=0"""
        assert calculate_water_level(100, 0) == 0


class TestDetermineStatus:
    """水位状态判断"""
    
    def test_store_full(self):
        """门店2.5a → FULL"""
        assert determine_status(2.5, NodeType.STORE) == WaterStatus.FULL
    
    def test_store_overflow(self):
        """门店4a → OVERFLOW"""
        assert determine_status(4.0, NodeType.STORE) == WaterStatus.OVERFLOW
    
    def test_store_warn(self):
        """门店1.5a → WARN"""
        assert determine_status(1.5, NodeType.STORE) == WaterStatus.WARN
    
    def test_distributor_full(self):
        """经销商1.5a → FULL"""
        assert determine_status(1.5, NodeType.DISTRIBUTOR) == WaterStatus.FULL
    
    def test_sub_dist_overflow(self):
        """二批商1.5a → OVERFLOW(应严控)"""
        assert determine_status(1.5, NodeType.SUB_DIST) == WaterStatus.OVERFLOW
    
    def test_empty(self):
        """0库存 → EMPTY"""
        assert determine_status(0, NodeType.STORE) == WaterStatus.EMPTY


class TestIsOutlier:
    """异常值检测"""
    
    def test_zero(self):
        """r=0 → 异常"""
        assert is_outlier(0, 10) is True
    
    def test_normal(self):
        """正常值"""
        assert is_outlier(11, 10) is False
    
    def test_promo(self):
        """r > median × 3 → 异常"""
        assert is_outlier(35, 10) is True
    
    def test_zero_median(self):
        """median=0 → 不能判断"""
        assert is_outlier(10, 0) is False


class TestTriValidate:
    """三重验证校准"""
    
    def test_normal_data(self):
        """正常数据"""
        data = [10, 11, 9, 10, 12, 11, 10, 11, 10, 12, 11, 10, 9, 10, 11]
        new_r, outliers = tri_validate_calibrate(data)
        assert 9 < new_r < 12  # 平均接近10
        assert outliers == 0
    
    def test_with_zeros(self):
        """含断货日"""
        data = [10, 11, 0, 0, 10, 11, 10, 11, 10, 12, 11, 10]
        new_r, outliers = tri_validate_calibrate(data)
        assert outliers >= 2  # 至少排除2个0
    
    def test_with_promo(self):
        """含促销日(r暴涨)"""
        data = [10, 11, 45, 40, 10, 11, 10, 11, 10, 12, 11, 10]
        new_r, outliers = tri_validate_calibrate(data)
        assert outliers >= 2  # 至少排除2个促销日
        assert new_r < 15  # 平均不应被促销日抬高
    
    def test_insufficient_data(self):
        """数据不足"""
        data = [10, 11, 0, 0]
        new_r, outliers = tri_validate_calibrate(data)
        assert new_r == 0  # 数据不足返回0
    
    def test_empty(self):
        """空数据"""
        new_r, outliers = tri_validate_calibrate([])
        assert new_r == 0


class TestIsReasonableChange:
    """合理性校验"""
    
    def test_small_change(self):
        """变化5% → 合理"""
        assert is_reasonable_change(10, 10.5, 0.15) is True
    
    def test_big_change(self):
        """变化50% → 不合理"""
        assert is_reasonable_change(10, 15, 0.15) is False
    
    def test_first_time(self):
        """首次校准(old=0)"""
        assert is_reasonable_change(0, 10, 0.15) is True


class TestOmakaseQty:
    """Omakase推单计算"""
    
    def test_normal(self):
        """正常推单"""
        # current=50 a=33 → target=99 gap=49 push=49*1.2=58.8 → 59
        assert calculate_omakase_qty(50, 33, 1.2) == 59
    
    def test_no_need(self):
        """库存够 → 不推"""
        # current=120 > 3a=99
        assert calculate_omakase_qty(120, 33, 1.2) == 0
    
    def test_zero_inventory(self):
        """库存=0"""
        # gap=99 push=99*1.2=118.8 → 119
        assert calculate_omakase_qty(0, 33, 1.2) == 119
