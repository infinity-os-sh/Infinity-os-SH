# INFINITY OS · Real Agent · Python版 V1.0

**Spec-First · Python 3.11 · FastAPI + SQLAlchemy + APScheduler**

> 本包是 Java版(infinity_os_real_agent_v1.zip)的Python翻译。  
> 业务逻辑100%一致 · 技术栈适配欣和团队Python+Kiro环境。

---

## 📦 这是什么

INFINITY OS 3个核心Agent的Python完整实现:

| Agent | 触发时间 | 职责 | Spec |
|---|---|---|---|
| A值校准 | 周一 06:00 | 三重验证校准r值 | `.kiro/specs/agent-01-a-value-calibration/` |
| 蝴蝶效应 | 周一 07:00 | 检测4类失真(A/B/C/D) | `.kiro/specs/agent-02-butterfly-effect/` |
| Omakase推单 | 周一 08:00 | 自动补货推单 | `.kiro/specs/agent-03-omakase-recommend/` |

**触发顺序固定不可倒置** · 校准→检测→推单。

---

## 🚀 快速开始(Tech Lead 3天落地)

### Day 1 · 环境搭建(4小时)

```bash
# 1. 克隆代码
git clone <repo-url>
cd infinity_os

# 2. 创建虚拟环境
python3.11 -m venv venv
source venv/bin/activate    # Windows: venv\Scripts\activate

# 3. 安装依赖
pip install -r requirements.txt

# 4. 配置环境变量
cp .env.example .env
# 编辑.env · 填写MySQL/Redis/企微配置

# 5. 创建数据库
mysql -u root -p < sql/001_init_tables.sql

# 6. 启动
uvicorn src.main:app --reload --port 8080
```

访问 `http://localhost:8080/docs` 看FastAPI自动生成的API文档。

### Day 2 · Code Review(8小时)

- [ ] 通读全部Python代码
- [ ] 运行 `pytest tests/` · 全部通过
- [ ] 测试3个Agent手动触发
  ```bash
  curl -X POST http://localhost:8080/api/agent/calibrate
  curl -X POST http://localhost:8080/api/agent/butterfly
  curl -X POST http://localhost:8080/api/agent/omakase
  ```

### Day 3 · 真实数据接入(8小时)

- [ ] 联系郭工 · 获取汉询/Dcloud只读账号
- [ ] 配置 `.env` · 填写真实数据源
- [ ] 启动APScheduler · 等待周一06:00自动跑
- [ ] 配置企微API · 测试一条推送

**3天后 · INFINITY OS第一个真Agent上线 ✅**

---

## 🏗️ 项目结构

```
infinity_os/
├── .kiro/                       ← Kiro Spec(必看·定义业务)
│   ├── steering/
│   └── specs/
├── src/
│   ├── main.py                  ← FastAPI入口
│   ├── config.py                ← 配置
│   ├── models/                  ← SQLAlchemy实体
│   ├── repositories/            ← 数据访问
│   ├── agents/                  ← 3个核心Agent ★
│   ├── schedulers/              ← 调度
│   ├── api/                     ← REST接口
│   └── utils/                   ← 工具
│       └── heartbeat.py         ← 心跳公式核心
├── tests/                       ← 测试
├── sql/                         ← DDL
├── requirements.txt
├── .env.example
└── docker-compose.yml
```

---

## 🔥 核心公式速查

### 心跳单元
```python
a = r * t   # r = 日销率 · t = 周转周期
```

### 三层水位
```
零售层(STORE):     3a满 → 2a预警 → 1a紧急
经销商(DISTRIBUTOR): 2a满 → 1a预警 → 0a断货
二批商(SUB_DIST):   1a严控(P2路径)
```

### 4类失真优先级
```
D类(战略) → A类(压货) → B类(促销) → C类(窜货)
```

### Omakase推单
```python
push_qty = math.ceil((3 * a - current_inventory) * 1.2)
# 触发:water_level < 2 且 无A/D类OPEN预警
```

---

## ⏰ 触发时间表

```
周一 06:00 → A值校准    (准备好基准r值)
周一 07:00 → 蝴蝶效应    (基于校准后r检测失真)
周一 08:00 → Omakase推单 (基于水位+预警生成推单)
```

修改触发时间在 `src/config.py`:
```python
agent_calibration_cron = "0 0 6 * * MON"
agent_butterfly_cron = "0 0 7 * * MON"  
agent_omakase_cron = "0 0 8 * * MON"
```

---

## 🧪 测试

```bash
# 跑全部测试
pytest tests/ -v

# 跑单个Agent测试
pytest tests/test_calibration_agent.py -v

# 看覆盖率
pytest --cov=src tests/
```

**核心算法目标覆盖率: 100%** · 业务Agent: >80%

---

## 📡 REST API

启动后访问 `http://localhost:8080/docs` 看完整API文档。

### 手动触发(测试用)
```
POST /api/agent/calibrate    A值校准
POST /api/agent/butterfly    蝴蝶效应
POST /api/agent/omakase      Omakase推单
POST /api/agent/run-all      完整流程
```

### 健康检查
```
GET  /api/health             基础健康
GET  /api/health/dashboard   系统总览
```

---

## ⚠️ 关键依赖

### 必须接入的外部数据源
1. **汉询** · `rixiao` 字段 · 真实日销
2. **Dcloud EPP** · `wm_stock_matnr` 表 · 实时库存
3. **SAP BSID** · 应收账款 · (Phase 3再接)

### 必须配置的外部服务
1. **企微API** · 推送预警/推单
2. **Redis** · 缓存
3. **MySQL 5.7+** · 主数据库

---

## 🔍 上线后第一周观察重点

| 观察项 | 目标 | 异常处理 |
|---|---|---|
| 周一06:00校准是否触发 | ✅ | 检查Scheduler日志 |
| 周一07:00蝴蝶是否触发 | ✅ | 检查Agent依赖 |
| 周一08:00 Omakase是否触发 | ✅ | 检查蝴蝶完成状态 |
| 校准结果与上周差异 | ±15% | >15%人工Review |
| 4类失真预警条数 | <50条 | >50说明阈值错 |
| Omakase推单总额 | <100万 | >100万人工审批 |
| 企微推送成功率 | >95% | <95%检查API |

---

## 📞 遇到问题

- **Agent不触发** → 检查 `src/schedulers/agent_scheduler.py` 的Cron表达式 + 时区配置
- **数据为空** → 检查 `.env` 的DATABASE_URL + 表权限
- **企微推送失败** → 检查WeChat配置 + Token有效期
- **学习日志不写入** → 检查反馈接口是否被调用

---

## 🔗 相关资源

- **Spec文档:** `.kiro/specs/` 目录(本项目内)
- **GitHub Pages:** https://infinity-os-sh.github.io/Infinity-os-SH/
- **Java版参考:** `infinity_os_real_agent_v1.zip`(架构设计参考)

---

**INFINITY OS · Python V1.0**  
**FROM:** DS · **TO:** Tech Lead + 开发团队  
**2026-04-22**
