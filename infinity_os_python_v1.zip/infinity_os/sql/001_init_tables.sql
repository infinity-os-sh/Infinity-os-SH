-- ============================================================
-- INFINITY OS · MySQL DDL · V1.0 · Python版
-- 6张核心表 · Universal Node Schema
-- 创建时间:2026-04-22
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- 表1 · inf_nodes · 节点定义表
-- ============================================================
DROP TABLE IF EXISTS `inf_nodes`;
CREATE TABLE `inf_nodes` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `node_code` VARCHAR(64) NOT NULL,
  `node_type` VARCHAR(32) NOT NULL COMMENT 'FACTORY/WAREHOUSE/DISTRIBUTOR/SUB_DIST/STORE/CONSUMER',
  `node_name` VARCHAR(128) NOT NULL,
  `parent_node_id` BIGINT DEFAULT NULL,
  `ipo_stage` TINYINT NOT NULL COMMENT '0-13',
  `region` VARCHAR(64) DEFAULT NULL,
  `city` VARCHAR(64) DEFAULT NULL,
  `city_grade` CHAR(1) DEFAULT NULL COMMENT 'A/B/C/D',
  `path` VARCHAR(2) DEFAULT 'P1' COMMENT 'P1直供/P2分销',
  `status` TINYINT DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_node_code` (`node_code`),
  KEY `idx_type_ipo` (`node_type`, `ipo_stage`),
  KEY `idx_parent` (`parent_node_id`),
  KEY `idx_city_grade` (`city`, `city_grade`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='节点定义表';


-- ============================================================
-- 表2 · inf_heartbeat · 心跳数据表
-- ============================================================
DROP TABLE IF EXISTS `inf_heartbeat`;
CREATE TABLE `inf_heartbeat` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `node_id` BIGINT NOT NULL,
  `sku_code` VARCHAR(64) NOT NULL,
  `r_actual` DECIMAL(10,2) NOT NULL,
  `r_target` DECIMAL(10,2) DEFAULT NULL,
  `t_period` INT NOT NULL DEFAULT 7,
  `a_unit` DECIMAL(10,2) NOT NULL,
  `inventory_actual` DECIMAL(12,2) NOT NULL,
  `water_level` DECIMAL(5,2) NOT NULL,
  `water_status` VARCHAR(16) NOT NULL COMMENT 'OVERFLOW/FULL/WARN/LOW/EMPTY',
  `data_date` DATE NOT NULL,
  `data_source` VARCHAR(32) NOT NULL COMMENT 'HANXUN/DCLOUD/SAP/MANUAL',
  `quality_score` TINYINT DEFAULT 100,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_node_sku_date` (`node_id`, `sku_code`, `data_date`),
  KEY `idx_water_status` (`water_status`),
  KEY `idx_data_date` (`data_date`),
  KEY `idx_sku` (`sku_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='心跳数据表';


-- ============================================================
-- 表3 · inf_alerts · 预警表
-- ============================================================
DROP TABLE IF EXISTS `inf_alerts`;
CREATE TABLE `inf_alerts` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `alert_code` VARCHAR(32) NOT NULL,
  `node_id` BIGINT NOT NULL,
  `sku_code` VARCHAR(64) NOT NULL,
  `distortion_type` CHAR(1) NOT NULL COMMENT 'A/B/C/D',
  `severity` VARCHAR(16) NOT NULL COMMENT 'CRITICAL/HIGH/MEDIUM/LOW/INFO',
  `description` TEXT,
  `evidence_json` JSON,
  `recommended_action` TEXT,
  `status` VARCHAR(16) DEFAULT 'OPEN',
  `assigned_to` VARCHAR(64) DEFAULT NULL,
  `pushed_at` DATETIME DEFAULT NULL,
  `confirmed_at` DATETIME DEFAULT NULL,
  `resolved_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_alert_code` (`alert_code`),
  KEY `idx_node_sku` (`node_id`, `sku_code`),
  KEY `idx_distortion_severity` (`distortion_type`, `severity`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='预警表';


-- ============================================================
-- 表4 · inf_actions · 动作表
-- ============================================================
DROP TABLE IF EXISTS `inf_actions`;
CREATE TABLE `inf_actions` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `action_code` VARCHAR(32) NOT NULL,
  `action_type` VARCHAR(32) NOT NULL,
  `node_id` BIGINT NOT NULL,
  `sku_code` VARCHAR(64) NOT NULL,
  `agent_source` VARCHAR(32) NOT NULL,
  `payload_json` JSON NOT NULL,
  `recommended_amount` DECIMAL(12,2) DEFAULT NULL,
  `confidence_score` DECIMAL(5,2) DEFAULT NULL,
  `status` VARCHAR(16) DEFAULT 'PENDING',
  `approver` VARCHAR(64) DEFAULT NULL,
  `approved_at` DATETIME DEFAULT NULL,
  `executed_at` DATETIME DEFAULT NULL,
  `outcome_json` JSON DEFAULT NULL,
  `feedback_json` JSON DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_action_code` (`action_code`),
  KEY `idx_node_sku` (`node_id`, `sku_code`),
  KEY `idx_agent_source` (`agent_source`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='动作表';


-- ============================================================
-- 表5 · inf_node_targets · 节点目标表
-- ============================================================
DROP TABLE IF EXISTS `inf_node_targets`;
CREATE TABLE `inf_node_targets` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `node_id` BIGINT NOT NULL,
  `sku_code` VARCHAR(64) NOT NULL,
  `r_target` DECIMAL(10,2) NOT NULL,
  `grade` TINYINT NOT NULL COMMENT '1/2/3/4',
  `grade_coefficient` DECIMAL(3,2) NOT NULL COMMENT '2.0/1.5/1.0/0.7',
  `expense_ratio_min` DECIMAL(5,4) DEFAULT NULL,
  `expense_ratio_max` DECIMAL(5,4) DEFAULT NULL,
  `effective_from` DATE NOT NULL,
  `effective_to` DATE DEFAULT NULL,
  `created_by` VARCHAR(64) NOT NULL,
  `approved_by` VARCHAR(64) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_node_sku_effective` (`node_id`, `sku_code`, `effective_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='节点目标表';


-- ============================================================
-- 表6 · inf_learning_log · 学习日志
-- ============================================================
DROP TABLE IF EXISTS `inf_learning_log`;
CREATE TABLE `inf_learning_log` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `agent_name` VARCHAR(32) NOT NULL,
  `event_type` VARCHAR(32) NOT NULL,
  `input_json` JSON,
  `decision_json` JSON,
  `outcome_json` JSON,
  `feedback_json` JSON,
  `accuracy_score` DECIMAL(5,2) DEFAULT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_agent_event` (`agent_name`, `event_type`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学习日志 · Agent自我进化基础';

SET FOREIGN_KEY_CHECKS = 1;
