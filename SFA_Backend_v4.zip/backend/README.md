# INFINITY OS · SFA 后端 v4
## 给开发团队的完整说明

---

## 核心设计变化（v3 → v4）

**v3逻辑（已废弃）：** 按SKU选择 → 每个SKU分别填货架+仓库
**v4逻辑（当前版本）：** 按位置选择 → 在每个位置填该位置所有SKU的数量

---

## 文件清单

```
schema.sql                    ← 数据库建表脚本（先执行这个）
entity/Entities.java          ← 所有JPA实体类
dto/DTOs.java                 ← 请求/响应DTO
service/HeartbeatService.java ← 心跳水位计算引擎（核心）
service/VisitService.java     ← 拜访业务逻辑
service/Services.java         ← CB积分/企微推送/Controller/ApiResponse
resources/application.yml     ← 配置文件 + pom.xml
```

---

## API接口文档

### Base URL
```
http://your-server.com/api/v1
```

---

### 1. 获取门店详情
**GET** `/stores/{storeId}`

返回该门店的陈列位置列表和SKU目标销速。
前端进入门店时调用，获取需要盘点的位置和SKU列表。

**响应示例：**
```json
{
  "success": true,
  "data": {
    "storeId": 1,
    "storeName": "家乐福古北店",
    "grade": "S+",
    "visitCycleT": 7,
    "storeType": "大卖场",
    "positions": [
      { "positionTypeId": 1, "typeCode": "shelf", "typeName": "主货架",
        "icon": "📦", "isStorage": false, "sortOrder": 1 },
      { "positionTypeId": 9, "typeCode": "storage", "typeName": "后仓",
        "icon": "🏪", "isStorage": true, "sortOrder": 9 }
    ],
    "skuTargets": [
      { "skuId": 1, "skuName": "六月鲜极鲜酱油 500ml",
        "targetR": 9.3, "aValue": 65.1, "bottlesPerCase": 12, "colorHex": "F5A623" }
    ]
  }
}
```

---

### 2. 开始拜访（GPS打卡）
**POST** `/visits/start`

```json
// 请求
{
  "storeId": 1,
  "userId": 101,
  "checkinLat": 31.2304,
  "checkinLng": 121.4737
}

// 响应
{
  "success": true,
  "data": {
    "visitId": 5001,
    "visitCode": "A3F8B2C1D4E5",
    "checkinValid": true,
    "distanceMeters": 45.2,
    "message": "打卡成功"
  }
}
```

---

### 3. 提交位置盘点数据
**POST** `/visits/position`

每完成一个位置调用一次。
后仓位置：cases填箱数，bottles填0。
货架/端架等：bottles填瓶数，cases填0。

```json
// 请求（主货架示例）
{
  "visitId": 5001,
  "positionTypeId": 1,
  "isTemporary": false,
  "skuData": {
    "1": { "bottles": 48, "cases": 0 },
    "2": { "bottles": 18, "cases": 0 },
    "3": { "bottles": 12, "cases": 0 },
    "4": { "bottles": 24, "cases": 0 }
  }
}

// 请求（后仓示例）
{
  "visitId": 5001,
  "positionTypeId": 9,
  "isTemporary": false,
  "skuData": {
    "1": { "bottles": 0, "cases": 3 },
    "2": { "bottles": 0, "cases": 2 }
  }
}

// 响应（含实时水位）
{
  "success": true,
  "data": {
    "positionInventoryId": 301,
    "progressDone": 3,
    "progressTotal": 5,
    "currentWaterLevels": [
      {
        "skuId": 1,
        "skuName": "六月鲜极鲜酱油 500ml",
        "allTotal": 84,
        "aValue": 65.1,
        "waterLevel": 1.290,
        "waterStatus": "warn",
        "waterLabel": "预警 ⚠️",
        "waterColor": "#f5a623",
        "actualR": 7.2,
        "targetR": 9.3,
        "achievementPct": 77.42,
        "daysRemaining": 11.7,
        "triggerReorder": true,
        "triggerButterfly": false
      }
    ]
  }
}
```

---

### 4. 上传位置照片
**POST** `/visits/{visitId}/photo/{positionTypeId}`

Content-Type: multipart/form-data
字段名：file

```
// 响应
{
  "success": true,
  "data": "https://your-oss.com/photos/2024/01/15/shelf_5001_1.jpg"
}
```

---

### 5. 最终提交拜访
**POST** `/visits/submit`

```json
// 请求
{ "visitId": 5001 }

// 响应
{
  "success": true,
  "data": {
    "visitCode": "A3F8B2C1D4E5",
    "storeName": "家乐福古北店",
    "positionsCompleted": 5,
    "photosUploaded": 4,
    "cbEarned": 28,
    "waterLevels": [...],
    "alerts": [
      "🔴 味达美金标酱油 500ml 库存危险，已触发紧急补货推单"
    ],
    "agentActions": [
      "无菜单推单Agent → 味达美 补货指令已发送",
      "A值校准Agent → 各SKU r值已更新",
      "Uber激励Agent → CB+28 已到账",
      "货架识别训练库 → 4张照片已入库"
    ],
    "submitTime": "01/15 14:32"
  }
}
```

---

### 6. 添加临时异位位置
**POST** `/visits/{visitId}/add-position/{positionTypeId}`

业务员发现新的临时异位时调用。

---

### 7. 实时水位查询
**GET** `/visits/{visitId}/water-levels`

随时查询当前已录入数据的水位状态。

---

## 数据库关键表关系

```
stores (门店)
  └── store_positions (门店陈列位置配置)
  └── store_sku_targets (门店SKU目标配置)

visit_reports (拜访主记录)
  └── position_inventories (位置盘点记录)  ← 核心：按位置
        └── position_sku_inventory (SKU数量明细)  ← 每位置每SKU
  └── sku_water_levels (水位快照)  ← 提交时计算
  └── price_records (价签记录)
  └── training_photos (训练图片)
```

---

## 心跳公式实现说明

```java
// 水位 = 总库存 ÷ a值
BigDecimal waterLevel = totalBottles / aValue;

// 状态判断
if (waterLevel >= 3.0) → full    （满仓）
if (waterLevel >= 2.0) → healthy （健康）
if (waterLevel >= 1.0) → warn    （预警 → 触发推单建议）
if (waterLevel <  1.0) → danger  （危险 → 触发企微预警）

// 实际销速
actualR = (上次库存 - 本次库存) ÷ 间隔天数
// 若无历史：actualR = 本次库存 ÷ T
```

---

## 企微推送配置

在 application.yml 中配置：
```yaml
wechat:
  work:
    webhook:
      url: https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=你的webhook密钥
```

触发条件：
- 水位 < 1a → 立即推送蝴蝶效应预警
- 水位 < 2a → 推送无菜单推单建议
- 价格 < ¥17 → 推送C类失真预警

---

## 部署步骤

```bash
# 1. 建库
mysql -u root -p < schema.sql

# 2. 修改配置
vim src/main/resources/application.yml
# 填入：数据库密码、企微Webhook、OSS配置

# 3. 打包
mvn clean package -DskipTests

# 4. 启动
java -jar target/sfa-backend-4.0.0.jar

# 5. 验证
curl http://localhost:8080/api/v1/stores/1
```

---

## 与现有SFA系统的对接

现有Java文件（InventoryReportActivity.java）需要修改：

**原来的调用方式（v3，按SKU）：**
```
选择SKU → 填货架数 → 填仓库数 → 提交
```

**新的调用方式（v4，按位置）：**
```
GET /api/v1/stores/{storeId}   → 获取位置列表
POST /api/v1/visits/start      → GPS打卡
POST /api/v1/visits/position   → 提交每个位置（循环调用）
POST /api/v1/visits/{id}/photo → 上传照片
POST /api/v1/visits/submit     → 最终提交
```

---

*INFINITY OS · 欣和SH · SFA Backend v4.0*
*对接问题请联系 T.San*
