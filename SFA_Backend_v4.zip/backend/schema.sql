-- ============================================================
-- INFINITY OS · SFA 库存上报 v4 数据库设计
-- 数据库：MySQL 8.0+
-- 设计原则：位置优先，SKU为次
-- ============================================================

CREATE DATABASE IF NOT EXISTS xinhe_sfa DEFAULT CHARACTER SET utf8mb4;
USE xinhe_sfa;

-- ------------------------------------------------------------
-- 1. 门店表
-- ------------------------------------------------------------
CREATE TABLE stores (
    id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_code    VARCHAR(32)  NOT NULL UNIQUE COMMENT '门店编码（SFA系统唯一标识）',
    store_name    VARCHAR(128) NOT NULL COMMENT '门店名称',
    store_type    VARCHAR(32)  NOT NULL COMMENT '门店类型：大卖场/标准超市/便利店/餐饮',
    grade         VARCHAR(8)   NOT NULL COMMENT '门店等级：S+/S/A/B/C/D',
    visit_cycle_t INT          NOT NULL DEFAULT 7 COMMENT '拜访周期T（天）',
    district      VARCHAR(64)  COMMENT '区域',
    city          VARCHAR(32)  COMMENT '城市',
    address       VARCHAR(256) COMMENT '地址',
    latitude      DECIMAL(10,7) COMMENT '纬度（GPS打卡用）',
    longitude     DECIMAL(10,7) COMMENT '经度（GPS打卡用）',
    gps_radius_m  INT          DEFAULT 200 COMMENT 'GPS打卡有效半径（米）',
    is_active     TINYINT(1)   DEFAULT 1,
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT '门店基础信息';

-- ------------------------------------------------------------
-- 2. SKU表
-- ------------------------------------------------------------
CREATE TABLE skus (
    id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    sku_code      VARCHAR(32)  NOT NULL UNIQUE COMMENT 'SKU编码',
    sku_name      VARCHAR(128) NOT NULL COMMENT 'SKU名称',
    brand         VARCHAR(32)  NOT NULL COMMENT '品牌：六月鲜/禾然/味达美/葱伴侣/小康',
    spec          VARCHAR(64)  COMMENT '规格：500ml/280ml等',
    bottles_per_case INT       NOT NULL DEFAULT 12 COMMENT '每箱瓶数',
    grade_year    INT          NOT NULL DEFAULT 1 COMMENT '年级（1-4年）',
    grade_coef    DECIMAL(4,2) NOT NULL DEFAULT 1.00 COMMENT '年级系数（1年×2.0 → 4年×0.7）',
    color_hex     VARCHAR(8)   COMMENT '前端显示颜色',
    is_active     TINYINT(1)   DEFAULT 1,
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP
) COMMENT 'SKU基础信息';

-- ------------------------------------------------------------
-- 3. 门店SKU目标配置（每家门店每个SKU的目标销速）
-- ------------------------------------------------------------
CREATE TABLE store_sku_targets (
    id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id      BIGINT       NOT NULL,
    sku_id        BIGINT       NOT NULL,
    target_r      DECIMAL(8,2) NOT NULL COMMENT '目标日销率（瓶/天）',
    a_value       DECIMAL(8,2) COMMENT '心跳单元a = target_r × T（瓶/周期）',
    is_active     TINYINT(1)   DEFAULT 1,
    updated_at    DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_store_sku (store_id, sku_id),
    FOREIGN KEY (store_id) REFERENCES stores(id),
    FOREIGN KEY (sku_id)   REFERENCES skus(id)
) COMMENT '门店SKU目标配置';

-- ------------------------------------------------------------
-- 4. 陈列位置类型（系统预定义）
-- ------------------------------------------------------------
CREATE TABLE position_types (
    id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    type_code     VARCHAR(32)  NOT NULL UNIQUE,
    type_name     VARCHAR(64)  NOT NULL COMMENT '位置名称',
    icon          VARCHAR(8)   COMMENT 'emoji图标',
    description   VARCHAR(256) COMMENT '位置说明',
    is_storage    TINYINT(1)   DEFAULT 0 COMMENT '是否为后仓（后仓以箱为单位）',
    sort_order    INT          DEFAULT 0
) COMMENT '陈列位置类型字典';

INSERT INTO position_types (type_code, type_name, icon, description, is_storage, sort_order) VALUES
('shelf',    '主货架',    '📦', '品类主陈列区，所有SKU常驻位置',         0, 1),
('endcap',   '端架',      '🔲', '走廊两端独立展位，高流量位置',           0, 2),
('display',  '堆头/地堆', '📦', '主通道地面码放，量感陈列',               0, 3),
('veg',      '蔬菜区旁',  '🥬', '生鲜区场景联动陈列',                   0, 4),
('meat',     '肉类区旁',  '🥩', '肉区场景联动陈列',                     0, 5),
('seafood',  '水产区旁',  '🐟', '海鲜区场景联动陈列',                   0, 6),
('cashier',  '收银台旁',  '🛒', '等待区冲动购买位置',                   0, 7),
('promo',    '入口促销区','🎪', '节假日临时促销位置',                   0, 8),
('storage',  '后仓',      '🏪', '仓库备货区，以箱为单位',               1, 9);

-- ------------------------------------------------------------
-- 5. 门店陈列位置配置（每家门店有哪些陈列位）
-- ------------------------------------------------------------
CREATE TABLE store_positions (
    id               BIGINT PRIMARY KEY AUTO_INCREMENT,
    store_id         BIGINT      NOT NULL,
    position_type_id BIGINT      NOT NULL,
    is_permanent     TINYINT(1)  DEFAULT 1 COMMENT '是否固定（0=临时异位）',
    added_date       DATE        COMMENT '首次发现日期',
    is_active        TINYINT(1)  DEFAULT 1,
    UNIQUE KEY uk_store_pos (store_id, position_type_id),
    FOREIGN KEY (store_id)         REFERENCES stores(id),
    FOREIGN KEY (position_type_id) REFERENCES position_types(id)
) COMMENT '门店陈列位置配置';

-- ------------------------------------------------------------
-- 6. 用户（业务员/经销商业代）
-- ------------------------------------------------------------
CREATE TABLE users (
    id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_code     VARCHAR(32)  NOT NULL UNIQUE,
    user_name     VARCHAR(64)  NOT NULL,
    role          VARCHAR(32)  NOT NULL COMMENT '角色：DSR业务员/经销商业代/美顾/DOM督导',
    district      VARCHAR(64)  COMMENT '负责区域',
    phone         VARCHAR(16),
    wechat_openid VARCHAR(64)  COMMENT '微信OpenID',
    cb_score      INT          DEFAULT 0 COMMENT 'CB积分总分',
    aiql_score    DECIMAL(5,2) DEFAULT 0 COMMENT 'AIQL综合评分',
    is_active     TINYINT(1)   DEFAULT 1,
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP
) COMMENT '用户基础信息';

-- ------------------------------------------------------------
-- 7. 拜访主记录（一次拜访 = 一条记录）
-- ------------------------------------------------------------
CREATE TABLE visit_reports (
    id              BIGINT PRIMARY KEY AUTO_INCREMENT,
    visit_code      VARCHAR(64)  NOT NULL UNIQUE COMMENT '拜访单号（UUID）',
    store_id        BIGINT       NOT NULL,
    user_id         BIGINT       NOT NULL,
    visit_date      DATE         NOT NULL,
    checkin_time    DATETIME     COMMENT 'GPS打卡时间',
    checkin_lat     DECIMAL(10,7) COMMENT '打卡纬度',
    checkin_lng     DECIMAL(10,7) COMMENT '打卡经度',
    checkin_valid   TINYINT(1)   DEFAULT 0 COMMENT '打卡是否有效（GPS在范围内）',
    submit_time     DATETIME     COMMENT '提交时间',
    status          VARCHAR(16)  DEFAULT 'draft' COMMENT 'draft/submitted/synced',

    -- 汇总字段（提交时计算写入）
    positions_total INT          DEFAULT 0 COMMENT '本次盘点位置总数',
    positions_done  INT          DEFAULT 0 COMMENT '完成盘点位置数',
    photos_count    INT          DEFAULT 0 COMMENT '上传照片数',
    cb_earned       INT          DEFAULT 0 COMMENT '本次获得CB积分',

    -- 水位汇总（JSON存各SKU水位结果）
    water_summary   JSON         COMMENT '各SKU水位汇总',

    -- 蝴蝶效应标记
    butterfly_alert TINYINT(1)   DEFAULT 0 COMMENT '是否触发蝴蝶效应预警',
    alert_types     VARCHAR(64)  COMMENT '失真类型：A压货/B促销/C窜货',

    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (store_id) REFERENCES stores(id),
    FOREIGN KEY (user_id)  REFERENCES users(id),
    INDEX idx_store_date (store_id, visit_date),
    INDEX idx_user_date  (user_id, visit_date)
) COMMENT '拜访主记录';

-- ------------------------------------------------------------
-- 8. 位置盘点记录（每个位置 = 一条记录）
-- ------------------------------------------------------------
CREATE TABLE position_inventories (
    id               BIGINT PRIMARY KEY AUTO_INCREMENT,
    visit_id         BIGINT      NOT NULL,
    position_type_id BIGINT      NOT NULL,
    is_temporary     TINYINT(1)  DEFAULT 0 COMMENT '是否临时异位（当次新发现）',
    photo_url        VARCHAR(512) COMMENT '该位置照片URL',
    photo_uploaded   TINYINT(1)  DEFAULT 0,
    is_done          TINYINT(1)  DEFAULT 0 COMMENT '该位置是否完成盘点',
    done_time        DATETIME,
    created_at       DATETIME    DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (visit_id)         REFERENCES visit_reports(id),
    FOREIGN KEY (position_type_id) REFERENCES position_types(id),
    UNIQUE KEY uk_visit_pos (visit_id, position_type_id)
) COMMENT '位置盘点记录';

-- ------------------------------------------------------------
-- 9. SKU库存明细（每个位置每个SKU的具体数字）
-- ------------------------------------------------------------
CREATE TABLE position_sku_inventory (
    id                   BIGINT PRIMARY KEY AUTO_INCREMENT,
    position_inventory_id BIGINT      NOT NULL,
    sku_id               BIGINT      NOT NULL,
    bottles_count        INT         DEFAULT 0 COMMENT '货架瓶数（非后仓）',
    cases_count          INT         DEFAULT 0 COMMENT '仓库箱数（后仓专用）',
    bottles_total        INT         DEFAULT 0 COMMENT '折算瓶数合计',

    FOREIGN KEY (position_inventory_id) REFERENCES position_inventories(id),
    FOREIGN KEY (sku_id)                REFERENCES skus(id),
    UNIQUE KEY uk_pos_sku (position_inventory_id, sku_id)
) COMMENT 'SKU库存明细';

-- ------------------------------------------------------------
-- 10. SKU心跳水位快照（提交时计算，驱动Agent）
-- ------------------------------------------------------------
CREATE TABLE sku_water_levels (
    id              BIGINT PRIMARY KEY AUTO_INCREMENT,
    visit_id        BIGINT       NOT NULL,
    store_id        BIGINT       NOT NULL,
    sku_id          BIGINT       NOT NULL,
    report_date     DATE         NOT NULL,

    -- 库存分项
    shelf_total     INT          DEFAULT 0 COMMENT '货架合计瓶数（所有非后仓位置）',
    storage_total   INT          DEFAULT 0 COMMENT '后仓合计瓶数',
    all_position_total INT       DEFAULT 0 COMMENT '所有位置合计瓶数',

    -- 心跳计算
    a_value         DECIMAL(8,2) COMMENT '心跳单元a（从store_sku_targets取）',
    water_level     DECIMAL(6,3) COMMENT '水位 = all_total / a',
    water_status    VARCHAR(16)  COMMENT 'full(≥3a)/healthy(2-3a)/warn(1-2a)/danger(<1a)',

    -- 销速计算
    actual_r        DECIMAL(8,2) COMMENT '实际日销率（瓶/天）',
    target_r        DECIMAL(8,2) COMMENT '目标日销率',
    achievement_pct DECIMAL(6,2) COMMENT '达成率%',
    days_remaining  DECIMAL(6,1) COMMENT '可售天数',

    -- Agent触发标记
    trigger_reorder     TINYINT(1) DEFAULT 0 COMMENT '是否触发补货推单',
    trigger_butterfly   TINYINT(1) DEFAULT 0 COMMENT '是否触发蝴蝶效应',
    distortion_type     VARCHAR(8) COMMENT 'A/B/C失真类型',

    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (visit_id)  REFERENCES visit_reports(id),
    FOREIGN KEY (store_id)  REFERENCES stores(id),
    FOREIGN KEY (sku_id)    REFERENCES skus(id),
    INDEX idx_store_sku_date (store_id, sku_id, report_date)
) COMMENT 'SKU心跳水位快照';

-- ------------------------------------------------------------
-- 11. 价签扫描记录
-- ------------------------------------------------------------
CREATE TABLE price_records (
    id              BIGINT PRIMARY KEY AUTO_INCREMENT,
    visit_id        BIGINT       NOT NULL,
    position_type_id BIGINT,
    sku_id          BIGINT       NOT NULL,
    own_price       DECIMAL(8,2) COMMENT '六月鲜实际售价',
    competitor_brand VARCHAR(64)  COMMENT '竞品品牌',
    competitor_price DECIMAL(8,2) COMMENT '竞品价格',
    price_floor     DECIMAL(8,2) DEFAULT 17.00 COMMENT '管控底价',
    below_floor     TINYINT(1)   DEFAULT 0 COMMENT '是否低于底价（触发C类失真）',
    photo_url       VARCHAR(512),
    recorded_at     DATETIME     DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (visit_id) REFERENCES visit_reports(id),
    FOREIGN KEY (sku_id)   REFERENCES skus(id)
) COMMENT '价签扫描记录';

-- ------------------------------------------------------------
-- 12. CB积分流水
-- ------------------------------------------------------------
CREATE TABLE cb_transactions (
    id              BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id         BIGINT       NOT NULL,
    visit_id        BIGINT,
    txn_type        VARCHAR(32)  NOT NULL COMMENT '类型：visit/photo/water_warn/full_complete',
    points          INT          NOT NULL COMMENT '积分变动（正=获得，负=扣除）',
    balance_after   INT          NOT NULL COMMENT '变动后余额',
    description     VARCHAR(256),
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)  REFERENCES users(id),
    FOREIGN KEY (visit_id) REFERENCES visit_reports(id),
    INDEX idx_user_date (user_id, created_at)
) COMMENT 'CB积分流水';

-- ------------------------------------------------------------
-- 13. 训练图片库（货架识别训练数据）
-- ------------------------------------------------------------
CREATE TABLE training_photos (
    id               BIGINT PRIMARY KEY AUTO_INCREMENT,
    visit_id         BIGINT       NOT NULL,
    position_type_id BIGINT       NOT NULL,
    store_id         BIGINT       NOT NULL,
    photo_url        VARCHAR(512) NOT NULL,
    file_size_kb     INT,
    width_px         INT,
    height_px        INT,

    -- 标注数据（人工填写的数字作为标注Ground Truth）
    label_json       JSON         COMMENT '标注数据：各SKU瓶数对应照片',
    is_labeled       TINYINT(1)   DEFAULT 0 COMMENT '是否已有标注',

    -- AI识别结果（用于对比和精度统计）
    ai_result_json   JSON         COMMENT 'AI识别结果',
    ai_accuracy      DECIMAL(5,2) COMMENT 'AI识别准确率%',

    upload_time      DATETIME     DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (visit_id)         REFERENCES visit_reports(id),
    FOREIGN KEY (position_type_id) REFERENCES position_types(id),
    FOREIGN KEY (store_id)         REFERENCES stores(id),
    INDEX idx_store_pos (store_id, position_type_id)
) COMMENT '货架识别训练图片库';

-- ============================================================
-- 初始化数据
-- ============================================================

-- 初始化SKU
INSERT INTO skus (sku_code, sku_name, brand, spec, bottles_per_case, grade_year, grade_coef, color_hex) VALUES
('LYX-500', '六月鲜极鲜酱油 500ml', '六月鲜', '500ml', 12, 4, 0.70, 'F5A623'),
('LYX-280', '六月鲜极鲜酱油 280ml', '六月鲜', '280ml', 12, 4, 0.70, 'FFC85E'),
('HR-500',  '禾然有机酱油 500ml',   '禾然',   '500ml', 12, 2, 1.50, '4ECDC4'),
('WDM-500', '味达美金标酱油 500ml', '味达美', '500ml', 12, 4, 0.70, '60A5FA');

-- 初始化示例门店
INSERT INTO stores (store_code, store_name, store_type, grade, visit_cycle_t, district, city) VALUES
('SH-001', '家乐福古北店',   '大卖场',  'S+', 7, '长宁', '上海'),
('SH-002', '华润万家天钥桥', '标准超市', 'S',  7, '徐汇', '上海'),
('SH-003', '全家漕溪路店',  '便利店',   'A',  7, '徐汇', '上海');

-- 初始化门店陈列位置（家乐福）
INSERT INTO store_positions (store_id, position_type_id, is_permanent) VALUES
(1, 1, 1), -- 主货架
(1, 2, 1), -- 端架
(1, 3, 1), -- 堆头
(1, 4, 1), -- 蔬菜区旁
(1, 9, 1); -- 后仓

-- 初始化门店SKU目标
INSERT INTO store_sku_targets (store_id, sku_id, target_r, a_value) VALUES
(1, 1, 9.3,  65.1), -- 家乐福 极鲜500
(1, 2, 3.5,  24.5), -- 家乐福 极鲜280
(1, 3, 1.5,  10.5), -- 家乐福 禾然
(1, 4, 5.0,  35.0); -- 家乐福 味达美
