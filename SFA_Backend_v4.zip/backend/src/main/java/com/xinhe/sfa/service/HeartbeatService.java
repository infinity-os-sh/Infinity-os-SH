package com.xinhe.sfa.service;

import com.xinhe.sfa.dto.*;
import com.xinhe.sfa.entity.*;
import com.xinhe.sfa.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 心跳水位计算引擎
 * 核心公式：r = a ÷ T
 * 水位 = 总库存 ÷ a
 * 三层：≥3a满仓 / 2-3a健康 / 1-2a预警 / <1a危险
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class HeartbeatService {

    private final StoreSkuTargetRepository targetRepo;
    private final SkuWaterLevelRepository waterLevelRepo;
    private final VisitReportRepository visitRepo;
    private final CbService cbService;
    private final WechatWorkService wechatWorkService;

    /**
     * 计算并持久化所有SKU的水位快照
     * 在提交拜访时调用
     */
    @Transactional
    public List<WaterLevelResult> calculateAndSave(
            VisitReport visit,
            Map<Long, Map<String, Integer>> skuTotals // skuId -> {shelf, storage, all}
    ) {
        List<WaterLevelResult> results = new ArrayList<>();
        Long storeId = visit.getStore().getId();
        List<StoreSkuTarget> targets = targetRepo.findByStoreId(storeId);

        for (StoreSkuTarget target : targets) {
            Long skuId = target.getSku().getId();
            Map<String, Integer> totals = skuTotals.getOrDefault(skuId,
                Map.of("shelf", 0, "storage", 0, "all", 0));

            int allTotal = totals.getOrDefault("all", 0);
            BigDecimal aValue = target.getAValue();

            // 水位计算
            BigDecimal waterLevel = aValue.compareTo(BigDecimal.ZERO) > 0
                ? new BigDecimal(allTotal).divide(aValue, 3, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

            // 水位状态
            String status = calcStatus(waterLevel);
            String label  = calcLabel(status);
            String color  = calcColor(status);

            // 实际销速计算
            BigDecimal actualR = calcActualR(visit, target, allTotal);
            BigDecimal targetR = target.getTargetR();
            BigDecimal achievement = targetR.compareTo(BigDecimal.ZERO) > 0
                ? actualR.divide(targetR, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;
            BigDecimal daysLeft = actualR.compareTo(BigDecimal.ZERO) > 0
                ? new BigDecimal(allTotal).divide(actualR, 1, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

            // 触发判断
            boolean triggerReorder    = waterLevel.compareTo(BigDecimal.valueOf(2)) < 0;
            boolean triggerButterfly  = waterLevel.compareTo(BigDecimal.ONE) < 0;
            String distortionType     = detectDistortion(visit, target, allTotal, actualR);

            // 持久化
            SkuWaterLevel wl = new SkuWaterLevel();
            wl.setVisitReport(visit);
            wl.setStore(visit.getStore());
            wl.setSku(target.getSku());
            wl.setReportDate(LocalDate.now());
            wl.setShelfTotal(totals.getOrDefault("shelf", 0));
            wl.setStorageTotal(totals.getOrDefault("storage", 0));
            wl.setAllPositionTotal(allTotal);
            wl.setAValue(aValue);
            wl.setWaterLevel(waterLevel);
            wl.setWaterStatus(status);
            wl.setActualR(actualR);
            wl.setTargetR(targetR);
            wl.setAchievementPct(achievement);
            wl.setDaysRemaining(daysLeft);
            wl.setTriggerReorder(triggerReorder);
            wl.setTriggerButterfly(triggerButterfly);
            wl.setDistortionType(distortionType);
            wl.setCreatedAt(LocalDateTime.now());
            waterLevelRepo.save(wl);

            // 构建响应
            WaterLevelResult result = new WaterLevelResult();
            result.setSkuId(skuId);
            result.setSkuName(target.getSku().getSkuName());
            result.setShelfTotal(wl.getShelfTotal());
            result.setStorageTotal(wl.getStorageTotal());
            result.setAllTotal(allTotal);
            result.setAValue(aValue);
            result.setWaterLevel(waterLevel);
            result.setWaterStatus(status);
            result.setWaterLabel(label);
            result.setWaterColor(color);
            result.setActualR(actualR);
            result.setTargetR(targetR);
            result.setAchievementPct(achievement);
            result.setDaysRemaining(daysLeft);
            result.setTriggerReorder(triggerReorder);
            result.setTriggerButterfly(triggerButterfly);
            result.setDistortionType(distortionType);
            results.add(result);

            // 触发Agent动作
            if (triggerButterfly) {
                log.warn("[蝴蝶效应] storeId={} skuId={} waterLevel={} status=danger",
                    storeId, skuId, waterLevel);
                wechatWorkService.sendButterflyAlert(visit, target.getSku(), waterLevel, distortionType);
            } else if (triggerReorder) {
                log.info("[推单触发] storeId={} skuId={} waterLevel={}", storeId, skuId, waterLevel);
                wechatWorkService.sendReorderSuggestion(visit, target, allTotal);
            }
        }

        return results;
    }

    private String calcStatus(BigDecimal level) {
        if (level.compareTo(BigDecimal.valueOf(3)) >= 0) return "full";
        if (level.compareTo(BigDecimal.valueOf(2)) >= 0) return "healthy";
        if (level.compareTo(BigDecimal.ONE)        >= 0) return "warn";
        return "danger";
    }

    private String calcLabel(String status) {
        return switch (status) {
            case "full"    -> "满仓 ✅";
            case "healthy" -> "健康";
            case "warn"    -> "预警 ⚠️";
            default        -> "危险 🔴";
        };
    }

    private String calcColor(String status) {
        return switch (status) {
            case "full"    -> "#4ade80";
            case "healthy" -> "#60a5fa";
            case "warn"    -> "#f5a623";
            default        -> "#ff5f5f";
        };
    }

    /**
     * 实际销速计算
     * r = (上次补货量 - 当前库存) ÷ 距上次补货天数
     * 若无历史数据则用：r = 当前库存 ÷ T
     */
    private BigDecimal calcActualR(VisitReport visit, StoreSkuTarget target, int currentTotal) {
        Optional<SkuWaterLevel> lastWl = waterLevelRepo
            .findLastByStoreAndSku(visit.getStore().getId(), target.getSku().getId());

        if (lastWl.isPresent()) {
            SkuWaterLevel last = lastWl.get();
            long daysBetween = LocalDate.now().toEpochDay() - last.getReportDate().toEpochDay();
            if (daysBetween > 0) {
                int consumed = last.getAllPositionTotal() - currentTotal;
                if (consumed > 0) {
                    return new BigDecimal(consumed)
                        .divide(BigDecimal.valueOf(daysBetween), 2, RoundingMode.HALF_UP);
                }
            }
        }

        // 回退：用库存÷T估算
        int T = visit.getStore().getVisitCycleT();
        return T > 0
            ? new BigDecimal(currentTotal).divide(BigDecimal.valueOf(T), 2, RoundingMode.HALF_UP)
            : BigDecimal.ZERO;
    }

    /**
     * 失真检测
     * A类：渠道压货（库存异常高·销速异常低）
     * B类：促销扰动（销速短期骤升）
     * C类：灰市窜货（价签低于底价·在PriceService处理）
     */
    private String detectDistortion(VisitReport visit, StoreSkuTarget target,
                                     int currentTotal, BigDecimal actualR) {
        BigDecimal aValue = target.getAValue();
        if (aValue.compareTo(BigDecimal.ZERO) == 0) return null;

        BigDecimal level = new BigDecimal(currentTotal).divide(aValue, 3, RoundingMode.HALF_UP);

        // A类：库存超3a且销速低于目标60%
        if (level.compareTo(BigDecimal.valueOf(3)) > 0 &&
            actualR.compareTo(target.getTargetR().multiply(BigDecimal.valueOf(0.6))) < 0) {
            return "A";
        }

        // B类：销速超目标200%（促销扰动）
        if (actualR.compareTo(target.getTargetR().multiply(BigDecimal.valueOf(2))) > 0) {
            return "B";
        }

        return null;
    }
}
