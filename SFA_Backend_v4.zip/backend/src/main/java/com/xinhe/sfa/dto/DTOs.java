package com.xinhe.sfa.dto;

import lombok.Data;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

// ============================================================
// 请求DTO
// ============================================================

/** 开始拜访请求 */
@Data
public class StartVisitRequest {
    private Long storeId;
    private Long userId;
    private BigDecimal checkinLat;
    private BigDecimal checkinLng;
}

/** 提交位置盘点数据 */
@Data
public class SubmitPositionRequest {
    private Long visitId;
    private Long positionTypeId;
    private Boolean isTemporary;
    /** key=skuId, value={bottles, cases} */
    private Map<Long, SkuQuantity> skuData;

    @Data
    public static class SkuQuantity {
        private Integer bottles = 0;
        private Integer cases   = 0;
    }
}

/** 提交整个拜访 */
@Data
public class SubmitVisitRequest {
    private Long visitId;
}

/** 价签扫描请求 */
@Data
public class PriceRecordRequest {
    private Long visitId;
    private Long positionTypeId;
    private Long skuId;
    private BigDecimal ownPrice;
    private String competitorBrand;
    private BigDecimal competitorPrice;
    private String photoUrl;
}

// ============================================================
// 响应DTO
// ============================================================

/** 门店详情（带陈列位置+SKU目标） */
@Data
public class StoreDetailResponse {
    private Long storeId;
    private String storeName;
    private String grade;
    private Integer visitCycleT;
    private String storeType;
    private List<PositionConfig> positions;
    private List<SkuTarget> skuTargets;

    @Data
    public static class PositionConfig {
        private Long positionTypeId;
        private String typeCode;
        private String typeName;
        private String icon;
        private Boolean isStorage;
        private Boolean isPermanent;
        private Integer sortOrder;
    }

    @Data
    public static class SkuTarget {
        private Long skuId;
        private String skuCode;
        private String skuName;
        private String brand;
        private Integer bottlesPerCase;
        private BigDecimal targetR;
        private BigDecimal aValue;
        private String colorHex;
    }
}

/** 拜访创建响应 */
@Data
public class VisitCreatedResponse {
    private Long visitId;
    private String visitCode;
    private Boolean checkinValid;
    private Double distanceMeters;
    private String message;
}

/** 水位计算结果 */
@Data
public class WaterLevelResult {
    private Long skuId;
    private String skuName;
    private Integer shelfTotal;
    private Integer storageTotal;
    private Integer allTotal;
    private BigDecimal aValue;
    private BigDecimal waterLevel;
    private String waterStatus;       // full/healthy/warn/danger
    private String waterLabel;        // 满仓/健康/预警/危险
    private String waterColor;        // hex color for frontend
    private BigDecimal actualR;
    private BigDecimal targetR;
    private BigDecimal achievementPct;
    private BigDecimal daysRemaining;
    private Boolean triggerReorder;
    private Boolean triggerButterfly;
    private String distortionType;
    // Position breakdown
    private List<PositionBreakdown> breakdown;

    @Data
    public static class PositionBreakdown {
        private String positionName;
        private Integer bottles;
    }
}

/** 提交汇总响应 */
@Data
public class SubmitSummaryResponse {
    private String visitCode;
    private String storeName;
    private Integer positionsCompleted;
    private Integer photosUploaded;
    private Integer cbEarned;
    private List<WaterLevelResult> waterLevels;
    private List<String> alerts;
    private List<String> agentActions;
    private String submitTime;
}

/** 位置完成响应 */
@Data
public class PositionDoneResponse {
    private Long positionInventoryId;
    private Integer progressDone;
    private Integer progressTotal;
    private List<WaterLevelResult> currentWaterLevels;
}
