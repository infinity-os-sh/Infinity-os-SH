// ============================================================
// Entity: Store.java
// ============================================================
package com.xinhe.sfa.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Entity @Table(name = "stores")
public class Store {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false) private String storeCode;
    @Column(nullable = false) private String storeName;
    private String storeType;
    private String grade;
    private Integer visitCycleT;
    private String district;
    private String city;
    private String address;
    private BigDecimal latitude;
    private BigDecimal longitude;
    private Integer gpsRadiusM = 200;
    private Boolean isActive = true;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

// ============================================================
// Entity: Sku.java
// ============================================================
package com.xinhe.sfa.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;

@Data @Entity @Table(name = "skus")
public class Sku {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false) private String skuCode;
    @Column(nullable = false) private String skuName;
    private String brand;
    private String spec;
    private Integer bottlesPerCase;
    private Integer gradeYear;
    private BigDecimal gradeCoef;
    private String colorHex;
    private Boolean isActive = true;
}

// ============================================================
// Entity: VisitReport.java
// ============================================================
package com.xinhe.sfa.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Entity @Table(name = "visit_reports")
public class VisitReport {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, nullable = false) private String visitCode;

    @ManyToOne @JoinColumn(name = "store_id")
    private Store store;
    @ManyToOne @JoinColumn(name = "user_id")
    private User user;

    private LocalDate visitDate;
    private LocalDateTime checkinTime;
    private BigDecimal checkinLat;
    private BigDecimal checkinLng;
    private Boolean checkinValid = false;
    private LocalDateTime submitTime;
    private String status = "draft";

    private Integer positionsTotal = 0;
    private Integer positionsDone  = 0;
    private Integer photosCount    = 0;
    private Integer cbEarned       = 0;

    @Column(columnDefinition = "JSON")
    private String waterSummary;

    private Boolean butterflyAlert = false;
    private String alertTypes;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

// ============================================================
// Entity: PositionInventory.java
// ============================================================
package com.xinhe.sfa.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;

@Data @Entity @Table(name = "position_inventories")
public class PositionInventory {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne @JoinColumn(name = "visit_id")
    private VisitReport visitReport;
    @ManyToOne @JoinColumn(name = "position_type_id")
    private PositionType positionType;

    private Boolean isTemporary = false;
    private String photoUrl;
    private Boolean photoUploaded = false;
    private Boolean isDone = false;
    private LocalDateTime doneTime;
    private LocalDateTime createdAt;
}

// ============================================================
// Entity: PositionSkuInventory.java
// ============================================================
package com.xinhe.sfa.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data @Entity @Table(name = "position_sku_inventory")
public class PositionSkuInventory {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne @JoinColumn(name = "position_inventory_id")
    private PositionInventory positionInventory;
    @ManyToOne @JoinColumn(name = "sku_id")
    private Sku sku;

    private Integer bottlesCount = 0;
    private Integer casesCount   = 0;
    private Integer bottlesTotal = 0;
}

// ============================================================
// Entity: SkuWaterLevel.java
// ============================================================
package com.xinhe.sfa.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Entity @Table(name = "sku_water_levels")
public class SkuWaterLevel {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne @JoinColumn(name = "visit_id")  private VisitReport visitReport;
    @ManyToOne @JoinColumn(name = "store_id")  private Store store;
    @ManyToOne @JoinColumn(name = "sku_id")    private Sku sku;

    private LocalDate reportDate;
    private Integer shelfTotal;
    private Integer storageTotal;
    private Integer allPositionTotal;

    private BigDecimal aValue;
    private BigDecimal waterLevel;
    private String waterStatus;

    private BigDecimal actualR;
    private BigDecimal targetR;
    private BigDecimal achievementPct;
    private BigDecimal daysRemaining;

    private Boolean triggerReorder    = false;
    private Boolean triggerButterfly  = false;
    private String distortionType;

    private LocalDateTime createdAt;
}

// ============================================================
// Entity: PositionType.java
// ============================================================
package com.xinhe.sfa.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data @Entity @Table(name = "position_types")
public class PositionType {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true) private String typeCode;
    private String typeName;
    private String icon;
    private String description;
    private Boolean isStorage = false;
    private Integer sortOrder = 0;
}

// ============================================================
// Entity: User.java
// ============================================================
package com.xinhe.sfa.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Entity @Table(name = "users")
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true) private String userCode;
    private String userName;
    private String role;
    private String district;
    private String phone;
    private String wechatOpenid;
    private Integer cbScore    = 0;
    private BigDecimal aiqlScore = BigDecimal.ZERO;
    private Boolean isActive   = true;
    private LocalDateTime createdAt;
}
