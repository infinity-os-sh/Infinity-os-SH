// ============================================================
// CbService.java - CB积分计算（乘法公式）
// ============================================================
package com.xinhe.sfa.service;

import com.xinhe.sfa.dto.WaterLevelResult;
import com.xinhe.sfa.entity.*;
import com.xinhe.sfa.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CbService {

    private final CbTransactionRepository cbTxnRepo;
    private final UserRepository userRepo;

    /**
     * CB积分计算公式（乘法）
     * CB = 基础分(15) × 打卡系数 × 买得到系数 × 看得到系数 × 完整度系数
     */
    @Transactional
    public int calcAndAward(VisitReport visit, List<WaterLevelResult> waterLevels, int photoCount) {
        double base = 15.0;

        // 打卡系数
        double checkinCoef = Boolean.TRUE.equals(visit.getCheckinValid()) ? 1.0 : 0.5;

        // 买得到系数（有预警SKU加分，因为发现了问题）
        long dangerCount = waterLevels.stream()
            .filter(w -> "danger".equals(w.getWaterStatus()) || "warn".equals(w.getWaterStatus()))
            .count();
        double buyCoef = dangerCount > 0 ? 1.2 : 1.0;

        // 看得到系数（拍了照片）
        double seeCoef = photoCount > 0 ? 1.2 : 1.0;

        // 完整度系数（填满所有位置+有照片）
        double completeCoef = 1.0;
        if (visit.getPositionsDone() >= visit.getPositionsTotal() && photoCount > 0) {
            completeCoef = 1.15;
        }

        int cbEarned = (int) Math.round(base * checkinCoef * buyCoef * seeCoef * completeCoef);

        // 持久化积分流水
        User user = visit.getUser();
        int newBalance = user.getCbScore() + cbEarned;

        CbTransaction txn = new CbTransaction();
        txn.setUser(user);
        txn.setVisitReport(visit);
        txn.setTxnType("visit");
        txn.setPoints(cbEarned);
        txn.setBalanceAfter(newBalance);
        txn.setDescription(String.format("拜访%s 完成%d个位置 照片%d张",
            visit.getStore().getStoreName(), visit.getPositionsDone(), photoCount));
        txn.setCreatedAt(LocalDateTime.now());
        cbTxnRepo.save(txn);

        user.setCbScore(newBalance);
        userRepo.save(user);

        log.info("[CB积分] userId={} earned={} balance={}", user.getId(), cbEarned, newBalance);
        return cbEarned;
    }
}

// ============================================================
// WechatWorkService.java - 企业微信推送
// ============================================================
package com.xinhe.sfa.service;

import com.xinhe.sfa.dto.WaterLevelResult;
import com.xinhe.sfa.entity.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class WechatWorkService {

    @Value("${wechat.work.webhook.url:}")
    private String webhookUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    /** 蝴蝶效应预警推送 */
    public void sendButterflyAlert(VisitReport visit, Sku sku,
                                    BigDecimal waterLevel, String distortionType) {
        String emoji = "danger".equals(getStatus(waterLevel)) ? "🔴" : "⚠️";
        String distText = distortionType == null ? "水位危险" :
            switch (distortionType) {
                case "A" -> "A类：渠道压货";
                case "B" -> "B类：促销扰动";
                case "C" -> "C类：灰市窜货";
                default  -> "异常";
            };

        String content = String.format(
            "%s **蝴蝶效应预警**\n" +
            "> 门店：%s\n" +
            "> SKU：%s\n" +
            "> 当前水位：%.2fa\n" +
            "> 失真类型：%s\n" +
            "> 业务员：%s\n" +
            "> 建议立即安排补货",
            emoji,
            visit.getStore().getStoreName(),
            sku.getSkuName(),
            waterLevel,
            distText,
            visit.getUser().getUserName()
        );
        sendMarkdown(content);
    }

    /** 补货推单推送 */
    public void sendReorderSuggestion(VisitReport visit, StoreSkuTarget target, int currentTotal) {
        BigDecimal aValue = target.getAValue();
        int suggestQty = aValue != null
            ? (int) Math.ceil(aValue.doubleValue() * 2 - currentTotal)
            : 0;
        if (suggestQty <= 0) return;

        int cases = (int) Math.ceil((double) suggestQty / target.getSku().getBottlesPerCase());
        String content = String.format(
            "🍣 **无菜单推单建议**\n" +
            "> 门店：%s\n" +
            "> SKU：%s\n" +
            "> 当前库存：%d瓶（%.1fa）\n" +
            "> 建议补货：%d瓶（约%d箱）\n" +
            "> 补货后达到2a健康水位",
            visit.getStore().getStoreName(),
            target.getSku().getSkuName(),
            currentTotal,
            aValue != null ? currentTotal / aValue.doubleValue() : 0,
            suggestQty, cases
        );
        sendMarkdown(content);
    }

    private void sendMarkdown(String content) {
        if (webhookUrl == null || webhookUrl.isEmpty()) {
            log.info("[企微模拟推送] {}", content.replace("\n", " | "));
            return;
        }
        try {
            Map<String, Object> body = new HashMap<>();
            body.put("msgtype", "markdown");
            body.put("markdown", Map.of("content", content));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            restTemplate.postForEntity(webhookUrl, new HttpEntity<>(body, headers), String.class);
        } catch (Exception e) {
            log.error("[企微推送失败] {}", e.getMessage());
        }
    }

    private String getStatus(BigDecimal level) {
        if (level.compareTo(BigDecimal.ONE) < 0) return "danger";
        if (level.compareTo(BigDecimal.valueOf(2)) < 0) return "warn";
        return "healthy";
    }
}

// ============================================================
// InventoryController.java - REST API
// ============================================================
package com.xinhe.sfa.controller;

import com.xinhe.sfa.dto.*;
import com.xinhe.sfa.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class InventoryController {

    private final VisitService visitService;
    private final PhotoService photoService;

    /**
     * 获取门店详情（陈列位置 + SKU目标）
     * GET /api/v1/stores/{storeId}
     */
    @GetMapping("/stores/{storeId}")
    public ResponseEntity<ApiResponse<StoreDetailResponse>> getStoreDetail(
            @PathVariable Long storeId) {
        return ok(visitService.getStoreDetail(storeId));
    }

    /**
     * 开始拜访（GPS打卡）
     * POST /api/v1/visits/start
     */
    @PostMapping("/visits/start")
    public ResponseEntity<ApiResponse<VisitCreatedResponse>> startVisit(
            @RequestBody StartVisitRequest req) {
        return ok(visitService.startVisit(req));
    }

    /**
     * 提交位置盘点数据
     * POST /api/v1/visits/position
     */
    @PostMapping("/visits/position")
    public ResponseEntity<ApiResponse<PositionDoneResponse>> submitPosition(
            @RequestBody SubmitPositionRequest req) {
        return ok(visitService.submitPosition(req));
    }

    /**
     * 上传位置照片
     * POST /api/v1/visits/{visitId}/photo/{positionTypeId}
     */
    @PostMapping("/visits/{visitId}/photo/{positionTypeId}")
    public ResponseEntity<ApiResponse<String>> uploadPhoto(
            @PathVariable Long visitId,
            @PathVariable Long positionTypeId,
            @RequestParam("file") MultipartFile file) {
        String url = photoService.upload(file, visitId, positionTypeId);
        visitService.markPhotoUploaded(visitId, positionTypeId, url);
        return ok(url);
    }

    /**
     * 最终提交整个拜访
     * POST /api/v1/visits/submit
     */
    @PostMapping("/visits/submit")
    public ResponseEntity<ApiResponse<SubmitSummaryResponse>> submitVisit(
            @RequestBody SubmitVisitRequest req) {
        return ok(visitService.submitVisit(req));
    }

    /**
     * 添加临时异位陈列位置
     * POST /api/v1/visits/{visitId}/add-position/{positionTypeId}
     */
    @PostMapping("/visits/{visitId}/add-position/{positionTypeId}")
    public ResponseEntity<ApiResponse<String>> addTemporaryPosition(
            @PathVariable Long visitId,
            @PathVariable Long positionTypeId) {
        visitService.addTemporaryPosition(visitId, positionTypeId);
        return ok("临时位置已添加");
    }

    /**
     * 获取当前水位实时状态
     * GET /api/v1/visits/{visitId}/water-levels
     */
    @GetMapping("/visits/{visitId}/water-levels")
    public ResponseEntity<ApiResponse<java.util.List<WaterLevelResult>>> getWaterLevels(
            @PathVariable Long visitId) {
        return ok(visitService.getCurrentWaterLevels(visitId));
    }

    private <T> ResponseEntity<ApiResponse<T>> ok(T data) {
        return ResponseEntity.ok(ApiResponse.success(data));
    }
}

// ============================================================
// ApiResponse.java - 统一响应格式
// ============================================================
package com.xinhe.sfa.dto;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class ApiResponse<T> {
    private boolean success;
    private T data;
    private String message;
    private String timestamp;
    private String code;

    public static <T> ApiResponse<T> success(T data) {
        ApiResponse<T> r = new ApiResponse<>();
        r.success = true;
        r.data = data;
        r.code = "200";
        r.timestamp = LocalDateTime.now().toString();
        return r;
    }

    public static <T> ApiResponse<T> error(String message) {
        ApiResponse<T> r = new ApiResponse<>();
        r.success = false;
        r.message = message;
        r.code = "500";
        r.timestamp = LocalDateTime.now().toString();
        return r;
    }
}
