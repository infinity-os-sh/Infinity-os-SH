package com.xinhe.sfa.service;

import com.xinhe.sfa.dto.*;
import com.xinhe.sfa.entity.*;
import com.xinhe.sfa.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class VisitService {

    private final VisitReportRepository visitRepo;
    private final StoreRepository storeRepo;
    private final UserRepository userRepo;
    private final PositionTypeRepository posTypeRepo;
    private final StorePositionRepository storePosRepo;
    private final PositionInventoryRepository posInvRepo;
    private final PositionSkuInventoryRepository posSkuInvRepo;
    private final SkuRepository skuRepo;
    private final HeartbeatService heartbeatService;
    private final CbService cbService;

    // ----------------------------------------------------------
    // 1. 获取门店详情（陈列位置 + SKU目标）
    // ----------------------------------------------------------
    public StoreDetailResponse getStoreDetail(Long storeId) {
        Store store = storeRepo.findById(storeId)
            .orElseThrow(() -> new RuntimeException("门店不存在: " + storeId));

        List<StorePosition> positions = storePosRepo.findByStoreIdAndIsActive(storeId, true);
        List<StoreSkuTarget> targets  = storeSkuTargetRepo.findByStoreId(storeId);

        StoreDetailResponse resp = new StoreDetailResponse();
        resp.setStoreId(store.getId());
        resp.setStoreName(store.getStoreName());
        resp.setGrade(store.getGrade());
        resp.setVisitCycleT(store.getVisitCycleT());
        resp.setStoreType(store.getStoreType());

        resp.setPositions(positions.stream().map(sp -> {
            StoreDetailResponse.PositionConfig pc = new StoreDetailResponse.PositionConfig();
            pc.setPositionTypeId(sp.getPositionType().getId());
            pc.setTypeCode(sp.getPositionType().getTypeCode());
            pc.setTypeName(sp.getPositionType().getTypeName());
            pc.setIcon(sp.getPositionType().getIcon());
            pc.setIsStorage(sp.getPositionType().getIsStorage());
            pc.setIsPermanent(sp.getIsPermanent());
            pc.setSortOrder(sp.getPositionType().getSortOrder());
            return pc;
        }).sorted(Comparator.comparing(StoreDetailResponse.PositionConfig::getSortOrder))
          .collect(Collectors.toList()));

        resp.setSkuTargets(targets.stream().map(t -> {
            StoreDetailResponse.SkuTarget st = new StoreDetailResponse.SkuTarget();
            st.setSkuId(t.getSku().getId());
            st.setSkuCode(t.getSku().getSkuCode());
            st.setSkuName(t.getSku().getSkuName());
            st.setBrand(t.getSku().getBrand());
            st.setBottlesPerCase(t.getSku().getBottlesPerCase());
            st.setTargetR(t.getTargetR());
            st.setAValue(t.getAValue());
            st.setColorHex(t.getSku().getColorHex());
            return st;
        }).collect(Collectors.toList()));

        return resp;
    }

    // ----------------------------------------------------------
    // 2. 开始拜访（GPS打卡）
    // ----------------------------------------------------------
    @Transactional
    public VisitCreatedResponse startVisit(StartVisitRequest req) {
        Store store = storeRepo.findById(req.getStoreId())
            .orElseThrow(() -> new RuntimeException("门店不存在"));
        User user = userRepo.findById(req.getUserId())
            .orElseThrow(() -> new RuntimeException("用户不存在"));

        // GPS验证
        boolean checkinValid = false;
        double distanceM = 0;
        if (req.getCheckinLat() != null && req.getCheckinLng() != null
            && store.getLatitude() != null) {
            distanceM = calcDistance(
                req.getCheckinLat().doubleValue(), req.getCheckinLng().doubleValue(),
                store.getLatitude().doubleValue(), store.getLongitude().doubleValue());
            checkinValid = distanceM <= store.getGpsRadiusM();
        }

        // 创建拜访记录
        VisitReport visit = new VisitReport();
        visit.setVisitCode(UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase());
        visit.setStore(store);
        visit.setUser(user);
        visit.setVisitDate(LocalDate.now());
        visit.setCheckinTime(LocalDateTime.now());
        visit.setCheckinLat(req.getCheckinLat());
        visit.setCheckinLng(req.getCheckinLng());
        visit.setCheckinValid(checkinValid);
        visit.setStatus("draft");
        visit.setCreatedAt(LocalDateTime.now());
        visit.setUpdatedAt(LocalDateTime.now());

        // 初始化门店所有陈列位置
        List<StorePosition> storePositions = storePosRepo.findByStoreIdAndIsActive(req.getStoreId(), true);
        visit.setPositionsTotal(storePositions.size());
        visit = visitRepo.save(visit);

        // 创建各位置盘点记录
        for (StorePosition sp : storePositions) {
            PositionInventory pi = new PositionInventory();
            pi.setVisitReport(visit);
            pi.setPositionType(sp.getPositionType());
            pi.setIsTemporary(false);
            pi.setIsDone(false);
            pi.setCreatedAt(LocalDateTime.now());
            posInvRepo.save(pi);
        }

        VisitCreatedResponse resp = new VisitCreatedResponse();
        resp.setVisitId(visit.getId());
        resp.setVisitCode(visit.getVisitCode());
        resp.setCheckinValid(checkinValid);
        resp.setDistanceMeters(Math.round(distanceM));
        resp.setMessage(checkinValid ? "打卡成功" : String.format("距门店%.0f米，超出打卡范围", distanceM));
        return resp;
    }

    // ----------------------------------------------------------
    // 3. 提交单个位置的盘点数据
    // ----------------------------------------------------------
    @Transactional
    public PositionDoneResponse submitPosition(SubmitPositionRequest req) {
        VisitReport visit = visitRepo.findById(req.getVisitId())
            .orElseThrow(() -> new RuntimeException("拜访记录不存在"));

        PositionInventory pi = posInvRepo
            .findByVisitIdAndPositionTypeId(req.getVisitId(), req.getPositionTypeId())
            .orElseGet(() -> {
                // 临时异位：动态创建
                PositionType pt = posTypeRepo.findById(req.getPositionTypeId())
                    .orElseThrow(() -> new RuntimeException("位置类型不存在"));
                PositionInventory newPi = new PositionInventory();
                newPi.setVisitReport(visit);
                newPi.setPositionType(pt);
                newPi.setIsTemporary(true);
                newPi.setIsDone(false);
                newPi.setCreatedAt(LocalDateTime.now());
                return posInvRepo.save(newPi);
            });

        boolean isStorage = pi.getPositionType().getIsStorage();

        // 保存各SKU库存数字
        for (Map.Entry<Long, SubmitPositionRequest.SkuQuantity> entry : req.getSkuData().entrySet()) {
            Long skuId = entry.getKey();
            SubmitPositionRequest.SkuQuantity qty = entry.getValue();
            Sku sku = skuRepo.findById(skuId).orElse(null);
            if (sku == null) continue;

            int bottles = qty.getBottles() != null ? qty.getBottles() : 0;
            int cases   = qty.getCases()   != null ? qty.getCases()   : 0;
            int total   = isStorage
                ? cases * sku.getBottlesPerCase()
                : bottles;

            PositionSkuInventory psi = posSkuInvRepo
                .findByPositionInventoryIdAndSkuId(pi.getId(), skuId)
                .orElse(new PositionSkuInventory());
            psi.setPositionInventory(pi);
            psi.setSku(sku);
            psi.setBottlesCount(bottles);
            psi.setCasesCount(cases);
            psi.setBottlesTotal(total);
            posSkuInvRepo.save(psi);
        }

        // 标记此位置完成
        pi.setIsDone(true);
        pi.setDoneTime(LocalDateTime.now());
        posInvRepo.save(pi);

        // 更新拜访进度
        long doneCount = posInvRepo.countByVisitIdAndIsDone(req.getVisitId(), true);
        visit.setPositionsDone((int) doneCount);
        visit.setUpdatedAt(LocalDateTime.now());
        visitRepo.save(visit);

        // 实时计算当前水位（给前端实时反馈）
        Map<Long, Map<String, Integer>> currentTotals = calcCurrentTotals(visit.getId());
        List<WaterLevelResult> waterLevels = heartbeatService.calculateAndSave(visit, currentTotals);

        PositionDoneResponse resp = new PositionDoneResponse();
        resp.setPositionInventoryId(pi.getId());
        resp.setProgressDone((int) doneCount);
        resp.setProgressTotal(visit.getPositionsTotal());
        resp.setCurrentWaterLevels(waterLevels);
        return resp;
    }

    // ----------------------------------------------------------
    // 4. 提交整个拜访（最终汇总）
    // ----------------------------------------------------------
    @Transactional
    public SubmitSummaryResponse submitVisit(SubmitVisitRequest req) {
        VisitReport visit = visitRepo.findById(req.getVisitId())
            .orElseThrow(() -> new RuntimeException("拜访记录不存在"));

        // 最终汇总水位
        Map<Long, Map<String, Integer>> totals = calcCurrentTotals(visit.getId());
        List<WaterLevelResult> waterLevels = heartbeatService.calculateAndSave(visit, totals);

        // 统计照片
        int photoCount = posInvRepo.countByVisitIdAndPhotoUploaded(visit.getId(), true);

        // CB积分计算
        int cbEarned = cbService.calcAndAward(visit, waterLevels, photoCount);

        // 蝴蝶效应判断
        boolean hasButterfly = waterLevels.stream().anyMatch(WaterLevelResult::getTriggerButterfly);
        String alertTypes = waterLevels.stream()
            .filter(w -> w.getDistortionType() != null)
            .map(WaterLevelResult::getDistortionType)
            .distinct().collect(Collectors.joining(","));

        // 更新拜访记录
        visit.setSubmitTime(LocalDateTime.now());
        visit.setStatus("submitted");
        visit.setPhotosCount(photoCount);
        visit.setCbEarned(cbEarned);
        visit.setButterflyAlert(hasButterfly);
        visit.setAlertTypes(alertTypes.isEmpty() ? null : alertTypes);
        visit.setUpdatedAt(LocalDateTime.now());
        visitRepo.save(visit);

        // 构建响应
        List<String> alerts = new ArrayList<>();
        List<String> agentActions = new ArrayList<>();

        waterLevels.forEach(w -> {
            if ("danger".equals(w.getWaterStatus())) {
                alerts.add("🔴 " + w.getSkuName() + " 库存危险，已触发紧急补货推单");
                agentActions.add("无菜单推单Agent → " + w.getSkuName() + " 补货指令已发送");
            } else if ("warn".equals(w.getWaterStatus())) {
                alerts.add("⚠️ " + w.getSkuName() + " 低于2a预警线，建议近期补货");
            }
            if (Boolean.TRUE.equals(w.getTriggerButterfly())) {
                agentActions.add("蝴蝶效应Agent → 异常检测触发，企微预警已发送");
            }
        });
        agentActions.add("A值校准Agent → 各SKU r值已更新");
        agentActions.add("Uber激励Agent → CB+" + cbEarned + " 已到账");
        if (photoCount > 0) {
            agentActions.add("货架识别训练库 → " + photoCount + "张照片已入库");
        }

        SubmitSummaryResponse resp = new SubmitSummaryResponse();
        resp.setVisitCode(visit.getVisitCode());
        resp.setStoreName(visit.getStore().getStoreName());
        resp.setPositionsCompleted(visit.getPositionsDone());
        resp.setPhotosUploaded(photoCount);
        resp.setCbEarned(cbEarned);
        resp.setWaterLevels(waterLevels);
        resp.setAlerts(alerts);
        resp.setAgentActions(agentActions);
        resp.setSubmitTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM/dd HH:mm")));
        return resp;
    }

    // ----------------------------------------------------------
    // 5. 照片上传完成回调
    // ----------------------------------------------------------
    @Transactional
    public void markPhotoUploaded(Long visitId, Long positionTypeId, String photoUrl) {
        posInvRepo.findByVisitIdAndPositionTypeId(visitId, positionTypeId)
            .ifPresent(pi -> {
                pi.setPhotoUrl(photoUrl);
                pi.setPhotoUploaded(true);
                posInvRepo.save(pi);
                log.info("[训练库] 照片入库 visitId={} position={} url={}", visitId, positionTypeId, photoUrl);
            });
    }

    // ----------------------------------------------------------
    // 工具：计算当前各SKU总库存
    // ----------------------------------------------------------
    private Map<Long, Map<String, Integer>> calcCurrentTotals(Long visitId) {
        Map<Long, Map<String, Integer>> result = new HashMap<>();
        List<PositionInventory> positions = posInvRepo.findByVisitId(visitId);

        for (PositionInventory pi : positions) {
            boolean isStorage = pi.getPositionType().getIsStorage();
            List<PositionSkuInventory> items = posSkuInvRepo.findByPositionInventoryId(pi.getId());
            for (PositionSkuInventory item : items) {
                Long skuId = item.getSku().getId();
                result.computeIfAbsent(skuId, k -> new HashMap<>(Map.of("shelf", 0, "storage", 0, "all", 0)));
                int bottles = item.getBottlesTotal();
                if (isStorage) {
                    result.get(skuId).merge("storage", bottles, Integer::sum);
                } else {
                    result.get(skuId).merge("shelf", bottles, Integer::sum);
                }
                result.get(skuId).merge("all", bottles, Integer::sum);
            }
        }
        return result;
    }

    // GPS距离计算（Haversine公式）
    private double calcDistance(double lat1, double lng1, double lat2, double lng2) {
        final int R = 6371000; // 地球半径（米）
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2)
            + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
            * Math.sin(dLng/2) * Math.sin(dLng/2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    }
}
