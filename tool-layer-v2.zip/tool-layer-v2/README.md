# INFINITY OS · 调用层四层体系 v2.0
## 完整交付包

---

## 文件清单

```
tool-layer-v2/
├── sql/
│   ├── V1__layer1_perception.sql    ← 感知层·3张表+1个视图·4类触发源+6个SFA定时任务
│   ├── V2__layer2_routing.sql       ← 路由层·3张表+1个视图·7条路由规则·4种执行模式
│   ├── V3__layer3_execution.sql     ← 执行层·3张表+1个视图·20个工具注册表
│   └── V4__layer4_feedback.sql      ← 反馈层·5张表+1个视图·审批队列·信用分日志
│
└── java/com/xinhe/infinityos/tool/
    ├── layer1/PerceptionService.java  ← 感知层·4类触发源统一入站+6个定时SFA触发器
    ├── layer2/RoutingService.java     ← 路由层·关键词规则匹配+任务队列创建
    ├── layer3/ToolExecutionService.java ← 执行层·20个工具调用实现+限流+重试
    ├── layer3/ToolResult.java         ← 工具结果数据结构
    ├── layer4/FeedbackService.java    ← 反馈层·审批处理+信用分+级联触发+用户反馈
    └── orchestrator/ToolOrchestrator.java ← ⭐统一调度器·四层串联·单一入口
```

---

## 四层对照表

| 层面 | 核心问题 | 实现 | 预置数据 |
|------|---------|------|---------|
| 层面一·感知 | 谁来触发？ | 4种触发源统一登记 | 6个SFA定时任务·4个Webhook端点 |
| 层面二·路由 | 派给谁做？怎么做？ | 关键词匹配+4种执行模式 | 7条预设路由规则 |
| 层面三·执行 | 具体怎么调用？ | 20个工具注册+限流+重试 | 20个工具定义 |
| 层面四·反馈 | 做完了然后呢？ | 写回记忆·审批·信用分·级联 | 审批超时处理·自动级联规则 |

---

## 4种执行模式

```
single     → 一个Agent独立处理
parallel   → 主Agent + 多个二级Agent同时启动
sequential → 主Agent完成后 → 二级Agent按顺序执行
pipeline   → 每步依赖上一步的输出（最常用）
```

---

## 7条预设路由规则（关键词触发）

| 规则 | 关键词 | 执行模式 | 处理链 |
|------|--------|---------|--------|
| 库存异常 | 库存/缺货/断货/压货 | pipeline | 蝴蝶效应→零售门店→推单→激励 |
| 补货指令 | 推单/补货/下单 | sequential | a值校准→推单→经销商 |
| 货架扫描 | 货架/陈列/照片 | pipeline | 货架识别→库存上报→激励积分 |
| 蝴蝶检测 | 蝴蝶/失真/传导 | single | 蝴蝶效应 |
| 战略分析 | 战略/分析/趋势 | parallel | 总指挥+品牌顾问+PRISM并行 |
| 价格违规 | 底价/乱价/¥17 | sequential | 价签识别→二批商→蝴蝶效应 |
| 默认兜底 | 其他所有 | single | AIO总指挥 |

---

## 20个工具分类

| 类别 | 工具 | auth级别 | 可逆 |
|------|------|---------|------|
| 数据读取 | T01-T08 | 0（自主）| ✅ |
| AI推理 | T09-T12 | 0（自主）| ✅ |
| 通知 | T13·T14 | 0-1 | ✅ |
| 短信告警 | T15 | 2（主管）| ✅ |
| 创建订单 | T16 | 2（主管）| ❌ 不可逆 |
| 更新库存 | T17 | 1（快速）| ❌ |
| 记录异常 | T18 | 0（自主）| ✅ |
| 更新CB分 | T19 | 2（主管）| ❌ |
| SAP同步 | T20 | 1（快速）| ✅ |

---

## 与三大模块的完整集成关系

```
用户提问
  ↓
ToolOrchestrator.handleUserRequest()
  ↓
[层面一·感知] PerceptionService.receiveUserRequest()
  ↓
[层面二·路由] RoutingService.route() → 创建任务队列
  ↓
[记忆层] MemoryOrchestrator.buildContext() ← 注入四层记忆
  ↓
[授权边界] AuthorizationEngine.evaluate() ← 26维度评估
  ↓ 自主执行
[层面三·执行] ToolExecutionService.executeTool() × N
  ↓ 每个工具完成
[层面四·反馈] FeedbackService.onTaskCompleted()
  ├── 更新Agent信用分
  ├── 触发pipeline下一步
  ├── 写回记忆层（SharedMemory + OrgKnowledge）
  └── 检查是否级联触发其他Agent
  ↓ 全部完成
最终回答 → 用户界面 / 企微推送
```

---

## 集成步骤

### Step 1：建表（1小时）
```sql
source V1__layer1_perception.sql;
source V2__layer2_routing.sql;
source V3__layer3_execution.sql;
source V4__layer4_feedback.sql;

-- 验证
SELECT COUNT(*) FROM sfa_report_schedules;  -- 应为6
SELECT COUNT(*) FROM routing_rules;          -- 应为7
SELECT COUNT(*) FROM tool_registry;          -- 应为20
```

### Step 2：Java包集成（1天）
将 `tool` 包复制到项目，在主控制器中：
```java
// 用户提问的唯一入口
@PostMapping("/api/chat")
public ResponseEntity<String> chat(@RequestBody ChatRequest req) {
    String requestId = toolOrchestrator.handleUserRequest(
        req.getUserId(), req.getSessionId(), req.getInput()
    );
    return ResponseEntity.ok(requestId);
}

// 前端轮询结果
@GetMapping("/api/result/{requestId}")
public ResponseEntity<Map> getResult(@PathVariable String requestId) {
    return ResponseEntity.ok(perceptionService.getRequestStatus(requestId));
}
```

### Step 3：实现外部API客户端（各1天）
```
SfaApiClient       → GET /sfa/store/{id}/inventory
SapApiClient       → RFC调用SAP获取订单/库存
WechatWorkClient   → 企微消息推送 + 审批按钮
ClaudeApiClient    → POST api.anthropic.com/v1/messages
QianwenVLClient    → 千问VL图像识别API
```

### Step 4：配置企微Webhook审批回调（0.5天）
```java
@PostMapping("/webhook/wechat/approval")
public void handleApproval(@RequestBody WechatApprovalCallback cb) {
    if ("approved".equals(cb.getResult())) {
        feedbackService.onApprovalGranted(cb.getApprovalId(), cb.getApprovedBy());
    } else {
        feedbackService.onApprovalRejected(cb.getApprovalId(),
            cb.getApprovedBy(), cb.getReason());
    }
}
```

---

## Java团队工作量估算（MVP）

| 任务 | 工作量 |
|------|--------|
| 建表+Java包复制 | 1.5天 |
| SfaApiClient（库存读取） | 1天 |
| ClaudeApiClient（AI分析） | 0.5天 |
| WechatWorkClient（推送+审批） | 1天 |
| 联调测试 | 1天 |
| **MVP合计** | **5天** |

---

## MVP优先路径

按此顺序上线，每步都能独立验证：

1. `T01_STORE_INVENTORY` + `T13_WECHAT_PUSH` → **SFA库存上报→企微通知** → 最高优先级
2. `T09_AI_ANALYZE` → **用户问答有AI回复**
3. `T16_CREATE_ORDER` + `T14_WECHAT_APPROVAL` → **推单+审批闭环**
4. `T11_SHELF_RECOGNITION` → **货架AI识别**
5. 其余工具逐步接入
