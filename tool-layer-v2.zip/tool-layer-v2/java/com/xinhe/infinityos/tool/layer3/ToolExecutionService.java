// ============================================================
// ToolExecutionService.java
// 层面三：执行层·20个工具的调用实现
// 每次调用前：auth-boundary评估 + 限流检查
// ============================================================
package com.xinhe.infinityos.tool.layer3;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ToolExecutionService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // 外部服务（Java团队实现）
    // @Autowired private SfaApiClient sfaClient;
    // @Autowired private SapApiClient sapClient;
    // @Autowired private WechatWorkClient wechatClient;
    // @Autowired private ClaudeApiClient claudeClient;
    // @Autowired private QianwenVLClient qianwenClient;
    // @Autowired private AuthorizationEngine authEngine;

    // ══ 统一工具调用入口 ══════════════════════════════════════

    /**
     * 执行工具调用·唯一入口
     * 内部完成：限流检查 → auth评估 → 实际调用 → 记录结果
     */
    public ToolResult executeTool(String taskId, String requestId, String agentId,
                                   String toolId, Map<String, Object> params) {
        String executionId = "EXEC_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        // 1. 加载工具定义
        Map<String, Object> tool = getToolDef(toolId);
        if (tool == null) {
            return ToolResult.fail("工具不存在: " + toolId, null);
        }

        // 2. 检查Agent是否有权限使用此工具
        if (!isAgentAllowed(agentId, tool)) {
            return ToolResult.fail("Agent " + agentId + " 无权使用工具 " + toolId, null);
        }

        // 3. 限流检查
        if (!checkRateLimit(toolId, agentId, tool)) {
            return ToolResult.fail("工具调用频率超限: " + toolId, null);
        }

        // 4. 创建执行记录
        createExecutionLog(executionId, taskId, requestId, agentId, toolId, params);

        // 5. auth-boundary评估（实际项目注入AuthorizationEngine）
        int authLevel = assessAuth(agentId, toolId, params, tool);
        if (authLevel == 5) { // HARD_BLOCK
            updateExecutionLog(executionId, "failed", null, "AUTH_BLOCKED", "授权边界拒绝执行");
            return ToolResult.fail("授权边界拒绝: " + toolId, executionId);
        }
        if (authLevel >= 1) { // 需要人工审批
            updateExecutionLog(executionId, "pending", null, null, null);
            return ToolResult.pendingApproval(executionId, authLevel);
        }

        // 6. 执行工具
        long startMs = System.currentTimeMillis();
        updateExecutionLogStatus(executionId, "running");

        ToolResult result;
        try {
            result = dispatchTool(toolId, agentId, params);
            long latency = System.currentTimeMillis() - startMs;
            updateExecutionLog(executionId, "success", result.getData(), null, null);
            updateLatency(executionId, (int) latency);

        } catch (Exception e) {
            // 自动重试（最多3次）
            result = retryTool(executionId, toolId, agentId, params, tool, e);
        }

        return result;
    }

    // ══ 20个工具的分发 ════════════════════════════════════════

    private ToolResult dispatchTool(String toolId, String agentId, Map<String, Object> params) {
        switch (toolId) {
            // ── 数据读取类 ──────────────────────────────────────
            case "T01_STORE_INVENTORY":   return readStoreInventory(params);
            case "T02_DISTRIBUTOR_STOCK": return readDistributorStock(params);
            case "T03_DAILY_SALES":       return readDailySales(params);
            case "T04_STORE_VISITS":      return readStoreVisits(params);
            case "T05_PRICE_CHECK":       return readPriceData(params);
            case "T06_PHOTO_SHELF":       return fetchShelfPhoto(params);
            case "T07_SAP_ORDER":         return readSapOrders(params);
            case "T08_CITY_STATS":        return readCityStats(params);
            // ── AI推理类 ────────────────────────────────────────
            case "T09_AI_ANALYZE":        return aiAnalyze(agentId, params);
            case "T10_AI_SUMMARIZE":      return aiSummarize(params);
            case "T11_SHELF_RECOGNITION": return shelfRecognition(params);
            case "T12_PRICE_TAG_OCR":     return priceTagOcr(params);
            // ── 通知类 ──────────────────────────────────────────
            case "T13_WECHAT_PUSH":       return wechatPush(params);
            case "T14_WECHAT_APPROVAL":   return wechatApproval(params);
            case "T15_SMS_ALERT":         return smsAlert(params);
            // ── 数据写入类 ──────────────────────────────────────
            case "T16_CREATE_ORDER":      return createOrder(params);
            case "T17_UPDATE_INVENTORY":  return updateInventory(params);
            case "T18_LOG_ANOMALY":       return logAnomaly(params);
            case "T19_UPDATE_CB_SCORE":   return updateCbScore(params);
            // ── 系统集成类 ──────────────────────────────────────
            case "T20_SYNC_SAP":          return syncSap(params);

            default:
                throw new IllegalArgumentException("未知工具: " + toolId);
        }
    }

    // ══ 20个工具的具体实现（桩实现·Java团队完善）════════════

    private ToolResult readStoreInventory(Map<String, Object> params) {
        // String storeId = String.valueOf(params.get("store_id"));
        // return sfaClient.getStoreInventory(storeId);  ← Java团队实现
        return ToolResult.ok(Map.of(
            "store_id", params.get("store_id"),
            "shelf_stock", 120,    // 货架库存（实际从SFA读取）
            "warehouse_stock", 80, // 仓库库存
            "total_stock", 200,
            "inventory_ratio", 2.5, // 当前库存/a值
            "water_level", "normal" // safe/warning/critical
        ));
    }

    private ToolResult readDistributorStock(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "distributor_id", params.get("distributor_id"),
            "current_stock", 5000,
            "inventory_ratio", 1.8,
            "last_order_date", "2026-04-05",
            "water_level", "normal"
        ));
    }

    private ToolResult readDailySales(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "entity_id", params.get("entity_id"),
            "date", params.getOrDefault("date", "today"),
            "sales_quantity", 48,
            "sales_amount", 2400.0,
            "r_value", 1.6,        // 日销率
            "vs_target", 0.85     // 目标达成率
        ));
    }

    private ToolResult readStoreVisits(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "store_id", params.get("store_id"),
            "last_visit_date", "2026-04-10",
            "visit_count_this_week", 2,
            "tier_requirement", 3,     // S+门店每周3次
            "compliance_rate", 0.67    // 达标率
        ));
    }

    private ToolResult readPriceData(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "entity_id", params.get("entity_id"),
            "current_price", 29.9,
            "floor_price", 17.0,
            "is_compliant", true,
            "last_checked", "2026-04-11"
        ));
    }

    private ToolResult fetchShelfPhoto(Map<String, Object> params) {
        // return sfaClient.getLatestShelfPhoto(params.get("store_id"));
        return ToolResult.ok(Map.of(
            "photo_url", "https://sfa.xinhe.com/photos/STORE_001/2026-04-11.jpg",
            "uploaded_at", "2026-04-11 09:30:00",
            "uploaded_by", "field_rep_001"
        ));
    }

    private ToolResult readSapOrders(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "distributor_id", params.get("distributor_id"),
            "orders_this_month", 3,
            "total_amount", 85000.0,
            "last_order_amount", 28000.0
        ));
    }

    private ToolResult readCityStats(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "city_id", params.get("city_id"),
            "total_stores", 127,
            "coverage_rate", 0.78,
            "avg_r_value", 1.42,
            "stores_below_2a", 12,
            "avg_inventory_ratio", 2.3
        ));
    }

    private ToolResult aiAnalyze(String agentId, Map<String, Object> params) {
        // String question = String.valueOf(params.get("question"));
        // String systemPrompt = String.valueOf(params.get("system_prompt"));
        // return claudeClient.analyze(systemPrompt, question);  ← Java团队实现
        return ToolResult.ok(Map.of(
            "analysis", "[AI推理结果·待接入Claude API]",
            "confidence", 0.85,
            "agent_id", agentId
        ));
    }

    private ToolResult aiSummarize(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "summary", "[摘要结果·待接入Claude API]",
            "original_length", params.getOrDefault("text_length", 0),
            "summary_length", 200
        ));
    }

    private ToolResult shelfRecognition(Map<String, Object> params) {
        // return qianwenClient.recognizeShelf(params.get("photo_url"));
        return ToolResult.ok(Map.of(
            "sku_count", 8,
            "brand_coverage", 0.75,
            "golden_position", true,
            "competitor_ratio", 0.25,
            "recognition_confidence", 0.82,
            "error_rate_estimate", 0.18
        ));
    }

    private ToolResult priceTagOcr(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "detected_price", 26.8,
            "floor_price", 17.0,
            "is_compliant", true,
            "ocr_confidence", 0.91
        ));
    }

    private ToolResult wechatPush(Map<String, Object> params) {
        // wechatClient.push(params.get("to"), params.get("message"));
        return ToolResult.ok(Map.of(
            "sent_to", params.get("to"),
            "message_id", "MSG_" + System.currentTimeMillis(),
            "status", "sent"
        ));
    }

    private ToolResult wechatApproval(Map<String, Object> params) {
        // wechatClient.createApproval(params);
        return ToolResult.ok(Map.of(
            "approval_id", "APR_" + System.currentTimeMillis(),
            "sent_to", params.get("approver"),
            "expires_in_hours", params.getOrDefault("expire_hours", 4),
            "status", "pending"
        ));
    }

    private ToolResult smsAlert(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "sent_to", params.get("phone"),
            "sms_id", "SMS_" + System.currentTimeMillis(),
            "status", "sent"
        ));
    }

    private ToolResult createOrder(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "order_id", "ORD_" + System.currentTimeMillis(),
            "distributor_id", params.get("distributor_id"),
            "amount", params.get("amount"),
            "sku_lines", params.get("sku_lines"),
            "status", "created"
        ));
    }

    private ToolResult updateInventory(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "store_id", params.get("store_id"),
            "updated_fields", List.of("shelf_stock", "warehouse_stock"),
            "water_level_recalculated", true,
            "status", "updated"
        ));
    }

    private ToolResult logAnomaly(Map<String, Object> params) {
        String caseId = "CASE_" + System.currentTimeMillis();
        jdbc.update(
            "INSERT INTO anomaly_case_library(case_id, anomaly_type, entity_type, entity_id, " +
            "detected_at, detected_by, description, severity) VALUES(?,?,?,?,NOW(),?,?,?)",
            caseId,
            params.getOrDefault("anomaly_type", "unknown"),
            params.getOrDefault("entity_type", "store"),
            params.getOrDefault("entity_id", "unknown"),
            params.getOrDefault("detected_by", "system"),
            params.getOrDefault("description", ""),
            params.getOrDefault("severity", "medium")
        );
        return ToolResult.ok(Map.of("case_id", caseId, "status", "logged"));
    }

    private ToolResult updateCbScore(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "rep_id", params.get("rep_id"),
            "new_score", params.get("new_score"),
            "delta", params.get("delta"),
            "status", "updated"
        ));
    }

    private ToolResult syncSap(Map<String, Object> params) {
        return ToolResult.ok(Map.of(
            "sync_id", "SYNC_" + System.currentTimeMillis(),
            "tables_synced", List.of("VBAK","VBAP","MARA","MARC"),
            "status", "triggered"
        ));
    }

    // ══ 限流检查 ══════════════════════════════════════════════

    private boolean checkRateLimit(String toolId, String agentId, Map<String, Object> tool) {
        Object rateLimit = tool.get("rate_limit_per_minute");
        if (rateLimit == null) return true;
        int limit = ((Number) rateLimit).intValue();

        int currentCount = jdbc.queryForObject(
            "SELECT COALESCE(call_count, 0) FROM tool_rate_counters " +
            "WHERE tool_id=? AND agent_id=? AND window_minute >= DATE_FORMAT(NOW(),'%Y-%m-%d %H:%i:00')",
            Integer.class, toolId, agentId
        );

        if (currentCount >= limit) return false;

        jdbc.update(
            "INSERT INTO tool_rate_counters(tool_id, agent_id, window_minute, call_count) " +
            "VALUES(?, ?, DATE_FORMAT(NOW(),'%Y-%m-%d %H:%i:00'), 1) " +
            "ON DUPLICATE KEY UPDATE call_count=call_count+1",
            toolId, agentId
        );
        return true;
    }

    // ══ auth评估（桩实现·实际注入AuthorizationEngine）═══════

    private int assessAuth(String agentId, String toolId, Map<String, Object> params, Map<String, Object> tool) {
        int minLevel = ((Number) tool.getOrDefault("min_auth_level", 0)).intValue();
        // 实际调用: return authEngine.evaluate(AuthRequest.forTool(agentId, toolId, params)).getFinalLevel();
        return minLevel; // 桩：直接返回工具定义的最低级别
    }

    // ══ 重试机制 ══════════════════════════════════════════════

    private ToolResult retryTool(String executionId, String toolId, String agentId,
                                   Map<String, Object> params, Map<String, Object> tool, Exception firstError) {
        int maxRetries = ((Number) tool.getOrDefault("max_retries", 3)).intValue();

        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                Thread.sleep(1000L * attempt); // 退避等待
                updateExecutionLogStatus(executionId, "retrying");
                jdbc.update("UPDATE tool_execution_log SET retry_count=? WHERE execution_id=?",
                    attempt, executionId);
                ToolResult result = dispatchTool(toolId, agentId, params);
                updateExecutionLog(executionId, "success", result.getData(), null, null);
                return result;
            } catch (Exception e) {
                if (attempt == maxRetries) {
                    updateExecutionLog(executionId, "failed", null,
                        "MAX_RETRY_EXCEEDED", e.getMessage());
                    return ToolResult.fail("工具调用失败(" + maxRetries + "次重试后): " + e.getMessage(), executionId);
                }
            }
        }
        return ToolResult.fail("重试失败: " + firstError.getMessage(), executionId);
    }

    // ══ 工具方法 ══════════════════════════════════════════════

    private Map<String, Object> getToolDef(String toolId) {
        try {
            return jdbc.queryForMap(
                "SELECT * FROM tool_registry WHERE tool_id=? AND is_active=1", toolId
            );
        } catch (Exception e) { return null; }
    }

    private boolean isAgentAllowed(String agentId, Map<String, Object> tool) {
        Object allowedJson = tool.get("allowed_agents");
        if (allowedJson == null) return true; // null=所有Agent
        try {
            List<String> allowed = mapper.readValue(allowedJson.toString(), List.class);
            return allowed.contains(agentId);
        } catch (Exception e) { return true; }
    }

    private void createExecutionLog(String executionId, String taskId, String requestId,
                                     String agentId, String toolId, Map<String, Object> params) {
        try {
            jdbc.update(
                "INSERT INTO tool_execution_log(execution_id, task_id, request_id, agent_id, " +
                "tool_id, input_params, status) VALUES(?,?,?,?,?,?,?)",
                executionId, taskId, requestId, agentId, toolId,
                mapper.writeValueAsString(params), "pending"
            );
        } catch (Exception ignored) {}
    }

    private void updateExecutionLog(String executionId, String status,
                                     Map<String, Object> output, String errorCode, String errorMsg) {
        try {
            jdbc.update(
                "UPDATE tool_execution_log SET status=?, output_result=?, " +
                "error_code=?, error_message=?, completed_at=NOW() WHERE execution_id=?",
                status,
                output != null ? mapper.writeValueAsString(output) : null,
                errorCode, errorMsg, executionId
            );
        } catch (Exception ignored) {}
    }

    private void updateExecutionLogStatus(String executionId, String status) {
        jdbc.update("UPDATE tool_execution_log SET status=? WHERE execution_id=?",
            status, executionId);
    }

    private void updateLatency(String executionId, int latencyMs) {
        jdbc.update("UPDATE tool_execution_log SET latency_ms=?, started_at=NOW() WHERE execution_id=?",
            latencyMs, executionId);
    }
}
