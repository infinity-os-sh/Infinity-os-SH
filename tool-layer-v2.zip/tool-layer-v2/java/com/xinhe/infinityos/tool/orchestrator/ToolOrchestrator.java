// ============================================================
// ToolOrchestrator.java
// 调用层四层统一调度器·单一入口
// 感知 → 路由 → 记忆组装 → 授权 → 执行 → 反馈
// ============================================================
package com.xinhe.infinityos.tool.orchestrator;

import com.xinhe.infinityos.tool.layer1.PerceptionService;
import com.xinhe.infinityos.tool.layer2.RoutingService;
import com.xinhe.infinityos.tool.layer3.ToolExecutionService;
import com.xinhe.infinityos.tool.layer3.ToolResult;
import com.xinhe.infinityos.tool.layer4.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ToolOrchestrator {

    @Autowired private PerceptionService  perception;
    @Autowired private RoutingService     routing;
    @Autowired private ToolExecutionService execution;
    @Autowired private FeedbackService    feedback;

    // 跨模块引用记忆层
    // @Autowired private MemoryOrchestrator memoryOrchestrator;

    // ══ 最核心方法：用户提问的完整处理流水线 ═════════════════

    /**
     * 用户在INFINITY OS中提问时·调用此方法
     *
     * 内部完成：
     * 感知（登记请求）→ 路由（派发Agent）→ 记忆组装（注入四层上下文）
     * → 每个Agent执行工具 → 反馈（写回记忆·汇总结果）
     *
     * 返回：requestId，前端用requestId轮询最终结果
     */
    public String handleUserRequest(String userId, String sessionId, String input) {
        return handleUserRequest(userId, sessionId, input, "normal");
    }

    public String handleUserRequest(String userId, String sessionId,
                                     String input, String priority) {
        // ── 层面一：感知·登记请求 ────────────────────────────
        String requestId = perception.receiveUserRequest(userId, sessionId, input, priority);
        perception.updateRequestStatus(requestId, "routing");

        // ── 层面二：路由·创建任务队列 ────────────────────────
        List<String> taskIds = routing.route(requestId);
        perception.updateRequestStatus(requestId, "executing");

        // ── 执行：遍历就绪任务·驱动整个流水线 ────────────────
        // 实际项目建议用事件驱动（MQ）；此处展示简化的同步驱动逻辑
        executeReadyTasks(requestId);

        return requestId;  // 前端用此ID轮询结果
    }

    /**
     * 执行某个请求下所有就绪的任务
     * pipeline模式下·每个任务完成后自动检查并启动下一个
     */
    public void executeReadyTasks(String requestId) {
        List<Map<String, Object>> readyTasks = routing.getReadyTasks(requestId);

        for (Map<String, Object> task : readyTasks) {
            String taskId  = String.valueOf(task.get("task_id"));
            String agentId = String.valueOf(task.get("agent_id"));
            String taskType = String.valueOf(task.get("task_type"));

            routing.markTaskRunning(taskId);

            // ── 层面三：根据taskType选择工具并执行 ───────────
            String toolId = resolveToolId(agentId, taskType, task);

            try {
                Map<String, Object> inputData = parseInputData(task);

                ToolResult result = execution.executeTool(
                    taskId, requestId, agentId, toolId, inputData
                );

                if (result.isOk()) {
                    routing.markTaskCompleted(taskId, result.getData());
                    // ── 层面四：反馈·成功 ─────────────────────
                    feedback.onTaskCompleted(requestId, taskId, agentId,
                        result.getData(), true);

                } else if (result.isPendingApproval()) {
                    // 需要人工审批：创建审批任务·企微推送
                    feedback.createApprovalRequest(
                        requestId, taskId, agentId,
                        toolId,
                        buildActionSummary(agentId, toolId, inputData),
                        inputData,
                        resolveRiskLevel(result.getAuthLevel()),
                        result.getAuthLevel(),
                        resolveApprover(result.getAuthLevel()),
                        buildPlainReason(agentId, toolId, inputData, result.getAuthLevel())
                    );
                    // 任务状态保持pending，等待审批回调

                } else {
                    // 失败
                    routing.markTaskFailed(taskId, result.getErrorMessage());
                    feedback.onTaskCompleted(requestId, taskId, agentId,
                        Map.of("error", result.getErrorMessage()), false);
                }

            } catch (Exception e) {
                routing.markTaskFailed(taskId, e.getMessage());
                feedback.onTaskCompleted(requestId, taskId, agentId,
                    Map.of("exception", e.getMessage()), false);
            }
        }
    }

    // ══ Agent→工具的映射 ══════════════════════════════════════

    /**
     * 根据Agent和任务类型，决定调用哪个工具
     * 实际项目可以让Agent自己决定（Agentic Loop），此处用静态映射简化
     */
    private String resolveToolId(String agentId, String taskType, Map<String, Object> task) {
        return switch (agentId) {
            case "retail_store"      -> "T01_STORE_INVENTORY";
            case "distributor"       -> "T02_DISTRIBUTOR_STOCK";
            case "butterfly"         -> "T01_STORE_INVENTORY"; // 读全链数据
            case "omakase"           -> "T16_CREATE_ORDER";
            case "shelf_recognition" -> "T11_SHELF_RECOGNITION";
            case "inventory_report"  -> "T17_UPDATE_INVENTORY";
            case "price_tag"         -> "T12_PRICE_TAG_OCR";
            case "uber_incentive"    -> "T19_UPDATE_CB_SCORE";
            case "a_calibration"     -> "T03_DAILY_SALES";
            case "aio_commander"     -> "T09_AI_ANALYZE";
            case "brand_advisor"     -> "T09_AI_ANALYZE";
            case "prism"             -> "T08_CITY_STATS";
            case "production"        -> "T20_SYNC_SAP";
            case "sub_distributor"   -> "T05_PRICE_CHECK";
            default                  -> "T09_AI_ANALYZE"; // 兜底：AI分析
        };
    }

    // ══ 辅助构建方法 ══════════════════════════════════════════

    private String buildActionSummary(String agentId, String toolId, Map<String, Object> input) {
        return switch (toolId) {
            case "T16_CREATE_ORDER" ->
                "为经销商 " + input.getOrDefault("distributor_id", "?") +
                " 创建补货单 ¥" + input.getOrDefault("amount", "?");
            case "T19_UPDATE_CB_SCORE" ->
                "更新美顾 " + input.getOrDefault("rep_id", "?") + " 的CB评分";
            case "T15_SMS_ALERT" ->
                "发送短信告警至 " + input.getOrDefault("phone", "?");
            default ->
                agentId + " 执行 " + toolId;
        };
    }

    private String buildPlainReason(String agentId, String toolId,
                                     Map<String, Object> input, int authLevel) {
        return switch (authLevel) {
            case 1 -> "此操作属于快速通道（2小时内确认）。原因：" + agentId + "发起" + toolId + "，金额或影响范围需要快速确认。";
            case 2 -> "此操作需要主管审批。" + agentId + "请求执行" + toolId + "，影响范围超出自主执行边界。";
            case 3 -> "此操作需要总监审批。涉及金额或影响范围较大，需48小时内处理。";
            default -> agentId + " 需要审批才能执行 " + toolId;
        };
    }

    private String resolveRiskLevel(int authLevel) {
        return switch (authLevel) {
            case 1 -> "low";
            case 2 -> "medium";
            case 3 -> "high";
            default -> "low";
        };
    }

    private String resolveApprover(int authLevel) {
        // 实际项目从组织架构表查询对应角色的用户ID
        return switch (authLevel) {
            case 1 -> "fast_track_approver";
            case 2 -> "manager";
            case 3 -> "director";
            default -> "manager";
        };
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseInputData(Map<String, Object> task) {
        try {
            Object inputData = task.get("input_data");
            if (inputData == null) return Map.of();
            if (inputData instanceof Map) return (Map<String, Object>) inputData;
            return new com.fasterxml.jackson.databind.ObjectMapper()
                .readValue(inputData.toString(), Map.class);
        } catch (Exception e) { return Map.of(); }
    }
}
