// ============================================================
// RoutingService.java
// 层面二：路由层·AIO总指挥派发器
// 判断：哪个Agent·单/多·顺序/并发
// ============================================================
package com.xinhe.infinityos.tool.layer2;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RoutingService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // ══ 核心路由方法 ══════════════════════════════════════════

    /**
     * 为请求匹配路由规则，创建执行任务
     * 返回创建的task_id列表
     */
    public List<String> route(String requestId) {
        // 1. 加载请求信息
        Map<String, Object> request;
        try {
            request = jdbc.queryForMap(
                "SELECT * FROM trigger_requests WHERE request_id=?", requestId
            );
        } catch (Exception e) {
            throw new IllegalStateException("请求不存在: " + requestId);
        }

        String rawInput = String.valueOf(request.get("raw_input"));
        String triggerType = String.valueOf(request.get("trigger_type"));
        String priority = String.valueOf(request.get("priority"));

        // 2. 匹配路由规则
        Map<String, Object> matchedRule = matchRule(rawInput, triggerType, priority);

        // 3. 记录路由决策
        recordRoutingDecision(requestId, matchedRule);

        // 4. 按执行模式创建任务
        String executionMode = String.valueOf(matchedRule.get("execution_mode"));
        String primaryAgent = String.valueOf(matchedRule.get("primary_agent"));
        List<String> secondaryAgents = parseJsonList(matchedRule.get("secondary_agents"));
        List<Map<String, Object>> pipelineSteps = parseJsonMapList(matchedRule.get("pipeline_steps"));

        List<String> taskIds = new ArrayList<>();

        switch (executionMode) {
            case "single":
                taskIds.add(createTask(requestId, primaryAgent, "analyze",
                    0, null, buildTaskInput(request, null)));
                break;

            case "parallel":
                // 主Agent + 所有二级Agent同时启动
                taskIds.add(createTask(requestId, primaryAgent, "analyze",
                    0, null, buildTaskInput(request, null)));
                for (String agent : secondaryAgents) {
                    taskIds.add(createTask(requestId, agent, "analyze",
                        0, null, buildTaskInput(request, null)));
                }
                break;

            case "sequential":
                // 主Agent → 二级Agent顺序执行
                String prevTaskId = null;
                String firstTaskId = createTask(requestId, primaryAgent, "analyze",
                    1, null, buildTaskInput(request, null));
                taskIds.add(firstTaskId);
                prevTaskId = firstTaskId;
                int seq = 2;
                for (String agent : secondaryAgents) {
                    String taskId = createTask(requestId, agent, "execute",
                        seq++, prevTaskId, buildTaskInput(request, prevTaskId));
                    taskIds.add(taskId);
                    prevTaskId = taskId;
                }
                break;

            case "pipeline":
                // 按pipeline_steps定义的顺序，每步依赖上一步
                if (!pipelineSteps.isEmpty()) {
                    taskIds.addAll(createPipelineTasks(requestId, pipelineSteps, request));
                } else {
                    // fallback到sequential
                    taskIds.add(createTask(requestId, primaryAgent, "analyze",
                        1, null, buildTaskInput(request, null)));
                    prevTaskId = taskIds.get(0);
                    int ps = 2;
                    for (String agent : secondaryAgents) {
                        String taskId = createTask(requestId, agent, "execute",
                            ps++, prevTaskId, buildTaskInput(request, prevTaskId));
                        taskIds.add(taskId);
                        prevTaskId = taskId;
                    }
                }
                break;

            default:
                taskIds.add(createTask(requestId, "aio_commander", "analyze",
                    0, null, buildTaskInput(request, null)));
        }

        // 5. 更新请求状态
        jdbc.update(
            "UPDATE trigger_requests SET status='routing', routed_at=NOW() WHERE request_id=?",
            requestId
        );

        // 6. 更新路由规则命中次数
        if (matchedRule.get("rule_id") != null) {
            jdbc.update(
                "UPDATE routing_rules SET hit_count=hit_count+1 WHERE rule_id=?",
                matchedRule.get("rule_id")
            );
        }

        return taskIds;
    }

    // ══ 规则匹配 ══════════════════════════════════════════════

    private Map<String, Object> matchRule(String input, String triggerType, String priority) {
        List<Map<String, Object>> rules = jdbc.queryForList(
            "SELECT * FROM routing_rules WHERE is_active=1 ORDER BY confidence DESC"
        );

        for (Map<String, Object> rule : rules) {
            // 检查trigger_type匹配
            String ruleTriggerType = (String) rule.get("trigger_type");
            if (ruleTriggerType != null && !ruleTriggerType.equals(triggerType)) continue;

            // 检查关键词匹配
            List<String> keywords = parseJsonStringList(rule.get("keyword_patterns"));
            if (!keywords.isEmpty()) {
                boolean keywordMatch = false;
                String lowerInput = input != null ? input.toLowerCase() : "";
                for (String kw : keywords) {
                    if (lowerInput.contains(kw.toLowerCase())) {
                        keywordMatch = true;
                        break;
                    }
                }
                if (!keywordMatch) continue;
            }

            // 规则匹配！返回
            return rule;
        }

        // 没有匹配的规则，使用默认路由（AIO总指挥兜底）
        return Map.of(
            "rule_id", "DEFAULT",
            "execution_mode", "single",
            "primary_agent", "aio_commander",
            "secondary_agents", "[]",
            "pipeline_steps", "[]",
            "confidence", 0.6
        );
    }

    // ══ 任务创建 ══════════════════════════════════════════════

    private String createTask(String requestId, String agentId, String taskType,
                               int sequenceOrder, String dependsOnTask,
                               Map<String, Object> inputData) {
        String taskId = "TASK_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        // 计算超时时间（默认5分钟）
        long timeoutMs = System.currentTimeMillis() + 300_000L;

        try {
            jdbc.update(
                "INSERT INTO agent_task_queue(task_id, request_id, agent_id, task_type, " +
                "sequence_order, depends_on_task, input_data, timeout_at) " +
                "VALUES(?,?,?,?,?,?,?,?)",
                taskId, requestId, agentId, taskType, sequenceOrder,
                dependsOnTask, mapper.writeValueAsString(inputData),
                new java.sql.Timestamp(timeoutMs)
            );
        } catch (Exception e) {
            throw new RuntimeException("创建任务失败", e);
        }

        return taskId;
    }

    private List<String> createPipelineTasks(String requestId,
                                              List<Map<String, Object>> steps,
                                              Map<String, Object> request) {
        List<String> taskIds = new ArrayList<>();
        String prevTaskId = null;

        for (int i = 0; i < steps.size(); i++) {
            Map<String, Object> step = steps.get(i);
            String agentId = String.valueOf(step.get("agent_id"));
            String taskType = String.valueOf(step.getOrDefault("task_type", "execute"));
            Map<String, Object> stepInput = buildTaskInput(request, prevTaskId);
            stepInput.put("pipeline_step", i + 1);

            String taskId = createTask(requestId, agentId, taskType,
                i + 1, prevTaskId, stepInput);
            taskIds.add(taskId);
            prevTaskId = taskId;
        }

        return taskIds;
    }

    // ══ 路由决策记录 ══════════════════════════════════════════

    private void recordRoutingDecision(String requestId, Map<String, Object> rule) {
        try {
            jdbc.update(
                "INSERT INTO routing_decisions(request_id, matched_rule_id, execution_mode, " +
                "primary_agent, secondary_agents, routing_reason, confidence) VALUES(?,?,?,?,?,?,?)",
                requestId,
                rule.get("rule_id"),
                rule.get("execution_mode"),
                rule.get("primary_agent"),
                mapper.writeValueAsString(rule.get("secondary_agents")),
                "匹配规则: " + rule.getOrDefault("description", "默认路由"),
                rule.get("confidence")
            );
        } catch (Exception ignored) {}
    }

    // ══ 任务状态管理 ══════════════════════════════════════════

    /**
     * 查询某请求下所有任务，找出当前可以开始执行的任务
     * 条件：status=pending 且 depends_on_task为null或前置任务已completed
     */
    public List<Map<String, Object>> getReadyTasks(String requestId) {
        return jdbc.queryForList(
            "SELECT t.* FROM agent_task_queue t " +
            "WHERE t.request_id=? AND t.status='pending' " +
            "AND (t.depends_on_task IS NULL " +
            "  OR EXISTS(SELECT 1 FROM agent_task_queue p " +
            "            WHERE p.task_id=t.depends_on_task AND p.status='completed'))",
            requestId
        );
    }

    public void markTaskRunning(String taskId) {
        jdbc.update(
            "UPDATE agent_task_queue SET status='running', started_at=NOW() WHERE task_id=?",
            taskId
        );
    }

    public void markTaskCompleted(String taskId, Map<String, Object> outputData) {
        try {
            jdbc.update(
                "UPDATE agent_task_queue SET status='completed', completed_at=NOW(), " +
                "output_data=? WHERE task_id=?",
                mapper.writeValueAsString(outputData), taskId
            );
        } catch (Exception e) {
            throw new RuntimeException("更新任务状态失败", e);
        }
    }

    public void markTaskFailed(String taskId, String errorMessage) {
        jdbc.update(
            "UPDATE agent_task_queue SET status='failed', completed_at=NOW(), " +
            "error_message=? WHERE task_id=?",
            errorMessage, taskId
        );
    }

    // ══ 工具方法 ══════════════════════════════════════════════

    private Map<String, Object> buildTaskInput(Map<String, Object> request, String prevTaskId) {
        Map<String, Object> input = new LinkedHashMap<>();
        input.put("request_id", request.get("request_id"));
        input.put("raw_input", request.get("raw_input"));
        input.put("trigger_source", request.get("trigger_source"));
        input.put("trigger_type", request.get("trigger_type"));
        input.put("context_hint", request.get("context_hint"));
        input.put("user_id", request.get("user_id"));
        input.put("session_id", request.get("session_id"));
        if (prevTaskId != null) {
            // 获取前置任务输出，传给下一个Agent
            try {
                String prevOutput = jdbc.queryForObject(
                    "SELECT output_data FROM agent_task_queue WHERE task_id=?",
                    String.class, prevTaskId
                );
                input.put("prev_task_output", prevOutput);
            } catch (Exception ignored) {}
        }
        return input;
    }

    @SuppressWarnings("unchecked")
    private List<String> parseJsonList(Object json) {
        if (json == null) return Collections.emptyList();
        try { return mapper.readValue(json.toString(), List.class); }
        catch (Exception e) { return Collections.emptyList(); }
    }

    @SuppressWarnings("unchecked")
    private List<String> parseJsonStringList(Object json) {
        return parseJsonList(json);
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseJsonMapList(Object json) {
        if (json == null) return Collections.emptyList();
        try { return mapper.readValue(json.toString(), List.class); }
        catch (Exception e) { return Collections.emptyList(); }
    }
}
