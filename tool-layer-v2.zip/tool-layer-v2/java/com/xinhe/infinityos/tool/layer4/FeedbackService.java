// ============================================================
// FeedbackService.java
// 层面四：反馈层·执行完成后的结果处理
// 写回记忆层 → 更新信用分 → 触发下一个Agent → 等待人工审批
// ============================================================
package com.xinhe.infinityos.tool.layer4;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class FeedbackService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // 注入记忆层（跨模块引用）
    // @Autowired private SharedMemoryService sharedMemory;
    // @Autowired private OrgKnowledgeService orgKnowledge;
    // @Autowired private PerceptionService perceptionService;
    // @Autowired private WechatWorkClient wechatClient;

    // ══ 核心：任务完成后的反馈处理 ═══════════════════════════

    /**
     * 单个任务执行完成后调用
     * 1. 更新任务状态
     * 2. 检查是否触发下一个任务（pipeline）
     * 3. 检查整个请求是否全部完成
     * 4. 如果全部完成，写回记忆层 + 生成最终回答
     */
    public void onTaskCompleted(String requestId, String taskId, String agentId,
                                 Map<String, Object> taskOutput, boolean success) {
        // 1. 更新Agent信用分
        updateCreditScore(agentId, requestId, success,
            success ? "任务成功完成" : "任务执行失败");

        // 2. 检查pipeline中是否有依赖此任务的后续任务可以启动
        triggerDependentTasks(requestId, taskId);

        // 3. 检查整个请求是否全部完成
        if (isRequestCompleted(requestId)) {
            finalizeRequest(requestId);
        }
    }

    /**
     * 任务需要人工审批时调用
     * 创建审批队列 + 推送企微审批按钮
     */
    public String createApprovalRequest(String requestId, String taskId, String agentId,
                                         String actionType, String actionSummary,
                                         Map<String, Object> actionDetail, String riskLevel,
                                         int authLevel, String requiredApprover,
                                         String plainReason) {
        String approvalId = "APR_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        // 根据授权级别设置过期时间
        int expireHours = switch (authLevel) {
            case 1 -> 2;   // 快速通道2小时
            case 2 -> 8;   // 主管审批当天
            case 3 -> 48;  // 总监审批48小时
            default -> 4;
        };
        long expiresAt = System.currentTimeMillis() + (long) expireHours * 3600 * 1000;

        try {
            jdbc.update(
                "INSERT INTO approval_queue(approval_id, request_id, task_id, agent_id, " +
                "action_type, action_summary, action_detail, risk_level, auth_level, " +
                "required_approver, plain_reason, expires_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                approvalId, requestId, taskId, agentId,
                actionType, actionSummary,
                mapper.writeValueAsString(actionDetail),
                riskLevel, authLevel, requiredApprover, plainReason,
                new java.sql.Timestamp(expiresAt)
            );
        } catch (Exception e) {
            throw new RuntimeException("创建审批请求失败", e);
        }

        // 推送企微审批消息（Java团队实现）
        // pushWechatApproval(approvalId, requiredApprover, actionSummary, plainReason, expireHours);

        return approvalId;
    }

    /**
     * 审批通过时调用（来自企微Webhook回调）
     */
    public void onApprovalGranted(String approvalId, String approvedBy) {
        Map<String, Object> approval = getApproval(approvalId);
        if (approval == null) throw new IllegalStateException("审批不存在: " + approvalId);

        // 更新审批状态
        jdbc.update(
            "UPDATE approval_queue SET status='approved', approved_by=?, decided_at=NOW() " +
            "WHERE approval_id=?", approvedBy, approvalId
        );

        // 恢复任务执行（标记为可继续）
        String taskId = String.valueOf(approval.get("task_id"));
        jdbc.update(
            "UPDATE agent_task_queue SET auth_required=0, approved_by=?, " +
            "status='pending' WHERE task_id=?",
            approvedBy, taskId
        );

        // 更新批准者的记忆：你批准了这个操作，你承担责任（㉓责任真空维度）
        // sharedMemory.recordEvent(approvedBy, "approval_granted", "task", taskId, ...)

        String requestId = String.valueOf(approval.get("request_id"));
        triggerDependentTasks(requestId, taskId);
    }

    /**
     * 审批拒绝时调用
     */
    public void onApprovalRejected(String approvalId, String rejectedBy, String reason) {
        Map<String, Object> approval = getApproval(approvalId);
        if (approval == null) return;

        jdbc.update(
            "UPDATE approval_queue SET status='rejected', approved_by=?, " +
            "decided_at=NOW(), decision_reason=? WHERE approval_id=?",
            rejectedBy, reason, approvalId
        );

        String taskId = String.valueOf(approval.get("task_id"));
        String agentId = String.valueOf(approval.get("agent_id"));
        jdbc.update(
            "UPDATE agent_task_queue SET status='failed', error_message=? WHERE task_id=?",
            "人工审批拒绝: " + reason, taskId
        );

        // 拒绝时扣减Agent信用分（判断有误）
        updateCreditScore(agentId, String.valueOf(approval.get("request_id")),
            false, "审批被拒绝·原因: " + reason);

        // 通知发起任务的Agent审批结果
        // sharedMemory.broadcast("system", agentId, "response", "normal", "审批拒绝", ...)

        String requestId = String.valueOf(approval.get("request_id"));
        if (isRequestCompleted(requestId)) finalizeRequest(requestId);
    }

    // ══ 结果汇总：整个请求完成后 ══════════════════════════════

    private void finalizeRequest(String requestId) {
        // 1. 统计任务结果
        Map<String, Object> stats = jdbc.queryForMap(
            "SELECT COUNT(*) as total, " +
            "SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) as completed, " +
            "SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END) as failed " +
            "FROM agent_task_queue WHERE request_id=?", requestId
        );

        int total = ((Number) stats.get("total")).intValue();
        int completed = ((Number) stats.get("completed")).intValue();
        int failed = ((Number) stats.get("failed")).intValue();

        String finalStatus = failed == 0 ? "success" :
            completed > 0 ? "partial" : "failed";

        // 2. 收集所有任务的输出，合并生成最终回答
        List<Map<String, Object>> taskOutputs = jdbc.queryForList(
            "SELECT agent_id, task_type, output_data FROM agent_task_queue " +
            "WHERE request_id=? AND status='completed' ORDER BY sequence_order",
            requestId
        );

        String finalResponse = buildFinalResponse(requestId, taskOutputs);
        List<String> keyFindings = extractKeyFindings(taskOutputs);
        List<String> triggeredAgents = extractTriggeredAgents(taskOutputs);

        // 3. 写入结果汇总
        try {
            jdbc.update(
                "INSERT INTO execution_results(request_id, total_tasks, completed_tasks, " +
                "failed_tasks, final_status, final_response, key_findings, triggered_agents, " +
                "total_latency_ms) VALUES(?,?,?,?,?,?,?,?,?)",
                requestId, total, completed, failed, finalStatus, finalResponse,
                mapper.writeValueAsString(keyFindings),
                mapper.writeValueAsString(triggeredAgents),
                calculateTotalLatency(requestId)
            );
        } catch (Exception e) {
            throw new RuntimeException("写入结果汇总失败", e);
        }

        // 4. 更新原始请求状态
        jdbc.update(
            "UPDATE trigger_requests SET status=?, completed_at=NOW(), " +
            "final_response=? WHERE request_id=?",
            finalStatus.equals("success") ? "completed" : finalStatus,
            finalResponse, requestId
        );

        // 5. 回写记忆层层面三（共享状态·让其他Agent知道这个请求完成了）
        // sharedMemory.writeState("system", "global", requestId, "request_completed", Map.of(...))

        // 6. 检查是否需要触发后续Agent
        checkAndTriggerCascade(requestId, keyFindings);
    }

    // ══ 级联触发：发现问题后触发下一个Agent ══════════════════

    private void checkAndTriggerCascade(String requestId, List<String> keyFindings) {
        // 如果发现库存预警，自动触发蝴蝶效应Agent
        for (String finding : keyFindings) {
            if (finding.contains("低于2a") || finding.contains("断货")) {
                scheduleCascade(requestId, "butterfly",
                    "库存异常检测", Map.of("finding", finding, "source_request", requestId));
            }
            if (finding.contains("压货") || finding.contains("超过1a")) {
                scheduleCascade(requestId, "butterfly",
                    "渠道压货检测", Map.of("finding", finding, "source_request", requestId));
            }
        }
    }

    private void scheduleCascade(String sourceRequestId, String targetAgent,
                                   String reason, Map<String, Object> data) {
        // 检查是否已经有相同目标的级联触发在pending状态
        int existing = jdbc.queryForObject(
            "SELECT COUNT(*) FROM cascade_triggers " +
            "WHERE source_request_id=? AND triggered_agent=? AND status='pending'",
            Integer.class, sourceRequestId, targetAgent
        );
        if (existing > 0) return;

        try {
            jdbc.update(
                "INSERT INTO cascade_triggers(source_request_id, source_agent, " +
                "triggered_agent, trigger_reason, trigger_data) VALUES(?,?,?,?,?)",
                sourceRequestId, "system", targetAgent, reason,
                mapper.writeValueAsString(data)
            );
        } catch (Exception ignored) {}

        // 实际触发（通过PerceptionService）
        // perceptionService.receiveAgentTrigger("system", targetAgent, reason, data, sourceRequestId);
    }

    // ══ 用户反馈处理 ══════════════════════════════════════════

    /**
     * 用户对回答评价后调用
     * 5星=excellent·1星=wrong·驱动Agent学习闭环
     */
    public void recordUserFeedback(String requestId, String userId, String agentId,
                                    int rating, String feedbackType, String comment) {
        jdbc.update(
            "INSERT INTO user_feedback(request_id, user_id, agent_id, rating, " +
            "feedback_type, comment) VALUES(?,?,?,?,?,?)",
            requestId, userId, agentId, rating, feedbackType, comment
        );

        // 根据评分更新信用分
        boolean isPositive = rating >= 4;
        updateCreditScore(agentId, requestId, isPositive,
            "用户反馈·" + rating + "星·" + feedbackType);

        // 层面四：把反馈写入组织知识·供规则学习
        // orgKnowledge.recordDecisionFeedback(requestId, agentId, rating, feedbackType);
    }

    // ══ 信用分更新 ════════════════════════════════════════════

    private void updateCreditScore(String agentId, String requestId,
                                    boolean isPositive, String reason) {
        double delta = isPositive ? 1.0 : -5.0;

        try {
            Double scoreBefore = jdbc.queryForObject(
                "SELECT credit_score FROM agent_memory_profiles WHERE agent_id=?",
                Double.class, agentId
            );
            if (scoreBefore == null) return;

            double scoreAfter = Math.min(100, Math.max(0, scoreBefore + delta));

            jdbc.update(
                "UPDATE agent_memory_profiles SET credit_score=? WHERE agent_id=?",
                scoreAfter, agentId
            );

            jdbc.update(
                "INSERT INTO credit_change_log(agent_id, request_id, change_type, delta, " +
                "score_before, score_after, reason) VALUES(?,?,?,?,?,?,?)",
                agentId, requestId,
                isPositive ? "correct" : "incorrect",
                delta, scoreBefore, scoreAfter, reason
            );

            // 信用分跌破40暂停Agent
            if (scoreAfter < 40 && scoreBefore >= 40) {
                jdbc.update(
                    "UPDATE agent_memory_profiles SET current_status='paused' WHERE agent_id=?",
                    agentId
                );
            }
        } catch (Exception ignored) {}
    }

    // ══ 定时任务：清理和监控 ══════════════════════════════════

    @Scheduled(cron = "0 */30 * * * *")
    public void processExpiredApprovals() {
        // 超时未审批的任务自动处理
        List<Map<String, Object>> expired = jdbc.queryForList(
            "SELECT * FROM approval_queue WHERE status='pending' AND expires_at < NOW()"
        );

        for (Map<String, Object> approval : expired) {
            jdbc.update(
                "UPDATE approval_queue SET status='expired' WHERE approval_id=?",
                approval.get("approval_id")
            );
            // 超时升级：通知上一级审批人
            int authLevel = ((Number) approval.get("auth_level")).intValue();
            if (authLevel < 3) {
                // escalate...
            }
        }
    }

    @Scheduled(cron = "0 0 */1 * * *")
    public void processTimeoutTasks() {
        // 超时未完成的任务标记失败
        int updated = jdbc.update(
            "UPDATE agent_task_queue SET status='failed', error_message='执行超时' " +
            "WHERE status='running' AND timeout_at < NOW()"
        );
        if (updated > 0) {
            // 查找受影响的requestId，触发finalize
        }
    }

    // ══ 工具方法 ══════════════════════════════════════════════

    private boolean isRequestCompleted(String requestId) {
        int pendingOrRunning = jdbc.queryForObject(
            "SELECT COUNT(*) FROM agent_task_queue " +
            "WHERE request_id=? AND status IN ('pending','running')",
            Integer.class, requestId
        );
        return pendingOrRunning == 0;
    }

    private void triggerDependentTasks(String requestId, String completedTaskId) {
        List<Map<String, Object>> dependents = jdbc.queryForList(
            "SELECT task_id FROM agent_task_queue " +
            "WHERE request_id=? AND depends_on_task=? AND status='pending'",
            requestId, completedTaskId
        );
        for (Map<String, Object> dep : dependents) {
            // 将pending任务标记为可执行（ExecutionService会轮询并执行）
            // 实际项目用事件驱动或任务队列（RabbitMQ/Kafka）
        }
    }

    private String buildFinalResponse(String requestId, List<Map<String, Object>> outputs) {
        if (outputs.isEmpty()) return "未获取到有效结果。";
        // 实际项目：调用Claude API把多个Agent的输出合并成自然语言回答
        // 此处返回最后一个任务的输出摘要
        Map<String, Object> lastOutput = outputs.get(outputs.size() - 1);
        return "已完成分析（" + outputs.size() + "个Agent协作），详见各模块输出。";
    }

    @SuppressWarnings("unchecked")
    private List<String> extractKeyFindings(List<Map<String, Object>> outputs) {
        List<String> findings = new ArrayList<>();
        for (Map<String, Object> output : outputs) {
            Object data = output.get("output_data");
            if (data == null) continue;
            try {
                Map<?, ?> parsed = mapper.readValue(data.toString(), Map.class);
                Object wl = parsed.get("water_level");
                if ("warning".equals(wl) || "critical".equals(wl)) {
                    findings.add("库存水位" + wl + "·实体:" + parsed.get("store_id"));
                }
            } catch (Exception ignored) {}
        }
        return findings;
    }

    private List<String> extractTriggeredAgents(List<Map<String, Object>> outputs) {
        List<String> agents = new ArrayList<>();
        for (Map<String, Object> output : outputs) {
            Object agentId = output.get("agent_id");
            if (agentId != null) agents.add(agentId.toString());
        }
        return agents;
    }

    private int calculateTotalLatency(String requestId) {
        try {
            return jdbc.queryForObject(
                "SELECT TIMESTAMPDIFF(MILLISECOND, MIN(started_at), MAX(completed_at)) " +
                "FROM agent_task_queue WHERE request_id=?",
                Integer.class, requestId
            );
        } catch (Exception e) { return 0; }
    }

    private Map<String, Object> getApproval(String approvalId) {
        try {
            return jdbc.queryForMap(
                "SELECT * FROM approval_queue WHERE approval_id=?", approvalId
            );
        } catch (Exception e) { return null; }
    }
}
