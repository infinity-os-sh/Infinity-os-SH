# Agent 03 · Omakase推单 · 任务清单

---

## 📋 任务分解

### Phase 1 · 前置数据(0.5天)
- [ ] 1.1 SKU价格表 `sku_prices`
- [ ] 1.2 Repository + 缓存到Redis

### Phase 2 · 核心算法(1天)
- [ ] 2.1 `PushQtyCalculator`
  - [ ] 单元测试(4个用例)
- [ ] 2.2 `BlockingAlertChecker`
  - [ ] 单元测试
- [ ] 2.3 `AutoApprovalJudge`
  - [ ] 单元测试

### Phase 3 · Agent主逻辑(1天)
- [ ] 3.1 `OmakaseRecommendAgent`
- [ ] 3.2 `run_full_recommendation()`
- [ ] 3.3 候选筛选逻辑
- [ ] 3.4 阻塞预警检查
- [ ] 3.5 推单生成
- [ ] 3.6 单元测试

### Phase 4 · 推送系统(1天)
- [ ] 4.1 `WechatOmakasePushService`
- [ ] 4.2 APPROVED → 经销商模板
- [ ] 4.3 PENDING → DOM审核模板
- [ ] 4.4 测试

### Phase 5 · 定时调度 + API(0.5天)
- [ ] 5.1 APScheduler(Mon 08:00)
- [ ] 5.2 依赖检查(蝴蝶完成)
- [ ] 5.3 `POST /api/agent/omakase`

### Phase 6 · 反馈接口(1天)
- [ ] 6.1 经销商确认接口 `POST /api/actions/{id}/confirm`
- [ ] 6.2 经销商调整接口 `POST /api/actions/{id}/adjust`
- [ ] 6.3 DOM审批接口 `POST /api/actions/{id}/approve`
- [ ] 6.4 反馈写入learning_log

### Phase 7 · 测试与部署(1天)
- [ ] 7.1 端到端测试(校准→蝴蝶→Omakase全流程)
- [ ] 7.2 性能测试
- [ ] 7.3 生产部署

---

## ⏱️ 总工时:6天

---

## 🎯 完成标准

- ✅ 4个验收用例全部通过
- ✅ 3个Agent触发顺序正确
- ✅ 阻塞预警过滤准确
- ✅ 自动批/人工审分流正确
- ✅ 反馈闭环完整(写入learning_log)
- ✅ 生产连续4周·推单准确率>90%
