# Agent 03 · Omakase推单 · 设计文档

---

## 🏗️ 架构

```
APScheduler(Mon 08:00)
    ↓ 等待蝴蝶Agent完成
OmakaseRecommendAgent.run_full_recommendation()
    ↓
找出所有水位<2a的经销商 (HeartbeatRepo)
    ↓
对每个候选:
    ↓
    1. 检查节点类型(只要DISTRIBUTOR)
    ↓
    2. 检查OPEN预警(过滤A/D类)
    ↓
    3. 计算推单量 = (3a - inventory) × 1.2
    ↓
    4. 查SKU单价·算金额
    ↓
    5. 判断金额:
       < 5万 → status=APPROVED
       ≥ 5万 → status=PENDING
    ↓
    6. 写入inf_actions
    ↓
    7. 推送企微:
       · APPROVED → 经销商
       · PENDING → DOM审核
```

---

## 🧮 核心算法

### 推单量计算

```python
def calculate_push_qty(current_inventory: float, a: float, safety: float = 1.2) -> int:
    """
    计算推单量
    
    公式:push = (3a - current_inventory) × safety
    
    Args:
        current_inventory: 当前库存
        a: 心跳单元
        safety: 安全系数(默认1.2)
    
    Returns:
        推单量(整数·向上取整)
    """
    target = 3 * a
    gap = target - current_inventory
    
    if gap <= 0:
        return 0
    
    push_qty = gap * safety
    return math.ceil(push_qty)
```

### 阻塞性预警检查

```python
def has_blocking_alert(node_id: int, sku_code: str) -> bool:
    """
    检查节点-SKU是否有阻塞性预警
    
    阻塞类型:
      · A类(压货)  → 已经压货·不能再推
      · D类(战略)  → 战略期·不推单
    
    非阻塞:
      · B类(促销)  → 正常促销·继续推
      · C类(窜货)  → 窜货问题独立处理
    """
    open_alerts = alert_repo.find_open(node_id, sku_code)
    return any(a.type in ['A', 'D'] for a in open_alerts)
```

### 自动批准判断

```python
def should_auto_approve(amount: float, threshold: float = 50000) -> bool:
    """
    < 5万 · 自动批
    >= 5万 · 人工审
    """
    return amount < threshold
```

---

## 📊 数据模型

### Action实体

```python
@dataclass
class Action:
    action_code: str           # OMK-abc12345
    action_type: str = 'RECOMMEND_ORDER'
    node_id: int
    sku_code: str
    agent_source: str = 'OMAKASE'
    recommended_qty: int
    recommended_amount: float  # = qty × unit_price
    confidence_score: float = 85  # 默认置信度
    status: str                # PENDING / APPROVED / REJECTED / EXECUTED
    approver: str | None
    payload_json: dict         # 详细信息(SKU/数量/单价/a值等)
    created_at: datetime
```

---

## 🔔 推送规则

### Status = APPROVED(直接推送经销商)

```
推送对象:经销商业务员
消息模板:
  【Omakase推单】
  经销商:{node_name}
  SKU:{sku_code}
  建议数量:{qty}瓶
  金额:¥{amount}
  【确认】 【调整】 【拒绝】
```

### Status = PENDING(先发DOM审核)

```
推送对象:DOM
消息模板:
  【Omakase推单·待审】
  经销商:{node_name}
  SKU:{sku_code}
  建议数量:{qty}瓶
  金额:¥{amount}(超过5万)
  【批准】 【驳回】
  
DOM批准后·再推经销商
```

---

## ⚡ 性能优化

### 数据预取

```python
# 一次SQL取所有候选
candidates = heartbeat_repo.find_low_water_with_node_info(
    date=yesterday,
    water_threshold=2.0,
    node_types=['DISTRIBUTOR']
)
# 包含:heartbeat + node JOIN的结果

# 一次SQL取所有OPEN预警
alerts = alert_repo.find_all_open()
alerts_index = build_index(alerts)  # 按(node_id, sku)索引

# 一次SQL取SKU价格
sku_prices = sku_repo.load_all_prices()  # 缓存到Redis
```

### 批量写入

```python
# 不一条条insert·用bulk_insert
session.bulk_insert_mappings(Action, actions_list)
session.commit()
```

---

## 🔒 安全考量

- **金额上限:** 单次运行总额<100万(超出报警·人工介入)
- **频率限制:** 每经销商每天最多1次推单
- **审批记录:** PENDING→APPROVED必须记录审批人
- **可撤销:** APPROVED状态24小时内可撤销

---

## 📈 学习机制

```
推单流程:
1. Agent生成PENDING/APPROVED
2. 经销商确认/调整/拒绝
3. 反馈写入 inf_learning_log
4. 后续学习:
   · 某经销商总是调整数量 → 下次适配
   · 某SKU总被拒 → 调整推单规则
   · 误报率累积 → 优化置信度

(Phase 3上线后启用)
```
