# Agent 01 · A值校准 · 任务清单

**Spec ID:** `agent-01-a-value-calibration`

---

## 📋 任务分解(按依赖顺序)

### 🔧 Phase 1 · 环境准备(预计 0.5天)

- [ ] 1.1 确认Python环境(3.11+)
- [ ] 1.2 安装依赖包
  ```bash
  pip install sqlalchemy pymysql apscheduler pandas numpy fastapi uvicorn
  ```
- [ ] 1.3 配置数据库连接(.env文件)
  ```
  DATABASE_URL=mysql+pymysql://user:pass@host:3306/infinity_os
  ```
- [ ] 1.4 验证数据库连接
- [ ] 1.5 验证inf_heartbeat表有30天以上数据

---

### 🏗️ Phase 2 · 核心模型(预计 0.5天)

- [ ] 2.1 创建SQLAlchemy模型
  - [ ] `models/heartbeat.py` · Heartbeat模型
  - [ ] `models/node.py` · Node模型
  - [ ] `models/learning_log.py` · LearningLog模型
- [ ] 2.2 创建Repository层
  - [ ] `repositories/heartbeat_repo.py`
  - [ ] `repositories/learning_log_repo.py`

---

### 🧠 Phase 3 · 核心算法(预计 1天)

- [ ] 3.1 实现异常值检测 `utils/outlier_detector.py`
  - [ ] 函数 `is_outlier(r_value, median)`
  - [ ] 单元测试 `test_outlier_detector.py`
- [ ] 3.2 实现三重验证 `utils/tri_validator.py`
  - [ ] 函数 `tri_validate_calibrate(r_series)`
  - [ ] 单元测试 `test_tri_validator.py`
  - [ ] 测试4个验收用例:
    - [ ] 正常数据
    - [ ] 含断货日
    - [ ] 含促销日
    - [ ] 数据不足
- [ ] 3.3 实现合理性校验 `utils/change_validator.py`
  - [ ] 函数 `is_reasonable_change(old_r, new_r, max_change)`
  - [ ] 单元测试

---

### 🤖 Phase 4 · Agent主逻辑(预计 1天)

- [ ] 4.1 创建 `agents/a_value_calibration_agent.py`
- [ ] 4.2 实现 `run_full_calibration()`
  - [ ] 读取30天数据
  - [ ] pandas分组
  - [ ] 循环调用`calibrate_one`
  - [ ] 汇总结果到CalibrationReport
- [ ] 4.3 实现 `calibrate_one(node_id, sku_code, history)`
  - [ ] 调用三重验证
  - [ ] 调用合理性校验
  - [ ] 写入learning_log
- [ ] 4.4 单元测试
  - [ ] `test_calibration_agent.py`
  - [ ] Mock Repository·测试业务逻辑

---

### ⏰ Phase 5 · 调度(预计 0.5天)

- [ ] 5.1 创建 `schedulers/agent_scheduler.py`
- [ ] 5.2 配置APScheduler
  ```python
  scheduler.add_job(
      agent.run_full_calibration,
      CronTrigger(day_of_week='mon', hour=6, minute=0)
  )
  ```
- [ ] 5.3 测试定时触发(可以先设5分钟后跑测试)

---

### 🌐 Phase 6 · REST API(预计 0.5天)

- [ ] 6.1 创建 `api/agent_api.py`
- [ ] 6.2 实现 `POST /api/agent/calibrate`
- [ ] 6.3 返回CalibrationReport
- [ ] 6.4 API测试(Postman/curl)

---

### 📤 Phase 7 · 企微推送(预计 0.5天)

- [ ] 7.1 创建 `services/wechat_push_service.py`
- [ ] 7.2 待审核的校准 → 推送DOM
- [ ] 7.3 消息模板设计
- [ ] 7.4 测试推送

---

### 📊 Phase 8 · 监控日志(预计 0.5天)

- [ ] 8.1 配置logging(INFO/WARN/ERROR分级)
- [ ] 8.2 添加Prometheus指标
- [ ] 8.3 失败报警

---

### ✅ Phase 9 · 集成测试(预计 1天)

- [ ] 9.1 端到端测试
  - [ ] 准备模拟30天数据
  - [ ] 手动触发校准
  - [ ] 验证所有验收标准
- [ ] 9.2 性能测试
  - [ ] 50000组合 · 验证5分钟内完成
- [ ] 9.3 异常测试
  - [ ] 数据库断连
  - [ ] 数据异常

---

### 📚 Phase 10 · 文档与部署(预计 0.5天)

- [ ] 10.1 编写 `README.md`
- [ ] 10.2 编写 `DEPLOYMENT.md`
- [ ] 10.3 Docker打包
- [ ] 10.4 生产环境部署
- [ ] 10.5 DS验收

---

## ⏱️ 总工时预估

**总计:6.5天(1-2周·含Code Review + 迭代)**

---

## 👥 负责人分工

| Phase | 主要负责 | 协助 | Code Review |
|-------|---------|------|-------------|
| Phase 1-2 | 开发者A | Tech Lead | Tech Lead |
| Phase 3 | 开发者A | 郭工(算法验证) | DS + Tech Lead |
| Phase 4-6 | 开发者A | Tech Lead | Tech Lead |
| Phase 7 | 开发者B | IT(企微权限) | Tech Lead |
| Phase 8-10 | 全员 | - | DS |

---

## 🎯 完成标准

- ✅ 所有单元测试通过(覆盖率>80%)
- ✅ 4个验收用例全部通过
- ✅ 性能测试达标
- ✅ DS签字验收
- ✅ 代码合并到main分支
- ✅ 生产环境连续运行1周无重大问题

---

## 📌 里程碑

- **M1(Day 2):** 核心算法完成·单元测试通过
- **M2(Day 4):** Agent主逻辑完成·集成测试开始
- **M3(Day 6):** API + 调度 + 推送全部完成
- **M4(Day 7):** 生产上线·首次自动校准成功
