# Agent 01 · A值校准 · 设计文档

**Spec ID:** `agent-01-a-value-calibration`  
**对应需求:** requirements.md

---

## 🏗️ 架构

```
┌─────────────────────────────────────────────────┐
│  APScheduler(Cron: 0 0 6 * * MON)              │
└──────────────────┬──────────────────────────────┘
                   ↓ 触发
┌─────────────────────────────────────────────────┐
│  AValueCalibrationAgent.run_full_calibration() │
└──────────────────┬──────────────────────────────┘
                   ↓
         ┌─────────┴──────────┐
         ↓                    ↓
    读取30天数据         按(node,sku)分组
    (HeartbeatRepo)      (pandas groupby)
         ↓                    ↓
         └──────┬─────────────┘
                ↓ 对每组
    ┌───────────┴────────────┐
    ↓                        ↓
异常值检测             三重验证计算
(is_outlier)          (tri_validate)
    ↓                        ↓
    └──────────┬─────────────┘
               ↓
         合理性校验(±15%)
               ↓
        ┌──────┴──────┐
        ↓             ↓
    自动更新      标记待审
(update r_actual)  (needs_review)
        ↓             ↓
        └──────┬──────┘
               ↓
      记录 inf_learning_log
```

---

## 🧩 关键组件

| 组件 | 职责 | 技术选型 |
|------|------|---------|
| Scheduler | 定时触发 | APScheduler |
| Repository | 数据访问 | SQLAlchemy |
| Agent核心 | 业务逻辑 | Python原生 |
| 异常检测 | 识别outlier | pandas + numpy |
| 三重验证 | 校准算法 | Python原生 |
| 推送 | 待审通知 | OkHttp → 企微API |

---

## 📊 数据模型

### 输入数据

```sql
-- 读取过去30天心跳数据
SELECT 
    node_id, 
    sku_code, 
    r_actual, 
    data_date,
    inventory_actual
FROM inf_heartbeat 
WHERE data_date >= CURRENT_DATE - INTERVAL 30 DAY
ORDER BY node_id, sku_code, data_date DESC;
```

### 输出数据

#### 1. 更新inf_heartbeat(仅最新行)

```sql
UPDATE inf_heartbeat 
SET r_actual = :newR,
    quality_score = :score
WHERE id = :latestId;
```

#### 2. 写入inf_learning_log

```sql
INSERT INTO inf_learning_log (
    agent_name, 
    event_type, 
    input_json, 
    decision_json, 
    created_at
) VALUES (
    'A_VALUE_CALIBRATION',
    'CALIBRATION_DONE',
    '{"node_id":123, "sku":"LYX500", "old_r":10, "data_points":30}',
    '{"new_r":10.3, "outliers_excluded":2, "change_ratio":0.03, "needs_review":false}',
    NOW()
);
```

---

## 🧮 核心算法

### 算法1 · 异常值检测 (is_outlier)

```python
def is_outlier(r_value: float, median: float) -> bool:
    """
    判断单个r值是否是异常值
    
    异常定义:
      1. r = 0 (断货日)
      2. r > median × 3 (促销日·r是中位数3倍以上)
      3. r > median × 5 (疑似数据错误)
    """
    if r_value == 0:
        return True
    if median == 0:
        return False
    if r_value > median * 3:
        return True
    return False
```

### 算法2 · 三重验证校准 (tri_validate)

```python
def tri_validate_calibrate(r_series: list[float]) -> tuple[float, int]:
    """
    三重验证校准r值
    
    三重验证:
      1. 剔除0值(断货日)
      2. 计算中位数·剔除 > 中位数×3 的异常值
      3. 对剩余数据求平均
    
    Returns:
      (new_r, outliers_excluded_count)
    """
    # 第一重:剔除0
    non_zero = [r for r in r_series if r > 0]
    if len(non_zero) < 5:
        return 0, 0  # 数据不足
    
    # 第二重:剔除超过中位数3倍的
    median = statistics.median(non_zero)
    filtered = [r for r in non_zero if r <= median * 3]
    
    # 第三重:剔除超过平均+3*std的(防极端值)
    if len(filtered) < 5:
        return 0, 0
    mean = statistics.mean(filtered)
    std = statistics.stdev(filtered) if len(filtered) > 1 else 0
    final = [r for r in filtered if abs(r - mean) <= 3 * std]
    
    if len(final) < 5:
        return 0, 0
    
    outliers_count = len(r_series) - len(final)
    return statistics.mean(final), outliers_count
```

### 算法3 · 合理性校验 (is_reasonable)

```python
def is_reasonable_change(old_r: float, new_r: float, max_change: float = 0.15) -> bool:
    """
    判断新r相对旧r的变化是否合理(≤±15%)
    """
    if old_r == 0:
        return True  # 首次校准·无对比
    change_ratio = abs(new_r - old_r) / old_r
    return change_ratio <= max_change
```

---

## 🔌 接口定义

### 内部接口

```python
class AValueCalibrationAgent:
    def run_full_calibration(self) -> CalibrationReport:
        """主入口·校准所有节点"""
        pass
    
    def calibrate_one(
        self, 
        node_id: int, 
        sku_code: str, 
        history: list[Heartbeat]
    ) -> CalibrationResult:
        """校准单个组合"""
        pass
```

### REST API

```
POST /api/agent/calibrate
  Response: {
    "status": "SUCCESS",
    "autoApprovedCount": 1250,
    "needsReviewCount": 23,
    "failedCount": 2,
    "totalDurationMs": 45000
  }
```

---

## 🚨 异常处理策略

| 异常 | 处理 |
|------|------|
| 数据库连接失败 | 重试3次·间隔5秒·失败报警 |
| 单个组合计算异常 | 捕获·记录到report·继续下一个 |
| 全部失败 | 事务回滚·发紧急预警 |
| 超时(>10分钟) | 强制中断·发警告 |

---

## ⚡ 性能考量

### 预估数据量

- 节点数:~10,000个
- SKU数:~500个
- 组合数:~50,000个
- 30天数据:~1,500,000条

### 优化策略

1. **批量读取** · 一次SQL读30天全量·不单次查询
2. **pandas分组** · 用pandas groupby代替循环
3. **批量写入** · 每1000条统一commit
4. **索引利用** · inf_heartbeat要有 (node_id, sku_code, data_date) 联合索引
5. **Redis缓存** · 中位数计算结果缓存

### 监控指标

```python
metrics = {
    "total_combinations": 50000,
    "processed": 49998,
    "auto_approved": 49500,
    "needs_review": 498,
    "failed": 2,
    "duration_ms": 180000,
    "avg_ms_per_combination": 3.6
}
```

---

## 🔒 安全考量

- **数据权限**:Agent运行账号只有SELECT + UPDATE权限·不能DELETE
- **审计日志**:所有UPDATE操作记录到inf_learning_log
- **敏感数据**:无敏感数据(r值不涉及个人信息)
- **SQL注入**:使用SQLAlchemy参数化查询
