# INFINITY OS · 项目结构

---

## 🗂️ 目录结构

```
infinity_os/
│
├── .kiro/                           ← Kiro配置(必须提交Git)
│   ├── steering/                    ← 全局规则(本目录)
│   │   ├── product.md               ← 产品定义
│   │   ├── tech.md                  ← 技术栈
│   │   └── structure.md             ← 本文件
│   └── specs/                       ← 功能Spec(每个功能一个子目录)
│       ├── agent-01-a-value-calibration/
│       │   ├── requirements.md
│       │   ├── design.md
│       │   └── tasks.md
│       ├── agent-02-butterfly-effect/
│       ├── agent-03-omakase-recommend/
│       ├── data-import-hanxun/
│       └── wechat-push/
│
├── src/                             ← 源码
│   ├── __init__.py
│   ├── main.py                      ← FastAPI入口
│   ├── config.py                    ← 配置管理
│   │
│   ├── models/                      ← SQLAlchemy ORM模型
│   │   ├── __init__.py
│   │   ├── base.py                  ← 基类
│   │   ├── node.py
│   │   ├── heartbeat.py
│   │   ├── alert.py
│   │   ├── action.py
│   │   ├── node_target.py
│   │   └── learning_log.py
│   │
│   ├── repositories/                ← 数据访问层(Repository模式)
│   │   ├── __init__.py
│   │   ├── base.py                  ← BaseRepository
│   │   ├── node_repo.py
│   │   ├── heartbeat_repo.py
│   │   ├── alert_repo.py
│   │   ├── action_repo.py
│   │   └── learning_log_repo.py
│   │
│   ├── services/                    ← 业务服务层
│   │   ├── __init__.py
│   │   ├── node_service.py
│   │   ├── heartbeat_service.py
│   │   └── wechat_push_service.py
│   │
│   ├── agents/                      ← Agent实现(核心)
│   │   ├── __init__.py
│   │   ├── base_agent.py            ← BaseAgent抽象类
│   │   ├── a_value_calibration.py
│   │   ├── butterfly_effect.py
│   │   └── omakase_recommend.py
│   │
│   ├── schedulers/                  ← 定时调度
│   │   ├── __init__.py
│   │   └── agent_scheduler.py
│   │
│   ├── api/                         ← FastAPI路由
│   │   ├── __init__.py
│   │   ├── agent_router.py
│   │   ├── alert_router.py
│   │   ├── action_router.py
│   │   └── health_router.py
│   │
│   └── utils/                       ← 工具类
│       ├── __init__.py
│       ├── heartbeat.py             ← 心跳公式核心
│       ├── outlier_detector.py
│       ├── tri_validator.py
│       └── logger.py
│
├── tests/                           ← 测试
│   ├── unit/                        ← 单元测试
│   │   ├── test_heartbeat.py
│   │   ├── test_outlier_detector.py
│   │   ├── test_tri_validator.py
│   │   └── test_agents/
│   │       ├── test_calibration_agent.py
│   │       ├── test_butterfly_agent.py
│   │       └── test_omakase_agent.py
│   ├── integration/                 ← 集成测试
│   │   └── test_end_to_end.py
│   └── conftest.py                  ← pytest fixtures
│
├── sql/                             ← DDL脚本
│   ├── 001_init_tables.sql          ← 6表DDL
│   ├── 002_indexes.sql              ← 索引
│   └── 003_seed_data.sql            ← 种子数据
│
├── scripts/                         ← 运维脚本
│   ├── init_db.py                   ← 初始化数据库
│   ├── migrate_data.py              ← 数据迁移
│   └── test_data_gen.py             ← 测试数据生成
│
├── docs/                            ← 文档
│   ├── architecture.md              ← 架构图
│   ├── api.md                       ← API文档
│   └── deployment.md                ← 部署说明
│
├── .env.example                     ← 环境变量模板
├── .gitignore
├── requirements.txt                 ← Python依赖
├── requirements-dev.txt             ← 开发依赖
├── docker-compose.yml               ← 本地环境
├── Dockerfile
├── pytest.ini
├── pyproject.toml
└── README.md
```

---

## 📐 分层职责

### 1. Model层(models/)
- **职责:** 数据实体·SQLAlchemy映射
- **不允许:** 业务逻辑·数据库操作

### 2. Repository层(repositories/)
- **职责:** 封装SQL·CRUD操作
- **不允许:** 业务决策·跨实体组合

### 3. Service层(services/)
- **职责:** 业务逻辑·跨Repository组合
- **不允许:** HTTP处理·调度

### 4. Agent层(agents/)
- **职责:** 自主决策·业务Agent
- **依赖:** Repository + Service + Utils

### 5. API层(api/)
- **职责:** HTTP接口·参数校验
- **不允许:** 业务逻辑(委托给Service/Agent)

### 6. Scheduler层(schedulers/)
- **职责:** 定时触发·调度Agent
- **不允许:** 业务逻辑

### 7. Utils层(utils/)
- **职责:** 无状态工具函数(公式·算法)
- **不允许:** 数据库操作·外部调用

---

## 🚦 命名规范

### 文件名
- **蛇形命名:** `a_value_calibration.py` · 不是 `AValueCalibration.py`
- **Test前缀:** `test_heartbeat.py`

### 类名
- **驼峰命名:** `class AValueCalibrationAgent`
- **Base前缀:** `BaseAgent` · `BaseRepository`

### 函数名
- **蛇形命名:** `def calculate_push_qty()`
- **动词开头:** `calculate_` · `validate_` · `detect_`

### 常量
- **全大写:** `MAX_CHANGE_RATIO = 0.15`
- **模块级:** 放在文件顶部·不要散落

---

## 📦 依赖管理

```
requirements.txt     ← 生产依赖
requirements-dev.txt ← 开发依赖(pytest/black/mypy等)
```

---

## 🔀 Git工作流

```
main分支:          生产代码·只能通过PR合并
dev分支:           开发集成分支
feature/xxx:       新功能分支(必须有对应.kiro/specs/)
fix/xxx:           Bug修复分支
```

每个feature分支PR合并前·必须:
- ✅ Spec文档已审
- ✅ 代码Review通过
- ✅ 测试全部通过
- ✅ 覆盖率达标
