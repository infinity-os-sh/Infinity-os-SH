# INFINITY OS · 技术栈

**给Kiro的"技术规范"** · 每次写代码遵循

---

## 🐍 主语言

**Python 3.11+**

理由:
- AI生态最成熟(LangChain·Anthropic SDK)
- 数据科学库齐全(pandas·numpy·scikit-learn)
- 团队选型(已在用Kiro + Python)

---

## 🛠️ 核心框架

| 层 | 技术 | 用途 |
|---|------|------|
| Web API | FastAPI | REST接口·高性能 |
| ORM | SQLAlchemy 2.0 | 数据访问 |
| 数据库驱动 | pymysql | MySQL |
| 定时任务 | APScheduler | Cron调度 |
| 缓存 | redis-py | Redis客户端 |
| HTTP客户端 | httpx | 企微API调用 |
| 数据处理 | pandas + numpy | 批量计算 |
| 测试 | pytest | 单元+集成测试 |
| 日志 | loguru | 结构化日志 |
| 配置 | pydantic-settings | 环境变量 |

---

## 💾 数据层

- **主数据库:** MySQL 5.7+(欣和已有)
- **缓存:** Redis 6+
- **数据源(外部):**
  - 汉询(r_actual · rixiao字段)
  - Dcloud EPP(库存 · wm_stock_matnr表)
  - SAP BSID(应收账款 · Phase 3)

---

## 📂 标准项目结构

```
infinity_os/
├── .kiro/
│   ├── steering/               ← 本目录(项目规范)
│   └── specs/                  ← 功能Spec
├── src/
│   ├── agents/                 ← 3个核心Agent
│   │   ├── a_value_calibration.py
│   │   ├── butterfly_effect.py
│   │   └── omakase_recommend.py
│   ├── models/                 ← SQLAlchemy实体
│   │   ├── node.py
│   │   ├── heartbeat.py
│   │   ├── alert.py
│   │   ├── action.py
│   │   └── learning_log.py
│   ├── repositories/           ← 数据访问层
│   ├── services/               ← 业务服务
│   ├── schedulers/             ← 调度器
│   ├── api/                    ← FastAPI路由
│   ├── utils/                  ← 工具类
│   │   └── heartbeat.py        ← 核心公式
│   └── config.py               ← 配置
├── tests/                      ← 测试
│   ├── unit/
│   └── integration/
├── sql/                        ← DDL脚本
├── requirements.txt
├── .env.example
├── docker-compose.yml
└── README.md
```

---

## 📝 代码规范

### 1. 类型注解(强制)

```python
# ✅ 对
def calculate_a(r: float, t: int) -> float:
    return r * t

# ❌ 错
def calculate_a(r, t):
    return r * t
```

### 2. Docstring(强制)

```python
def calculate_a(r: float, t: int) -> float:
    """
    计算心跳单元 a = r × T
    
    Spec: .kiro/specs/heartbeat-core/requirements.md 第2.1节
    
    Args:
        r: 日销率(瓶/天)
        t: 周转周期(天)
    
    Returns:
        a值(瓶)
    
    Raises:
        ValueError: 如果 r<0 或 t<=0
    """
    if r < 0 or t <= 0:
        raise ValueError(f"invalid input: r={r}, t={t}")
    return r * t
```

### 3. 异常处理(强制)

```python
# ✅ 对
try:
    result = risky_operation()
except SpecificException as e:
    logger.error(f"操作失败: {e}")
    raise  # 或返回默认值 · 根据Spec

# ❌ 错(静默吞异常)
try:
    result = risky_operation()
except:
    pass
```

### 4. 日志(强制)

```python
from loguru import logger

# ✅ 对(结构化)
logger.info("校准完成", extra={
    "node_id": 123,
    "sku": "LYX500",
    "old_r": 10,
    "new_r": 10.3,
    "change_ratio": 0.03
})

# ❌ 错(字符串拼接)
logger.info(f"node 123 sku LYX500 changed from 10 to 10.3")
```

### 5. 配置管理(强制)

```python
# ✅ 对(pydantic-settings)
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str
    redis_url: str
    wechat_corp_id: str
    
    class Config:
        env_file = ".env"

# ❌ 错(硬编码)
DATABASE_URL = "mysql://user:pass@host:3306/db"
```

---

## 🧪 测试要求

### 覆盖率

- 核心算法:**100%覆盖**
- Agent业务逻辑:**>80%覆盖**
- API接口:**>70%覆盖**

### 测试结构

```python
# tests/unit/test_heartbeat.py
import pytest
from src.utils.heartbeat import calculate_a

class TestCalculateA:
    """
    测试心跳单元计算
    Spec: .kiro/specs/heartbeat-core/requirements.md
    """
    
    def test_normal_case(self):
        """验收标准1 · 正常输入"""
        assert calculate_a(10, 7) == 70
    
    def test_zero_r(self):
        """验收标准2 · r=0"""
        assert calculate_a(0, 7) == 0
    
    def test_negative_r_raises(self):
        """验收标准3 · r<0 抛异常"""
        with pytest.raises(ValueError):
            calculate_a(-1, 7)
    
    def test_zero_t_raises(self):
        """验收标准4 · t=0 抛异常"""
        with pytest.raises(ValueError):
            calculate_a(10, 0)
```

---

## 🚀 部署

### 本地开发

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # 填写配置
alembic upgrade head   # 跑DDL
uvicorn src.main:app --reload
```

### 生产部署

```bash
docker-compose up -d
```

---

## 📦 关键依赖版本

```txt
fastapi==0.109.0
sqlalchemy==2.0.25
pymysql==1.1.0
apscheduler==3.10.4
redis==5.0.1
httpx==0.26.0
pandas==2.1.4
numpy==1.26.3
pytest==7.4.4
pydantic-settings==2.1.0
loguru==0.7.2
```
