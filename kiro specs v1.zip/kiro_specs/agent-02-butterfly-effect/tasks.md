# Agent 02 · 蝴蝶效应 · 任务清单

---

## 📋 任务分解

### Phase 1 · 战略事件表(前置 0.5天)
- [ ] 1.1 创建 `inf_strategic_events` 表
- [ ] 1.2 录入已知战略事件(涨价/退市/大促)
- [ ] 1.3 Repository + Service

### Phase 2 · 4个检测器(核心 2天)
- [ ] 2.1 `StrategicDistortionDetector`(D类)
  - [ ] 单元测试
- [ ] 2.2 `PushInventoryDetector`(A类)
  - [ ] 单元测试(3种场景)
- [ ] 2.3 `PromotionDistortionDetector`(B类)
  - [ ] 单元测试
- [ ] 2.4 `CrossRegionDistortionDetector`(C类)
  - [ ] 单元测试

### Phase 3 · Agent主逻辑(1天)
- [ ] 3.1 `ButterflyEffectAgent`
- [ ] 3.2 `run_full_detection()`
- [ ] 3.3 按优先级顺序调用4个检测器
- [ ] 3.4 Alert去重(同节点同SKU不重复)
- [ ] 3.5 单元测试

### Phase 4 · 企微推送(0.5天)
- [ ] 4.1 推送规则引擎(按severity路由)
- [ ] 4.2 消息模板设计
- [ ] 4.3 测试

### Phase 5 · 定时调度(0.5天)
- [ ] 5.1 APScheduler配置(Mon 07:00)
- [ ] 5.2 依赖检查(A值校准必须完成)

### Phase 6 · API(0.5天)
- [ ] 6.1 `POST /api/agent/butterfly`
- [ ] 6.2 `GET /api/alerts?status=OPEN`

### Phase 7 · 测试与部署(1天)
- [ ] 7.1 集成测试
- [ ] 7.2 性能测试
- [ ] 7.3 部署

---

## ⏱️ 总工时:6天

---

## 🎯 完成标准

- ✅ 4类失真检测全部通过单元测试
- ✅ D类优先级约束验证(D期间不触发ABC)
- ✅ 误报率<5%(用历史数据回测)
- ✅ 推送及时率>95%
