# Agent 02 · 蝴蝶效应 · 设计文档

---

## 🏗️ 架构

```
APScheduler(Mon 07:00)
    ↓
ButterflyEffectAgent.run_full_detection()
    ↓
读取昨日所有heartbeat
    ↓
对每条数据·按优先级检测:
    ↓
    1. detect_strategic_distortion(D类) 优先
    ↓   ↓ 如果是D类·跳过A/B/C
    ↓
    2. detect_push_inventory(A类)
    ↓
    3. detect_promotion_distortion(B类)
    ↓
    4. detect_cross_region_distortion(C类)
    ↓
生成Alert → 写入inf_alerts
    ↓
推送企微(按severity)
```

---

## 🧮 核心检测算法

### D类·战略扰动检测(优先)

```python
def detect_strategic(heartbeat, node, events):
    """
    如果该节点/SKU/日期有战略事件标记·直接D类·跳过其他检测
    
    战略事件来源:
      · inf_strategic_events表(手动维护)
      · 产品生命周期(新品期/成熟期/退市期)
      · 涨价/降价公告
    """
    active_events = events.filter_active(
        node_id=heartbeat.node_id,
        sku=heartbeat.sku_code,
        date=heartbeat.data_date
    )
    if active_events:
        return create_alert('D', node, heartbeat, 
            f"战略事件期:{active_events[0].name}")
    return None
```

### A类·压货失真检测

```python
def detect_push_inventory(heartbeat, node):
    # 条件1:节点类型
    if node.type not in ['DISTRIBUTOR', 'STORE']:
        return None
    
    # 条件2:水位 > 3a
    if heartbeat.water_level <= 3.0:
        return None
    
    # 条件3:最近7天r下降
    last_7 = repo.find_recent(heartbeat.node_id, heartbeat.sku, 7)
    prev_7 = repo.find_period(heartbeat.node_id, heartbeat.sku, -14, -7)
    if avg_r(last_7) >= avg_r(prev_7) * 0.9:  # 未下降10%
        return None
    
    return create_alert('A', node, heartbeat,
        f"压货:水位{heartbeat.water_level}a + r下降 {decline_pct}%",
        severity='HIGH')
```

### B类·促销扰动检测

```python
def detect_promotion(heartbeat, node):
    last_3_avg = repo.avg_r(heartbeat.node_id, heartbeat.sku, days=3)
    last_14_avg = repo.avg_r(heartbeat.node_id, heartbeat.sku, days=14)
    
    if last_14_avg == 0:
        return None
    
    ratio = last_3_avg / last_14_avg
    if ratio < 2.0:
        return None  # 不是促销
    
    # 检查库存是否同步下降
    inventory_drop = check_inventory_drop(heartbeat)
    if inventory_drop < 0.5:
        return None  # 库存没大幅下降·可能是数据错误
    
    return create_alert('B', node, heartbeat,
        f"促销:r骤升{ratio}x + 库存降{inventory_drop*100}%",
        severity='MEDIUM')
```

### C类·窜货失真检测

```python
def detect_cross_region(heartbeat, node):
    # 只检测二批商
    if node.type != 'SUB_DIST':
        return None
    
    # 二批商应严控水位=1a·>1.5a触发
    if heartbeat.water_level <= 1.5:
        return None
    
    return create_alert('C', node, heartbeat,
        f"窜货:二批商水位{heartbeat.water_level}a(应<1a)",
        severity='CRITICAL')
```

---

## 📊 数据结构

### Alert实体

```python
@dataclass
class Alert:
    alert_code: str           # BFE-A-abc12345
    node_id: int
    sku_code: str
    distortion_type: str      # A/B/C/D
    severity: str             # CRITICAL/HIGH/MEDIUM/INFO
    description: str
    evidence_json: dict       # 证据快照
    recommended_action: str
    status: str = 'OPEN'
    created_at: datetime
```

---

## 🔔 推送策略

| Severity | 推送对象 | 推送时机 |
|----------|---------|---------|
| CRITICAL(C类) | DOM + 业务总 + DS | 立即推送 |
| HIGH(A类) | DOM + 区域经理 | 立即推送 |
| MEDIUM(B类) | DOM | 汇总后推送(每天一次) |
| INFO(D类) | 仅记录 | 不推送 |

---

## ⚡ 性能

- pandas批量处理·不逐条SQL
- Redis缓存战略事件表
- 预期:50000组合 ≤ 3分钟
