-- ============================================================
-- V5__enhancements.sql
-- memory-all-layers-v2 新增表
-- 对应10个待加强功能
-- ============================================================

-- ── #1 对话压缩：给 conv_snapshots 加字段 ───────────────────
ALTER TABLE conv_snapshots
  ADD COLUMN key_topics    JSON    COMMENT '压缩时提取的主要话题',
  ADD COLUMN compress_mode VARCHAR(32) DEFAULT 'llm' COMMENT 'llm/rule';

-- ── #2 MySQL全文检索索引（替代pgvector）────────────────────
-- 给现有表加 FULLTEXT 索引，支持语义模糊检索
ALTER TABLE user_query_history
  ADD FULLTEXT INDEX ft_conclusions (key_conclusions, session_summary);

ALTER TABLE anomaly_case_library
  ADD FULLTEXT INDEX ft_anomaly (description, lessons_learned);

ALTER TABLE org_decision_rules
  ADD FULLTEXT INDEX ft_rules (rule_name, condition_desc, action_desc);

ALTER TABLE store_behavior_patterns
  ADD FULLTEXT INDEX ft_store (known_issues(200));

-- 语义检索词向量缓存（减少重复调用LLM生成摘要词）
CREATE TABLE search_keyword_cache (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    query_text   VARCHAR(512) NOT NULL,
    keywords     JSON NOT NULL,              -- LLM提取的检索关键词数组
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    hit_count    INT NOT NULL DEFAULT 0,
    UNIQUE KEY uk_query (query_text(200)),
    INDEX idx_created (created_at)
) COMMENT='检索关键词缓存·#2语义检索辅助';

-- ── #4 遗忘机制：给现有表加重要度字段 ─────────────────────
ALTER TABLE user_query_history
  ADD COLUMN importance      DECIMAL(4,3) NOT NULL DEFAULT 1.000 COMMENT '重要度0-1，按时间衰减',
  ADD COLUMN access_count    INT          NOT NULL DEFAULT 0     COMMENT '被引用次数',
  ADD COLUMN archived        TINYINT(1)   NOT NULL DEFAULT 0     COMMENT '1=已归档',
  ADD INDEX idx_archived_importance (archived, importance);

ALTER TABLE user_preference_learning
  ADD COLUMN importance      DECIMAL(4,3) NOT NULL DEFAULT 1.000,
  ADD COLUMN last_accessed_at DATETIME;

ALTER TABLE org_decision_rules
  ADD COLUMN last_triggered_importance DECIMAL(4,3) DEFAULT 1.000;

-- 遗忘日志：记录每次衰减和清理操作
CREATE TABLE memory_forgetting_log (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    table_name   VARCHAR(64) NOT NULL,
    record_id    BIGINT      NOT NULL,
    action       ENUM('decay','archive','delete') NOT NULL,
    importance_before DECIMAL(4,3),
    importance_after  DECIMAL(4,3),
    reason       VARCHAR(256),
    executed_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_table_action (table_name, action),
    INDEX idx_executed (executed_at)
) COMMENT='记忆遗忘日志·#4遗忘机制';

-- ── #5+6 矛盾检测+同义合并 ──────────────────────────────────
-- 偏好冲突记录
CREATE TABLE preference_conflicts (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         VARCHAR(64) NOT NULL,
    preference_key  VARCHAR(64) NOT NULL,
    old_value       VARCHAR(512),
    new_value       VARCHAR(512) NOT NULL,
    old_confidence  DECIMAL(4,2),
    new_confidence  DECIMAL(4,2),
    resolution      ENUM('keep_old','keep_new','merge','flag') NOT NULL,
    resolved_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_key (preference_key)
) COMMENT='偏好冲突记录·#5矛盾检测';

-- 同义词映射表
CREATE TABLE synonym_mappings (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    canonical    VARCHAR(128) NOT NULL COMMENT '标准表达',
    synonym      VARCHAR(128) NOT NULL COMMENT '同义表达',
    category     VARCHAR(64)  NOT NULL COMMENT 'area/brand/metric/channel',
    is_active    TINYINT(1)   NOT NULL DEFAULT 1,
    UNIQUE KEY uk_synonym (synonym, category),
    INDEX idx_canonical (canonical)
) COMMENT='同义词映射·#6同义合并';

-- 预置同义词
INSERT INTO synonym_mappings (canonical, synonym, category) VALUES
('关注区域','负责区域','area'),
('关注区域','管辖区域','area'),
('关注区域','分管区域','area'),
('关注区域','负责地区','area'),
('六月鲜','liuyuexian','brand'),
('味达美','weidamei','brand'),
('日销率','r值','metric'),
('日销率','r_value','metric'),
('库存水位','水位','metric'),
('库存水位','inventory_level','metric'),
('心跳单元','a值','metric'),
('心跳单元','a_value','metric'),
('S+门店','旗舰门店','channel'),
('经销商','distributor','channel'),
('二批商','sub_distributor','channel');

-- ── #7 情节记忆 ──────────────────────────────────────────────
CREATE TABLE episode_memory (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    episode_id      VARCHAR(64) NOT NULL UNIQUE,
    session_id      VARCHAR(64) NOT NULL,
    user_id         VARCHAR(64) NOT NULL,
    -- 用户意图
    user_query      TEXT        NOT NULL,
    intent_type     VARCHAR(64),           -- query/command/alert
    intent_agent_id VARCHAR(64),           -- 被路由到的Agent
    intent_confidence DECIMAL(4,2),
    -- 执行过程
    route_mode      VARCHAR(32),           -- single/pipeline/parallel
    tool_calls      JSON,                  -- [{tool_id,input,output,latency_ms}]
    agents_involved JSON,                  -- ["butterfly","omakase"]
    -- 结果
    final_answer    TEXT,
    answer_quality  TINYINT,              -- 用户反馈评分1-5（事后填入）
    total_duration_ms INT,
    -- 检索辅助
    topic_keywords  JSON,                  -- LLM提取的主题词，支持#2全文检索
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FULLTEXT INDEX ft_episode (user_query, final_answer),
    INDEX idx_session (session_id),
    INDEX idx_user_created (user_id, created_at)
) COMMENT='情节记忆·完整交互过程记录·#7';

-- ── #8+9 团队知识库+upvote ───────────────────────────────────
CREATE TABLE team_knowledge (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    knowledge_id    VARCHAR(64) NOT NULL UNIQUE,
    -- 内容
    title           VARCHAR(256) NOT NULL,
    content         TEXT         NOT NULL,
    knowledge_type  ENUM('finding','rule','pattern','insight','alert') NOT NULL,
    scope           ENUM('global','city','brand','channel') NOT NULL DEFAULT 'global',
    scope_id        VARCHAR(64),           -- 特定城市/品牌ID
    -- 来源
    created_by      VARCHAR(64)  NOT NULL,
    source_episode  VARCHAR(64),           -- 来自哪个情节记忆
    -- 审批
    status          ENUM('draft','pending','approved','rejected') NOT NULL DEFAULT 'draft',
    approved_by     VARCHAR(64),
    approved_at     DATETIME,
    reject_reason   VARCHAR(256),
    -- 评价
    upvote_count    INT          NOT NULL DEFAULT 0,
    downvote_count  INT          NOT NULL DEFAULT 0,
    view_count      INT          NOT NULL DEFAULT 0,
    -- 质量
    reliability     DECIMAL(4,2) GENERATED ALWAYS AS
                    (upvote_count / NULLIF(upvote_count + downvote_count, 0)) STORED,
    -- 检索
    tags            JSON,                  -- ["上海","库存","S+"]
    -- 生命周期
    expires_at      DATETIME,
    is_active       TINYINT(1)   NOT NULL DEFAULT 1,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FULLTEXT INDEX ft_knowledge (title, content),
    INDEX idx_scope (scope, scope_id, status),
    INDEX idx_created_by (created_by),
    INDEX idx_upvote (upvote_count DESC)
) COMMENT='团队知识库·人→人共享·#8';

CREATE TABLE team_knowledge_votes (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    knowledge_id    VARCHAR(64)  NOT NULL,
    user_id         VARCHAR(64)  NOT NULL,
    vote_type       ENUM('up','down') NOT NULL,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_user_knowledge (knowledge_id, user_id),
    INDEX idx_knowledge (knowledge_id)
) COMMENT='团队知识投票·#9 upvote机制';

-- ── #10 记忆工具链：LLM自主读写的调用日志 ──────────────────
CREATE TABLE memory_tool_calls (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    call_id         VARCHAR(64)  NOT NULL UNIQUE,
    session_id      VARCHAR(64)  NOT NULL,
    agent_id        VARCHAR(64)  NOT NULL,
    tool_name       VARCHAR(64)  NOT NULL,  -- save_memory/recall_memory/forget_memory等
    input_params    JSON         NOT NULL,
    output_result   JSON,
    success         TINYINT(1)   NOT NULL DEFAULT 1,
    latency_ms      INT,
    called_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session (session_id),
    INDEX idx_agent_tool (agent_id, tool_name),
    INDEX idx_called (called_at)
) COMMENT='记忆工具调用日志·#10工具链';

-- 视图：团队知识健康度
CREATE VIEW v_team_knowledge_health AS
SELECT
    COUNT(*) AS total_knowledge,
    SUM(CASE WHEN status='approved' THEN 1 ELSE 0 END) AS approved_count,
    SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending_approval,
    ROUND(AVG(upvote_count), 1) AS avg_upvotes,
    SUM(CASE WHEN expires_at < NOW() THEN 1 ELSE 0 END) AS expired_count,
    MAX(created_at) AS latest_contribution
FROM team_knowledge
WHERE is_active = 1;
