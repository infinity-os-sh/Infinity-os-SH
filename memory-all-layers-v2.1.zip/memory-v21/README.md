# INFINITY OS · 四层记忆系统 v2.1
## 完整交付包（含v1全部文件 + v2增强 + 3个集成修复）

---

## 这个包是完整的，不需要v1

v2.1包含所有文件，直接替换之前的memory-all-layers-v1.zip。

---

## 文件清单（17个文件）

```
memory-all-layers-v2.1/
├── sql/
│   ├── V1__layer1_conversation_memory.sql  ← v1原文·3张表
│   ├── V2__layer2_user_memory.sql          ← v1原文·4张表
│   ├── V3__layer3_shared_memory.sql        ← v1原文·5张表+24个Agent
│   ├── V4__layer4_org_knowledge.sql        ← v1原文·5张表+4条规则
│   └── V5__enhancements.sql               ← v2新增·10张表+5个索引+15条同义词
│
└── java/.../memory/
    ├── layer1/
    │   └── ConversationMemoryService.java  ← #1 真实LLM压缩
    ├── layer2/
    │   └── UserMemoryService.java          ← 修复遗漏2·接入MemoryIntegrator
    ├── layer3/
    │   └── SharedMemoryService.java        ← v1原文
    ├── layer4/
    │   └── OrgKnowledgeService.java        ← v1原文
    ├── enhance/                            ← v2全新目录
    │   ├── SemanticSearchService.java      ← #2 MySQL全文检索
    │   ├── MemoryForgetter.java            ← #4 遗忘机制
    │   ├── MemoryIntegrator.java           ← #5+6 矛盾检测+同义合并
    │   ├── EpisodeStore.java               ← #7 情节记忆
    │   ├── TeamKnowledgeService.java       ← #8+9 团队知识库+upvote
    │   └── MemoryToolService.java          ← #10 记忆工具链
    └── orchestrator/
        ├── MemoryOrchestrator.java         ← #3 token预算·修复遗漏3·接入EpisodeStore
        └── AgentContext.java               ← 新增3个字段
```

---

## v2.1相对v2修复的3个遗漏

| 遗漏 | 问题 | 修复方式 |
|------|------|---------|
| 遗漏1 | v2包缺少v1原有文件 | v2.1包含全部17个文件，无需依赖v1 |
| 遗漏2 | MemoryIntegrator做了但没接入 | UserMemoryService.updatePreferencesFromSession()改为调用integrator.resolvePreferenceConflict() |
| 遗漏3 | EpisodeStore做了但没接入 | MemoryOrchestrator新增EpisodeTracker·onUserMessage()开始情节·onAgentReply()完成情节 |

---

## 新增调用接口（v2.1）

相比v1，ToolOrchestrator调用MemoryOrchestrator时需要改动：

```java
// v1写法（仍然兼容）
memoryOrchestrator.onUserMessage(sessionId, content);
memoryOrchestrator.onAgentReply(sessionId, agentId, content, eventData);

// v2.1新写法（推荐，支持情节记录）
memoryOrchestrator.onUserMessage(sessionId, userId, content);  // 多传userId
memoryOrchestrator.onAgentReply(sessionId, agentId, content, eventData);  // 不变

// 路由确定后（可选，补充情节路由信息）
memoryOrchestrator.onRoutingDecided(sessionId, agentId, routeMode, confidence);

// 工具调用后（可选，补充情节工具记录）
memoryOrchestrator.onToolCalled(sessionId, toolId, input, output, latencyMs);
```

---

## 升级步骤

### Step 1：全量建表（1小时）
```sql
-- 按顺序执行全部5个SQL
source V1__layer1_conversation_memory.sql;
source V2__layer2_user_memory.sql;
source V3__layer3_shared_memory.sql;
source V4__layer4_org_knowledge.sql;
source V5__enhancements.sql;

-- 验证
SELECT COUNT(*) FROM synonym_mappings;      -- 15
SELECT COUNT(*) FROM agent_memory_profiles; -- 24
SELECT COUNT(*) FROM org_decision_rules;    -- 4
SELECT COUNT(*) FROM tool_registry;         -- （tool-layer-v2的表，此包没有）
```

### Step 2：Java包全量替换（10分钟）
直接用v2.1的java目录覆盖项目中的memory目录，不需要保留任何v1文件。

### Step 3：application.properties
```properties
anthropic.api.key=your-api-key
anthropic.api.model=claude-sonnet-4-20250514
spring.redis.host=localhost
spring.redis.port=6379
spring.datasource.url=jdbc:mysql://host/db?useUnicode=true&characterEncoding=UTF-8
```

### Step 4：ToolOrchestrator集成点修改（30分钟）
在tool-layer-v2的ToolOrchestrator里找到调用onUserMessage的地方，加上userId参数：
```java
// 改前
memoryOrchestrator.onUserMessage(sessionId, content);
// 改后
memoryOrchestrator.onUserMessage(sessionId, userId, content);
```

---

## 10个功能完成状态

| 编号 | 功能 | 状态 | 集成点 |
|------|------|------|--------|
| #1 | LLM对话压缩 | ✅ | ConversationMemoryService.triggerSnapshot() |
| #2 | MySQL语义检索 | ✅ | SemanticSearchService·替代pgvector |
| #3 | token预算控制 | ✅ | MemoryOrchestrator.buildSystemPrompt() |
| #4 | 遗忘机制 | ✅ | MemoryForgetter·每日凌晨2点 |
| #5 | 矛盾检测 | ✅ | UserMemoryService→MemoryIntegrator（遗漏2已修复） |
| #6 | 同义合并 | ✅ | MemoryIntegrator·synonym_mappings表 |
| #7 | 情节记忆 | ✅ | EpisodeStore→MemoryOrchestrator（遗漏3已修复） |
| #8 | 团队知识库 | ✅ | TeamKnowledgeService |
| #9 | upvote机制 | ✅ | TeamKnowledgeService.vote() |
| #10 | 记忆工具链 | ✅ | MemoryToolService·6个Tool·Agentic Loop |
