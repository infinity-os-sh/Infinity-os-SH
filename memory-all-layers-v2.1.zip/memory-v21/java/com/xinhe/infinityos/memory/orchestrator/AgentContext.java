// AgentContext.java (v2·增强版·新增字段)
package com.xinhe.infinityos.memory.orchestrator;

import java.util.List;
import java.util.Map;

public class AgentContext {
    // v1字段
    private String userContextPrompt;
    private List<Map<String, String>> conversationHistory;
    private List<Map<String, Object>> pendingMessages;
    private List<Map<String, Object>> criticalStates;
    private Map<String, Object> entityProfile;
    private List<Map<String, Object>> similarCases;
    private List<Map<String, Object>> applicableRules;

    // v2新增：#2语义检索相关历史
    private List<Map<String, Object>> relevantHistory;
    // v2新增：#7情节记忆
    private List<Map<String, Object>> recentEpisodes;
    // v2新增：#8团队知识
    private List<Map<String, Object>> teamKnowledge;

    // Getters & Setters
    public String getUserContextPrompt() { return userContextPrompt; }
    public void setUserContextPrompt(String v) { this.userContextPrompt = v; }
    public List<Map<String, String>> getConversationHistory() { return conversationHistory; }
    public void setConversationHistory(List<Map<String, String>> v) { this.conversationHistory = v; }
    public List<Map<String, Object>> getPendingMessages() { return pendingMessages; }
    public void setPendingMessages(List<Map<String, Object>> v) { this.pendingMessages = v; }
    public List<Map<String, Object>> getCriticalStates() { return criticalStates; }
    public void setCriticalStates(List<Map<String, Object>> v) { this.criticalStates = v; }
    public Map<String, Object> getEntityProfile() { return entityProfile; }
    public void setEntityProfile(Map<String, Object> v) { this.entityProfile = v; }
    public List<Map<String, Object>> getSimilarCases() { return similarCases; }
    public void setSimilarCases(List<Map<String, Object>> v) { this.similarCases = v; }
    public List<Map<String, Object>> getApplicableRules() { return applicableRules; }
    public void setApplicableRules(List<Map<String, Object>> v) { this.applicableRules = v; }
    // v2新增
    public List<Map<String, Object>> getRelevantHistory() { return relevantHistory; }
    public void setRelevantHistory(List<Map<String, Object>> v) { this.relevantHistory = v; }
    public List<Map<String, Object>> getRecentEpisodes() { return recentEpisodes; }
    public void setRecentEpisodes(List<Map<String, Object>> v) { this.recentEpisodes = v; }
    public List<Map<String, Object>> getTeamKnowledge() { return teamKnowledge; }
    public void setTeamKnowledge(List<Map<String, Object>> v) { this.teamKnowledge = v; }
}
