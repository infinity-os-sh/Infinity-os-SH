// ============================================================
// MemoryOrchestrator.java  (v2.1·完整修复版)
// 修复遗漏3：onUserMessage() / onAgentReply() 接入EpisodeStore
// 同时保留v2的全部增强：#2语义检索 + #3 token预算
// ============================================================
package com.xinhe.infinityos.memory.orchestrator;

import com.xinhe.infinityos.memory.enhance.*;
import com.xinhe.infinityos.memory.layer1.ConversationMemoryService;
import com.xinhe.infinityos.memory.layer2.UserMemoryService;
import com.xinhe.infinityos.memory.layer3.SharedMemoryService;
import com.xinhe.infinityos.memory.layer4.OrgKnowledgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class MemoryOrchestrator {

    // v1四层
    @Autowired private ConversationMemoryService layer1;
    @Autowired private UserMemoryService         layer2;
    @Autowired private SharedMemoryService       layer3;
    @Autowired private OrgKnowledgeService       layer4;

    // v2增强
    @Autowired private SemanticSearchService  semanticSearch;
    @Autowired private MemoryForgetter        forgetter;
    @Autowired private MemoryIntegrator       integrator;
    @Autowired private EpisodeStore           episodeStore;     // ← 遗漏3修复
    @Autowired private TeamKnowledgeService   teamKnowledge;
    @Autowired private MemoryToolService      memoryTools;

    // token预算常量
    private static final int TOKEN_BUDGET_P0          = 200;
    private static final int TOKEN_BUDGET_P1_HISTORY  = 150;
    private static final int TOKEN_BUDGET_P1_ALERTS   = 100;
    private static final int TOKEN_BUDGET_P2          = 200;
    private static final int TOKEN_BUDGET_TEAM        = 100;
    private static final int TOKEN_BUDGET_TOTAL       = 800;

    // ── 遗漏3修复：episodeId跟踪（sessionId → episodeId）────
    // 用于在onUserMessage()开始情节、onAgentReply()完成情节
    private final Map<String, EpisodeTracker> activeEpisodes = new ConcurrentHashMap<>();

    private static class EpisodeTracker {
        String episodeId;
        long startMs;
        List<String> agentsInvolved = new ArrayList<>();
        EpisodeTracker(String id) { this.episodeId = id; this.startMs = System.currentTimeMillis(); }
    }

    // ── 构建完整Agent上下文 ──────────────────────────────────
    public AgentContext buildContext(String userId, String sessionId,
                                     String agentId, String entityId,
                                     Map<String, Object> requestData) {
        AgentContext ctx = new AgentContext();
        String currentTopic = requestData != null
            ? String.valueOf(requestData.getOrDefault("raw_input", "")) : "";

        // P0·用户上下文（层面二）
        ctx.setUserContextPrompt(layer2.buildUserContextPrompt(userId));

        // P0·对话历史（层面一）
        ctx.setConversationHistory(layer1.getContextMessages(sessionId));

        // P1·语义相关历史（#2）
        ctx.setRelevantHistory(semanticSearch.searchQueryHistory(userId, currentTopic, 3));

        // P1·critical状态（层面三）
        ctx.setCriticalStates(layer3.readCriticalStates());

        // P1·未读广播（层面三）
        ctx.setPendingMessages(layer3.pullMessages(agentId));

        // P2·实体画像（层面四）
        if (entityId != null) {
            String entityType = requestData != null
                ? String.valueOf(requestData.getOrDefault("entity_type", "store")) : "store";
            if ("store".equals(entityType)) ctx.setEntityProfile(layer4.getStoreProfile(entityId));

            String anomalyType = requestData != null
                ? String.valueOf(requestData.getOrDefault("anomaly_type", "")) : "";
            if (!anomalyType.isEmpty()) {
                ctx.setSimilarCases(semanticSearch.searchSimilarCases(currentTopic, anomalyType, 3));
            }
        }

        // P2·决策规则（语义匹配）
        String ruleCategory = requestData != null
            ? String.valueOf(requestData.getOrDefault("rule_category", "inventory")) : "inventory";
        ctx.setApplicableRules(semanticSearch.searchRules(currentTopic, ruleCategory, 3));

        // #7·情节记忆
        ctx.setRecentEpisodes(episodeStore.getRecentEpisodes(userId, 3));

        // #8·团队知识
        String scope = requestData != null
            ? String.valueOf(requestData.getOrDefault("scope", "global")) : "global";
        ctx.setTeamKnowledge(teamKnowledge.searchKnowledge(currentTopic, scope, null, 3));

        return ctx;
    }

    // ── #3 带token预算的system prompt构建 ───────────────────
    public String buildSystemPrompt(String baseAgentPrompt, AgentContext ctx) {
        StringBuilder prompt = new StringBuilder(baseAgentPrompt);
        prompt.append("\n\n");
        int usedTokens = estimateTokens(baseAgentPrompt);

        // P0·用户上下文（必注入）
        if (ctx.getUserContextPrompt() != null) {
            String p0 = truncateToTokens(ctx.getUserContextPrompt(), TOKEN_BUDGET_P0);
            prompt.append(p0).append("\n");
            usedTokens += estimateTokens(p0);
        }

        // P1·critical警报（最多3条）
        if (ctx.getCriticalStates() != null && !ctx.getCriticalStates().isEmpty()
            && usedTokens < TOKEN_BUDGET_TOTAL - TOKEN_BUDGET_P1_ALERTS) {
            StringBuilder s = new StringBuilder("【⚠️ 系统级警报】\n");
            ctx.getCriticalStates().stream().limit(3).forEach(st ->
                s.append("  - ").append(st.get("state_key"))
                 .append("：").append(st.get("state_value")).append("\n"));
            String alerts = truncateToTokens(s.toString(), TOKEN_BUDGET_P1_ALERTS);
            prompt.append(alerts);
            usedTokens += estimateTokens(alerts);
        }

        // P1·语义相关历史（#2）
        if (ctx.getRelevantHistory() != null && !ctx.getRelevantHistory().isEmpty()
            && usedTokens < TOKEN_BUDGET_TOTAL - TOKEN_BUDGET_P1_HISTORY) {
            StringBuilder s = new StringBuilder("【相关历史记录】\n");
            ctx.getRelevantHistory().stream().limit(2).forEach(h ->
                s.append("  - ").append(h.get("key_conclusions")).append("\n"));
            String hist = truncateToTokens(s.toString(), TOKEN_BUDGET_P1_HISTORY);
            prompt.append(hist);
            usedTokens += estimateTokens(hist);
        }

        // P1·Agent间消息（最多2条）
        if (ctx.getPendingMessages() != null && !ctx.getPendingMessages().isEmpty()
            && usedTokens < TOKEN_BUDGET_TOTAL - 100) {
            StringBuilder s = new StringBuilder("【📡 Agent消息】\n");
            ctx.getPendingMessages().stream().limit(2).forEach(m ->
                s.append("  - [").append(m.get("from")).append("] ")
                 .append(m.get("subject")).append("\n"));
            String msgs = truncateToTokens(s.toString(), 100);
            prompt.append(msgs);
            usedTokens += estimateTokens(msgs);
        }

        // P2·实体画像
        if (ctx.getEntityProfile() != null && !ctx.getEntityProfile().isEmpty()
            && usedTokens < TOKEN_BUDGET_TOTAL - TOKEN_BUDGET_P2 / 3) {
            Map<String, Object> p = ctx.getEntityProfile();
            String profileStr = truncateToTokens(
                "【实体画像】风险:" + p.get("risk_level") + " 问题:" + p.get("known_issues") + "\n",
                TOKEN_BUDGET_P2 / 3);
            prompt.append(profileStr);
            usedTokens += estimateTokens(profileStr);
        }

        // P2·决策规则
        if (ctx.getApplicableRules() != null && !ctx.getApplicableRules().isEmpty()
            && usedTokens < TOKEN_BUDGET_TOTAL - TOKEN_BUDGET_P2 / 3) {
            StringBuilder s = new StringBuilder("【适用规则】\n");
            ctx.getApplicableRules().stream().limit(3).forEach(r ->
                s.append("  - [").append(r.get("rule_name")).append("] ")
                 .append(r.get("action_desc")).append("\n"));
            String rules = truncateToTokens(s.toString(), TOKEN_BUDGET_P2 / 3);
            prompt.append(rules);
            usedTokens += estimateTokens(rules);
        }

        // P2·相似案例
        if (ctx.getSimilarCases() != null && !ctx.getSimilarCases().isEmpty()
            && usedTokens < TOKEN_BUDGET_TOTAL - TOKEN_BUDGET_P2 / 3) {
            StringBuilder s = new StringBuilder("【相似案例】\n");
            ctx.getSimilarCases().stream().limit(2).forEach(c ->
                s.append("  - ").append(c.get("description"))
                 .append(" → ").append(c.get("lessons_learned")).append("\n"));
            String cases = truncateToTokens(s.toString(), TOKEN_BUDGET_P2 / 3);
            prompt.append(cases);
            usedTokens += estimateTokens(cases);
        }

        // #8·团队知识
        if (ctx.getTeamKnowledge() != null && !ctx.getTeamKnowledge().isEmpty()
            && usedTokens < TOKEN_BUDGET_TOTAL - TOKEN_BUDGET_TEAM) {
            StringBuilder s = new StringBuilder("【团队知识】\n");
            ctx.getTeamKnowledge().stream().limit(2).forEach(k ->
                s.append("  - ").append(k.get("title"))
                 .append("：").append(k.get("content")).append("\n"));
            String kn = truncateToTokens(s.toString(), TOKEN_BUDGET_TEAM);
            prompt.append(kn);
            usedTokens += estimateTokens(kn);
            if (usedTokens >= TOKEN_BUDGET_TOTAL)
                prompt.append("  [记忆已截断]\n");
        }

        prompt.append("\n基于以上上下文，请回答用户的问题。");
        return prompt.toString();
    }

    // ══ 修复遗漏3：对话钩子接入EpisodeStore ══════════════════

    /**
     * 用户发送消息时调用
     * v2.1新增：同时开始一个情节记录
     */
    public void onUserMessage(String sessionId, String userId, String content) {
        // 层面一：写入对话轮次（v1已有）
        layer1.addTurn(sessionId, "user", content);

        // #7 遗漏3修复：开始情节记录
        try {
            String episodeId = episodeStore.startEpisode(sessionId, userId, content);
            activeEpisodes.put(sessionId, new EpisodeTracker(episodeId));
        } catch (Exception ignored) {}
    }

    /**
     * 兼容v1签名（无userId参数），userId从session查询
     */
    public void onUserMessage(String sessionId, String content) {
        layer1.addTurn(sessionId, "user", content);
        // 无userId时不开启情节记录（降级处理）
    }

    /**
     * Agent回复后调用
     * v2.1新增：同时完成情节记录
     */
    public void onAgentReply(String sessionId, String agentId,
                              String content, Map<String, Object> eventData) {
        // 层面一：写入对话轮次（v1已有）
        layer1.addTurn(sessionId, "assistant", content);

        // 层面三：记录事件（v1已有）
        if (eventData != null && !eventData.isEmpty()) {
            layer3.recordEvent(agentId, "chat_reply", "system", sessionId,
                eventData, "success", 1.0);
        }

        // #7 遗漏3修复：完成情节记录
        EpisodeTracker tracker = activeEpisodes.remove(sessionId);
        if (tracker != null) {
            try {
                // 记录本次参与的Agent
                if (!tracker.agentsInvolved.contains(agentId)) {
                    tracker.agentsInvolved.add(agentId);
                }
                int durationMs = (int)(System.currentTimeMillis() - tracker.startMs);
                episodeStore.completeEpisode(
                    tracker.episodeId, content,
                    tracker.agentsInvolved, durationMs
                );
            } catch (Exception ignored) {}
        }
    }

    /**
     * 路由确定后，更新情节的路由信息
     */
    public void onRoutingDecided(String sessionId, String agentId,
                                  String routeMode, double confidence) {
        EpisodeTracker tracker = activeEpisodes.get(sessionId);
        if (tracker != null) {
            try {
                episodeStore.updateRouting(
                    tracker.episodeId, "query", agentId, confidence, routeMode
                );
                tracker.agentsInvolved.add(agentId);
            } catch (Exception ignored) {}
        }
    }

    /**
     * 工具调用后，记录到情节
     */
    public void onToolCalled(String sessionId, String toolId,
                              Map<String, Object> input, Map<String, Object> output,
                              int latencyMs) {
        EpisodeTracker tracker = activeEpisodes.get(sessionId);
        if (tracker != null) {
            try {
                episodeStore.addToolCall(tracker.episodeId, toolId, input, output, latencyMs);
            } catch (Exception ignored) {}
        }
    }

    // ── 会话结束 ─────────────────────────────────────────────
    public void onSessionEnd(String userId, String sessionId, String agentId,
                              String summary, List<String> topics,
                              List<String> cities, List<String> stores) {
        layer1.endSession(sessionId);
        layer2.saveSessionSummary(userId, sessionId, summary, topics, cities, stores);
        // 清理未完成的情节追踪
        activeEpisodes.remove(sessionId);
    }

    // ── 异常记录（跨层面三+层面四） ──────────────────────────
    public String recordAnomalyWithBroadcast(String agentId, String anomalyType,
                                              String entityType, String entityId,
                                              String description, String severity) {
        String caseId = layer4.recordAnomaly(anomalyType, entityType, entityId,
            description, severity, agentId);
        String priority = "critical".equals(severity) ? "critical" : "high";
        layer3.broadcast(agentId, null, "alert", priority,
            "异常·" + anomalyType + "·" + entityId,
            Map.of("caseId", caseId, "anomalyType", anomalyType,
                   "entityType", entityType, "entityId", entityId,
                   "severity", severity, "description", description));
        layer3.writeState(agentId, entityType, entityId, "anomaly_" + anomalyType,
            Map.of("caseId", caseId, "type", anomalyType, "severity", severity,
                   "detectedAt", System.currentTimeMillis()),
            priority, "critical".equals(severity) ? null : 60);
        return caseId;
    }

    // ── token预算工具方法 ────────────────────────────────────
    private int estimateTokens(String text) {
        if (text == null) return 0;
        int chinese = 0, ascii = 0;
        for (char c : text.toCharArray()) {
            if (c > 127) chinese++; else ascii++;
        }
        return chinese / 2 + ascii / 4 + 1;
    }

    private String truncateToTokens(String text, int tokenBudget) {
        if (text == null) return "";
        int charBudget = tokenBudget * 2;
        if (text.length() <= charBudget) return text;
        return text.substring(0, charBudget) + "...[截断]";
    }
}
