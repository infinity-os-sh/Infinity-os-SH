// ============================================================
// MemoryForgetter.java
// #4 记忆遗忘机制
// 重要度衰减公式：new_importance = importance × 0.95^days + 0.05 × log(access_count+1)
// 超过阈值 → 归档；归档超期 → 物理删除
// ============================================================
package com.xinhe.infinityos.memory.enhance;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class MemoryForgetter {

    @Autowired private JdbcTemplate jdbc;

    // 衰减参数
    private static final double DECAY_RATE      = 0.95;  // 每天衰减5%
    private static final double ACCESS_BONUS     = 0.05;  // 每次访问加分
    private static final double ARCHIVE_THRESHOLD = 0.2;  // 低于0.2归档
    private static final double DELETE_THRESHOLD  = 0.05; // 归档后低于0.05删除
    private static final int    ARCHIVE_AFTER_DAYS = 90;  // 90天未访问归档
    private static final int    DELETE_AFTER_DAYS  = 180; // 归档后180天物理删除

    // ── 每天凌晨2点执行全量衰减 ──────────────────────────────
    @Scheduled(cron = "0 0 2 * * *")
    public void dailyDecay() {
        decayQueryHistory();
        decayPreferenceLearning();
        decayOrgRules();
        cleanupArchivedRecords();
    }

    // ── 用户查询历史衰减 ─────────────────────────────────────
    private void decayQueryHistory() {
        List<Map<String, Object>> records = jdbc.queryForList(
            "SELECT id, importance, access_count, session_date " +
            "FROM user_query_history WHERE archived=0"
        );

        for (Map<String, Object> r : records) {
            long id = ((Number) r.get("id")).longValue();
            double importance = ((Number) r.getOrDefault("importance", 1.0)).doubleValue();
            int accessCount = ((Number) r.getOrDefault("access_count", 0)).intValue();
            Object sessionDate = r.get("session_date");

            // 计算距今天数
            int days = getDaysSince(sessionDate);

            // 衰减公式
            double newImportance = importance * Math.pow(DECAY_RATE, days)
                + ACCESS_BONUS * Math.log(accessCount + 1);
            newImportance = Math.max(0.0, Math.min(1.0, newImportance));

            if (newImportance < ARCHIVE_THRESHOLD || days > ARCHIVE_AFTER_DAYS) {
                // 归档
                jdbc.update(
                    "UPDATE user_query_history SET importance=?, archived=1 WHERE id=?",
                    newImportance, id
                );
                logForgetting("user_query_history", id, "archive", importance, newImportance,
                    "importance=" + String.format("%.3f", newImportance) + " days=" + days);
            } else {
                jdbc.update(
                    "UPDATE user_query_history SET importance=? WHERE id=?",
                    newImportance, id
                );
                logForgetting("user_query_history", id, "decay", importance, newImportance, null);
            }
        }
    }

    // ── 用户偏好学习记录衰减 ─────────────────────────────────
    private void decayPreferenceLearning() {
        // 低置信度(<0.3) 且 长期未访问 → 直接删除
        int deleted = jdbc.update(
            "DELETE FROM user_preference_learning " +
            "WHERE confidence < 0.3 " +
            "AND (last_accessed_at IS NULL OR last_accessed_at < DATE_SUB(NOW(), INTERVAL 60 DAY))"
        );
        if (deleted > 0) {
            logForgetting("user_preference_learning", -1L, "delete", null, null,
                "低置信度且长期未访问，共删除" + deleted + "条");
        }

        // 更新重要度
        jdbc.update(
            "UPDATE user_preference_learning " +
            "SET importance = GREATEST(0, importance * POW(?,  " +
            "    DATEDIFF(NOW(), COALESCE(last_accessed_at, created_at)))) " +
            "WHERE importance > ?",
            DECAY_RATE, DELETE_THRESHOLD
        );
    }

    // ── 组织决策规则衰减 ─────────────────────────────────────
    private void decayOrgRules() {
        // 超过60天未触发 且 置信度低 → 自动失活
        int deactivated = jdbc.update(
            "UPDATE org_decision_rules SET is_active=0 " +
            "WHERE is_active=1 " +
            "AND source='learned' " +
            "AND confidence < 0.6 " +
            "AND (last_triggered_at IS NULL OR last_triggered_at < DATE_SUB(NOW(), INTERVAL 60 DAY))"
        );
        if (deactivated > 0) {
            logForgetting("org_decision_rules", -1L, "archive", null, null,
                "长期未触发的低置信度规则，共失活" + deactivated + "条");
        }
    }

    // ── 清理归档数据（物理删除） ─────────────────────────────
    private void cleanupArchivedRecords() {
        // 归档超过180天且importance<0.05的历史记录物理删除
        int deleted = jdbc.update(
            "DELETE FROM user_query_history " +
            "WHERE archived=1 " +
            "AND importance < ? " +
            "AND session_date < DATE_SUB(NOW(), INTERVAL ? DAY)",
            DELETE_THRESHOLD, DELETE_AFTER_DAYS
        );
        if (deleted > 0) {
            logForgetting("user_query_history", -1L, "delete", null, null,
                "归档超期物理删除，共" + deleted + "条");
        }
    }

    // ── 访问时更新重要度（被引用则加分）────────────────────
    public void onMemoryAccessed(String tableName, Long recordId) {
        switch (tableName) {
            case "user_query_history":
                jdbc.update(
                    "UPDATE user_query_history " +
                    "SET access_count=access_count+1, " +
                    "    importance=LEAST(1.0, importance + ?) " +
                    "WHERE id=?",
                    ACCESS_BONUS, recordId
                );
                break;
            case "user_preference_learning":
                jdbc.update(
                    "UPDATE user_preference_learning " +
                    "SET last_accessed_at=NOW(), " +
                    "    importance=LEAST(1.0, importance + ?) " +
                    "WHERE id=?",
                    ACCESS_BONUS, recordId
                );
                break;
        }
    }

    // ── 工具方法 ─────────────────────────────────────────────
    private int getDaysSince(Object dateObj) {
        if (dateObj == null) return 0;
        try {
            if (dateObj instanceof java.sql.Date) {
                long diff = System.currentTimeMillis() - ((java.sql.Date) dateObj).getTime();
                return (int) (diff / (1000 * 60 * 60 * 24));
            }
        } catch (Exception ignored) {}
        return 0;
    }

    private void logForgetting(String tableName, Long recordId, String action,
                                Double importanceBefore, Double importanceAfter, String reason) {
        jdbc.update(
            "INSERT INTO memory_forgetting_log(table_name, record_id, action, " +
            "importance_before, importance_after, reason) VALUES(?,?,?,?,?,?)",
            tableName, recordId, action, importanceBefore, importanceAfter, reason
        );
    }
}
