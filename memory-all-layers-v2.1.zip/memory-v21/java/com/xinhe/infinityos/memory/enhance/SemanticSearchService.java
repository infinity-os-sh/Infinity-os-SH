// ============================================================
// SemanticSearchService.java
// #2 语义检索·MySQL全文检索实现
// 原T代码用pgvector（Python/PostgreSQL），D代码环境是Java+MySQL
// 改用MySQL FULLTEXT + LLM关键词扩展，无需引入第二个数据库
// ============================================================
package com.xinhe.infinityos.memory.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class SemanticSearchService {

    @Value("${anthropic.api.key}")
    private String anthropicApiKey;

    @Value("${anthropic.api.model:claude-sonnet-4-20250514}")
    private String claudeModel;

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    private final HttpClient httpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10)).build();

    // ══ 核心：语义检索（全文检索 + LLM关键词扩展）═══════════

    /**
     * 语义检索历史对话摘要
     * 用于：buildUserContextPrompt() 按当前话题检索最相关的历史记录
     */
    public List<Map<String, Object>> searchQueryHistory(String userId, String topic, int limit) {
        List<String> keywords = expandKeywords(topic);
        if (keywords.isEmpty()) return Collections.emptyList();

        String matchExpr = buildMatchExpr(keywords);

        try {
            // MySQL FULLTEXT全文检索
            return jdbc.queryForList(
                "SELECT h.*, MATCH(h.key_conclusions, h.session_summary) " +
                "AGAINST(? IN BOOLEAN MODE) AS relevance_score " +
                "FROM user_query_history h " +
                "WHERE h.user_id=? " +
                "AND h.archived=0 " +
                "AND MATCH(h.key_conclusions, h.session_summary) AGAINST(? IN BOOLEAN MODE) " +
                "ORDER BY relevance_score DESC, h.session_date DESC " +
                "LIMIT ?",
                matchExpr, userId, matchExpr, limit
            );
        } catch (Exception e) {
            // 全文检索失败时降级到LIKE查询
            return fallbackLikeSearch(userId, keywords, limit);
        }
    }

    /**
     * 语义检索相似异常案例
     * 用于：findSimilarCases() 不只精确匹配anomaly_type，还能模糊匹配描述
     */
    public List<Map<String, Object>> searchSimilarCases(String description,
                                                          String anomalyType,
                                                          int limit) {
        List<String> keywords = expandKeywords(description);
        String matchExpr = buildMatchExpr(keywords);

        List<Map<String, Object>> results = new ArrayList<>();

        // 策略1：精确类型匹配（高优先级）
        results.addAll(jdbc.queryForList(
            "SELECT *, 10.0 AS relevance_score FROM anomaly_case_library " +
            "WHERE anomaly_type=? AND resolution_outcome IN ('resolved','escalated') " +
            "ORDER BY detected_at DESC LIMIT ?",
            anomalyType, limit / 2
        ));

        // 策略2：全文语义匹配（补充召回）
        if (!matchExpr.isEmpty()) {
            try {
                List<Map<String, Object>> semantic = jdbc.queryForList(
                    "SELECT *, MATCH(description, lessons_learned) AGAINST(? IN BOOLEAN MODE) " +
                    "AS relevance_score FROM anomaly_case_library " +
                    "WHERE anomaly_type != ? " +
                    "AND MATCH(description, lessons_learned) AGAINST(? IN BOOLEAN MODE) " +
                    "AND resolution_outcome IN ('resolved','escalated') " +
                    "ORDER BY relevance_score DESC LIMIT ?",
                    matchExpr, anomalyType, matchExpr, limit / 2
                );
                results.addAll(semantic);
            } catch (Exception ignored) {}
        }

        // 去重 + 按相关度排序
        return deduplicateAndSort(results, limit);
    }

    /**
     * 语义检索决策规则
     * 用于：matchDecisionRules() 按当前情境检索最相关的规则
     */
    public List<Map<String, Object>> searchRules(String context, String category, int limit) {
        List<String> keywords = expandKeywords(context);
        String matchExpr = buildMatchExpr(keywords);

        List<Map<String, Object>> results = new ArrayList<>();

        // 精确类别匹配
        results.addAll(jdbc.queryForList(
            "SELECT *, 10.0 AS relevance_score FROM org_decision_rules " +
            "WHERE is_active=1 AND rule_category=? " +
            "AND confidence > 0.7 ORDER BY confidence DESC LIMIT ?",
            category, limit / 2
        ));

        // 全文语义补充
        if (!matchExpr.isEmpty()) {
            try {
                results.addAll(jdbc.queryForList(
                    "SELECT *, MATCH(rule_name, condition_desc, action_desc) " +
                    "AGAINST(? IN BOOLEAN MODE) AS relevance_score " +
                    "FROM org_decision_rules " +
                    "WHERE is_active=1 AND rule_category != ? " +
                    "AND MATCH(rule_name, condition_desc, action_desc) AGAINST(? IN BOOLEAN MODE) " +
                    "ORDER BY relevance_score DESC LIMIT ?",
                    matchExpr, category, matchExpr, limit / 2
                ));
            } catch (Exception ignored) {}
        }

        return deduplicateAndSort(results, limit);
    }

    /**
     * 语义检索团队知识库（#8团队知识库使用）
     */
    public List<Map<String, Object>> searchTeamKnowledge(String topic, String scope,
                                                           String scopeId, int limit) {
        List<String> keywords = expandKeywords(topic);
        String matchExpr = buildMatchExpr(keywords);

        try {
            return jdbc.queryForList(
                "SELECT *, MATCH(title, content) AGAINST(? IN BOOLEAN MODE) AS relevance_score " +
                "FROM team_knowledge " +
                "WHERE status='approved' AND is_active=1 " +
                (scope != null ? "AND (scope=? OR scope='global') " : "") +
                "AND MATCH(title, content) AGAINST(? IN BOOLEAN MODE) " +
                "ORDER BY relevance_score DESC, upvote_count DESC LIMIT ?",
                scope != null
                    ? new Object[]{matchExpr, scope, matchExpr, limit}
                    : new Object[]{matchExpr, matchExpr, limit}
            );
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    // ══ LLM关键词扩展：把自然语言转换为检索词 ════════════════

    /**
     * 调用Claude API把话题/问题扩展为检索关键词
     * 同时查缓存避免重复调用
     */
    public List<String> expandKeywords(String topic) {
        if (topic == null || topic.isBlank()) return Collections.emptyList();

        // 1. 查缓存
        List<String> cached = getKeywordCache(topic);
        if (cached != null) return cached;

        // 2. 先做同义词归一化
        String normalizedTopic = normalizeSynonyms(topic);

        // 3. 基础分词（中文按词切分）
        List<String> baseKeywords = basicSegment(normalizedTopic);

        // 4. LLM扩展（获取相关词）
        List<String> expanded = llmExpandKeywords(normalizedTopic, baseKeywords);

        // 5. 写缓存
        saveKeywordCache(topic, expanded);
        return expanded;
    }

    private List<String> llmExpandKeywords(String topic, List<String> baseKeywords) {
        try {
            String prompt = "从以下问题/话题中提取5-8个最关键的中文检索词，" +
                "包括同义词和相关词。只输出词语，用逗号分隔，不要解释：\n" + topic;

            Map<String, Object> body = Map.of(
                "model", claudeModel,
                "max_tokens", 100,
                "messages", List.of(Map.of("role", "user", "content", prompt))
            );

            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.anthropic.com/v1/messages"))
                .header("Content-Type", "application/json")
                .header("x-api-key", anthropicApiKey)
                .header("anthropic-version", "2023-06-01")
                .timeout(Duration.ofSeconds(10))
                .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
                .build();

            HttpResponse<String> response = httpClient.send(request,
                HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                Map<?, ?> resp = mapper.readValue(response.body(), Map.class);
                List<?> content = (List<?>) resp.get("content");
                if (content != null && !content.isEmpty()) {
                    String text = String.valueOf(((Map<?,?>) content.get(0)).get("text"));
                    List<String> llmKeywords = Arrays.stream(text.split("[,，、]+"))
                        .map(String::trim).filter(s -> !s.isEmpty())
                        .collect(Collectors.toList());
                    // 合并基础词和LLM扩展词，去重
                    Set<String> merged = new LinkedHashSet<>(baseKeywords);
                    merged.addAll(llmKeywords);
                    return new ArrayList<>(merged);
                }
            }
        } catch (Exception ignored) {}

        return baseKeywords; // 降级：只用基础分词
    }

    // ══ MySQL BOOLEAN MODE 表达式构建 ════════════════════════

    private String buildMatchExpr(List<String> keywords) {
        if (keywords.isEmpty()) return "";
        // 构建 BOOLEAN MODE 检索表达式：+词1 +词2 词3
        // 前两个关键词设为必须匹配(+)，其余为可选
        return keywords.stream()
            .limit(8)
            .map(kw -> kw.length() >= 2 ? kw : null) // MySQL全文检索最少2字
            .filter(Objects::nonNull)
            .collect(Collectors.joining(" "));
    }

    // ══ 辅助方法 ══════════════════════════════════════════════

    private String normalizeSynonyms(String text) {
        try {
            List<Map<String, Object>> synonyms = jdbc.queryForList(
                "SELECT synonym, canonical FROM synonym_mappings WHERE is_active=1"
            );
            String result = text;
            for (Map<String, Object> s : synonyms) {
                result = result.replace(
                    String.valueOf(s.get("synonym")),
                    String.valueOf(s.get("canonical"))
                );
            }
            return result;
        } catch (Exception e) { return text; }
    }

    private List<String> basicSegment(String text) {
        // 简单中文分词：按2-4字滑动窗口切片
        List<String> tokens = new ArrayList<>();
        if (text == null) return tokens;
        // 按常见停用词切分
        String[] parts = text.split("[的了在是和与或，。？！、：；""''（）]");
        for (String part : parts) {
            String trimmed = part.trim();
            if (trimmed.length() >= 2) tokens.add(trimmed);
        }
        return tokens;
    }

    @SuppressWarnings("unchecked")
    private List<String> getKeywordCache(String topic) {
        try {
            String cached = jdbc.queryForObject(
                "SELECT keywords FROM search_keyword_cache WHERE query_text=?",
                String.class, topic
            );
            jdbc.update("UPDATE search_keyword_cache SET hit_count=hit_count+1 WHERE query_text=?", topic);
            return mapper.readValue(cached, List.class);
        } catch (Exception e) { return null; }
    }

    private void saveKeywordCache(String topic, List<String> keywords) {
        try {
            jdbc.update(
                "INSERT IGNORE INTO search_keyword_cache(query_text, keywords) VALUES(?,?)",
                topic, mapper.writeValueAsString(keywords)
            );
        } catch (Exception ignored) {}
    }

    private List<Map<String, Object>> fallbackLikeSearch(String userId,
                                                           List<String> keywords, int limit) {
        if (keywords.isEmpty()) return Collections.emptyList();
        String likeClause = keywords.stream()
            .limit(3)
            .map(kw -> "key_conclusions LIKE '%" + kw.replace("'", "") + "%'")
            .collect(Collectors.joining(" OR "));
        return jdbc.queryForList(
            "SELECT * FROM user_query_history WHERE user_id=? AND (" + likeClause + ") " +
            "AND archived=0 ORDER BY session_date DESC LIMIT ?",
            userId, limit
        );
    }

    private List<Map<String, Object>> deduplicateAndSort(List<Map<String, Object>> results, int limit) {
        Set<Object> seen = new HashSet<>();
        return results.stream()
            .filter(r -> seen.add(r.get("id")))
            .sorted((a, b) -> {
                double sa = ((Number) a.getOrDefault("relevance_score", 0)).doubleValue();
                double sb = ((Number) b.getOrDefault("relevance_score", 0)).doubleValue();
                return Double.compare(sb, sa);
            })
            .limit(limit)
            .collect(Collectors.toList());
    }
}
