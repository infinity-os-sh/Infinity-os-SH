// ============================================================
// MemoryToolService.java
// #10 记忆工具链·LLM自主读写记忆的Tool接口
// 注意：T代码用Python LangChain @tool，D代码是Java Spring
//       此处用Spring @Service封装为结构化Tool定义
//       通过Claude API的tool_use功能让LLM自主调用
// ============================================================
package com.xinhe.infinityos.memory.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

@Service
public class MemoryToolService {

    @Value("${anthropic.api.key}")
    private String anthropicApiKey;

    @Value("${anthropic.api.model:claude-sonnet-4-20250514}")
    private String claudeModel;

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;
    @Autowired private SemanticSearchService semanticSearch;
    @Autowired private TeamKnowledgeService teamKnowledge;
    @Autowired private EpisodeStore episodeStore;

    private final HttpClient httpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10)).build();

    // ══ 6个Tool的定义（JSON Schema格式，传给Claude API）═════

    public static final List<Map<String, Object>> TOOL_DEFINITIONS = List.of(

        buildTool("save_user_memory",
            "保存用户偏好或关键信息到记忆系统。当用户表达偏好、设置、关注点时调用。",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "memory_type", Map.of("type","string",
                        "description","记忆类型：preference（偏好）/ insight（发现）/ watchlist（关注项）"),
                    "key",   Map.of("type","string","description","记忆的键，如 preferred_city / alert_threshold"),
                    "value", Map.of("type","string","description","记忆的值"),
                    "confidence", Map.of("type","number","description","置信度0-1，默认0.8")
                ),
                "required", List.of("memory_type","key","value")
            )
        ),

        buildTool("recall_user_memory",
            "检索用户的历史记忆。当需要了解用户背景、偏好、历史关注点时调用。",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "topic", Map.of("type","string","description","检索主题，如 上海库存 / 六月鲜 / S+门店"),
                    "memory_type", Map.of("type","string","description","可选：preference / history / watchlist，不填则全部检索")
                ),
                "required", List.of("topic")
            )
        ),

        buildTool("recall_episode",
            "检索历史情节记忆。当用户问上次分析了什么、某个具体问题的历史记录时调用。",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "topic", Map.of("type","string","description","检索主题"),
                    "limit", Map.of("type","integer","description","返回条数，默认3")
                ),
                "required", List.of("topic")
            )
        ),

        buildTool("forget_user_memory",
            "删除指定的用户记忆。当用户说不再关注某事、信息已过期时调用。",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "memory_type", Map.of("type","string","description","preference / watchlist"),
                    "key", Map.of("type","string","description","要删除的记忆键")
                ),
                "required", List.of("memory_type","key")
            )
        ),

        buildTool("share_insight",
            "将重要发现分享到团队知识库，供其他用户使用。当用户有重要发现值得团队知道时调用。",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "title",   Map.of("type","string","description","知识标题"),
                    "content", Map.of("type","string","description","知识内容"),
                    "scope",   Map.of("type","string","description","范围：global / city / brand / channel"),
                    "tags",    Map.of("type","array","items",Map.of("type","string"),"description","标签列表")
                ),
                "required", List.of("title","content")
            )
        ),

        buildTool("query_team_knowledge",
            "查询团队知识库，获取其他成员分享的知识和发现。",
            Map.of(
                "type", "object",
                "properties", Map.of(
                    "topic", Map.of("type","string","description","查询主题"),
                    "scope", Map.of("type","string","description","可选：global / city / brand")
                ),
                "required", List.of("topic")
            )
        )
    );

    // ══ 带记忆工具链的Claude API调用 ════════════════════════

    /**
     * 核心方法：用工具链调用Claude API
     * Claude会在对话过程中自主决定是否调用记忆工具
     *
     * @param userId    当前用户（所有工具调用通过闭包绑定user_id）
     * @param sessionId 当前会话
     * @param agentId   当前Agent
     * @param systemPrompt Agent的系统提示词
     * @param messages  对话历史
     * @return Claude的最终回复文本
     */
    public String callWithMemoryTools(String userId, String sessionId, String agentId,
                                       String systemPrompt,
                                       List<Map<String, String>> messages) {
        try {
            Map<String, Object> requestBody = new LinkedHashMap<>();
            requestBody.put("model", claudeModel);
            requestBody.put("max_tokens", 1000);
            requestBody.put("system", systemPrompt);
            requestBody.put("messages", messages);
            requestBody.put("tools", TOOL_DEFINITIONS);

            String response = callClaudeApi(requestBody);
            Map<?, ?> resp = mapper.readValue(response, Map.class);

            // 处理工具调用（agentic loop）
            return processAgenticLoop(userId, sessionId, agentId, requestBody, resp);

        } catch (Exception e) {
            throw new RuntimeException("记忆工具链调用失败", e);
        }
    }

    // ══ Agentic Loop：处理工具调用并继续对话 ═════════════════

    @SuppressWarnings("unchecked")
    private String processAgenticLoop(String userId, String sessionId, String agentId,
                                       Map<String, Object> requestBody, Map<?, ?> resp) throws Exception {
        int maxIterations = 5; // 防止无限循环
        int iteration = 0;

        while ("tool_use".equals(resp.get("stop_reason")) && iteration < maxIterations) {
            iteration++;
            List<?> content = (List<?>) resp.get("content");

            // 构建assistant消息（包含工具调用）
            Map<String, Object> assistantMsg = Map.of("role", "assistant", "content", content);

            // 执行所有工具调用
            List<Map<String, Object>> toolResults = new ArrayList<>();
            for (Object block : content) {
                Map<?, ?> b = (Map<?, ?>) block;
                if ("tool_use".equals(b.get("type"))) {
                    String toolName = String.valueOf(b.get("name"));
                    String toolUseId = String.valueOf(b.get("id"));
                    Map<String, Object> input = (Map<String, Object>) b.get("input");

                    // 执行工具（注入userId）
                    Object result = executeTool(userId, sessionId, agentId, toolName, input);

                    // 记录工具调用日志
                    logToolCall(sessionId, agentId, toolName, input, result);

                    toolResults.add(Map.of(
                        "type", "tool_result",
                        "tool_use_id", toolUseId,
                        "content", mapper.writeValueAsString(result)
                    ));
                }
            }

            // 把工具结果加回messages，继续调用
            List<Map<String, Object>> messages =
                (List<Map<String, Object>>) requestBody.get("messages");
            messages.add(assistantMsg);
            messages.add(Map.of("role", "user", "content", toolResults));

            // 继续调用Claude
            String nextResponse = callClaudeApi(requestBody);
            resp = mapper.readValue(nextResponse, Map.class);
        }

        // 提取最终文本回复
        List<?> finalContent = (List<?>) resp.get("content");
        if (finalContent != null) {
            for (Object block : finalContent) {
                Map<?, ?> b = (Map<?, ?>) block;
                if ("text".equals(b.get("type"))) {
                    return String.valueOf(b.get("text"));
                }
            }
        }
        return "记忆工具链执行完成，但未返回文本。";
    }

    // ══ 6个工具的具体执行 ════════════════════════════════════

    private Object executeTool(String userId, String sessionId, String agentId,
                                String toolName, Map<String, Object> input) {
        return switch (toolName) {
            case "save_user_memory"    -> toolSaveUserMemory(userId, input);
            case "recall_user_memory"  -> toolRecallUserMemory(userId, input);
            case "recall_episode"      -> toolRecallEpisode(userId, input);
            case "forget_user_memory"  -> toolForgetUserMemory(userId, input);
            case "share_insight"       -> toolShareInsight(userId, input);
            case "query_team_knowledge"-> toolQueryTeamKnowledge(input);
            default -> Map.of("error", "未知工具: " + toolName);
        };
    }

    private Object toolSaveUserMemory(String userId, Map<String, Object> input) {
        String memoryType = String.valueOf(input.get("memory_type"));
        String key = String.valueOf(input.get("key"));
        String value = String.valueOf(input.get("value"));
        double confidence = input.containsKey("confidence")
            ? ((Number) input.get("confidence")).doubleValue() : 0.8;

        jdbc.update(
            "INSERT INTO user_preference_learning(user_id, preference_key, new_value, " +
            "confidence, learned_from) VALUES(?,?,?,?,?) " +
            "ON DUPLICATE KEY UPDATE new_value=VALUES(new_value), confidence=VALUES(confidence)",
            userId, key, value, confidence, "llm_tool:" + memoryType
        );
        return Map.of("status", "saved", "key", key, "value", value);
    }

    private Object toolRecallUserMemory(String userId, Map<String, Object> input) {
        String topic = String.valueOf(input.get("topic"));
        List<Map<String, Object>> results = semanticSearch.searchQueryHistory(userId, topic, 5);
        List<Map<String, Object>> prefs = jdbc.queryForList(
            "SELECT preference_key, new_value, confidence FROM user_preference_learning " +
            "WHERE user_id=? ORDER BY id DESC LIMIT 10", userId
        );
        return Map.of("query_history", results, "preferences", prefs);
    }

    private Object toolRecallEpisode(String userId, Map<String, Object> input) {
        String topic = String.valueOf(input.get("topic"));
        int limit = input.containsKey("limit") ? ((Number) input.get("limit")).intValue() : 3;
        return episodeStore.searchEpisodes(userId, topic, limit);
    }

    private Object toolForgetUserMemory(String userId, Map<String, Object> input) {
        String memoryType = String.valueOf(input.get("memory_type"));
        String key = String.valueOf(input.get("key"));
        int deleted = 0;
        if ("preference".equals(memoryType)) {
            deleted = jdbc.update(
                "DELETE FROM user_preference_learning WHERE user_id=? AND preference_key=?",
                userId, key
            );
        } else if ("watchlist".equals(memoryType)) {
            deleted = jdbc.update(
                "UPDATE user_watchlist SET is_active=0 WHERE user_id=? AND entity_name=?",
                userId, key
            );
        }
        return Map.of("status", deleted > 0 ? "forgotten" : "not_found", "key", key);
    }

    private Object toolShareInsight(String userId, Map<String, Object> input) {
        String title = String.valueOf(input.get("title"));
        String content = String.valueOf(input.get("content"));
        String scope = input.containsKey("scope") ? String.valueOf(input.get("scope")) : "global";
        List<String> tags = input.containsKey("tags")
            ? (List<String>) input.get("tags") : Collections.emptyList();
        String knowledgeId = teamKnowledge.submitAndApprove(
            userId, title, content, "insight", scope, null, tags
        );
        return Map.of("status", "shared", "knowledge_id", knowledgeId, "title", title);
    }

    private Object toolQueryTeamKnowledge(Map<String, Object> input) {
        String topic = String.valueOf(input.get("topic"));
        String scope = input.containsKey("scope") ? String.valueOf(input.get("scope")) : null;
        return teamKnowledge.searchKnowledge(topic, scope, null, 5);
    }

    // ══ 工具方法 ══════════════════════════════════════════════

    private String callClaudeApi(Map<String, Object> body) throws Exception {
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://api.anthropic.com/v1/messages"))
            .header("Content-Type", "application/json")
            .header("x-api-key", anthropicApiKey)
            .header("anthropic-version", "2023-06-01")
            .timeout(Duration.ofSeconds(60))
            .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
            .build();
        HttpResponse<String> response = httpClient.send(request,
            HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new RuntimeException("Claude API错误: " + response.statusCode());
        }
        return response.body();
    }

    private void logToolCall(String sessionId, String agentId, String toolName,
                              Map<String, Object> input, Object output) {
        try {
            String callId = "TC_" + System.currentTimeMillis();
            jdbc.update(
                "INSERT INTO memory_tool_calls(call_id, session_id, agent_id, tool_name, " +
                "input_params, output_result) VALUES(?,?,?,?,?,?)",
                callId, sessionId, agentId, toolName,
                mapper.writeValueAsString(input),
                mapper.writeValueAsString(output)
            );
        } catch (Exception ignored) {}
    }

    private static Map<String, Object> buildTool(String name, String description,
                                                   Map<String, Object> inputSchema) {
        return Map.of(
            "name", name,
            "description", description,
            "input_schema", inputSchema
        );
    }
}
