// ============================================================
// EpisodeStore.java
// #7 情节记忆：完整执行过程记录
// 记录：用户问了什么 → 意图识别 → 调了哪些工具 → 最终回答
// 支持：用户问"我上次问了什么"、事后质量审计、行为模式分析
// ============================================================
package com.xinhe.infinityos.memory.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EpisodeStore {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;
    @Autowired private SemanticSearchService semanticSearch;

    // ── 开始记录一个情节（用户发起问题时）──────────────────
    public String startEpisode(String sessionId, String userId, String userQuery) {
        String episodeId = "EP_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        // 提取主题关键词（供后续检索）
        List<String> keywords = semanticSearch.expandKeywords(userQuery);

        try {
            jdbc.update(
                "INSERT INTO episode_memory(episode_id, session_id, user_id, user_query, " +
                "topic_keywords) VALUES(?,?,?,?,?)",
                episodeId, sessionId, userId, userQuery,
                mapper.writeValueAsString(keywords)
            );
        } catch (Exception e) {
            throw new RuntimeException("开始情节记录失败", e);
        }
        return episodeId;
    }

    // ── 更新路由信息（路由完成后）───────────────────────────
    public void updateRouting(String episodeId, String intentType, String intentAgentId,
                               double intentConfidence, String routeMode) {
        jdbc.update(
            "UPDATE episode_memory SET intent_type=?, intent_agent_id=?, " +
            "intent_confidence=?, route_mode=? WHERE episode_id=?",
            intentType, intentAgentId, intentConfidence, routeMode, episodeId
        );
    }

    // ── 添加工具调用记录（每次工具调用后）──────────────────
    public void addToolCall(String episodeId, String toolId, Map<String, Object> input,
                             Map<String, Object> output, int latencyMs) {
        try {
            // 读取现有tool_calls JSON数组
            String existing = jdbc.queryForObject(
                "SELECT tool_calls FROM episode_memory WHERE episode_id=?",
                String.class, episodeId
            );

            List<Map<String, Object>> toolCalls = existing != null
                ? mapper.readValue(existing, List.class)
                : new ArrayList<>();

            // 添加新的工具调用记录
            Map<String, Object> call = new LinkedHashMap<>();
            call.put("tool_id", toolId);
            call.put("input", input);
            call.put("output", output);
            call.put("latency_ms", latencyMs);
            call.put("called_at", System.currentTimeMillis());
            toolCalls.add(call);

            jdbc.update(
                "UPDATE episode_memory SET tool_calls=? WHERE episode_id=?",
                mapper.writeValueAsString(toolCalls), episodeId
            );
        } catch (Exception e) {
            throw new RuntimeException("记录工具调用失败", e);
        }
    }

    // ── 完成情节记录（Agent回复后）──────────────────────────
    public void completeEpisode(String episodeId, String finalAnswer,
                                 List<String> agentsInvolved, int totalDurationMs) {
        try {
            jdbc.update(
                "UPDATE episode_memory SET final_answer=?, agents_involved=?, " +
                "total_duration_ms=? WHERE episode_id=?",
                finalAnswer,
                mapper.writeValueAsString(agentsInvolved),
                totalDurationMs, episodeId
            );
        } catch (Exception e) {
            throw new RuntimeException("完成情节记录失败", e);
        }
    }

    // ── 用户评分（事后反馈）──────────────────────────────────
    public void rateEpisode(String episodeId, int rating) {
        jdbc.update(
            "UPDATE episode_memory SET answer_quality=? WHERE episode_id=?",
            rating, episodeId
        );
    }

    // ── 检索情节记忆 ─────────────────────────────────────────

    /**
     * 用户问"我上次问了什么"
     */
    public List<Map<String, Object>> getRecentEpisodes(String userId, int limit) {
        return jdbc.queryForList(
            "SELECT episode_id, user_query, intent_agent_id, route_mode, " +
            "agents_involved, final_answer, total_duration_ms, answer_quality, created_at " +
            "FROM episode_memory " +
            "WHERE user_id=? " +
            "ORDER BY created_at DESC LIMIT ?",
            userId, limit
        );
    }

    /**
     * 语义检索相关情节（"之前那个关于库存的分析"）
     */
    public List<Map<String, Object>> searchEpisodes(String userId, String topic, int limit) {
        List<String> keywords = semanticSearch.expandKeywords(topic);
        if (keywords.isEmpty()) return getRecentEpisodes(userId, limit);

        String matchExpr = String.join(" ", keywords);
        try {
            return jdbc.queryForList(
                "SELECT episode_id, user_query, intent_agent_id, agents_involved, " +
                "final_answer, answer_quality, created_at, " +
                "MATCH(user_query, final_answer) AGAINST(? IN BOOLEAN MODE) AS relevance " +
                "FROM episode_memory " +
                "WHERE user_id=? " +
                "AND MATCH(user_query, final_answer) AGAINST(? IN BOOLEAN MODE) " +
                "ORDER BY relevance DESC, created_at DESC LIMIT ?",
                matchExpr, userId, matchExpr, limit
            );
        } catch (Exception e) {
            return getRecentEpisodes(userId, limit);
        }
    }

    /**
     * 质量审计：找出回答质量差的情节（rating<=2）
     */
    public List<Map<String, Object>> getLowQualityEpisodes(int limit) {
        return jdbc.queryForList(
            "SELECT e.*, u.user_name FROM episode_memory e " +
            "LEFT JOIN user_profiles u ON e.user_id = u.user_id " +
            "WHERE e.answer_quality <= 2 AND e.answer_quality IS NOT NULL " +
            "ORDER BY e.created_at DESC LIMIT ?",
            limit
        );
    }

    /**
     * 行为分析：哪些Agent被问得最多
     */
    public List<Map<String, Object>> getAgentUsageStats(int days) {
        return jdbc.queryForList(
            "SELECT intent_agent_id, COUNT(*) AS query_count, " +
            "AVG(total_duration_ms) AS avg_duration_ms, " +
            "AVG(answer_quality) AS avg_quality " +
            "FROM episode_memory " +
            "WHERE created_at > DATE_SUB(NOW(), INTERVAL ? DAY) " +
            "AND intent_agent_id IS NOT NULL " +
            "GROUP BY intent_agent_id " +
            "ORDER BY query_count DESC",
            days
        );
    }

    /**
     * 构建"最近情节摘要"注入system prompt（#3 token预算使用）
     */
    public String buildRecentEpisodesSummary(String userId, int limit) {
        List<Map<String, Object>> episodes = getRecentEpisodes(userId, limit);
        if (episodes.isEmpty()) return null;

        StringBuilder sb = new StringBuilder("【最近" + episodes.size() + "次交互】\n");
        for (Map<String, Object> ep : episodes) {
            sb.append("- ").append(ep.get("user_query"))
              .append("（").append(ep.get("created_at")).append("）\n");
        }
        return sb.toString();
    }
}
