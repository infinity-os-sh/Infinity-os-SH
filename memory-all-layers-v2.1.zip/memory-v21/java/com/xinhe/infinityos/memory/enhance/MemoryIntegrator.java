// ============================================================
// MemoryIntegrator.java
// #5 记忆矛盾检测：新旧偏好冲突时保留高置信度
// #6 同义合并：负责区域=关注区域，自动归一化
// ============================================================
package com.xinhe.infinityos.memory.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class MemoryIntegrator {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // ── #6 同义归一化（写入前先过同义词表）─────────────────
    public String normalizeTerm(String term, String category) {
        if (term == null) return null;
        try {
            String canonical = jdbc.queryForObject(
                "SELECT canonical FROM synonym_mappings WHERE synonym=? AND category=? AND is_active=1",
                String.class, term, category
            );
            return canonical != null ? canonical : term;
        } catch (Exception e) {
            return term; // 没有同义词就原样返回
        }
    }

    /**
     * 对整段文本做同义词归一化（用于处理用户输入）
     */
    public String normalizeText(String text) {
        if (text == null) return null;
        try {
            List<Map<String, Object>> synonyms = jdbc.queryForList(
                "SELECT synonym, canonical FROM synonym_mappings WHERE is_active=1 ORDER BY LENGTH(synonym) DESC"
            );
            String result = text;
            for (Map<String, Object> s : synonyms) {
                result = result.replace(
                    String.valueOf(s.get("synonym")),
                    String.valueOf(s.get("canonical"))
                );
            }
            return result;
        } catch (Exception e) { return text; }
    }

    // ── #5 矛盾检测：写入新偏好前检查冲突 ───────────────────

    /**
     * 检测并处理偏好矛盾
     * 在 UserMemoryService.saveSessionSummary() 中调用
     *
     * @return 最终应写入的值（可能是旧值/新值/合并值）
     */
    public ConflictResolution resolvePreferenceConflict(
            String userId, String preferenceKey,
            String newValue, double newConfidence) {

        // 1. 查现有偏好
        Map<String, Object> existing = getExistingPreference(userId, preferenceKey);
        if (existing == null) {
            // 没有现有值，直接写入
            return ConflictResolution.accept(newValue, newConfidence, "首次写入");
        }

        String oldValue = String.valueOf(existing.get("new_value"));
        double oldConfidence = ((Number) existing.getOrDefault("confidence", 0.5)).doubleValue();

        // 2. 同义归一化后比较
        String normalizedNew = normalizeText(newValue);
        String normalizedOld = normalizeText(oldValue);

        // 如果归一化后相同 → 不冲突，更新置信度
        if (normalizedNew.equals(normalizedOld)) {
            double mergedConfidence = Math.min(1.0, (oldConfidence + newConfidence) / 2.0 + 0.05);
            return ConflictResolution.accept(newValue, mergedConfidence, "同义合并");
        }

        // 3. 检测矛盾类型
        ConflictType conflictType = detectConflictType(preferenceKey, oldValue, newValue);

        ConflictResolution resolution;
        switch (conflictType) {
            case DIRECT_CONTRADICTION:
                // 直接矛盾（如城市从上海变北京）：保留置信度高的
                if (newConfidence > oldConfidence + 0.1) {
                    resolution = ConflictResolution.accept(newValue, newConfidence, "新值置信度更高");
                } else if (oldConfidence > newConfidence + 0.1) {
                    resolution = ConflictResolution.reject(oldValue, oldConfidence, "旧值置信度更高");
                } else {
                    // 置信度相近：合并（列表类）或取新值（单值类）
                    resolution = isMergeableType(preferenceKey)
                        ? ConflictResolution.merge(mergeValues(oldValue, newValue),
                            Math.max(oldConfidence, newConfidence), "列表合并")
                        : ConflictResolution.accept(newValue, newConfidence, "取最新值");
                }
                break;

            case ADDITIVE:
                // 追加类（用户新增了一个关注城市）
                resolution = ConflictResolution.merge(
                    mergeValues(oldValue, newValue),
                    Math.max(oldConfidence, newConfidence), "追加合并"
                );
                break;

            default:
                resolution = ConflictResolution.accept(newValue, newConfidence, "默认接受");
        }

        // 4. 记录冲突处理过程
        logConflict(userId, preferenceKey, oldValue, newValue,
            oldConfidence, newConfidence, resolution.getResolutionType());

        return resolution;
    }

    // ── 冲突类型识别 ─────────────────────────────────────────
    private ConflictType detectConflictType(String key, String oldVal, String newVal) {
        // 城市/区域类：单值替换 = 直接矛盾
        if (key.contains("city") || key.contains("area") || key.contains("region")) {
            return ConflictType.DIRECT_CONTRADICTION;
        }
        // 列表类偏好：追加
        if (key.contains("preferred_") || key.contains("_list")) {
            return ConflictType.ADDITIVE;
        }
        return ConflictType.DIRECT_CONTRADICTION;
    }

    private boolean isMergeableType(String key) {
        return key.startsWith("preferred_") || key.contains("_list");
    }

    @SuppressWarnings("unchecked")
    private String mergeValues(String oldVal, String newVal) {
        try {
            // 尝试作为JSON数组合并
            List<String> oldList = mapper.readValue(oldVal, List.class);
            List<String> newList = mapper.readValue(newVal, List.class);
            Set<String> merged = new LinkedHashSet<>(oldList);
            merged.addAll(newList);
            // 最多保留10个
            List<String> result = new ArrayList<>(merged);
            if (result.size() > 10) result = result.subList(result.size() - 10, result.size());
            return mapper.writeValueAsString(result);
        } catch (Exception e) {
            // 不是JSON，字符串合并
            return oldVal.equals(newVal) ? oldVal : oldVal + "," + newVal;
        }
    }

    // ── 工具方法 ─────────────────────────────────────────────
    private Map<String, Object> getExistingPreference(String userId, String preferenceKey) {
        try {
            return jdbc.queryForMap(
                "SELECT new_value, confidence FROM user_preference_learning " +
                "WHERE user_id=? AND preference_key=? ORDER BY id DESC LIMIT 1",
                userId, preferenceKey
            );
        } catch (Exception e) { return null; }
    }

    private void logConflict(String userId, String key, String oldVal, String newVal,
                              double oldConf, double newConf, String resolution) {
        jdbc.update(
            "INSERT INTO preference_conflicts(user_id, preference_key, old_value, new_value, " +
            "old_confidence, new_confidence, resolution) VALUES(?,?,?,?,?,?,?)",
            userId, key, oldVal, newVal, oldConf, newConf, resolution
        );
    }

    // ── 内部数据结构 ─────────────────────────────────────────
    public enum ConflictType { DIRECT_CONTRADICTION, ADDITIVE, NO_CONFLICT }

    public static class ConflictResolution {
        private final String finalValue;
        private final double finalConfidence;
        private final String reason;
        private final String resolutionType; // keep_old/keep_new/merge

        private ConflictResolution(String v, double c, String r, String t) {
            finalValue = v; finalConfidence = c; reason = r; resolutionType = t;
        }
        public static ConflictResolution accept(String v, double c, String r) {
            return new ConflictResolution(v, c, r, "keep_new");
        }
        public static ConflictResolution reject(String v, double c, String r) {
            return new ConflictResolution(v, c, r, "keep_old");
        }
        public static ConflictResolution merge(String v, double c, String r) {
            return new ConflictResolution(v, c, r, "merge");
        }
        public String getFinalValue() { return finalValue; }
        public double getFinalConfidence() { return finalConfidence; }
        public String getReason() { return reason; }
        public String getResolutionType() { return resolutionType; }
    }
}
