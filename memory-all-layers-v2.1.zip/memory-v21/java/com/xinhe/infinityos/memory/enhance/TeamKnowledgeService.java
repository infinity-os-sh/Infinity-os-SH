// ============================================================
// TeamKnowledgeService.java
// #8 团队知识库：人→人共享，审批流程
// #9 upvote机制：投票确认可靠性
// 注意：与D代码层面三SharedMemoryService职责区分
//   SharedMemoryService = Agent→Agent实时协作总线
//   TeamKnowledgeService = 人→人知识沉淀（经审批）
// ============================================================
package com.xinhe.infinityos.memory.enhance;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class TeamKnowledgeService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;
    @Autowired private SemanticSearchService semanticSearch;

    // ── #8 提交知识（用户发现→进入待审批） ──────────────────
    public String submitKnowledge(String userId, String title, String content,
                                   String knowledgeType, String scope, String scopeId,
                                   List<String> tags, String sourceEpisodeId) {
        String knowledgeId = "KN_" + System.currentTimeMillis() + "_" +
            UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        try {
            jdbc.update(
                "INSERT INTO team_knowledge(knowledge_id, title, content, knowledge_type, " +
                "scope, scope_id, created_by, source_episode, status, tags) " +
                "VALUES(?,?,?,?,?,?,?,?,?,?)",
                knowledgeId, title, content, knowledgeType,
                scope, scopeId, userId, sourceEpisodeId,
                "pending",  // 默认进入待审批状态
                mapper.writeValueAsString(tags)
            );
        } catch (Exception e) {
            throw new RuntimeException("提交知识失败", e);
        }

        // 通知管理员有待审批的知识
        // wechatService.pushToRole("knowledge_approver", "有新知识待审批：" + title);

        return knowledgeId;
    }

    /**
     * 快速提交（低风险知识，创建者可自批）
     * 适用于：数据发现类（finding）、低影响范围的洞察
     */
    public String submitAndApprove(String userId, String title, String content,
                                    String knowledgeType, String scope, String scopeId,
                                    List<String> tags) {
        String knowledgeId = submitKnowledge(userId, title, content, knowledgeType,
            scope, scopeId, tags, null);
        approve(knowledgeId, userId); // 自批
        return knowledgeId;
    }

    // ── 审批流程 ─────────────────────────────────────────────
    public void approve(String knowledgeId, String approvedBy) {
        jdbc.update(
            "UPDATE team_knowledge SET status='approved', approved_by=?, approved_at=NOW() " +
            "WHERE knowledge_id=?",
            approvedBy, knowledgeId
        );
    }

    public void reject(String knowledgeId, String rejectedBy, String reason) {
        jdbc.update(
            "UPDATE team_knowledge SET status='rejected', approved_by=?, " +
            "reject_reason=? WHERE knowledge_id=?",
            rejectedBy, reason, knowledgeId
        );
    }

    // ── #9 upvote机制 ────────────────────────────────────────
    public void vote(String knowledgeId, String userId, boolean isUpvote) {
        String voteType = isUpvote ? "up" : "down";

        // 检查是否已经投过票
        try {
            Map<String, Object> existing = jdbc.queryForMap(
                "SELECT id, vote_type FROM team_knowledge_votes " +
                "WHERE knowledge_id=? AND user_id=?",
                knowledgeId, userId
            );

            if (String.valueOf(existing.get("vote_type")).equals(voteType)) {
                // 重复投同类票 → 取消
                jdbc.update(
                    "DELETE FROM team_knowledge_votes WHERE knowledge_id=? AND user_id=?",
                    knowledgeId, userId
                );
                if (isUpvote) {
                    jdbc.update("UPDATE team_knowledge SET upvote_count=upvote_count-1 WHERE knowledge_id=?", knowledgeId);
                } else {
                    jdbc.update("UPDATE team_knowledge SET downvote_count=downvote_count-1 WHERE knowledge_id=?", knowledgeId);
                }
            } else {
                // 改变投票方向
                jdbc.update(
                    "UPDATE team_knowledge_votes SET vote_type=? WHERE knowledge_id=? AND user_id=?",
                    voteType, knowledgeId, userId
                );
                if (isUpvote) {
                    jdbc.update("UPDATE team_knowledge SET upvote_count=upvote_count+1, downvote_count=downvote_count-1 WHERE knowledge_id=?", knowledgeId);
                } else {
                    jdbc.update("UPDATE team_knowledge SET upvote_count=upvote_count-1, downvote_count=downvote_count+1 WHERE knowledge_id=?", knowledgeId);
                }
            }
        } catch (Exception e) {
            // 首次投票
            jdbc.update(
                "INSERT INTO team_knowledge_votes(knowledge_id, user_id, vote_type) VALUES(?,?,?)",
                knowledgeId, userId, voteType
            );
            if (isUpvote) {
                jdbc.update("UPDATE team_knowledge SET upvote_count=upvote_count+1 WHERE knowledge_id=?", knowledgeId);
            } else {
                jdbc.update("UPDATE team_knowledge SET downvote_count=downvote_count+1 WHERE knowledge_id=?", knowledgeId);
            }
        }

        // upvote>=5 且 downvote==0 → 自动提升为"优质知识"（pin到顶部）
        checkAutoPromotion(knowledgeId);
    }

    // ── 检索团队知识 ─────────────────────────────────────────

    /**
     * 语义检索（注入到system prompt使用）
     */
    public List<Map<String, Object>> searchKnowledge(String topic, String scope,
                                                      String scopeId, int limit) {
        return semanticSearch.searchTeamKnowledge(topic, scope, scopeId, limit);
    }

    /**
     * 获取最新+最热门的团队知识（用于首页展示）
     */
    public List<Map<String, Object>> getHighlightKnowledge(String scope, int limit) {
        return jdbc.queryForList(
            "SELECT knowledge_id, title, content, knowledge_type, scope, " +
            "created_by, upvote_count, reliability, created_at " +
            "FROM team_knowledge " +
            "WHERE status='approved' AND is_active=1 " +
            (scope != null ? "AND (scope=? OR scope='global') " : "") +
            "ORDER BY upvote_count DESC, created_at DESC LIMIT ?",
            scope != null ? new Object[]{scope, limit} : new Object[]{limit}
        );
    }

    /**
     * 获取待审批列表（给知识管理员）
     */
    public List<Map<String, Object>> getPendingApprovals() {
        return jdbc.queryForList(
            "SELECT k.*, u.user_name as submitter_name " +
            "FROM team_knowledge k " +
            "LEFT JOIN user_profiles u ON k.created_by = u.user_id " +
            "WHERE k.status='pending' ORDER BY k.created_at ASC"
        );
    }

    /**
     * 构建team knowledge摘要注入prompt（供MemoryOrchestrator使用）
     */
    public String buildKnowledgePromptSection(String topic, String scope, int tokenBudget) {
        List<Map<String, Object>> knowledge = searchKnowledge(topic, scope, null, 3);
        if (knowledge.isEmpty()) return null;

        StringBuilder sb = new StringBuilder("【团队知识库】\n");
        int usedChars = 0;
        int charBudget = tokenBudget * 2; // 粗略估算：1token≈2中文字符

        for (Map<String, Object> k : knowledge) {
            String entry = "- [" + k.get("knowledge_type") + "] " +
                k.get("title") + "：" + k.get("content") + "\n";
            if (usedChars + entry.length() > charBudget) break;
            sb.append(entry);
            usedChars += entry.length();
        }
        return sb.toString();
    }

    // ── 定时任务：清理过期知识 ───────────────────────────────
    @Scheduled(cron = "0 0 3 * * *")
    public void cleanupExpiredKnowledge() {
        int deactivated = jdbc.update(
            "UPDATE team_knowledge SET is_active=0 " +
            "WHERE is_active=1 AND expires_at IS NOT NULL AND expires_at < NOW()"
        );
        // 低质量知识（downvote > upvote * 2 且 downvote >= 3）自动下架
        int lowQuality = jdbc.update(
            "UPDATE team_knowledge SET is_active=0 " +
            "WHERE is_active=1 AND status='approved' " +
            "AND downvote_count >= 3 AND downvote_count > upvote_count * 2"
        );
    }

    // ── 工具方法 ─────────────────────────────────────────────
    private void checkAutoPromotion(String knowledgeId) {
        try {
            Map<String, Object> k = jdbc.queryForMap(
                "SELECT upvote_count, downvote_count FROM team_knowledge WHERE knowledge_id=?",
                knowledgeId
            );
            int upvotes = ((Number) k.get("upvote_count")).intValue();
            int downvotes = ((Number) k.get("downvote_count")).intValue();
            // upvote>=5 且 downvote==0 → 标记为featured
            if (upvotes >= 5 && downvotes == 0) {
                jdbc.update(
                    "UPDATE team_knowledge SET knowledge_type='insight' WHERE knowledge_id=? AND knowledge_type='finding'",
                    knowledgeId
                );
            }
        } catch (Exception ignored) {}
    }
}
