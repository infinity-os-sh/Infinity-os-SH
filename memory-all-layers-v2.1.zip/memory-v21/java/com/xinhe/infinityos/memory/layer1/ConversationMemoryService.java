// ============================================================
// ConversationMemoryService.java  (v2·增强版)
// #1 LLM对话压缩：真实调用Claude API替换桩实现
// 原v1的桩：triggerSnapshot() 写死 "[待实现...]"
// v2：构建压缩prompt → 调用Claude API → 写入真实摘要
// ============================================================
package com.xinhe.infinityos.memory.layer1;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

@Service
public class ConversationMemoryService {

    private static final int MAX_REDIS_TURNS = 20;
    private static final int SNAPSHOT_EVERY  = 10;
    private static final Duration SESSION_TTL = Duration.ofHours(24);

    @Value("${anthropic.api.key}")
    private String anthropicApiKey;

    @Value("${anthropic.api.model:claude-sonnet-4-20250514}")
    private String claudeModel;

    @Autowired private RedisTemplate<String, String> redisTemplate;
    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    private final HttpClient httpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10))
        .build();

    // ── 开始新会话 ───────────────────────────────────────────
    public String startSession(String userId, String agentId) {
        String sessionId = UUID.randomUUID().toString().replace("-", "");
        jdbc.update(
            "INSERT INTO conv_sessions(session_id, user_id, agent_id) VALUES(?,?,?)",
            sessionId, userId, agentId
        );
        String metaKey = "conv:" + sessionId + ":meta";
        Map<String, String> meta = Map.of(
            "userId", userId,
            "agentId", agentId != null ? agentId : "brain",
            "turnCount", "0"
        );
        redisTemplate.opsForHash().putAll(metaKey, meta);
        redisTemplate.expire(metaKey, SESSION_TTL);
        return sessionId;
    }

    // ── 添加轮次 ─────────────────────────────────────────────
    public void addTurn(String sessionId, String role, String content) {
        String metaKey = "conv:" + sessionId + ":meta";
        String turnCountStr = (String) redisTemplate.opsForHash().get(metaKey, "turnCount");
        int turnIndex = turnCountStr != null ? Integer.parseInt(turnCountStr) + 1 : 1;

        Map<String, Object> turn = Map.of(
            "role", role, "content", content,
            "turnIndex", turnIndex, "timestamp", System.currentTimeMillis()
        );
        String turnsKey = "conv:" + sessionId + ":turns";
        try {
            redisTemplate.opsForList().rightPush(turnsKey, mapper.writeValueAsString(turn));
            Long size = redisTemplate.opsForList().size(turnsKey);
            if (size != null && size > MAX_REDIS_TURNS)
                redisTemplate.opsForList().leftPop(turnsKey);
            redisTemplate.expire(turnsKey, SESSION_TTL);
        } catch (Exception e) {
            throw new RuntimeException("Redis写入失败", e);
        }
        redisTemplate.opsForHash().put(metaKey, "turnCount", String.valueOf(turnIndex));
        redisTemplate.expire(metaKey, SESSION_TTL);

        persistTurnAsync(sessionId, turnIndex, role, content);

        // 每10轮触发一次真实LLM压缩
        if (turnIndex % SNAPSHOT_EVERY == 0 && "assistant".equals(role)) {
            triggerSnapshot(sessionId, turnIndex);
        }
    }

    // ── 获取上下文 ───────────────────────────────────────────
    public List<Map<String, String>> getContextMessages(String sessionId) {
        List<Map<String, String>> messages = new ArrayList<>();

        // 注入真实LLM摘要（而非v1的占位文本）
        String latestSnapshot = getLatestSnapshot(sessionId);
        if (latestSnapshot != null && !latestSnapshot.startsWith("[待实现")) {
            messages.add(Map.of("role", "user",
                "content", "【之前对话摘要·请作为背景知识】\n" + latestSnapshot));
            messages.add(Map.of("role", "assistant",
                "content", "已了解之前对话背景，请继续。"));
        }

        String turnsKey = "conv:" + sessionId + ":turns";
        List<String> rawTurns = redisTemplate.opsForList().range(turnsKey, 0, -1);
        if (rawTurns != null) {
            for (String raw : rawTurns) {
                try {
                    Map<?, ?> t = mapper.readValue(raw, Map.class);
                    messages.add(Map.of(
                        "role", String.valueOf(t.get("role")),
                        "content", String.valueOf(t.get("content"))
                    ));
                } catch (Exception ignored) {}
            }
        }
        return messages;
    }

    // ── #1 核心：真实LLM压缩（替换v1桩实现）────────────────
    private void triggerSnapshot(String sessionId, int upToTurn) {
        // 获取需要压缩的历史轮次
        List<Map<String, Object>> turns = jdbc.queryForList(
            "SELECT role, content, turn_index FROM conv_turns " +
            "WHERE session_id=? AND turn_index <= ? ORDER BY turn_index",
            sessionId, upToTurn - SNAPSHOT_EVERY
        );
        if (turns.isEmpty()) return;

        // 构建压缩对话文本
        StringBuilder dialogText = new StringBuilder();
        for (Map<String, Object> t : turns) {
            String role = "user".equals(t.get("role")) ? "用户" : "AI";
            dialogText.append(role).append(": ").append(t.get("content")).append("\n");
        }

        // 调用Claude API生成真实摘要
        String summary = callClaudeForSummary(dialogText.toString());
        List<String> topics = extractTopics(summary);

        // 写入数据库
        jdbc.update(
            "INSERT INTO conv_snapshots(session_id, snapshot_at, summary, key_topics, compress_mode) " +
            "VALUES(?,?,?,?,?) " +
            "ON DUPLICATE KEY UPDATE summary=VALUES(summary), key_topics=VALUES(key_topics)",
            sessionId, upToTurn, summary,
            safeJson(topics), "llm"
        );

        // 同步更新conv_sessions的context_summary
        jdbc.update(
            "UPDATE conv_sessions SET context_summary=? WHERE session_id=?",
            summary, sessionId
        );
    }

    /**
     * #1 核心实现：调用Claude API压缩对话历史
     * v1是桩，v2是真实调用
     */
    private String callClaudeForSummary(String dialogText) {
        String systemPrompt =
            "你是一个对话压缩助手。请将以下对话历史压缩为3-5句话的摘要，" +
            "重点保留：用户关注的核心问题、提到的关键实体（门店/城市/品牌/指标）、" +
            "AI给出的关键结论或建议。用中文输出，不超过200字。";

        String userPrompt = "请压缩以下对话：\n\n" + dialogText;

        try {
            Map<String, Object> requestBody = Map.of(
                "model", claudeModel,
                "max_tokens", 400,
                "system", systemPrompt,
                "messages", List.of(Map.of("role", "user", "content", userPrompt))
            );

            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://api.anthropic.com/v1/messages"))
                .header("Content-Type", "application/json")
                .header("x-api-key", anthropicApiKey)
                .header("anthropic-version", "2023-06-01")
                .timeout(Duration.ofSeconds(30))
                .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(requestBody)))
                .build();

            HttpResponse<String> response = httpClient.send(request,
                HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                Map<?, ?> resp = mapper.readValue(response.body(), Map.class);
                List<?> content = (List<?>) resp.get("content");
                if (content != null && !content.isEmpty()) {
                    Map<?, ?> firstBlock = (Map<?, ?>) content.get(0);
                    return String.valueOf(firstBlock.get("text"));
                }
            }
        } catch (Exception e) {
            // 降级：截取最后500字作为摘要
            String fallback = dialogText.length() > 500
                ? "【自动截取】" + dialogText.substring(dialogText.length() - 500)
                : dialogText;
            return fallback;
        }
        return "对话摘要生成失败，请查看原始记录。";
    }

    // ── 工具方法 ─────────────────────────────────────────────
    private String getLatestSnapshot(String sessionId) {
        try {
            return jdbc.queryForObject(
                "SELECT summary FROM conv_snapshots WHERE session_id=? ORDER BY snapshot_at DESC LIMIT 1",
                String.class, sessionId
            );
        } catch (Exception e) { return null; }
    }

    private List<String> extractTopics(String summary) {
        // 简单关键词提取（实际项目可用NLP）
        List<String> topics = new ArrayList<>();
        String[] keywords = {"上海","北京","成都","库存","补货","经销商","S+","六月鲜","r值","水位"};
        for (String kw : keywords) {
            if (summary.contains(kw)) topics.add(kw);
        }
        return topics;
    }

    private void persistTurnAsync(String sessionId, int turnIndex, String role, String content) {
        jdbc.update(
            "INSERT INTO conv_turns(session_id, turn_index, role, content) VALUES(?,?,?,?)",
            sessionId, turnIndex, role, content
        );
        jdbc.update(
            "UPDATE conv_sessions SET turn_count=?, last_active_at=NOW() WHERE session_id=?",
            turnIndex, sessionId
        );
    }

    private String safeJson(Object obj) {
        try { return mapper.writeValueAsString(obj); } catch (Exception e) { return "[]"; }
    }

    public void endSession(String sessionId) {
        jdbc.update("UPDATE conv_sessions SET is_active=0 WHERE session_id=?", sessionId);
    }

    public int cleanupExpiredSessions() {
        return jdbc.update(
            "UPDATE conv_sessions SET is_active=0 " +
            "WHERE is_active=1 AND last_active_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
        );
    }
}
