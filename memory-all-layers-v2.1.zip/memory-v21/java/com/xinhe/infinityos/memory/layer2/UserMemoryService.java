// ============================================================
// UserMemoryService.java  (v2.1·修复版)
// 修复遗漏2：updatePreferencesFromSession() 接入 MemoryIntegrator
// 写入偏好前先过矛盾检测 + 同义归一化
// ============================================================
package com.xinhe.infinityos.memory.layer2;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xinhe.infinityos.memory.enhance.MemoryIntegrator;
import com.xinhe.infinityos.memory.enhance.MemoryIntegrator.ConflictResolution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserMemoryService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;
    @Autowired private MemoryIntegrator integrator;   // ← v2.1新增注入

    // ── 用户登录时：构建个性化上下文 ────────────────────────
    public String buildUserContextPrompt(String userId) {
        Map<String, Object> profile = getUserProfile(userId);
        if (profile == null) {
            initUserProfile(userId);
            return "这是该用户第一次使用INFINITY OS。";
        }

        StringBuilder ctx = new StringBuilder();
        ctx.append("【用户上下文】\n");
        ctx.append("用户身份：").append(profile.getOrDefault("user_name", "未知")).append("\n");
        ctx.append("角色：").append(profile.getOrDefault("role", "manager")).append("\n");

        Object cities = profile.get("preferred_cities");
        if (cities != null) ctx.append("重点关注城市：").append(cities).append("\n");

        Object brands = profile.get("preferred_brands");
        if (brands != null) ctx.append("主要负责品牌：").append(brands).append("\n");

        List<String> recentConclusions = getRecentConclusions(userId, 3);
        if (!recentConclusions.isEmpty()) {
            ctx.append("近期关注的问题：\n");
            recentConclusions.forEach(c -> ctx.append("  - ").append(c).append("\n"));
        }

        List<Map<String, Object>> watches = getActiveWatches(userId);
        if (!watches.isEmpty()) {
            ctx.append("持续跟踪中（").append(watches.size()).append("项）：");
            watches.forEach(w -> ctx.append(w.get("entity_name")).append("·"));
            ctx.append("\n");
        }

        return ctx.toString();
    }

    // ── 会话结束时：提取并保存摘要 ──────────────────────────
    public void saveSessionSummary(String userId, String sessionId,
                                   String summary, List<String> topics,
                                   List<String> cities, List<String> stores) {
        try {
            jdbc.update(
                "INSERT INTO user_query_history(user_id, session_id, session_date, " +
                "main_topics, queried_cities, queried_stores, key_conclusions) " +
                "VALUES(?,?,CURDATE(),?,?,?,?)",
                userId, sessionId,
                mapper.writeValueAsString(topics),
                mapper.writeValueAsString(cities),
                mapper.writeValueAsString(stores),
                summary
            );
            jdbc.update(
                "UPDATE user_profiles SET total_sessions=total_sessions+1, " +
                "last_login_at=NOW() WHERE user_id=?", userId
            );
            // ── 修复遗漏2：通过MemoryIntegrator写偏好 ────────
            updatePreferencesFromSession(userId, cities, topics);

        } catch (Exception e) {
            throw new RuntimeException("保存会话摘要失败", e);
        }
    }

    // ── 关注项管理 ───────────────────────────────────────────
    public Long addWatchItem(String userId, String watchType, String entityId,
                              String entityName, String reason,
                              Map<String, Object> alertThreshold) {
        try {
            jdbc.update(
                "INSERT INTO user_watchlist(user_id, watch_type, entity_id, entity_name, " +
                "watch_reason, alert_threshold) VALUES(?,?,?,?,?,?)",
                userId, watchType, entityId, entityName, reason,
                mapper.writeValueAsString(alertThreshold)
            );
            return jdbc.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
        } catch (Exception e) {
            throw new RuntimeException("添加关注项失败", e);
        }
    }

    public List<Map<String, Object>> checkWatchlistAlerts(String userId) {
        return jdbc.queryForList(
            "SELECT w.*, p.current_status " +
            "FROM user_watchlist w " +
            "LEFT JOIN agent_memory_profiles p ON w.entity_id = p.agent_id " +
            "WHERE w.user_id=? AND w.is_active=1 " +
            "AND (w.last_triggered_at IS NULL " +
            "  OR w.last_triggered_at < DATE_SUB(NOW(), INTERVAL 1 DAY))",
            userId
        );
    }

    // ── 修复遗漏2：接入MemoryIntegrator的偏好更新 ───────────
    /**
     * v1：直接做Set.addAll，不检测矛盾，不归一化同义词
     * v2.1：先同义归一化 → 矛盾检测 → 按解决结果写入
     */
    private void updatePreferencesFromSession(String userId,
                                               List<String> cities,
                                               List<String> topics) {
        if (cities != null && !cities.isEmpty()) {
            updateSinglePreference(userId, "preferred_cities",
                serializeList(cities), 0.75);
        }
        List<String> brands = extractBrands(topics);
        if (!brands.isEmpty()) {
            updateSinglePreference(userId, "preferred_brands",
                serializeList(brands), 0.70);
        }
        List<String> metrics = extractMetrics(topics);
        if (!metrics.isEmpty()) {
            updateSinglePreference(userId, "preferred_metrics",
                serializeList(metrics), 0.65);
        }
    }

    /**
     * 单个偏好写入：同义归一化 → 矛盾检测 → 写入
     */
    private void updateSinglePreference(String userId, String preferenceKey,
                                         String newValue, double confidence) {
        // Step1：同义归一化（#6）
        String normalizedValue = integrator.normalizeText(newValue);

        // Step2：矛盾检测（#5）——这是v1完全缺失的步骤
        ConflictResolution resolution = integrator.resolvePreferenceConflict(
            userId, preferenceKey, normalizedValue, confidence
        );

        // Step3：旧值置信度更高时不更新
        if ("keep_old".equals(resolution.getResolutionType())) return;

        // Step4：写入user_profiles对应字段
        updateUserProfileField(userId, preferenceKey, resolution.getFinalValue());

        // Step5：写入preference_learning日志
        try {
            jdbc.update(
                "INSERT INTO user_preference_learning(user_id, preference_key, " +
                "new_value, confidence, learned_from) VALUES(?,?,?,?,?) " +
                "ON DUPLICATE KEY UPDATE new_value=VALUES(new_value), " +
                "confidence=VALUES(confidence)",
                userId, preferenceKey,
                resolution.getFinalValue(),
                resolution.getFinalConfidence(),
                "session:" + resolution.getReason()
            );
        } catch (Exception ignored) {}
    }

    private void updateUserProfileField(String userId, String field, String value) {
        String column = switch (field) {
            case "preferred_cities"  -> "preferred_cities";
            case "preferred_brands"  -> "preferred_brands";
            case "preferred_metrics" -> "preferred_metrics";
            default -> null;
        };
        if (column == null) return;
        jdbc.update(
            "UPDATE user_profiles SET " + column + "=? WHERE user_id=?",
            value, userId
        );
    }

    // ── 辅助提取 ─────────────────────────────────────────────
    private List<String> extractBrands(List<String> topics) {
        if (topics == null) return Collections.emptyList();
        List<String> brands = new ArrayList<>();
        String[] known = {"六月鲜","味达美","禾然","葱伴侣","小康"};
        for (String topic : topics)
            for (String b : known)
                if (topic.contains(b) && !brands.contains(b)) brands.add(b);
        return brands;
    }

    private List<String> extractMetrics(List<String> topics) {
        if (topics == null) return Collections.emptyList();
        List<String> metrics = new ArrayList<>();
        String[] known = {"r值","库存水位","铺货率","动销率","心跳单元","日销率"};
        for (String topic : topics)
            for (String m : known)
                if (topic.contains(m) && !metrics.contains(m)) metrics.add(m);
        return metrics;
    }

    private String serializeList(List<String> list) {
        try { return mapper.writeValueAsString(list); }
        catch (Exception e) { return "[]"; }
    }

    // ── 内部查询 ─────────────────────────────────────────────
    private Map<String, Object> getUserProfile(String userId) {
        try {
            return jdbc.queryForMap("SELECT * FROM v_user_context WHERE user_id=?", userId);
        } catch (Exception e) { return null; }
    }

    private void initUserProfile(String userId) {
        jdbc.update(
            "INSERT IGNORE INTO user_profiles(user_id, user_name, role) VALUES(?,?,?)",
            userId, userId, "manager"
        );
    }

    private List<String> getRecentConclusions(String userId, int limit) {
        try {
            return jdbc.queryForList(
                "SELECT key_conclusions FROM user_query_history " +
                "WHERE user_id=? AND key_conclusions IS NOT NULL AND archived=0 " +
                "ORDER BY session_date DESC LIMIT ?",
                String.class, userId, limit
            );
        } catch (Exception e) { return Collections.emptyList(); }
    }

    private List<Map<String, Object>> getActiveWatches(String userId) {
        return jdbc.queryForList(
            "SELECT * FROM user_watchlist WHERE user_id=? AND is_active=1 " +
            "ORDER BY created_at DESC LIMIT 5", userId
        );
    }
}
