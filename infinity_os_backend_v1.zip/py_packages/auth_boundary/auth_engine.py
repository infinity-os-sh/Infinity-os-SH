# ============================================================
# auth_engine.py  ·  INFINITY OS 授权边界引擎 (Python版)
# 替代: AuthorizationEngine.java
# 框架: FastAPI + SQLAlchemy + Pydantic
# ============================================================

from fastapi import FastAPI, HTTPException, Depends
from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, Boolean, Text
from sqlalchemy.orm import declarative_base, Session, sessionmaker
from pydantic import BaseModel
from datetime import datetime
from typing import Optional
import os, json

# ── 数据库连接 ─────────────────────────────────────────────
DATABASE_URL = os.getenv("DATABASE_URL", "mysql+pymysql://root:password@localhost:3306/infinity_os")
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

# ── 数据模型 ──────────────────────────────────────────────
class UserRole(Base):
    __tablename__ = "auth_user_roles"
    id          = Column(Integer, primary_key=True, autoincrement=True)
    user_id     = Column(String(50), nullable=False)
    role        = Column(String(30), nullable=False)   # mgmt/dom/dsr/ba/dist/brand/member
    scope_type  = Column(String(20), nullable=False)   # national/region/city/district/self
    scope_id    = Column(String(100), nullable=False)  # ALL/上海/浦东/dist_bc/U001
    partner_level = Column(String(20), default='standard')  # standard/deep
    is_active   = Column(Boolean, default=True)
    created_at  = Column(DateTime, default=datetime.now)

class AuthOperationRule(Base):
    __tablename__ = "auth_operation_rules"
    id              = Column(Integer, primary_key=True, autoincrement=True)
    operation_type  = Column(String(50), nullable=False)
    hard_blocked    = Column(Boolean, default=False)
    min_level       = Column(Integer, default=0)  # 0=自主 1=主管 2=总监 3=人工
    description     = Column(String(200))

class AuthLog(Base):
    __tablename__ = "auth_logs"
    id              = Column(Integer, primary_key=True, autoincrement=True)
    user_id         = Column(String(50))
    operation_type  = Column(String(50))
    entity_id       = Column(String(100))
    decision        = Column(String(20))  # ALLOW/DENY/APPROVE_REQUIRED
    reason          = Column(Text)
    created_at      = Column(DateTime, default=datetime.now)

# ── Pydantic模型 ──────────────────────────────────────────
class AuthRequest(BaseModel):
    user_id:        str
    operation_type: str
    entity_id:      str
    amount:         float = 0.0
    confidence:     float = 1.0

class AuthResponse(BaseModel):
    can_execute:    bool
    decision:       str  # ALLOW / DENY / APPROVE_REQUIRED
    reason:         str
    required_level: int = 0  # 0=自主 1=主管审批 2=总监审批 3=人工必须
    user_role:      str = ""
    partner_level:  str = ""

class UserInfo(BaseModel):
    user_id:        str
    role:           str
    scope_type:     str
    scope_id:       str
    partner_level:  str

# ── DB依赖 ────────────────────────────────────────────────
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ── 核心授权引擎 ──────────────────────────────────────────
class AuthorizationEngine:

    # 角色默认权限配置
    ROLE_PERMISSIONS = {
        "mgmt":   {"data_scope": "national", "max_auto_amount": 999999},
        "dom":    {"data_scope": "city",     "max_auto_amount": 50000},
        "dsr":    {"data_scope": "district", "max_auto_amount": 0},
        "ba":     {"data_scope": "self",     "max_auto_amount": 0},
        "dist":   {"data_scope": "region",   "max_auto_amount": 30000},
        "brand":  {"data_scope": "national", "max_auto_amount": 0},
        "member": {"data_scope": "self",     "max_auto_amount": 0},
    }

    # 深度合伙人额外权限
    DEEP_PARTNER_BONUS = {
        "dist": {"max_auto_amount": 50000, "autonomy_boost": 1.5},
    }

    # 硬性禁止操作（任何角色都不能自主执行）
    HARD_BLOCKED_OPS = {
        "delete_user", "modify_contract", "override_iron_law",
        "access_other_region_data", "modify_price_below_floor"
    }

    # 金额分级审批阈值
    AMOUNT_LEVELS = [
        (10000,  0),   # <1万 → 自主
        (50000,  1),   # <5万 → 主管
        (200000, 2),   # <20万 → 总监
        (999999, 3),   # >20万 → 人工
    ]

    def evaluate(self, req: AuthRequest, user_role: UserRole) -> AuthResponse:
        role = user_role.role
        partner = user_role.partner_level

        # ① 硬性禁止
        if req.operation_type in self.HARD_BLOCKED_OPS:
            return AuthResponse(
                can_execute=False,
                decision="DENY",
                reason=f"操作类型 {req.operation_type} 硬性禁止，任何角色不可执行",
                required_level=3
            )

        # ② 数据范围检查
        if not self._check_scope(req.entity_id, user_role):
            return AuthResponse(
                can_execute=False,
                decision="DENY",
                reason=f"越权访问：{role} 无权访问 {req.entity_id}",
                required_level=3,
                user_role=role
            )

        # ③ 金额分级
        amount_level = self._get_amount_level(req.amount, role, partner)

        # ④ 置信度检查（低于70%降一级）
        if req.confidence < 0.7:
            amount_level = min(amount_level + 1, 3)

        # ⑤ 深度合伙人加成
        if partner == "deep" and role in self.DEEP_PARTNER_BONUS:
            bonus = self.DEEP_PARTNER_BONUS[role]
            if req.amount <= bonus["max_auto_amount"]:
                amount_level = max(amount_level - 1, 0)

        # ⑥ 输出决策
        if amount_level == 0:
            return AuthResponse(
                can_execute=True,
                decision="ALLOW",
                reason="自主权限范围内，可直接执行",
                required_level=0,
                user_role=role,
                partner_level=partner
            )
        elif amount_level <= 2:
            return AuthResponse(
                can_execute=False,
                decision="APPROVE_REQUIRED",
                reason=f"金额¥{req.amount:,.0f}超出自主上限，需要{'主管' if amount_level==1 else '总监'}审批",
                required_level=amount_level,
                user_role=role,
                partner_level=partner
            )
        else:
            return AuthResponse(
                can_execute=False,
                decision="APPROVE_REQUIRED",
                reason="需要人工介入审批",
                required_level=3,
                user_role=role,
                partner_level=partner
            )

    def _check_scope(self, entity_id: str, user_role: UserRole) -> bool:
        if user_role.scope_type == "national":
            return True
        if user_role.scope_type == "self":
            return entity_id == user_role.user_id
        # 简化：其他scope检查entity_id是否包含scope_id关键词
        return user_role.scope_id in entity_id or entity_id.startswith(user_role.scope_id)

    def _get_amount_level(self, amount: float, role: str, partner: str) -> int:
        role_cfg = self.ROLE_PERMISSIONS.get(role, {})
        max_auto = role_cfg.get("max_auto_amount", 0)
        if amount <= max_auto:
            return 0
        for threshold, level in self.AMOUNT_LEVELS:
            if amount <= threshold:
                return level
        return 3


# ── FastAPI 应用 ───────────────────────────────────────────
app = FastAPI(title="INFINITY OS · 授权边界系统", version="1.0.0")
auth_engine = AuthorizationEngine()

@app.get("/api/auth/user/{user_id}", response_model=UserInfo)
def get_user_info(user_id: str, token: str = "", db: Session = Depends(get_db)):
    """SFA登录后调用：获取用户角色和权限范围"""
    # TODO: 正式部署后验证token有效性
    user = db.query(UserRole).filter(
        UserRole.user_id == user_id,
        UserRole.is_active == True
    ).first()
    if not user:
        raise HTTPException(status_code=404, detail=f"用户 {user_id} 不存在或未配置权限")
    return UserInfo(
        user_id=user.user_id,
        role=user.role,
        scope_type=user.scope_type,
        scope_id=user.scope_id,
        partner_level=user.partner_level
    )

@app.post("/api/auth/evaluate", response_model=AuthResponse)
def evaluate_action(req: AuthRequest, db: Session = Depends(get_db)):
    """Agent执行任何操作前调用：评估是否有权限"""
    user = db.query(UserRole).filter(
        UserRole.user_id == req.user_id,
        UserRole.is_active == True
    ).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")
    result = auth_engine.evaluate(req, user)
    # 记录日志
    log = AuthLog(
        user_id=req.user_id,
        operation_type=req.operation_type,
        entity_id=req.entity_id,
        decision=result.decision,
        reason=result.reason
    )
    db.add(log)
    db.commit()
    return result

@app.get("/health")
def health():
    return {"status": "ok", "service": "auth-boundary", "version": "1.0.0-python"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
