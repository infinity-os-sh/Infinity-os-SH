# ============================================================
# memory_system.py  ·  INFINITY OS 四层记忆系统 (Python版)
# 替代: MemoryOrchestrator.java + 四个Service
# 框架: FastAPI + SQLAlchemy + APScheduler + Redis
# ============================================================

from fastapi import FastAPI, Depends
from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, Boolean, Text, JSON
from sqlalchemy.orm import declarative_base, Session, sessionmaker
from pydantic import BaseModel
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
import redis, os, json, logging

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("memory_system")

# ── 连接配置 ──────────────────────────────────────────────
DATABASE_URL = os.getenv("DATABASE_URL", "mysql+pymysql://root:password@localhost:3306/infinity_os")
REDIS_URL    = os.getenv("REDIS_URL", "redis://localhost:6379/0")

engine      = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)
Base        = declarative_base()
redis_client = redis.from_url(REDIS_URL, decode_responses=True)

# ── 数据模型 ──────────────────────────────────────────────
class ConvSession(Base):
    __tablename__ = "conv_sessions"
    id          = Column(String(50), primary_key=True)
    user_id     = Column(String(50))
    agent_id    = Column(String(50))
    started_at  = Column(DateTime, default=datetime.now)
    last_active = Column(DateTime, default=datetime.now)
    turn_count  = Column(Integer, default=0)
    is_active   = Column(Boolean, default=True)

class ConvTurn(Base):
    __tablename__ = "conv_turns"
    id          = Column(Integer, primary_key=True, autoincrement=True)
    session_id  = Column(String(50))
    role        = Column(String(10))   # user/assistant
    content     = Column(Text)
    created_at  = Column(DateTime, default=datetime.now)

class AgentMemoryEvent(Base):
    __tablename__ = "agent_memory_events"
    id          = Column(Integer, primary_key=True, autoincrement=True)
    agent_id    = Column(String(50))
    entity_type = Column(String(30))   # store/distributor/sku
    entity_id   = Column(String(100))
    event_type  = Column(String(50))   # low_inventory/distortion_A/order_pushed
    event_data  = Column(JSON)
    severity    = Column(Integer, default=3)  # 1-5
    is_resolved = Column(Boolean, default=False)
    created_at  = Column(DateTime, default=datetime.now)
    expires_at  = Column(DateTime)

class AgentMemoryProfile(Base):
    __tablename__ = "agent_memory_profiles"
    entity_type             = Column(String(30), primary_key=True)
    entity_id               = Column(String(100), primary_key=True)
    profile_data            = Column(JSON)
    r_history               = Column(JSON)   # 过去90天r值数组
    risk_score              = Column(Float, default=0.0)
    low_inventory_count_30d = Column(Integer, default=0)
    last_updated            = Column(DateTime, default=datetime.now)

class AgentMemoryDecision(Base):
    __tablename__ = "agent_memory_decisions"
    id               = Column(Integer, primary_key=True, autoincrement=True)
    agent_id         = Column(String(50))
    entity_id        = Column(String(100))
    decision_type    = Column(String(50))
    input_snapshot   = Column(JSON)
    output_action    = Column(JSON)
    outcome          = Column(Text)       # 事后回填
    feedback_score   = Column(Float)      # 决策质量评分
    created_at       = Column(DateTime, default=datetime.now)
    outcome_at       = Column(DateTime)   # T+7回填时间

class InfLearningLog(Base):
    __tablename__ = "inf_learning_log"
    id              = Column(Integer, primary_key=True, autoincrement=True)
    agent_id        = Column(String(50))
    action_type     = Column(String(50))   # omakase_push/butterfly_alert/calibration
    entity_id       = Column(String(100))
    input_data      = Column(JSON)
    output_data     = Column(JSON)
    human_feedback  = Column(String(20))   # confirmed/rejected/modified
    actual_outcome  = Column(JSON)         # T+7实际结果
    accuracy_score  = Column(Float)        # 准确度评分
    created_at      = Column(DateTime, default=datetime.now)
    outcome_at      = Column(DateTime)

# ── Pydantic模型 ──────────────────────────────────────────
class MemoryContext(BaseModel):
    entity_id:       str
    recent_events:   List[Dict] = []
    profile:         Optional[Dict] = None
    last_decision:   Optional[Dict] = None
    risk_score:      float = 0.0

class RecordDecisionReq(BaseModel):
    agent_id:      str
    entity_id:     str
    decision_type: str
    input_data:    Dict
    output_data:   Dict

class RecordFeedbackReq(BaseModel):
    decision_id:    int
    human_feedback: str   # confirmed/rejected/modified
    modified_value: Optional[Any] = None

# ── DB依赖 ────────────────────────────────────────────────
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ── 记忆编排器 ────────────────────────────────────────────
class MemoryOrchestrator:

    def build_context(self, entity_id: str, agent_id: str, db: Session) -> MemoryContext:
        """给Agent调用前组装完整记忆上下文"""

        # 层面三：近30天事件
        cutoff = datetime.now() - timedelta(days=30)
        events = db.query(AgentMemoryEvent).filter(
            AgentMemoryEvent.entity_id == entity_id,
            AgentMemoryEvent.created_at >= cutoff
        ).order_by(AgentMemoryEvent.created_at.desc()).limit(10).all()

        # 层面四：实体画像
        profile = db.query(AgentMemoryProfile).filter(
            AgentMemoryProfile.entity_id == entity_id
        ).first()

        # 层面三：上次决策
        last = db.query(AgentMemoryDecision).filter(
            AgentMemoryDecision.agent_id == agent_id,
            AgentMemoryDecision.entity_id == entity_id
        ).order_by(AgentMemoryDecision.created_at.desc()).first()

        return MemoryContext(
            entity_id=entity_id,
            recent_events=[{
                "type": e.event_type,
                "severity": e.severity,
                "data": e.event_data,
                "time": e.created_at.isoformat()
            } for e in events],
            profile=profile.profile_data if profile else None,
            last_decision={
                "type": last.decision_type,
                "output": last.output_action,
                "outcome": last.outcome,
                "score": last.feedback_score,
                "time": last.created_at.isoformat()
            } if last else None,
            risk_score=profile.risk_score if profile else 0.0
        )

    def build_system_prompt_injection(self, ctx: MemoryContext) -> str:
        """把记忆上下文转成系统提示词注入"""
        parts = []
        if ctx.recent_events:
            parts.append(f"【近期事件记忆·{len(ctx.recent_events)}条】")
            for e in ctx.recent_events[:5]:
                parts.append(f"  {e['time'][:10]} | {e['type']} | 严重度{e['severity']}")
        if ctx.profile:
            parts.append(f"【实体画像】风险评分:{ctx.risk_score:.1f} | {json.dumps(ctx.profile, ensure_ascii=False)[:100]}")
        if ctx.last_decision:
            parts.append(f"【上次决策】类型:{ctx.last_decision['type']} | 评分:{ctx.last_decision.get('score','未知')}")
        return "\n".join(parts)

    def record_event(self, agent_id: str, entity_id: str, entity_type: str,
                     event_type: str, data: dict, severity: int, db: Session):
        """记录Agent发现的事件"""
        event = AgentMemoryEvent(
            agent_id=agent_id,
            entity_type=entity_type,
            entity_id=entity_id,
            event_type=event_type,
            event_data=data,
            severity=severity,
            expires_at=datetime.now() + timedelta(days=30)
        )
        db.add(event)
        # 同时写Redis实时缓存（5分钟过期）
        key = f"event:{entity_id}:{event_type}"
        redis_client.setex(key, 300, json.dumps(data, ensure_ascii=False))
        db.commit()

    def record_decision(self, req: RecordDecisionReq, db: Session) -> int:
        """记录Agent的每次决策，7天后回填结果"""
        decision = AgentMemoryDecision(
            agent_id=req.agent_id,
            entity_id=req.entity_id,
            decision_type=req.decision_type,
            input_snapshot=req.input_data,
            output_action=req.output_data,
        )
        # 同步写inf_learning_log
        log_entry = InfLearningLog(
            agent_id=req.agent_id,
            action_type=req.decision_type,
            entity_id=req.entity_id,
            input_data=req.input_data,
            output_data=req.output_data,
            outcome_at=datetime.now() + timedelta(days=7)
        )
        db.add(decision)
        db.add(log_entry)
        db.commit()
        db.refresh(decision)
        return decision.id


# ── 定时维护任务 ──────────────────────────────────────────
orchestrator = MemoryOrchestrator()

def cleanup_expired_memory():
    """每天凌晨02:00 · 清理过期短期记忆"""
    log.info("[记忆维护] 开始清理过期记忆...")
    db = SessionLocal()
    try:
        deleted = db.query(AgentMemoryEvent).filter(
            AgentMemoryEvent.expires_at < datetime.now(),
            AgentMemoryEvent.is_resolved == True
        ).delete()
        db.commit()
        log.info(f"[记忆维护] 清理完成，删除 {deleted} 条")
    finally:
        db.close()

def update_daily_profiles():
    """每天23:59 · 更新实体画像风险评分"""
    log.info("[记忆维护] 开始更新实体画像...")
    db = SessionLocal()
    try:
        cutoff = datetime.now() - timedelta(days=30)
        # 查今日有事件的实体，更新风险评分
        events = db.query(
            AgentMemoryEvent.entity_id,
            AgentMemoryEvent.entity_type
        ).filter(
            AgentMemoryEvent.created_at >= datetime.now().replace(hour=0, minute=0)
        ).distinct().all()

        for entity_id, entity_type in events:
            count = db.query(AgentMemoryEvent).filter(
                AgentMemoryEvent.entity_id == entity_id,
                AgentMemoryEvent.created_at >= cutoff
            ).count()
            risk = min(count * 10.0, 100.0)  # 简单风险评分
            profile = db.query(AgentMemoryProfile).filter(
                AgentMemoryProfile.entity_id == entity_id
            ).first()
            if profile:
                profile.risk_score = risk
                profile.low_inventory_count_30d = count
                profile.last_updated = datetime.now()
            else:
                db.add(AgentMemoryProfile(
                    entity_type=entity_type,
                    entity_id=entity_id,
                    risk_score=risk,
                    low_inventory_count_30d=count
                ))
        db.commit()
        log.info("[记忆维护] 实体画像更新完成")
    finally:
        db.close()

def weekly_outcome_backfill():
    """每周一10:00 · T+7结果回填 + 准确度评分"""
    log.info("[学习日志] 开始T+7结果回填...")
    db = SessionLocal()
    try:
        cutoff = datetime.now() - timedelta(days=7)
        pending = db.query(InfLearningLog).filter(
            InfLearningLog.outcome_at <= datetime.now(),
            InfLearningLog.actual_outcome == None
        ).all()
        for entry in pending:
            # TODO: 接入真实业务数据查询实际结果
            # 暂时标记为待回填
            entry.actual_outcome = {"status": "pending_backfill"}
            entry.outcome_at = datetime.now()
        db.commit()
        log.info(f"[学习日志] 处理 {len(pending)} 条待回填记录")
    finally:
        db.close()

def start_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(cleanup_expired_memory,  CronTrigger(hour=2,  minute=0))
    scheduler.add_job(update_daily_profiles,   CronTrigger(hour=23, minute=59))
    scheduler.add_job(weekly_outcome_backfill, CronTrigger(day_of_week='mon', hour=10, minute=0))
    scheduler.start()
    log.info("[定时任务] 记忆维护调度器已启动")
    return scheduler


# ── FastAPI 应用 ───────────────────────────────────────────
app = FastAPI(title="INFINITY OS · 四层记忆系统", version="1.0.0")

@app.on_event("startup")
def startup():
    start_scheduler()

@app.get("/api/memory/context/{entity_id}")
def get_memory_context(entity_id: str, agent_id: str = "system", db: Session = Depends(get_db)):
    """Agent调用前获取记忆上下文"""
    ctx = orchestrator.build_context(entity_id, agent_id, db)
    return ctx

@app.get("/api/memory/prompt_injection/{entity_id}")
def get_prompt_injection(entity_id: str, agent_id: str = "system", db: Session = Depends(get_db)):
    """直接获取可注入Claude系统提示词的记忆文本"""
    ctx = orchestrator.build_context(entity_id, agent_id, db)
    return {"injection": orchestrator.build_system_prompt_injection(ctx)}

@app.post("/api/memory/decision")
def record_decision(req: RecordDecisionReq, db: Session = Depends(get_db)):
    """记录Agent决策，自动写入inf_learning_log"""
    decision_id = orchestrator.record_decision(req, db)
    return {"decision_id": decision_id, "outcome_expected_at": (datetime.now() + timedelta(days=7)).isoformat()}

@app.post("/api/memory/feedback")
def record_feedback(req: RecordFeedbackReq, db: Session = Depends(get_db)):
    """老板/用户确认或拒绝后记录反馈"""
    decision = db.query(AgentMemoryDecision).filter(
        AgentMemoryDecision.id == req.decision_id
    ).first()
    if not decision:
        return {"error": "决策记录不存在"}
    decision.outcome = req.human_feedback
    decision.feedback_score = 1.0 if req.human_feedback == "confirmed" else 0.0
    decision.outcome_at = datetime.now()
    # 同步更新learning_log
    log_entry = db.query(InfLearningLog).filter(
        InfLearningLog.agent_id == decision.agent_id,
        InfLearningLog.entity_id == decision.entity_id,
        InfLearningLog.created_at >= decision.created_at - timedelta(seconds=5)
    ).first()
    if log_entry:
        log_entry.human_feedback = req.human_feedback
        log_entry.accuracy_score = decision.feedback_score
    db.commit()
    return {"status": "ok", "feedback": req.human_feedback}

@app.get("/api/memory/learning_stats")
def get_learning_stats(agent_id: str, db: Session = Depends(get_db)):
    """获取Agent学习统计（准确率趋势）"""
    logs = db.query(InfLearningLog).filter(
        InfLearningLog.agent_id == agent_id,
        InfLearningLog.human_feedback != None
    ).all()
    total = len(logs)
    confirmed = sum(1 for l in logs if l.human_feedback == "confirmed")
    return {
        "agent_id": agent_id,
        "total_decisions": total,
        "confirmed": confirmed,
        "accuracy": round(confirmed / total * 100, 1) if total > 0 else 0,
        "sample_size": total,
        "threshold_for_auto": 500  # 500条样本后才考虑提高自主权
    }

@app.get("/health")
def health():
    return {"status": "ok", "service": "memory-system", "version": "1.0.0-python"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)
