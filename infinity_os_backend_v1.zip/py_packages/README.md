# INFINITY OS · Python后端包 v1.0
## 完整替代 Java Spring Boot 版本

---

## 四个服务文件

| 文件 | 端口 | 替代Java包 | 职责 |
|------|------|-----------|------|
| `infinity_backend/infinity_backend.py` | 8000 | infinity-os-backend.zip | 核心业务：心跳·Omakase·SPD仪表板 |
| `auth_boundary/auth_engine.py` | 8001 | auth-boundary-v1.zip | L2权限控制·26维度授权引擎 |
| `memory_system/memory_system.py` | 8002 | memory-all-layers-v1.zip | L6四层记忆·inf_learning_log·定时任务 |
| `tool_layer/tool_layer.py` | 8003 | tool-layer-v2.zip | L4工具调度·企微推送·推单确认闭环 |

**SQL建表文件不变，继续用原来的.sql文件建表。**

---

## 3步启动

### 第一步：安装依赖（5分钟）
```bash
pip install -r requirements.txt
```

### 第二步：配置环境变量（10分钟）
```bash
cp .env.template .env
# 编辑 .env 填入真实数据库密码和企微Webhook
```

### 第三步：启动四个服务
```bash
# 方式A：分别启动（开发调试用）
python infinity_backend/infinity_backend.py   # 端口 8000
python auth_boundary/auth_engine.py           # 端口 8001
python memory_system/memory_system.py         # 端口 8002
python tool_layer/tool_layer.py               # 端口 8003

# 方式B：生产环境（推荐）
uvicorn infinity_backend.infinity_backend:app --host 0.0.0.0 --port 8000 --workers 2
uvicorn auth_boundary.auth_engine:app --host 0.0.0.0 --port 8001 --workers 1
uvicorn memory_system.memory_system:app --host 0.0.0.0 --port 8002 --workers 1
uvicorn tool_layer.tool_layer:app --host 0.0.0.0 --port 8003 --workers 1
```

---

## 定时任务（自动运行，无需手动配置）

| 时间 | 任务 | 服务 |
|------|------|------|
| 凌晨02:00 | 清理过期记忆 | memory_system |
| 凌晨07:00 | 蝴蝶效应扫描 | infinity_backend |
| 凌晨08:00 | Omakase推单计算 | infinity_backend |
| 每天23:59 | 更新实体画像风险评分 | memory_system |
| 每周一10:00 | T+7结果回填·学习日志更新 | memory_system |

服务启动时定时任务自动启动，**无需额外配置cron**。

---

## API快速验证

服务启动后，运行以下命令验证：

```bash
# 1. 基础健康检查
curl http://localhost:8000/health
curl http://localhost:8001/health
curl http://localhost:8002/health
curl http://localhost:8003/health

# 2. 用户权限验证
curl "http://localhost:8001/api/auth/user/U001?token=test"
# 期望：{"user_id":"U001","role":"mgmt","scope_type":"national"...}

# 3. SPD仪表板数据
curl "http://localhost:8000/api/spd/dashboard/dist_bc"
# 期望：完整JSON含core/todos/pl/roi

# 4. 蝴蝶效应扫描
curl "http://localhost:8000/api/butterfly/scan"
# 期望：{"alerts":[...],"alert_count":N}

# 5. 推单计算
curl "http://localhost:8000/api/omakase/dist_bc"
# 期望：{"orders":[...],"total_qty":N}
```

---

## SFA登录打通（关键）

SFA登录成功后跳转v30带参数：
```
https://infinity-os-sh.github.io/Infinity-os-SH/infinity_os_v30.html
  ?userId=U001
  &token=xxx
  &role=dist
```

v30自动调用：
```
GET http://your-server:8001/api/auth/user/U001?token=xxx
→ 返回角色和权限范围
→ v30自动显示对应视图
```

---

## 与data_pipeline_v1.zip的关系

Python数据管道（已有）独立运行，不依赖这四个服务：
```
凌晨04:00 → hanxun_etl.py → 写入inf_heartbeat.r_actual
凌晨04:30 → dcloud_etl.py → 写入inf_heartbeat.inventory_actual
凌晨05:00 → data_quality_check.py
凌晨06:00 → A值校准（butterfly_omakase.py）
凌晨07:00 → 蝴蝶效应（本服务定时任务）
凌晨08:00 → Omakase推单（本服务定时任务）
```

---

欣和食品 · INFINITY OS · Python后端 v1.0 · 2026年4月25日
