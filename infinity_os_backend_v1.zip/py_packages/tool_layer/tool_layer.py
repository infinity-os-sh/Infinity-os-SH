# ============================================================
# tool_layer.py  ·  INFINITY OS L4工具调度层 (Python版)
# 替代: ToolOrchestrator.java + 4个Service
# 框架: FastAPI + httpx (异步HTTP) + APScheduler
# ============================================================

from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, Boolean, Text, JSON
from sqlalchemy.orm import declarative_base, Session, sessionmaker
from pydantic import BaseModel
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
import httpx, os, json, logging, asyncio

log = logging.getLogger("tool_layer")

DATABASE_URL = os.getenv("DATABASE_URL", "mysql+pymysql://root:password@localhost:3306/infinity_os")
WECHAT_WORK_WEBHOOK = os.getenv("WECHAT_WORK_WEBHOOK", "")
CLAUDE_API_KEY = os.getenv("CLAUDE_API_KEY", "")
AUTH_SERVICE_URL = os.getenv("AUTH_SERVICE_URL", "http://localhost:8001")
MEMORY_SERVICE_URL = os.getenv("MEMORY_SERVICE_URL", "http://localhost:8002")

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

# ── 数据模型 ──────────────────────────────────────────────
class ToolExecution(Base):
    __tablename__ = "tool_executions"
    id              = Column(Integer, primary_key=True, autoincrement=True)
    agent_id        = Column(String(50))
    tool_name       = Column(String(50))
    input_data      = Column(JSON)
    output_data     = Column(JSON)
    status          = Column(String(20), default='pending')  # pending/running/success/failed
    error_msg       = Column(Text)
    duration_ms     = Column(Integer)
    created_at      = Column(DateTime, default=datetime.now)
    completed_at    = Column(DateTime)

class InfAction(Base):
    __tablename__ = "inf_actions"
    id              = Column(Integer, primary_key=True, autoincrement=True)
    node_id         = Column(String(50))
    action_type     = Column(String(50))    # omakase_push/alert_push/calibrate
    triggered_by    = Column(String(50))    # agent_id
    payload         = Column(JSON)
    status          = Column(String(20), default='pending')
    feedback_json   = Column(JSON)
    created_at      = Column(DateTime, default=datetime.now)
    resolved_at     = Column(DateTime)

# ── Pydantic模型 ──────────────────────────────────────────
class ToolRequest(BaseModel):
    agent_id:    str
    tool_name:   str
    params:      Dict[str, Any]
    entity_id:   str = ""
    user_id:     str = ""

class WechatPushReq(BaseModel):
    agent_id:    str
    to_user:     str       # 企微用户ID
    title:       str
    content:     str
    action_type: str       # confirm_order/view_alert/acknowledge
    entity_id:   str
    amount:      float = 0.0

class ConfirmOrderReq(BaseModel):
    action_id:  int
    user_id:    str
    decision:   str    # confirmed/rejected/modified
    modified_qty: Optional[float] = None

# ── 工具执行层 ────────────────────────────────────────────

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class ToolExecutionService:

    AVAILABLE_TOOLS = {
        "query_r_actual":    "查询门店实际日销率",
        "query_inventory":   "查询经销商库存水位",
        "push_wechat":       "推送企微消息",
        "write_inf_action":  "写入待办事项",
        "call_claude":       "调用Claude AI",
        "query_heartbeat":   "查询心跳数据",
        "write_learning_log":"写入学习日志",
    }

    async def execute(self, req: ToolRequest, db: Session) -> Dict:
        start = datetime.now()
        execution = ToolExecution(
            agent_id=req.agent_id,
            tool_name=req.tool_name,
            input_data=req.params,
            status='running'
        )
        db.add(execution)
        db.commit()
        db.refresh(execution)

        try:
            result = await self._dispatch(req.tool_name, req.params, db)
            execution.status = 'success'
            execution.output_data = result
        except Exception as e:
            execution.status = 'failed'
            execution.error_msg = str(e)
            result = {"error": str(e)}
        finally:
            execution.completed_at = datetime.now()
            execution.duration_ms = int((datetime.now() - start).total_seconds() * 1000)
            db.commit()

        return result

    async def _dispatch(self, tool_name: str, params: Dict, db: Session) -> Dict:
        if tool_name == "query_r_actual":
            return self._query_r_actual(params, db)
        elif tool_name == "query_inventory":
            return self._query_inventory(params, db)
        elif tool_name == "push_wechat":
            return await self._push_wechat(params)
        elif tool_name == "write_inf_action":
            return self._write_inf_action(params, db)
        elif tool_name == "call_claude":
            return await self._call_claude(params)
        elif tool_name == "write_learning_log":
            return self._write_learning_log(params, db)
        else:
            raise ValueError(f"未知工具: {tool_name}")

    def _query_r_actual(self, params: Dict, db: Session) -> Dict:
        """从inf_heartbeat查询门店实际日销率"""
        from sqlalchemy import text
        node_id = params.get("node_id")
        sku_code = params.get("sku_code")
        days = params.get("days", 7)
        cutoff = datetime.now() - timedelta(days=days)
        result = db.execute(text("""
            SELECT node_id, sku_code,
                   AVG(r_actual) as avg_r,
                   AVG(a_actual) as avg_a,
                   AVG(water_level) as avg_water,
                   COUNT(*) as data_points
            FROM inf_heartbeat
            WHERE node_id = :node_id
              AND sku_code = :sku_code
              AND data_date >= :cutoff
            GROUP BY node_id, sku_code
        """), {"node_id": node_id, "sku_code": sku_code, "cutoff": cutoff}).fetchone()
        if result:
            return dict(result._mapping)
        return {"node_id": node_id, "avg_r": 0, "data_points": 0}

    def _query_inventory(self, params: Dict, db: Session) -> Dict:
        """查询经销商库存水位"""
        from sqlalchemy import text
        dist_id = params.get("dist_id")
        result = db.execute(text("""
            SELECT n.node_id, n.node_name,
                   h.sku_code, h.inventory_actual,
                   h.water_level, h.water_status
            FROM inf_nodes n
            JOIN inf_heartbeat h ON n.node_id = h.node_id
            WHERE n.node_id = :dist_id
              AND h.data_date = CURDATE() - INTERVAL 1 DAY
        """), {"dist_id": dist_id}).fetchall()
        return {"dist_id": dist_id, "inventory": [dict(r._mapping) for r in result]}

    async def _push_wechat(self, params: Dict) -> Dict:
        """推送企微Webhook消息"""
        if not WECHAT_WORK_WEBHOOK:
            log.warning("企微Webhook未配置，跳过推送")
            return {"status": "skipped", "reason": "webhook not configured"}
        payload = {
            "msgtype": "markdown",
            "markdown": {
                "content": f"## {params.get('title','INFINITY OS通知')}\n{params.get('content','')}"
            }
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(WECHAT_WORK_WEBHOOK, json=payload, timeout=10)
            return {"status": "sent", "code": resp.status_code}

    def _write_inf_action(self, params: Dict, db: Session) -> Dict:
        """写入待办事项到inf_actions"""
        action = InfAction(
            node_id=params.get("node_id"),
            action_type=params.get("action_type"),
            triggered_by=params.get("agent_id"),
            payload=params.get("payload", {}),
            status='pending'
        )
        db.add(action)
        db.commit()
        db.refresh(action)
        return {"action_id": action.id, "status": "created"}

    async def _call_claude(self, params: Dict) -> Dict:
        """调用Claude API"""
        headers = {
            "x-api-key": CLAUDE_API_KEY,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        }
        body = {
            "model": "claude-sonnet-4-20250514",
            "max_tokens": params.get("max_tokens", 1000),
            "system": params.get("system", "你是INFINITY OS的AI助手"),
            "messages": [{"role": "user", "content": params.get("prompt", "")}]
        }
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers=headers, json=body, timeout=30
            )
            data = resp.json()
            return {"text": data.get("content", [{}])[0].get("text", "")}

    def _write_learning_log(self, params: Dict, db: Session) -> Dict:
        from sqlalchemy import text
        db.execute(text("""
            INSERT INTO inf_learning_log
            (agent_id, action_type, entity_id, input_data, output_data, outcome_at)
            VALUES (:agent_id, :action_type, :entity_id, :input_data, :output_data, :outcome_at)
        """), {
            "agent_id":    params.get("agent_id"),
            "action_type": params.get("action_type"),
            "entity_id":   params.get("entity_id"),
            "input_data":  json.dumps(params.get("input_data", {})),
            "output_data": json.dumps(params.get("output_data", {})),
            "outcome_at":  datetime.now() + timedelta(days=7)
        })
        db.commit()
        return {"status": "logged"}


# ── FastAPI 应用 ───────────────────────────────────────────
app = FastAPI(title="INFINITY OS · L4工具调度层", version="1.0.0")
tool_service = ToolExecutionService()

@app.post("/api/tool/execute")
async def execute_tool(req: ToolRequest, db: Session = Depends(get_db)):
    """Agent执行工具的统一入口"""
    # 先验证权限
    async with httpx.AsyncClient() as client:
        auth_resp = await client.post(f"{AUTH_SERVICE_URL}/api/auth/evaluate", json={
            "user_id": req.user_id or req.agent_id,
            "operation_type": f"tool_{req.tool_name}",
            "entity_id": req.entity_id,
        })
        auth = auth_resp.json()
        if not auth.get("can_execute") and auth.get("decision") == "DENY":
            raise HTTPException(status_code=403, detail=auth.get("reason"))
    result = await tool_service.execute(req, db)
    return result

@app.post("/api/tool/wechat_push")
async def push_wechat(req: WechatPushReq, db: Session = Depends(get_db)):
    """推送企微消息并创建待办"""
    # 1. 创建inf_action待办
    action = InfAction(
        node_id=req.entity_id,
        action_type=req.action_type,
        triggered_by=req.agent_id,
        payload={"title": req.title, "content": req.content, "amount": req.amount}
    )
    db.add(action)
    db.commit()
    db.refresh(action)
    # 2. 推企微
    result = await tool_service._push_wechat({
        "title": req.title,
        "content": f"{req.content}\n\n[action_id:{action.id}]"
    })
    return {"action_id": action.id, "wechat_status": result}

@app.post("/api/tool/confirm_order")
def confirm_order(req: ConfirmOrderReq, db: Session = Depends(get_db)):
    """老板在企微或v30点确认后的闭环处理"""
    action = db.query(InfAction).filter(InfAction.id == req.action_id).first()
    if not action:
        raise HTTPException(status_code=404, detail="待办事项不存在")
    action.status = 'resolved' if req.decision == 'confirmed' else 'rejected'
    action.feedback_json = {
        "user_id": req.user_id,
        "decision": req.decision,
        "modified_qty": req.modified_qty,
        "resolved_at": datetime.now().isoformat()
    }
    action.resolved_at = datetime.now()
    db.commit()
    # 写学习日志
    tool_service._write_learning_log({
        "agent_id": action.triggered_by,
        "action_type": action.action_type,
        "entity_id": action.node_id,
        "input_data": action.payload,
        "output_data": {"decision": req.decision, "modified_qty": req.modified_qty}
    }, db)
    return {"status": "ok", "decision": req.decision, "action_id": req.action_id}

@app.get("/api/tool/pending_actions/{node_id}")
def get_pending_actions(node_id: str, db: Session = Depends(get_db)):
    """获取某个节点的待办事项（v30仪表板调用）"""
    actions = db.query(InfAction).filter(
        InfAction.node_id == node_id,
        InfAction.status == 'pending'
    ).order_by(InfAction.created_at.desc()).limit(3).all()
    return {"node_id": node_id, "pending": [{
        "id": a.id,
        "type": a.action_type,
        "payload": a.payload,
        "created_at": a.created_at.isoformat()
    } for a in actions]}

@app.get("/health")
def health():
    return {"status": "ok", "service": "tool-layer", "version": "1.0.0-python"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8003)
