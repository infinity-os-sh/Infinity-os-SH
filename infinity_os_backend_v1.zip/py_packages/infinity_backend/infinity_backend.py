# ============================================================
# infinity_backend.py  ·  INFINITY OS核心业务后端 (Python版)
# 替代: infinity-os-backend.zip (Java Spring Boot)
# 框架: FastAPI + SQLAlchemy + APScheduler
# 包含: VelocityCalculation / SPD仪表板API / 心跳系统
# ============================================================

from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, Boolean, Text, JSON, Date
from sqlalchemy.orm import declarative_base, Session, sessionmaker
from sqlalchemy import text
from pydantic import BaseModel
from datetime import datetime, timedelta, date
from typing import Optional, List, Dict
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
import os, json, logging, httpx

log = logging.getLogger("infinity_backend")
DATABASE_URL = os.getenv("DATABASE_URL", "mysql+pymysql://root:password@localhost:3306/infinity_os")
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

# ── 数据模型 ──────────────────────────────────────────────
class InfNode(Base):
    __tablename__ = "inf_nodes"
    node_id       = Column(String(50), primary_key=True)
    node_name     = Column(String(100))
    node_type     = Column(String(20))   # factory/dist/store/consumer
    parent_id     = Column(String(50))
    city          = Column(String(30))
    region        = Column(String(30))
    grade         = Column(Integer, default=3)
    credit_score  = Column(Float, default=80.0)
    is_active     = Column(Boolean, default=True)

class InfHeartbeat(Base):
    __tablename__ = "inf_heartbeat"
    id              = Column(Integer, primary_key=True, autoincrement=True)
    node_id         = Column(String(50))
    sku_code        = Column(String(50))
    data_date       = Column(Date)
    r_actual        = Column(Float, default=0.0)   # 实际日销率
    r_target        = Column(Float, default=0.0)   # 目标日销率
    a_actual        = Column(Float, default=0.0)   # 实际心跳单元
    a_unit          = Column(Float, default=0.0)   # 标准心跳单元
    inventory_actual = Column(Float, default=0.0)  # 实际库存
    water_level      = Column(Float, default=0.0)  # 水位（inventory/a_unit）
    water_status     = Column(String(20))           # overflow/full/warn/low/empty
    digest_rate      = Column(Float, default=0.0)  # 消化率
    t_period         = Column(Integer, default=30)  # 周转周期天数
    data_source      = Column(String(20))           # HANXUN/DCLOUD/MANUAL
    created_at       = Column(DateTime, default=datetime.now)

class SpdDistributor(Base):
    __tablename__ = "spd_distributors"
    id             = Column(String(20), primary_key=True)
    name           = Column(String(50))
    owner_name     = Column(String(20))
    owner_wechat   = Column(String(50))
    region         = Column(String(50))
    city           = Column(String(20))
    credit_grade   = Column(String(1), default='B')
    spd_level      = Column(String(20), default='standard')
    contract_start = Column(Date)
    contract_end   = Column(Date)
    status         = Column(String(10), default='active')

class SpdPerformance(Base):
    __tablename__ = "spd_performance"
    id               = Column(Integer, primary_key=True, autoincrement=True)
    dist_id          = Column(String(20))
    period           = Column(String(7))    # 2026-04
    revenue_target   = Column(Float)
    revenue_actual   = Column(Float, default=0)
    revenue_ach      = Column(Float)
    gross_profit     = Column(Float, default=0)
    net_profit       = Column(Float, default=0)
    digest_rate      = Column(Float, default=0)
    inventory_value  = Column(Float, default=0)
    growth_rate      = Column(Float, default=0)
    roi_annual       = Column(Float)
    updated_at       = Column(DateTime, default=datetime.now)

# ── Pydantic模型 ──────────────────────────────────────────
class NodeTargetReq(BaseModel):
    node_id:   str
    sku_code:  str
    r_target:  float
    t_period:  int = 30

class SpdDashboardResponse(BaseModel):
    dist_id:       str
    owner_name:    str
    period:        str
    core:          Dict
    todos:         List[Dict]
    pl:            Dict
    roi:           Dict
    iron_laws:     Dict

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ── 核心业务逻辑 ──────────────────────────────────────────

class VelocityCalculationEngine:
    """心跳公式计算引擎 · 替代 VelocityCalculationService.java"""

    # 铁律③消化率阈值
    IRON3_WARNING = 0.65
    IRON3_CRITICAL = 0.50

    # 水位定义（节点类型→水位区间）
    WATER_LEVELS = {
        "store":  {"overflow": 4.0, "full": 3.0, "warn": 2.0, "low": 1.0},
        "dist":   {"overflow": 3.0, "full": 2.0, "warn": 1.5, "low": 1.0},
        "dist_p2":{"overflow": 2.0, "full": 1.0, "warn": 0.8, "low": 0.5},
    }

    def calculate_water_status(self, water_level: float, node_type: str) -> str:
        levels = self.WATER_LEVELS.get(node_type, self.WATER_LEVELS["store"])
        if water_level >= levels["overflow"]: return "overflow"
        if water_level >= levels["full"]:     return "full"
        if water_level >= levels["warn"]:     return "warn"
        if water_level >= levels["low"]:      return "low"
        return "empty"

    def calculate_heartbeat(self, r_actual: float, inventory: float,
                             t_period: int, node_type: str) -> Dict:
        """计算心跳指标"""
        a_unit = r_actual * t_period if r_actual > 0 else 0
        water_level = inventory / a_unit if a_unit > 0 else 0
        water_status = self.calculate_water_status(water_level, node_type)
        digest_rate = r_actual / (inventory / t_period) if inventory > 0 else 0
        return {
            "a_unit": round(a_unit, 2),
            "water_level": round(water_level, 2),
            "water_status": water_status,
            "digest_rate": round(min(digest_rate, 1.0), 4),
            "iron3_ok": digest_rate >= self.IRON3_WARNING,
        }

    def detect_butterfly_effect(self, heartbeats: List[Dict]) -> List[Dict]:
        """蝴蝶效应检测 · A/B/C/D四类失真"""
        alerts = []
        for h in heartbeats:
            # A类：压货失真（库存溢出+消化率低）
            if h.get("water_status") in ("overflow",) and h.get("digest_rate", 1) < 0.65:
                alerts.append({
                    "type": "A",
                    "name": "压货失真",
                    "node_id": h["node_id"],
                    "severity": 4,
                    "desc": f"库存{h['water_level']:.1f}a·消化率{h['digest_rate']:.0%}"
                })
            # C类：窜货失真（水位突然大幅下降）
            if h.get("water_level", 2) < 0.5 and h.get("r_actual", 0) > h.get("r_target", 0) * 1.5:
                alerts.append({
                    "type": "C",
                    "name": "窜货失真",
                    "node_id": h["node_id"],
                    "severity": 3,
                    "desc": f"动销异常高·库存急降·疑似窜货"
                })
        return alerts

    def calculate_omakase_order(self, node_id: str, skus: List[Dict]) -> List[Dict]:
        """Omakase无菜单推单计算"""
        orders = []
        for sku in skus:
            r = sku.get("r_actual", 0)
            inventory = sku.get("inventory_actual", 0)
            t = sku.get("t_period", 30)
            a_unit = r * t
            water = inventory / a_unit if a_unit > 0 else 0

            # 推单逻辑：水位<1.5a时推单，目标补到2a
            if water < 1.5 and r > 0:
                order_qty = max(0, 2 * a_unit - inventory)
                if order_qty > 0:
                    orders.append({
                        "sku_code": sku["sku_code"],
                        "sku_name": sku.get("sku_name", sku["sku_code"]),
                        "current_inventory": round(inventory, 0),
                        "current_water": round(water, 2),
                        "order_qty": round(order_qty, 0),
                        "target_water": 2.0,
                        "reason": f"当前{water:.1f}a·低于1.5a预警线·补至2a"
                    })
            elif water >= 4.0:
                orders.append({
                    "sku_code": sku["sku_code"],
                    "sku_name": sku.get("sku_name", sku["sku_code"]),
                    "order_qty": 0,
                    "paused": True,
                    "reason": f"库存{water:.1f}a超出满仓·暂停推单"
                })
        return orders


velocity_engine = VelocityCalculationEngine()

# ── FastAPI 应用 ───────────────────────────────────────────
app = FastAPI(title="INFINITY OS · 核心业务后端", version="1.0.0")

# ── SPD仪表板API ──────────────────────────────────────────
@app.get("/api/spd/dashboard/{dist_id}")
def get_spd_dashboard(dist_id: str, db: Session = Depends(get_db)):
    """SPD老板仪表板数据（v30调用）"""
    dist = db.query(SpdDistributor).filter(SpdDistributor.id == dist_id).first()
    if not dist:
        raise HTTPException(404, detail=f"经销商 {dist_id} 不存在")

    period = datetime.now().strftime("%Y-%m")
    perf = db.query(SpdPerformance).filter(
        SpdPerformance.dist_id == dist_id,
        SpdPerformance.period == period
    ).first()

    # 核心三数字
    core = {
        "net_profit": perf.net_profit if perf else 0,
        "net_profit_target": perf.revenue_target * 0.08 if perf else 0,
        "roi_annual": perf.roi_annual if perf else 0,
        "team_health": 72,   # TODO: 接入团队考核数据
        "revenue_growth": perf.growth_rate if perf else 0,
        "digest_rate": perf.digest_rate if perf else 0,
    }

    # 获取实时库存预警
    heartbeats = db.execute(text("""
        SELECT h.node_id, h.sku_code, h.water_level, h.water_status, h.digest_rate
        FROM inf_heartbeat h
        JOIN inf_nodes n ON h.node_id = n.node_id
        WHERE n.parent_id = :dist_id
          AND h.data_date = CURDATE() - INTERVAL 1 DAY
        ORDER BY h.water_level DESC
        LIMIT 20
    """), {"dist_id": dist_id}).fetchall()

    # 生成待办事项
    todos = _build_todos(dist_id, [dict(r._mapping) for r in heartbeats], perf)

    # P&L
    pl = {
        "revenue":       perf.revenue_actual if perf else 0,
        "cogs":          perf.revenue_actual * 0.70 if perf else 0,
        "gross_profit":  perf.gross_profit if perf else 0,
        "team_cost":     19800,   # TODO: 接入薪酬数据
        "warehouse_cost": 12000,
        "rebate_est":    1400,
        "net_profit":    perf.net_profit if perf else 0,
    }

    # ROI
    roi = {
        "inventory_capital": perf.inventory_value if perf else 0,
        "dist_investment":   69000,
        "xinhe_injection":   81600,
        "quarterly_revenue": (perf.revenue_actual or 0) * 3,
        "quarterly_net":     (perf.net_profit or 0) * 3,
    }

    # 铁律状态
    iron_laws = {
        "iron1": True,
        "iron3": (perf.digest_rate or 0) >= 0.65,
        "digest_rate": perf.digest_rate if perf else 0,
    }

    return {
        "dist_id": dist_id,
        "owner_name": dist.owner_name,
        "period": period,
        "core": core,
        "todos": todos,
        "pl": pl,
        "roi": roi,
        "iron_laws": iron_laws,
    }

def _build_todos(dist_id: str, heartbeats: List[Dict], perf) -> List[Dict]:
    todos = []
    # 检查压货预警
    overflow = [h for h in heartbeats if h.get("water_status") == "overflow"]
    if overflow:
        todos.append({
            "type": "alert",
            "priority": "urgent",
            "title": f"库存预警·{overflow[0]['sku_code']}",
            "desc": f"库存{overflow[0]['water_level']:.1f}a超满仓·已暂停推单",
            "action": "view_alert"
        })
    # Omakase推单待确认
    todos.append({
        "type": "omakase",
        "priority": "urgent",
        "title": "本周补货推单待确认",
        "desc": "系统已计算推单方案，请确认",
        "action": "confirm_order"
    })
    # 铁律③警告
    if perf and perf.digest_rate < 0.65:
        todos.append({
            "type": "iron_law",
            "priority": "normal",
            "title": "铁律③·消化率偏低",
            "desc": f"当前消化率{perf.digest_rate:.0%}·目标65%以上",
            "action": "view_report"
        })
    return todos[:3]  # 最多3条

# ── 心跳系统API ───────────────────────────────────────────
@app.get("/api/heartbeat/{node_id}")
def get_node_heartbeat(node_id: str, date_str: Optional[str] = None, db: Session = Depends(get_db)):
    """获取节点心跳数据"""
    target_date = date_str or (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
    rows = db.execute(text("""
        SELECT node_id, sku_code, r_actual, r_target, a_unit,
               inventory_actual, water_level, water_status, digest_rate
        FROM inf_heartbeat
        WHERE node_id = :node_id AND data_date = :date
    """), {"node_id": node_id, "date": target_date}).fetchall()
    return {"node_id": node_id, "date": target_date,
            "heartbeats": [dict(r._mapping) for r in rows]}

@app.post("/api/heartbeat/calculate")
def calculate_heartbeat(node_id: str, sku_code: str, r_actual: float,
                         inventory: float, t_period: int = 30,
                         node_type: str = "store", db: Session = Depends(get_db)):
    """实时计算心跳指标"""
    result = velocity_engine.calculate_heartbeat(r_actual, inventory, t_period, node_type)
    return {"node_id": node_id, "sku_code": sku_code, **result}

# ── Omakase推单API ────────────────────────────────────────
@app.get("/api/omakase/{dist_id}")
def get_omakase_order(dist_id: str, db: Session = Depends(get_db)):
    """获取经销商本周Omakase推单方案"""
    rows = db.execute(text("""
        SELECT h.node_id, h.sku_code, h.r_actual, h.inventory_actual,
               h.water_level, h.water_status, h.t_period
        FROM inf_heartbeat h
        JOIN inf_nodes n ON h.node_id = n.node_id
        WHERE n.parent_id = :dist_id
          AND h.data_date = CURDATE() - INTERVAL 1 DAY
    """), {"dist_id": dist_id}).fetchall()
    skus = [dict(r._mapping) for r in rows]
    orders = velocity_engine.calculate_omakase_order(dist_id, skus)
    total_qty = sum(o.get("order_qty", 0) for o in orders)
    return {
        "dist_id": dist_id,
        "generated_at": datetime.now().isoformat(),
        "orders": orders,
        "total_qty": total_qty,
        "status": "pending_confirmation"
    }

# ── 蝴蝶效应API ───────────────────────────────────────────
@app.get("/api/butterfly/scan")
def scan_butterfly(city: Optional[str] = None, db: Session = Depends(get_db)):
    """全链蝴蝶效应扫描"""
    query = """
        SELECT h.node_id, h.sku_code, h.water_level, h.water_status,
               h.digest_rate, h.r_actual, h.r_target
        FROM inf_heartbeat h
        JOIN inf_nodes n ON h.node_id = n.node_id
        WHERE h.data_date = CURDATE() - INTERVAL 1 DAY
    """
    params = {}
    if city:
        query += " AND n.city = :city"
        params["city"] = city
    rows = db.execute(text(query), params).fetchall()
    heartbeats = [dict(r._mapping) for r in rows]
    alerts = velocity_engine.detect_butterfly_effect(heartbeats)
    return {
        "scanned_at": datetime.now().isoformat(),
        "total_nodes": len(heartbeats),
        "alerts": alerts,
        "alert_count": len(alerts)
    }

# ── 定时任务 ──────────────────────────────────────────────
def daily_butterfly_scan():
    """每天07:00蝴蝶效应扫描"""
    log.info("[蝴蝶效应] 开始每日扫描...")
    db = SessionLocal()
    try:
        rows = db.execute(text("""
            SELECT h.node_id, h.sku_code, h.water_level, h.water_status,
                   h.digest_rate, h.r_actual, h.r_target
            FROM inf_heartbeat h
            WHERE h.data_date = CURDATE() - INTERVAL 1 DAY
        """)).fetchall()
        alerts = velocity_engine.detect_butterfly_effect([dict(r._mapping) for r in rows])
        log.info(f"[蝴蝶效应] 扫描完成，发现 {len(alerts)} 条预警")
        # TODO: 推送企微预警
    finally:
        db.close()

def daily_omakase_push():
    """每天08:00Omakase推单计算"""
    log.info("[Omakase] 开始每日推单计算...")
    # TODO: 遍历所有活跃经销商，计算推单，推送企微
    log.info("[Omakase] 推单完成")

@app.on_event("startup")
def startup():
    scheduler = BackgroundScheduler()
    scheduler.add_job(daily_butterfly_scan, CronTrigger(hour=7,  minute=0))
    scheduler.add_job(daily_omakase_push,   CronTrigger(hour=8,  minute=0))
    scheduler.start()
    log.info("[定时任务] 业务调度器已启动")

@app.get("/health")
def health():
    return {"status": "ok", "service": "infinity-backend", "version": "1.0.0-python"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
