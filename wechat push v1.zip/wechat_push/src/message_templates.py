"""
4类消息模板 · 文本生成器

输入:Alert/Action/Report对象
输出:Markdown字符串 或 卡片dict

设计原则:
  · 视觉一致(═══分隔)
  · 信息分层(标题→数字→证据→行动)
  · 可操作(带按钮/URL)
"""
from datetime import date, datetime
from typing import Optional


# ============ 模板1 · 蝴蝶预警 ============

DISTORTION_ICONS = {
    "A": ("📦", "压货失真"),
    "B": ("🎁", "促销扰动"),
    "C": ("🚨", "窜货失真"),
    "D": ("📋", "战略扰动"),
}

SEVERITY_ICONS = {
    "CRITICAL": "🚨",
    "HIGH": "⚠️",
    "MEDIUM": "💡",
    "LOW": "ℹ️",
}


def format_butterfly_alert(
    distortion_type: str,
    severity: str,
    node_code: str,
    node_name: str,
    sku_code: str,
    water_level: float,
    description: str,
    recommended_action: str,
    detail_url: str,
    evidence: dict = None,
) -> str:
    """
    蝴蝶预警 · Markdown
    """
    icon, type_name = DISTORTION_ICONS.get(distortion_type, ("⚠️", "未知"))
    sev_icon = SEVERITY_ICONS.get(severity, "⚠️")
    
    md = f"""**{sev_icon} INFINITY OS · {icon}{type_name}预警**

📍 节点:`{node_code}` · {node_name}
📦 SKU:`{sku_code}`
💧 水位:**{water_level}a**
⚠️ 严重程度:**{severity}**

📊 详情:
{description}

💡 建议动作:
{recommended_action}

🔗 [查看详情]({detail_url})"""
    
    return md


# ============ 模板2 · Omakase推单 ============

def format_omakase_text(
    node_code: str,
    node_name: str,
    sku_code: str,
    qty: int,
    amount: float,
    inventory: float,
    water_level: float,
    a_unit: float,
    safety_factor: float,
    status: str,
    detail_url: str,
) -> str:
    """
    Omakase推单 · 文本版(简化)
    """
    target_inv = 3 * a_unit
    gap = target_inv - inventory
    
    auto_or_pending = "✅ 自动批准" if status == "APPROVED" else "⏳ 待审批"
    
    md = f"""**🍱 INFINITY OS · Omakase推单**

📍 经销商:`{node_code}` · {node_name}
📦 SKU:`{sku_code}`
📊 当前库存:{inventory}瓶 (水位{water_level}a)

💡 建议补货:**{qty}瓶**
💰 预估金额:**¥{amount:,.0f}**

📈 计算依据:
- 目标库存:{target_inv:.0f}瓶 (3a)
- 缺口:{gap:.0f}瓶
- 安全系数:×{safety_factor} = {qty}瓶

⚡ 状态:{auto_or_pending}

🔗 [查看详情]({detail_url})"""
    
    return md


def build_omakase_card(
    action_code: str,
    node_code: str,
    node_name: str,
    sku_code: str,
    qty: int,
    amount: float,
    inventory: float,
    water_level: float,
    status: str,
    detail_url: str,
) -> dict:
    """
    Omakase推单 · 模板卡片(可交互)
    """
    title_prefix = "🍱 推单" if status == "APPROVED" else "🍱 推单待审"
    
    if status == "APPROVED":
        # 经销商收到 · 确认/调整/拒绝
        buttons = [
            {"text": "✅ 确认订货", "type": 1, "key": f"confirm_{action_code}"},
            {"text": "✏️ 调整数量", "type": 1, "key": f"adjust_{action_code}"},
            {"text": "❌ 拒绝", "type": 1, "key": f"reject_{action_code}"},
        ]
    else:
        # DOM收到 · 批准/驳回
        buttons = [
            {"text": "✅ 批准", "type": 1, "key": f"approve_{action_code}"},
            {"text": "❌ 驳回", "type": 1, "key": f"deny_{action_code}"},
            {"text": "🔍 完整分析", "type": 0, "url": detail_url},
        ]
    
    return {
        "card_type": "button_interaction",
        "main_title": {
            "title": f"{title_prefix} · ¥{amount:,.0f}",
            "desc": f"{node_name} · {sku_code}",
        },
        "horizontal_content_list": [
            {"keyname": "推单量", "value": f"{qty}瓶"},
            {"keyname": "当前库存", "value": f"{inventory:.0f}瓶"},
            {"keyname": "水位", "value": f"{water_level}a"},
        ],
        "card_action": {"type": 1, "url": detail_url},
        "button_list": buttons,
    }


# ============ 模板3 · 校准报告 ============

def format_calibration_report(
    auto_approved: int,
    needs_review: int,
    failed: int,
    duration_ms: int,
    top_reviews: list = None,
    detail_url: str = "",
) -> str:
    """A值校准 · 周报"""
    md = f"""**📊 INFINITY OS · 周一校准报告**
{date.today()}

【总览】
- ✅ 自动通过:**{auto_approved}** 个组合
- ⚠️ 待审核:**{needs_review}** 个组合
- ❌ 失败:{failed} 个组合
- ⏱️ 总耗时:{duration_ms/1000:.1f}秒
"""
    
    if top_reviews:
        md += "\n【待审核 TOP 5】\n"
        for i, item in enumerate(top_reviews[:5], 1):
            old_r = item.get("old_r", 0)
            new_r = item.get("new_r", 0)
            change_pct = ((new_r - old_r) / old_r * 100) if old_r > 0 else 0
            md += f"{i}. `{item['node_code']}` / `{item['sku_code']}`\n"
            md += f"   原r={old_r} → 新r={new_r} (变化{change_pct:+.1f}%)\n\n"
    
    if detail_url:
        md += f"\n[查看完整报告]({detail_url})"
    
    return md


# ============ 模板4 · 系统日报 ============

def format_business_daily_report(
    water_status_dist: dict,
    alerts_by_type: dict,
    omakase_stats: dict,
    needs_attention: list = None,
) -> str:
    """业务日报(给DS)"""
    md = f"""**📊 INFINITY OS · 业务日报**
{date.today()}

【昨日水位状态】
"""
    icons = {"FULL": "🟢", "WARN": "🟡", "LOW": "🔴", "EMPTY": "⚪", "OVERFLOW": "🟠"}
    for status, count in water_status_dist.items():
        icon = icons.get(status, "⚫")
        md += f"- {icon} {status}: {count} 节点\n"
    
    md += "\n【昨日预警】\n"
    type_names = {"A": "A类压货", "B": "B类促销", "C": "C类窜货", "D": "D类战略"}
    for t, name in type_names.items():
        count = alerts_by_type.get(t, 0)
        emoji = "✅" if count == 0 else ("⚠️" if count < 5 else "🚨")
        md += f"- {name}:{count} {emoji}\n"
    
    md += f"""
【昨日Omakase】
- 推单:{omakase_stats.get('total', 0)}笔
- 总额:¥{omakase_stats.get('amount', 0):,.0f}
- 自动批:{omakase_stats.get('auto', 0)}笔
- 待审:{omakase_stats.get('pending', 0)}笔
"""
    
    if needs_attention:
        md += "\n【需关注】\n"
        for item in needs_attention:
            md += f"- 📍 {item}\n"
    
    return md


def format_system_health_report(
    agents_status: dict,
    quality_check: dict,
    push_stats: dict,
) -> str:
    """系统健康日报(给Tech Lead)"""
    md = f"""**🔧 INFINITY OS · 系统日报**
{date.today()}

【Agent运行】
"""
    for agent_name, info in agents_status.items():
        status = "✅" if info["success"] else "❌"
        md += f"- {status} {agent_name} · {info['time']} · {info['message']}\n"
    
    md += f"""
【数据质量】
- 完整性:{quality_check.get('completeness', 0):.1f}%
- 时效性:{quality_check.get('timeliness', 0):.1f}%
- 合理性:{quality_check.get('reasonable', 0):.1f}%
- 趋势:{quality_check.get('trend', '正常')}

【企微推送】
- 发送:{push_stats.get('sent', 0)}条
- 成功:{push_stats.get('success', 0)}条 ({push_stats.get('success_rate', 0):.1f}%)
- 失败:{push_stats.get('failed', 0)}条
"""
    
    return md
