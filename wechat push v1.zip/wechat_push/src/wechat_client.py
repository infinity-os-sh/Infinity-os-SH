"""
企业微信API客户端 · 核心组件

职责:
  1. access_token管理(自动续期)
  2. 文本消息发送
  3. Markdown消息发送
  4. 模板卡片消息发送(可交互)

文档:https://developer.work.weixin.qq.com/document/path/90235

使用:
  from src.wechat_client import WechatClient
  
  client = WechatClient()
  client.send_text("Hello", to_user="zhangsan")
  client.send_markdown("**Bold**", to_user="zhangsan")
"""
import os
import time
from typing import Optional
import httpx
from loguru import logger


class WechatClient:
    """企业微信API客户端"""
    
    BASE_URL = "https://qyapi.weixin.qq.com/cgi-bin"
    
    def __init__(
        self,
        corp_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        secret: Optional[str] = None,
        enabled: Optional[bool] = None,
    ):
        # 优先用参数·否则从环境变量读
        self.corp_id = corp_id or os.getenv("WECHAT_CORP_ID", "")
        self.agent_id = agent_id or os.getenv("WECHAT_AGENT_ID", "")
        self.secret = secret or os.getenv("WECHAT_SECRET", "")
        self.enabled = enabled if enabled is not None else (
            os.getenv("WECHAT_ENABLED", "false").lower() == "true"
        )
        
        # access_token缓存
        self._access_token: Optional[str] = None
        self._token_expires_at: float = 0
        
        if not self.enabled:
            logger.warning("⚠️ 企微推送已禁用(WECHAT_ENABLED=false)·只打印不发送")
    
    # ============ Token管理 ============
    
    def get_access_token(self) -> str:
        """
        获取access_token(带缓存)
        企微token有效期2小时·这里提前5分钟续期
        """
        now = time.time()
        if self._access_token and now < self._token_expires_at - 300:
            return self._access_token
        
        # 重新获取
        url = f"{self.BASE_URL}/gettoken"
        params = {"corpid": self.corp_id, "corpsecret": self.secret}
        
        with httpx.Client(timeout=10) as client:
            resp = client.get(url, params=params)
            data = resp.json()
        
        if data.get("errcode") != 0:
            raise RuntimeError(f"获取access_token失败: {data}")
        
        self._access_token = data["access_token"]
        self._token_expires_at = now + data.get("expires_in", 7200)
        logger.debug(f"✅ access_token已更新 · 有效至 {self._token_expires_at}")
        
        return self._access_token
    
    # ============ 发送方法 ============
    
    def send_text(
        self,
        content: str,
        to_user: Optional[str] = None,
        to_party: Optional[str] = None,
        to_tag: Optional[str] = None,
    ) -> dict:
        """
        发送文本消息
        
        Args:
            content: 文本内容
            to_user: 接收用户ID(多个用'|'分隔)
            to_party: 接收部门ID
            to_tag: 接收标签ID
        
        Returns:
            企微API响应
        """
        message = {
            "touser": to_user or "",
            "toparty": to_party or "",
            "totag": to_tag or "",
            "msgtype": "text",
            "agentid": self.agent_id,
            "text": {"content": content},
            "safe": 0,
        }
        return self._send(message)
    
    def send_markdown(
        self,
        content: str,
        to_user: Optional[str] = None,
        to_party: Optional[str] = None,
    ) -> dict:
        """发送Markdown消息(用于格式化报告)"""
        message = {
            "touser": to_user or "",
            "toparty": to_party or "",
            "msgtype": "markdown",
            "agentid": self.agent_id,
            "markdown": {"content": content},
        }
        return self._send(message)
    
    def send_template_card(
        self,
        card: dict,
        to_user: Optional[str] = None,
        to_party: Optional[str] = None,
    ) -> dict:
        """发送模板卡片消息(用于交互)"""
        message = {
            "touser": to_user or "",
            "toparty": to_party or "",
            "msgtype": "template_card",
            "agentid": self.agent_id,
            "template_card": card,
        }
        return self._send(message)
    
    def _send(self, message: dict) -> dict:
        """实际发送 · 处理token + 错误"""
        if not self.enabled:
            logger.info(f"📨 [DRY-RUN] 消息: {message}")
            return {"errcode": 0, "errmsg": "ok (dry-run)"}
        
        try:
            token = self.get_access_token()
            url = f"{self.BASE_URL}/message/send"
            params = {"access_token": token}
            
            with httpx.Client(timeout=10) as client:
                resp = client.post(url, params=params, json=message)
                data = resp.json()
            
            if data.get("errcode") != 0:
                logger.error(f"❌ 推送失败: {data}")
            else:
                logger.info(f"✅ 推送成功: msgid={data.get('msgid')}")
            
            return data
        
        except Exception as e:
            logger.error(f"❌ 推送异常: {e}")
            return {"errcode": -1, "errmsg": str(e)}


# ============ CLI · 测试用 ============

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="企微推送测试")
    parser.add_argument("--test", action="store_true", help="发测试消息")
    parser.add_argument("--to", help="接收人ID(企微账号)")
    parser.add_argument("--message", default="INFINITY OS 测试消息", help="消息内容")
    args = parser.parse_args()
    
    if args.test:
        client = WechatClient()
        result = client.send_text(args.message, to_user=args.to)
        print(f"结果: {result}")
