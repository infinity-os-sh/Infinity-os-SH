"""
推送服务 · 业务路由层

把"业务事件"翻译成"具体推送":
  · Alert → 按severity路由 → 推给谁 → 用什么模板
  · Action → 按金额路由 → 推给谁 → 带按钮
  · 报告 → 定时推 → 给指定人

使用:
  push = PushService()
  push.send_alert(alert_obj)
  push.send_omakase(action_obj)
  push.send_calibration_report(report_obj)
  push.send_daily_report()
"""
from datetime import date
from typing import Optional
from loguru import logger

from src.wechat_client import WechatClient
from src.recipient_resolver import RecipientResolver
from src.message_templates import (
    format_butterfly_alert,
    format_omakase_text,
    build_omakase_card,
    format_calibration_report,
    format_business_daily_report,
    format_system_health_report,
)


class PushService:
    """推送服务 · 业务路由"""
    
    def __init__(
        self,
        wechat_client: Optional[WechatClient] = None,
        recipient_resolver: Optional[RecipientResolver] = None,
    ):
        self.wechat = wechat_client or WechatClient()
        self.resolver = recipient_resolver or RecipientResolver()
    
    # ============ 蝴蝶预警推送 ============
    
    def send_alert(self, alert) -> dict:
        """
        蝴蝶预警 · 按severity路由
        
        Args:
            alert: Alert对象 · 至少包含
                   distortion_type, severity, node_code, node_name,
                   sku_code, water_level, description,
                   recommended_action, alert_code
        """
        # 路由规则
        recipients = self._get_alert_recipients(alert.severity)
        if not recipients:
            logger.info(f"预警 {alert.alert_code} 无需推送(severity={alert.severity})")
            return {"errcode": 0, "errmsg": "no recipients"}
        
        # 生成消息
        detail_url = f"https://infinity-os.../alert/{alert.alert_code}"
        content = format_butterfly_alert(
            distortion_type=alert.distortion_type,
            severity=alert.severity,
            node_code=getattr(alert, "node_code", str(alert.node_id)),
            node_name=getattr(alert, "node_name", ""),
            sku_code=alert.sku_code,
            water_level=float(getattr(alert, "water_level", 0)),
            description=alert.description or "",
            recommended_action=alert.recommended_action or "",
            detail_url=detail_url,
        )
        
        # 推送
        to_user = self.resolver.resolve_users(recipients)
        return self.wechat.send_markdown(content, to_user=to_user)
    
    def _get_alert_recipients(self, severity: str) -> list[str]:
        """按severity决定收件人"""
        if severity == "CRITICAL":
            return ["DOM_team", "business_director", "DS"]
        if severity == "HIGH":
            return ["DOM_team", "regional_managers"]
        if severity == "MEDIUM":
            return ["DOM_team"]  # 实际应进入"汇总队列"·此处简化
        # INFO不推
        return []
    
    # ============ Omakase推单推送 ============
    
    def send_omakase(self, action) -> dict:
        """
        Omakase推单 · 按金额路由
        
        Args:
            action: Action对象 · 至少包含
                    action_code, node_id/node_code/node_name,
                    sku_code, recommended_amount, status,
                    payload_json
        """
        amount = float(action.recommended_amount or 0)
        payload = action.payload_json or {}
        
        # 决定收件人
        if action.status == "APPROVED" and amount < 50000:
            # 直接推经销商业务员
            recipients = [self.resolver.resolve_distributor_sales(
                getattr(action, "node_code", str(action.node_id))
            )]
            status_type = "approved_to_sales"
        else:
            # 推DOM审批
            recipients = ["DOM_team"]
            status_type = "pending_approval"
        
        # 生成卡片消息
        card = build_omakase_card(
            action_code=action.action_code,
            node_code=getattr(action, "node_code", str(action.node_id)),
            node_name=getattr(action, "node_name", ""),
            sku_code=action.sku_code,
            qty=int(payload.get("qty", 0)),
            amount=amount,
            inventory=float(payload.get("current_inventory", 0)),
            water_level=float(payload.get("water_level", 0)),
            status=action.status,
            detail_url=f"https://infinity-os.../action/{action.action_code}",
        )
        
        # 推送
        to_user = "|".join(recipients) if isinstance(recipients[0], str) and "_" in recipients[0] else self.resolver.resolve_users(recipients)
        return self.wechat.send_template_card(card, to_user=to_user)
    
    # ============ 校准报告推送 ============
    
    def send_calibration_report(self, report) -> dict:
        """A值校准周报"""
        content = format_calibration_report(
            auto_approved=report.auto_approved_count,
            needs_review=report.needs_review_count,
            failed=report.failed_count,
            duration_ms=report.total_duration_ms,
            top_reviews=[
                {
                    "node_code": str(r.node_id),
                    "sku_code": r.sku_code,
                    "old_r": r.old_r,
                    "new_r": r.new_r,
                }
                for r in (report.results or [])
                if r.needs_human_review
            ][:5],
            detail_url="https://infinity-os.../calibration/latest",
        )
        
        to_user = self.resolver.resolve_users(["DS", "tech_lead"])
        return self.wechat.send_markdown(content, to_user=to_user)
    
    # ============ 系统日报推送 ============
    
    def send_business_daily_report(
        self,
        water_status_dist: dict,
        alerts_by_type: dict,
        omakase_stats: dict,
        needs_attention: list = None,
    ) -> dict:
        """业务日报 · 给DS"""
        content = format_business_daily_report(
            water_status_dist=water_status_dist,
            alerts_by_type=alerts_by_type,
            omakase_stats=omakase_stats,
            needs_attention=needs_attention,
        )
        to_user = self.resolver.resolve_users(["DS"])
        return self.wechat.send_markdown(content, to_user=to_user)
    
    def send_system_health_report(
        self,
        agents_status: dict,
        quality_check: dict,
        push_stats: dict,
    ) -> dict:
        """系统健康日报 · 给Tech Lead"""
        content = format_system_health_report(
            agents_status=agents_status,
            quality_check=quality_check,
            push_stats=push_stats,
        )
        to_user = self.resolver.resolve_users(["tech_lead"])
        return self.wechat.send_markdown(content, to_user=to_user)
    
    # ============ 简化API ============
    
    def send_text(self, content: str, to_user: str = None, to_party: str = None) -> dict:
        """简单文本推送"""
        return self.wechat.send_text(content, to_user=to_user, to_party=to_party)
