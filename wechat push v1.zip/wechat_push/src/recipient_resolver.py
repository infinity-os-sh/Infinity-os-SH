"""
收件人解析器 · 把"角色名"翻译成"企微账号"

例如:
  · 输入:["DOM_team"]
  · 输出:["zhangsan|lisi|wangwu"]  # 企微的touser格式
"""
import os
from typing import Optional


# ============ 角色 → 用户ID映射 ============
# 实际部署时·这些应该从配置文件或数据库读取
# 本示例先硬编码 · Tech Lead根据真实账号填写

ROLE_TO_USERS = {
    # 个人角色
    "DS": ["DS_user"],
    "tech_lead": ["TechLead_user"],
    "business_director": ["BizDir_user"],
    
    # 团队
    "DOM_team": ["dom1", "dom2", "dom3"],
    "regional_managers": ["region_east", "region_west", "region_north", "region_south"],
    
    # 区域(动态·按城市)
    # regional_manager_of(city) 在代码中处理
    
    # 经销商业务员(动态·按经销商)
    # distributor_sales(node_code) 在代码中处理
}

# 角色 → 部门ID映射(企微toparty格式)
ROLE_TO_PARTIES = {
    "sales_team": "1",  # 销售部门ID
    "ops_team": "2",    # 运营部门ID
}


class RecipientResolver:
    """收件人解析器"""
    
    def __init__(self, custom_mapping: Optional[dict] = None):
        """
        Args:
            custom_mapping: 自定义映射(覆盖默认)
        """
        self.role_to_users = {**ROLE_TO_USERS, **(custom_mapping or {})}
    
    def resolve_users(self, recipients: list[str]) -> str:
        """
        把角色列表解析为touser字符串
        
        Args:
            recipients: ["DS", "DOM_team", ...]
        
        Returns:
            "DS_user|dom1|dom2|dom3"
        """
        all_users = []
        for role in recipients:
            users = self.role_to_users.get(role, [])
            all_users.extend(users)
        
        # 去重
        unique_users = list(dict.fromkeys(all_users))
        return "|".join(unique_users)
    
    def resolve_parties(self, recipients: list[str]) -> str:
        """解析为部门ID"""
        all_parties = []
        for role in recipients:
            party = ROLE_TO_PARTIES.get(role)
            if party:
                all_parties.append(party)
        return "|".join(all_parties)
    
    def resolve_regional_manager(self, city: str) -> str:
        """根据城市找区域经理(动态)"""
        # TODO: 接入真实城市 → 区域 → 经理的映射
        # 简化:北京/天津→region_north, 上海/杭州→region_east, 等
        city_to_region = {
            "上海": "region_east", "杭州": "region_east", "南京": "region_east",
            "北京": "region_north", "天津": "region_north",
            "广州": "region_south", "深圳": "region_south",
            "成都": "region_west", "重庆": "region_west",
        }
        region = city_to_region.get(city, "region_north")
        return region
    
    def resolve_distributor_sales(self, node_code: str) -> str:
        """根据经销商节点找业务员(动态)"""
        # TODO: 从数据库查询经销商对应的业务员
        # 这里返回一个占位符
        return f"sales_for_{node_code}"
