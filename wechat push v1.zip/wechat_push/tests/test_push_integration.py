"""
集成测试 · 真实推送(需要IT配好企微才能跑)

使用:
  # 配置 .env 后
  pytest tests/test_push_integration.py -v -s
  
  # 或者直接跑(测试模式)
  python tests/test_push_integration.py
"""
import os
import pytest
from src.wechat_client import WechatClient
from src.push_service import PushService
from src.message_templates import (
    format_butterfly_alert,
    format_omakase_text,
    format_calibration_report,
)


def test_template_butterfly_alert():
    """测试蝴蝶预警模板"""
    md = format_butterfly_alert(
        distortion_type="C",
        severity="CRITICAL",
        node_code="DIST_SH_007",
        node_name="上海二批商A",
        sku_code="LYX500",
        water_level=1.8,
        description="二批商水位过高",
        recommended_action="立即检查窜货",
        detail_url="https://infinity-os.../alert/123",
    )
    assert "🚨" in md
    assert "DIST_SH_007" in md
    assert "1.8a" in md
    print("\n=== 蝴蝶预警模板 ===")
    print(md)


def test_template_omakase():
    """测试Omakase推单模板"""
    md = format_omakase_text(
        node_code="DIST_SH_002",
        node_name="上海经销商B",
        sku_code="LYX500",
        qty=59,
        amount=472,
        inventory=50,
        water_level=0.8,
        a_unit=33,
        safety_factor=1.2,
        status="APPROVED",
        detail_url="https://infinity-os.../action/abc",
    )
    assert "🍱" in md
    assert "59瓶" in md
    assert "¥472" in md
    print("\n=== Omakase推单模板 ===")
    print(md)


def test_template_calibration_report():
    """测试校准报告模板"""
    md = format_calibration_report(
        auto_approved=1250,
        needs_review=23,
        failed=2,
        duration_ms=45000,
        top_reviews=[
            {"node_code": "DIST_SH_001", "sku_code": "LYX500", "old_r": 10, "new_r": 15.5},
            {"node_code": "STORE_BJ_023", "sku_code": "LYX1000", "old_r": 8, "new_r": 4.2},
        ],
        detail_url="https://infinity-os.../calibration",
    )
    assert "1250" in md
    assert "DIST_SH_001" in md
    print("\n=== 校准报告模板 ===")
    print(md)


def test_dry_run_send():
    """测试干跑模式 · 不真发"""
    client = WechatClient(
        corp_id="test",
        agent_id="1",
        secret="s",
        enabled=False,  # 干跑
    )
    result = client.send_text("INFINITY OS 测试", to_user="anybody")
    assert result["errcode"] == 0


@pytest.mark.skipif(
    os.getenv("WECHAT_ENABLED", "false").lower() != "true",
    reason="WECHAT_ENABLED未开启·跳过真实推送测试"
)
def test_real_push():
    """真实推送测试 · 需要IT配好企微"""
    test_user = os.getenv("WECHAT_TEST_USER", "")
    if not test_user:
        pytest.skip("未设置WECHAT_TEST_USER环境变量")
    
    client = WechatClient()
    result = client.send_text(
        "🎯 INFINITY OS 推送测试 · 如收到说明配置成功",
        to_user=test_user,
    )
    assert result["errcode"] == 0


if __name__ == "__main__":
    # 直接跑·展示所有模板效果
    test_template_butterfly_alert()
    test_template_omakase()
    test_template_calibration_report()
    test_dry_run_send()
    print("\n✅ 所有模板测试通过")
