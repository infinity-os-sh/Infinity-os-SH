"""
WechatClient 单元测试
"""
import pytest
from unittest.mock import patch, MagicMock
from src.wechat_client import WechatClient


class TestWechatClient:
    
    def test_disabled_dry_run(self):
        """禁用时 · 不真实发送"""
        client = WechatClient(
            corp_id="test_corp",
            agent_id="test_agent",
            secret="test_secret",
            enabled=False,
        )
        result = client.send_text("hello", to_user="zhangsan")
        assert result["errcode"] == 0
        assert "dry-run" in result["errmsg"]
    
    @patch("src.wechat_client.httpx.Client")
    def test_get_access_token(self, mock_client_class):
        """token获取"""
        mock_client = MagicMock()
        mock_client_class.return_value.__enter__.return_value = mock_client
        mock_client.get.return_value.json.return_value = {
            "errcode": 0,
            "access_token": "test_token_123",
            "expires_in": 7200,
        }
        
        client = WechatClient(
            corp_id="test", agent_id="1", secret="s", enabled=True
        )
        token = client.get_access_token()
        assert token == "test_token_123"
    
    @patch("src.wechat_client.httpx.Client")
    def test_send_text_success(self, mock_client_class):
        """文本发送成功"""
        mock_client = MagicMock()
        mock_client_class.return_value.__enter__.return_value = mock_client
        # 模拟token + send两次调用
        mock_client.get.return_value.json.return_value = {
            "errcode": 0,
            "access_token": "tk",
            "expires_in": 7200,
        }
        mock_client.post.return_value.json.return_value = {
            "errcode": 0, "errmsg": "ok", "msgid": "msg_001"
        }
        
        client = WechatClient(
            corp_id="t", agent_id="1", secret="s", enabled=True
        )
        result = client.send_text("hi", to_user="zs")
        assert result["errcode"] == 0
