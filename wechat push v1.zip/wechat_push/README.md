# INFINITY OS · 企微推送包 V1.0

**给:Tech Lead + IT管理员**

让INFINITY OS的Alert · Action · 报告 → 真实推送到企业微信

---

## 📦 包内容

```
wechat_push/
├── README.md                       ← 本文档
├── docs/
│   ├── 企微对接申请书.md            ← 给IT申请权限的模板
│   ├── 推送规则路由表.md            ← 谁收什么·必读
│   └── 消息模板设计.md              ← 4类模板·可视化效果
├── src/
│   ├── wechat_client.py            ← 企微API客户端(核心)
│   ├── push_service.py             ← 推送服务(业务路由)
│   ├── message_templates.py        ← 4类消息模板
│   └── recipient_resolver.py       ← 收件人解析(人/组/标签)
├── config/
│   └── push_rules.yaml             ← 推送规则配置(谁收什么)
└── tests/
    ├── test_wechat_client.py       ← 客户端单测
    └── test_push_integration.py    ← 集成测试·真实发消息
```

---

## 🚀 3步落地(IT配合·1天)

### Step 1 · 申请企微权限(30分钟)
```
打开 docs/企微对接申请书.md
按模板向IT管理员申请:
  · CorpID
  · AgentID(自建应用)
  · Secret
  · 可见范围(哪些部门能收)
```

### Step 2 · 配置.env(5分钟)
```bash
# 在主项目infinity_os/.env中添加
WECHAT_CORP_ID=ww1234567890abcdef
WECHAT_AGENT_ID=1000003
WECHAT_SECRET=xxxxxxxxxxxxxxxxxxxxx
WECHAT_ENABLED=true
```

### Step 3 · 测试推送(15分钟)
```bash
# 给自己发一条测试
python -m src.wechat_client --test --to YourWeChatID

# 跑集成测试
pytest tests/test_push_integration.py -v
```

**3步完成 · 企微推送上线。**

---

## 🎯 4类推送场景

### 场景1 · 蝴蝶预警(自动·实时)
```
触发:周一07:00 · 蝴蝶效应Agent输出预警
推送:
  · CRITICAL → DOM + 业务总 + DS · 立即
  · HIGH → DOM + 区域经理 · 立即
  · MEDIUM → DOM · 汇总后(每天一次)
  · INFO → 不推送·只入库
```

### 场景2 · Omakase推单(自动·按金额分流)
```
触发:周一08:00 · Omakase Agent生成推单
推送:
  · 金额 < 5万 · 直接推经销商业务员(已APPROVED)
  · 金额 ≥ 5万 · 推DOM审批 → 批准后推经销商
```

### 场景3 · A值校准报告(每周一·08:30)
```
触发:校准完成后
推送:
  · 总报告 → DS + Tech Lead · 数字化看板
  · 待审条目 → DOM · 逐条确认
```

### 场景4 · 系统日报(每天·09:00)
```
推送:
  · 给DS · 昨日水位/预警/推单总结
  · 给Tech Lead · 昨日系统运行健康度
```

---

## 🔥 核心能力速查

```python
from src.push_service import PushService

push = PushService()

# 推送单条预警
push.send_alert(alert_id=12345)

# 推送Omakase推单
push.send_omakase(action_id=67890)

# 推送日报
push.send_daily_report()

# 推送给指定人
push.send_text("测试消息", to_user="zhangsan")

# 推送给指定部门
push.send_text("通知", to_party="sales_team")
```

---

## ⚠️ 关键风险

| 风险 | 影响 | 缓解 |
|------|------|------|
| Token过期 | 推送失败 | 自动续期(每7200秒) |
| 单日消息超限 | 部分丢失 | 控制频率·日报合并发送 |
| IT权限不足 | 没法推送 | 申请书完整说明权限范围 |
| 误推送惊扰 | 影响信任 | 灰度·先发DS+Tech Lead小范围验证 |

---

## 📞 常见问题

### Q1 · 没有企微账号怎么办?
```
方案:配置WECHAT_ENABLED=false
推送会写日志·不真实发出
等IT配置好再切真实模式
```

### Q2 · 怎么知道推送成功了?
```
1. wechat_client.py返回的errcode=0 → 成功
2. 用户企微App会立刻收到
3. INFINITY OS会写inf_actions.outcome_json记录推送结果
```

### Q3 · 推送内容怎么改?
```
打开 src/message_templates.py
4类模板 · 直接改文本
不改逻辑·只改文案
```

---

**FROM:** DS  
**TO:** Tech Lead + IT  
**2026-04-22**
