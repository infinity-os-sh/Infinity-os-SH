// ============================================================
// ToolExecutor.java
// 工具执行器：接收Claude的tool_use请求，路由到对应系统
// 这是第4层的"神经系统"——Claude说要调什么，这里负责真正去调
// ============================================================
package com.xinhe.infinityos.tools.executor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xinhe.infinityos.tools.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class ToolExecutor {

    private static final Logger log = LoggerFactory.getLogger(ToolExecutor.class);

    @Autowired private ErpService       erpService;
    @Autowired private CrmService       crmService;
    @Autowired private ScmService       scmService;
    @Autowired private WechatService    wechatService;
    @Autowired private MemoryToolService memoryToolService;
    @Autowired private ObjectMapper     objectMapper;

    /**
     * 核心路由方法
     * Claude返回 tool_use 块时调用此方法
     *
     * @param toolName  Claude决定调用的工具名
     * @param toolInput Claude提供的参数（JSON Map）
     * @return 工具执行结果（JSON字符串，回传给Claude继续推理）
     */
    public String execute(String toolName, Map<String, Object> toolInput) {
        log.info("[工具调用] {} | 参数: {}", toolName, toolInput);

        try {
            String result = switch (toolName) {

                // ── ERP ──────────────────────────────────────
                case "erp_query_inventory" ->
                    erpService.queryInventory(
                        str(toolInput, "entity_id"),
                        str(toolInput, "entity_type"),
                        listOf(toolInput, "sku_ids")
                    );

                case "erp_query_sales_velocity" ->
                    erpService.querySalesVelocity(
                        str(toolInput, "entity_id"),
                        intOf(toolInput, "days", 30),
                        str(toolInput, "sku_id")
                    );

                case "erp_query_production" ->
                    erpService.queryProduction(
                        str(toolInput, "sku_id"),
                        str(toolInput, "date_range")
                    );

                case "erp_write_order" ->
                    erpService.writeOrder(
                        str(toolInput, "distributor_id"),
                        listMapOf(toolInput, "order_lines"),
                        str(toolInput, "notes")
                    );

                // ── CRM ──────────────────────────────────────
                case "crm_query_distributor" ->
                    crmService.queryDistributor(
                        str(toolInput, "distributor_id"),
                        listOf(toolInput, "fields")
                    );

                case "crm_query_store" ->
                    crmService.queryStore(
                        str(toolInput, "store_id"),
                        str(toolInput, "city_code")
                    );

                case "crm_query_beauty_advisor" ->
                    crmService.queryBeautyAdvisor(
                        str(toolInput, "ba_id"),
                        str(toolInput, "store_id"),
                        doubleOf(toolInput, "min_cb", 0.0)
                    );

                case "crm_update_score" ->
                    crmService.updateScore(
                        str(toolInput, "person_id"),
                        str(toolInput, "score_type"),
                        doubleOf(toolInput, "delta", 0.0),
                        str(toolInput, "reason")
                    );

                // ── SCM ──────────────────────────────────────
                case "scm_query_logistics" ->
                    scmService.queryLogistics(
                        str(toolInput, "distributor_id"),
                        str(toolInput, "order_id")
                    );

                case "scm_query_supply_risk" ->
                    scmService.querySupplyRisk(
                        str(toolInput, "sku_id"),
                        intOf(toolInput, "horizon_days", 30)
                    );

                // ── 企业微信 ──────────────────────────────────
                case "wechat_push_alert" ->
                    wechatService.pushAlert(
                        str(toolInput, "recipient_id"),
                        str(toolInput, "message_type"),
                        str(toolInput, "title"),
                        str(toolInput, "content"),
                        str(toolInput, "action_url")
                    );

                case "wechat_create_task" ->
                    wechatService.createTask(
                        str(toolInput, "assignee_id"),
                        str(toolInput, "store_id"),
                        str(toolInput, "task_type"),
                        str(toolInput, "description"),
                        str(toolInput, "due_time"),
                        intOf(toolInput, "reward_points", 0)
                    );

                // ── 记忆层 ────────────────────────────────────
                case "memory_query" ->
                    memoryToolService.query(
                        str(toolInput, "entity_id"),
                        str(toolInput, "event_type"),
                        intOf(toolInput, "days", 30)
                    );

                case "memory_write_event" ->
                    memoryToolService.writeEvent(
                        str(toolInput, "entity_id"),
                        str(toolInput, "entity_name"),
                        str(toolInput, "event_type"),
                        mapOf(toolInput, "event_data"),
                        intOf(toolInput, "severity", 3)
                    );

                default -> toJson(Map.of(
                    "error", "未知工具: " + toolName,
                    "status", "failed"
                ));
            };

            log.info("[工具结果] {} | 成功", toolName);
            return result;

        } catch (Exception e) {
            log.error("[工具执行失败] {} | {}", toolName, e.getMessage(), e);
            return toJson(Map.of(
                "error", e.getMessage(),
                "tool",  toolName,
                "status", "failed"
            ));
        }
    }

    // ── 参数提取工具方法 ──────────────────────────────────────

    private String str(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v != null ? v.toString() : null;
    }

    private int intOf(Map<String, Object> map, String key, int def) {
        Object v = map.get(key);
        if (v == null) return def;
        return v instanceof Number n ? n.intValue() : Integer.parseInt(v.toString());
    }

    private double doubleOf(Map<String, Object> map, String key, double def) {
        Object v = map.get(key);
        if (v == null) return def;
        return v instanceof Number n ? n.doubleValue() : Double.parseDouble(v.toString());
    }

    @SuppressWarnings("unchecked")
    private java.util.List<String> listOf(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v instanceof java.util.List ? (java.util.List<String>) v : java.util.List.of();
    }

    @SuppressWarnings("unchecked")
    private java.util.List<Map<String, Object>> listMapOf(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v instanceof java.util.List ? (java.util.List<Map<String, Object>>) v : java.util.List.of();
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> mapOf(Map<String, Object> map, String key) {
        Object v = map.get(key);
        return v instanceof Map ? (Map<String, Object>) v : Map.of();
    }

    private String toJson(Object obj) {
        try { return objectMapper.writeValueAsString(obj); }
        catch (Exception e) { return "{\"error\":\"json序列化失败\"}"; }
    }
}
