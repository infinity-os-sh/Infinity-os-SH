// ============================================================
// ToolDefinitions.java
// Claude Tool Use 工具定义
// 这里定义的每一个Tool，Claude会自主判断何时调用
// ============================================================
package com.xinhe.infinityos.tools.definition;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ToolDefinitions {

    // ══════════════════════════════════════════════════════════
    // ERP 工具组
    // ══════════════════════════════════════════════════════════

    public static Map<String, Object> ERP_QUERY_INVENTORY = Map.of(
        "name", "erp_query_inventory",
        "description", "查询ERP系统中某门店或经销商的实时库存数据，包括货架量、仓库量、在途量",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "entity_id",   Map.of("type", "string", "description", "门店ID或经销商ID"),
                "entity_type", Map.of("type", "string", "enum", List.of("store","distributor","sub_dist")),
                "sku_ids",     Map.of("type", "array",  "items", Map.of("type","string"),
                                     "description", "SKU列表，为空则查全部")
            ),
            "required", List.of("entity_id", "entity_type")
        )
    );

    public static Map<String, Object> ERP_QUERY_SALES_VELOCITY = Map.of(
        "name", "erp_query_sales_velocity",
        "description", "查询ERP中某实体的销售速率r值，支持指定时间范围",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "entity_id",  Map.of("type", "string"),
                "days",       Map.of("type", "integer", "description", "查询最近N天，默认30"),
                "sku_id",     Map.of("type", "string",  "description", "不填则返回全品")
            ),
            "required", List.of("entity_id")
        )
    );

    public static Map<String, Object> ERP_QUERY_PRODUCTION = Map.of(
        "name", "erp_query_production",
        "description", "查询工厂生产计划、产能利用率、发货计划",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "sku_id",     Map.of("type", "string"),
                "date_range", Map.of("type", "string", "description", "格式: 2025-01-01,2025-01-31")
            ),
            "required", List.of()
        )
    );

    public static Map<String, Object> ERP_WRITE_ORDER = Map.of(
        "name", "erp_write_order",
        "description", "向ERP写入补货订单（待确认状态），触发经销商确认流程",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "distributor_id", Map.of("type", "string"),
                "order_lines",    Map.of("type", "array", "items", Map.of(
                    "type", "object",
                    "properties", Map.of(
                        "sku_id",   Map.of("type", "string"),
                        "quantity", Map.of("type", "integer"),
                        "unit",     Map.of("type", "string", "description", "箱/瓶")
                    )
                )),
                "notes",          Map.of("type", "string", "description", "备注")
            ),
            "required", List.of("distributor_id", "order_lines")
        )
    );

    // ══════════════════════════════════════════════════════════
    // CRM 工具组
    // ══════════════════════════════════════════════════════════

    public static Map<String, Object> CRM_QUERY_DISTRIBUTOR = Map.of(
        "name", "crm_query_distributor",
        "description", "查询经销商CRM档案：基本信息、合作年限、历史业绩、信用评级、联系人",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "distributor_id", Map.of("type", "string"),
                "fields",         Map.of("type", "array", "items", Map.of("type","string"),
                                        "description", "指定返回字段，为空返回全部")
            ),
            "required", List.of("distributor_id")
        )
    );

    public static Map<String, Object> CRM_QUERY_STORE = Map.of(
        "name", "crm_query_store",
        "description", "查询门店CRM档案：等级、地址、负责DSR、历史动销、拜访记录",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "store_id",   Map.of("type", "string"),
                "city_code",  Map.of("type", "string", "description", "按城市批量查询")
            ),
            "required", List.of()
        )
    );

    public static Map<String, Object> CRM_QUERY_BEAUTY_ADVISOR = Map.of(
        "name", "crm_query_beauty_advisor",
        "description", "查询美顾档案：类型(全职/兼职/外包)、CB分、AIQL评分、负责门店、本月任务完成率",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "ba_id",      Map.of("type", "string"),
                "store_id",   Map.of("type", "string", "description", "查某门店的美顾"),
                "min_cb",     Map.of("type", "number",  "description", "CB分最低阈值过滤")
            ),
            "required", List.of()
        )
    );

    public static Map<String, Object> CRM_UPDATE_SCORE = Map.of(
        "name", "crm_update_score",
        "description", "更新美顾或DSR的CB分、AIQL分（Uber激励Agent专用）",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "person_id",  Map.of("type", "string"),
                "score_type", Map.of("type", "string", "enum", List.of("cb_score","aiql_score")),
                "delta",      Map.of("type", "number",  "description", "变化量，正负均可"),
                "reason",     Map.of("type", "string")
            ),
            "required", List.of("person_id", "score_type", "delta", "reason")
        )
    );

    // ══════════════════════════════════════════════════════════
    // SCM 工具组
    // ══════════════════════════════════════════════════════════

    public static Map<String, Object> SCM_QUERY_LOGISTICS = Map.of(
        "name", "scm_query_logistics",
        "description", "查询在途物流：发货单、预计到货时间、当前位置",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "distributor_id", Map.of("type", "string"),
                "order_id",       Map.of("type", "string")
            ),
            "required", List.of()
        )
    );

    public static Map<String, Object> SCM_QUERY_SUPPLY_RISK = Map.of(
        "name", "scm_query_supply_risk",
        "description", "查询供应链风险：原材料库存、供应商交货期、断供预警",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "sku_id",    Map.of("type", "string"),
                "horizon_days", Map.of("type", "integer", "description", "预测未来N天，默认30")
            ),
            "required", List.of()
        )
    );

    // ══════════════════════════════════════════════════════════
    // 企业微信 工具组
    // ══════════════════════════════════════════════════════════

    public static Map<String, Object> WECHAT_PUSH_ALERT = Map.of(
        "name", "wechat_push_alert",
        "description", "发送企业微信消息给指定人员或群组，用于预警通知、任务派发、日报推送",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "recipient_id",  Map.of("type", "string",  "description", "员工ID或群ID"),
                "message_type",  Map.of("type", "string",  "enum",
                                        List.of("alert","task","report","info")),
                "title",         Map.of("type", "string"),
                "content",       Map.of("type", "string"),
                "action_url",    Map.of("type", "string",  "description", "点击跳转链接，可选")
            ),
            "required", List.of("recipient_id", "message_type", "title", "content")
        )
    );

    public static Map<String, Object> WECHAT_CREATE_TASK = Map.of(
        "name", "wechat_create_task",
        "description", "在企业微信中为美顾或DSR创建任务（Uber激励Agent专用）",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "assignee_id",   Map.of("type", "string"),
                "store_id",      Map.of("type", "string"),
                "task_type",     Map.of("type", "string",
                                        "description", "shelf_scan/promotion/sampling/display"),
                "description",   Map.of("type", "string"),
                "due_time",      Map.of("type", "string",  "description", "截止时间 ISO8601"),
                "reward_points", Map.of("type", "integer", "description", "完成奖励CB积分")
            ),
            "required", List.of("assignee_id", "store_id", "task_type", "description")
        )
    );

    // ══════════════════════════════════════════════════════════
    // 记忆层 工具组（Agent互相读写记忆）
    // ══════════════════════════════════════════════════════════

    public static Map<String, Object> MEMORY_QUERY = Map.of(
        "name", "memory_query",
        "description", "查询某实体的历史记忆事件，用于判断是否重复发生、趋势判断",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "entity_id",  Map.of("type", "string"),
                "event_type", Map.of("type", "string", "description", "不填则返回所有类型"),
                "days",       Map.of("type", "integer", "description", "查近N天，默认30")
            ),
            "required", List.of("entity_id")
        )
    );

    public static Map<String, Object> MEMORY_WRITE_EVENT = Map.of(
        "name", "memory_write_event",
        "description", "向记忆层写入新事件，用于记录Agent的检测结果",
        "input_schema", Map.of(
            "type", "object",
            "properties", Map.of(
                "entity_id",   Map.of("type", "string"),
                "entity_name", Map.of("type", "string"),
                "event_type",  Map.of("type", "string"),
                "event_data",  Map.of("type", "object"),
                "severity",    Map.of("type", "integer", "description", "1-5")
            ),
            "required", List.of("entity_id", "entity_name", "event_type", "event_data", "severity")
        )
    );

    // ══════════════════════════════════════════════════════════
    // 工具集合：按Agent分组
    // ══════════════════════════════════════════════════════════

    /** 蝴蝶效应Agent的工具集 */
    public static List<Map<String, Object>> BUTTERFLY_TOOLS = List.of(
        ERP_QUERY_INVENTORY,
        ERP_QUERY_SALES_VELOCITY,
        MEMORY_QUERY,
        MEMORY_WRITE_EVENT,
        WECHAT_PUSH_ALERT
    );

    /** 无菜单推单Agent的工具集 */
    public static List<Map<String, Object>> OMAKASE_TOOLS = List.of(
        ERP_QUERY_INVENTORY,
        ERP_QUERY_SALES_VELOCITY,
        CRM_QUERY_DISTRIBUTOR,
        ERP_WRITE_ORDER,
        MEMORY_QUERY,
        WECHAT_PUSH_ALERT
    );

    /** Uber激励Agent的工具集 */
    public static List<Map<String, Object>> UBER_TOOLS = List.of(
        CRM_QUERY_BEAUTY_ADVISOR,
        CRM_QUERY_STORE,
        CRM_UPDATE_SCORE,
        WECHAT_CREATE_TASK,
        MEMORY_QUERY
    );

    /** AIO总指挥的工具集（全量） */
    public static List<Map<String, Object>> COMMANDER_TOOLS = List.of(
        ERP_QUERY_INVENTORY,
        ERP_QUERY_SALES_VELOCITY,
        ERP_QUERY_PRODUCTION,
        CRM_QUERY_DISTRIBUTOR,
        CRM_QUERY_STORE,
        SCM_QUERY_SUPPLY_RISK,
        WECHAT_PUSH_ALERT,
        MEMORY_QUERY,
        MEMORY_WRITE_EVENT
    );
}
