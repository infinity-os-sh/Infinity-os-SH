// ============================================================
// AgentController.java
// REST API：前端/定时任务触发Agent执行
// ============================================================
package com.xinhe.infinityos.tools.controller;

import com.xinhe.infinityos.tools.service.AgentOrchestrationService;
import com.xinhe.infinityos.tools.service.AgentOrchestrationService.AgentResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/agents")
@CrossOrigin(origins = "*") // 允许INFINITY OS前端跨域调用
public class AgentController {

    @Autowired
    private AgentOrchestrationService orchestrationService;

    // ── 通用对话接口 ─────────────────────────────────────────

    /**
     * POST /api/agents/chat
     * 前端INFINITY OS界面调用（替换当前直接调Claude API的方式）
     * 现在Agent可以真正查ERP/CRM/SCM了
     */
    @PostMapping("/chat")
    public ResponseEntity<Map<String, Object>> chat(@RequestBody Map<String, String> body) {
        String agentId   = body.getOrDefault("agent_id",    "butterfly");
        String entityId  = body.getOrDefault("entity_id",   "");
        String question  = body.getOrDefault("question",    "");

        AgentResponse resp = orchestrationService.executeAgent(agentId, entityId, question);

        return ResponseEntity.ok(Map.of(
            "success",        resp.isSuccess(),
            "agent_id",       resp.getAgentId(),
            "answer",         resp.isSuccess() ? resp.getAnswer() : resp.getErrorMessage(),
            "tool_calls",     resp.getToolCallCount(),
            "has_real_data",  resp.getToolCallCount() > 0
        ));
    }

    // ── 蝴蝶效应触发 ─────────────────────────────────────────

    /**
     * POST /api/agents/butterfly/check
     * 触发单个经销商的蝴蝶效应检测
     */
    @PostMapping("/butterfly/check")
    public ResponseEntity<Map<String, Object>> butterflyCheck(
            @RequestBody Map<String, String> body) {

        String distributorId = body.get("distributor_id");
        AgentResponse resp = orchestrationService.runButterflyCheck(distributorId);
        return buildResponse(resp);
    }

    /**
     * POST /api/agents/butterfly/batch-check
     * 批量检测（由AIO总指挥或定时任务触发）
     */
    @PostMapping("/butterfly/batch-check")
    public ResponseEntity<Map<String, Object>> butterflyBatchCheck(
            @RequestBody Map<String, Object> body) {
        // TODO: 遍历所有经销商，并行执行蝴蝶效应检测
        // 建议使用 CompletableFuture 并行处理
        return ResponseEntity.ok(Map.of(
            "status",  "accepted",
            "message", "批量检测任务已提交，结果将通过企业微信推送"
        ));
    }

    // ── 无菜单推单触发 ───────────────────────────────────────

    /**
     * POST /api/agents/omakase/push
     * 触发经销商补货推单
     */
    @PostMapping("/omakase/push")
    public ResponseEntity<Map<String, Object>> omakasePush(
            @RequestBody Map<String, String> body) {

        String distributorId = body.get("distributor_id");
        AgentResponse resp = orchestrationService.runOmakasePush(distributorId);
        return buildResponse(resp);
    }

    // ── Uber激励任务派发 ─────────────────────────────────────

    /**
     * POST /api/agents/uber/dispatch
     * 为门店派发美顾任务
     */
    @PostMapping("/uber/dispatch")
    public ResponseEntity<Map<String, Object>> uberDispatch(
            @RequestBody Map<String, String> body) {

        String storeId = body.get("store_id");
        AgentResponse resp = orchestrationService.dispatchBeautyAdvisorTasks(storeId);
        return buildResponse(resp);
    }

    // ── 健康检查 ─────────────────────────────────────────────

    /**
     * GET /api/agents/health
     * 检查工具层连通性
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        return ResponseEntity.ok(Map.of(
            "status",          "UP",
            "layer",           "第4层 - 调用能力",
            "erp_connected",   false, // TODO: 实际ping ERP
            "crm_connected",   false,
            "scm_connected",   false,
            "wechat_connected", false,
            "mock_mode",       true,
            "memory_layer",    "active"
        ));
    }

    // ── 工具方法 ─────────────────────────────────────────────

    private ResponseEntity<Map<String, Object>> buildResponse(AgentResponse resp) {
        if (resp.isSuccess()) {
            return ResponseEntity.ok(Map.of(
                "success",    true,
                "answer",     resp.getAnswer(),
                "tool_calls", resp.getToolCallCount()
            ));
        }
        return ResponseEntity.status(500).body(Map.of(
            "success", false,
            "error",   resp.getErrorMessage()
        ));
    }
}
