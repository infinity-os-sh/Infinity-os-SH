// ============================================================
// ClaudeApiService.java
// Claude API调用服务（支持Tool Use）
// ============================================================
package com.xinhe.infinityos.tools.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class ClaudeApiService {

    private static final Logger log = LoggerFactory.getLogger(ClaudeApiService.class);
    private static final String CLAUDE_API = "https://api.anthropic.com/v1/messages";
    private static final String MODEL      = "claude-sonnet-4-20250514";

    @Autowired private RestTemplate restTemplate;
    @Autowired private ObjectMapper objectMapper;

    @Value("${anthropic.api-key:}")
    private String apiKey;

    /**
     * 带工具列表调用Claude API
     * 返回结构化的ClaudeResponse（含text内容和tool_use块）
     */
    public ClaudeResponse callWithTools(String systemPrompt,
                                         List<Map<String, Object>> messages,
                                         List<Map<String, Object>> tools) {
        try {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("model",      MODEL);
            body.put("max_tokens", 4096);
            body.put("system",     systemPrompt);
            body.put("messages",   messages);

            if (tools != null && !tools.isEmpty()) {
                body.put("tools", tools);
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("x-api-key", apiKey);
            headers.set("anthropic-version", "2023-06-01");

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(
                    CLAUDE_API, request, String.class);

            return parseClaudeResponse(response.getBody());

        } catch (Exception e) {
            log.error("[Claude API调用失败] {}", e.getMessage(), e);
            return ClaudeResponse.error(e.getMessage());
        }
    }

    private ClaudeResponse parseClaudeResponse(String rawJson) throws Exception {
        JsonNode root      = objectMapper.readTree(rawJson);
        JsonNode content   = root.get("content");
        String   stopReason = root.path("stop_reason").asText();

        List<AgentOrchestrationService.ToolUseBlock> toolUses = new ArrayList<>();
        StringBuilder textContent = new StringBuilder();
        List<Object> rawContent = new ArrayList<>();

        if (content != null && content.isArray()) {
            for (JsonNode block : content) {
                String type = block.path("type").asText();
                rawContent.add(objectMapper.convertValue(block, Object.class));

                if ("text".equals(type)) {
                    textContent.append(block.path("text").asText());
                } else if ("tool_use".equals(type)) {
                    String id   = block.path("id").asText();
                    String name = block.path("name").asText();
                    @SuppressWarnings("unchecked")
                    Map<String, Object> input = objectMapper.convertValue(
                            block.get("input"), Map.class);
                    toolUses.add(new AgentOrchestrationService.ToolUseBlock(id, name, input));
                }
            }
        }

        return new ClaudeResponse(
                false, null,
                textContent.toString(),
                toolUses,
                rawContent,
                stopReason
        );
    }

    // 内部响应类
    public static class ClaudeResponse {
        private final boolean   error;
        private final String    errorMessage;
        private final String    textContent;
        private final List<AgentOrchestrationService.ToolUseBlock> toolUseBlocks;
        private final List<Object> rawContent;
        private final String    stopReason;

        public ClaudeResponse(boolean error, String errorMessage, String textContent,
                               List<AgentOrchestrationService.ToolUseBlock> toolUseBlocks,
                               List<Object> rawContent, String stopReason) {
            this.error         = error;
            this.errorMessage  = errorMessage;
            this.textContent   = textContent;
            this.toolUseBlocks = toolUseBlocks != null ? toolUseBlocks : List.of();
            this.rawContent    = rawContent != null ? rawContent : List.of();
            this.stopReason    = stopReason;
        }

        public static ClaudeResponse error(String msg) {
            return new ClaudeResponse(true, msg, null, null, null, null);
        }

        public boolean   isError()          { return error; }
        public String    getErrorMessage()   { return errorMessage; }
        public String    getTextContent()    { return textContent; }
        public List<AgentOrchestrationService.ToolUseBlock> getToolUseBlocks() { return toolUseBlocks; }
        public List<Object> getRawContent()  { return rawContent; }
        public String    getStopReason()     { return stopReason; }
    }
}


// ============================================================
// CrmService.java  （骨架 - 与ErpService结构相同）
// ============================================================
// package com.xinhe.infinityos.tools.service;
// @Service
// public class CrmService {
//
//     @Value("${xinhe.crm.base-url:http://crm-internal/api}")
//     private String crmBaseUrl;
//     @Value("${xinhe.crm.mock-mode:true}")
//     private boolean mockMode;
//
//     public String queryDistributor(String distributorId, List<String> fields) throws Exception {
//         if (mockMode) {
//             return mockDistributor(distributorId);
//         }
//         // 调用真实CRM API
//     }
//
//     private String mockDistributor(String id) throws Exception {
//         return objectMapper.writeValueAsString(Map.of(
//             "distributor_id",    id,
//             "name",              "上海XX经销商",
//             "cooperation_years", 3,
//             "credit_rating",     "A",
//             "ytd_sales",         1280000,
//             "order_acceptance_rate", 0.87,
//             "avg_absorption_days",   18,
//             "contact",           "张经理 138-xxxx-xxxx",
//             "data_source",       "MOCK"
//         ));
//     }
//
//     public String queryStore(String storeId, String cityCode) ...
//     public String queryBeautyAdvisor(String baId, String storeId, double minCb) ...
//     public String updateScore(String personId, String scoreType, double delta, String reason) ...
// }


// ============================================================
// ScmService.java  （骨架）
// ============================================================
// @Service
// public class ScmService {
//     public String queryLogistics(String distributorId, String orderId) ...
//     public String querySupplyRisk(String skuId, int horizonDays) ...
// }


// ============================================================
// WechatService.java  （骨架）
// ============================================================
// @Service
// public class WechatService {
//
//     @Value("${xinhe.wechat.corp-id:}")
//     private String corpId;
//     @Value("${xinhe.wechat.secret:}")
//     private String secret;
//
//     public String pushAlert(String recipientId, String messageType,
//                             String title, String content, String actionUrl) {
//         // 调用企业微信发送消息API
//         // POST https://qyapi.weixin.qq.com/cgi-bin/message/send
//     }
//
//     public String createTask(String assigneeId, String storeId, String taskType,
//                              String description, String dueTime, int rewardPoints) {
//         // 调用企业微信任务API
//     }
// }


// ============================================================
// MemoryToolService.java  （记忆层的工具调用包装）
// ============================================================
// @Service
// public class MemoryToolService {
//
//     @Autowired
//     private AgentMemoryService memoryService;
//     @Autowired
//     private AgentMemoryEventRepository eventRepo;
//     @Autowired
//     private ObjectMapper objectMapper;
//
//     public String query(String entityId, String eventType, int days) throws Exception {
//         List<AgentMemoryEvent> events = eventRepo.findRecentByEntity(
//             entityId, LocalDateTime.now().minusDays(days));
//         if (eventType != null && !eventType.isEmpty()) {
//             events = events.stream()
//                 .filter(e -> e.getEventType().equals(eventType))
//                 .collect(Collectors.toList());
//         }
//         return objectMapper.writeValueAsString(Map.of(
//             "entity_id", entityId,
//             "days",      days,
//             "count",     events.size(),
//             "events",    events
//         ));
//     }
//
//     public String writeEvent(String entityId, String entityName,
//                              String eventType, Map<String, Object> eventData,
//                              int severity) throws Exception {
//         memoryService.recordGenericEvent(entityId, entityName, eventType, eventData, severity);
//         return objectMapper.writeValueAsString(Map.of("status","ok","written",true));
//     }
// }
