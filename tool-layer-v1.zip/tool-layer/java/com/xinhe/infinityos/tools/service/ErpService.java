// ============================================================
// ErpService.java
// ERP系统对接服务
// 结构：接口定义 → Mock实现（立刻可用）→ 真实实现（接通ERP后替换）
// ============================================================
package com.xinhe.infinityos.tools.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class ErpService {

    private static final Logger log = LoggerFactory.getLogger(ErpService.class);

    @Autowired private ObjectMapper objectMapper;
    @Autowired private RestTemplate restTemplate;

    // ERP系统地址（配置在 application.yml）
    @Value("${xinhe.erp.base-url:http://erp-internal/api}")
    private String erpBaseUrl;

    @Value("${xinhe.erp.api-key:}")
    private String erpApiKey;

    // 是否使用Mock数据（ERP未接通时为true）
    @Value("${xinhe.erp.mock-mode:true}")
    private boolean mockMode;

    // ── 查询库存 ─────────────────────────────────────────────

    public String queryInventory(String entityId, String entityType,
                                  List<String> skuIds) throws Exception {
        if (mockMode) {
            return mockInventory(entityId, entityType);
        }

        // 真实ERP调用
        String url = erpBaseUrl + "/inventory/query";
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("entity_id",   entityId);
        body.put("entity_type", entityType);
        if (skuIds != null && !skuIds.isEmpty()) {
            body.put("sku_ids", skuIds);
        }

        return callErpApi(url, body);
    }

    private String mockInventory(String entityId, String entityType) throws Exception {
        // Mock数据结构与真实ERP返回格式一致，方便后续切换
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("entity_id",    entityId);
        result.put("entity_type",  entityType);
        result.put("query_time",   java.time.LocalDateTime.now().toString());
        result.put("data_source",  "MOCK - ERP未接入");

        List<Map<String, Object>> skus = new ArrayList<>();
        skus.add(buildSkuInventory("SKU_LYX_500", "六月鲜特级酱油500ml", 24, 48, 0,  2.1));
        skus.add(buildSkuInventory("SKU_LYX_1L",  "六月鲜特级酱油1L",    12, 24, 12, 1.8));
        skus.add(buildSkuInventory("SKU_WDM_500", "味达美酱油500ml",      36, 60, 0,  3.2));
        result.put("sku_list", skus);

        // 计算综合水位
        result.put("overall_water_level", "2a");
        result.put("alert_level", "WARNING");

        return objectMapper.writeValueAsString(result);
    }

    private Map<String, Object> buildSkuInventory(String skuId, String skuName,
                                                    int shelf, int warehouse,
                                                    int inTransit, double rValue) {
        Map<String, Object> sku = new LinkedHashMap<>();
        sku.put("sku_id",         skuId);
        sku.put("sku_name",       skuName);
        sku.put("stock_shelf",    shelf);
        sku.put("stock_warehouse", warehouse);
        sku.put("stock_transit",  inTransit);
        sku.put("stock_total",    shelf + warehouse + inTransit);
        sku.put("r_value",        rValue);  // 日销量
        double aValue = rValue * 30;        // T=30天
        sku.put("a_value",        aValue);
        sku.put("days_coverage",  Math.round((shelf + warehouse) / rValue));
        // 水位判断
        double totalStock = shelf + warehouse;
        String waterLevel = totalStock >= aValue * 3 ? "3a" :
                            totalStock >= aValue * 2 ? "2a" :
                            totalStock >= aValue     ? "1a" : "0";
        sku.put("water_level",    waterLevel);
        sku.put("needs_restock",  totalStock < aValue * 2);
        return sku;
    }

    // ── 查询销售速率 ─────────────────────────────────────────

    public String querySalesVelocity(String entityId, int days, String skuId) throws Exception {
        if (mockMode) {
            return mockSalesVelocity(entityId, days);
        }
        String url = erpBaseUrl + "/sales/velocity";
        Map<String, Object> body = Map.of(
            "entity_id", entityId,
            "days", days,
            "sku_id", skuId != null ? skuId : ""
        );
        return callErpApi(url, body);
    }

    private String mockSalesVelocity(String entityId, int days) throws Exception {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("entity_id",   entityId);
        result.put("period_days", days);
        result.put("data_source", "MOCK - ERP未接入");

        // 模拟近N天r值趋势
        List<Map<String, Object>> trend = new ArrayList<>();
        double baseR = 2.3;
        for (int i = days; i >= 0; i -= 7) {
            Map<String, Object> point = new LinkedHashMap<>();
            point.put("date",    java.time.LocalDate.now().minusDays(i).toString());
            point.put("r_value", Math.round((baseR + (Math.random() - 0.5) * 0.4) * 10.0) / 10.0);
            trend.add(point);
        }
        result.put("r_trend",     trend);
        result.put("r_avg_30d",   2.3);
        result.put("r_avg_7d",    2.1);
        result.put("r_current",   2.1);
        result.put("trend_direction", "declining"); // declining/stable/rising
        result.put("trend_note",  "近7天较30天均值下降8.7%，建议关注");
        return objectMapper.writeValueAsString(result);
    }

    // ── 查询生产计划 ─────────────────────────────────────────

    public String queryProduction(String skuId, String dateRange) throws Exception {
        if (mockMode) {
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("sku_id",        skuId != null ? skuId : "ALL");
            result.put("date_range",    dateRange);
            result.put("capacity_rate", "94%");
            result.put("planned_output", 180000);
            result.put("actual_output",  168000);
            result.put("delivery_plan",  List.of(
                Map.of("date", "2025-02-05", "quantity", 60000, "status", "confirmed"),
                Map.of("date", "2025-02-12", "quantity", 60000, "status", "planned"),
                Map.of("date", "2025-02-19", "quantity", 48000, "status", "planned")
            ));
            result.put("risk_flag",     false);
            result.put("data_source",   "MOCK");
            return objectMapper.writeValueAsString(result);
        }
        return callErpApi(erpBaseUrl + "/production/plan",
                Map.of("sku_id", skuId, "date_range", dateRange));
    }

    // ── 写入订单 ─────────────────────────────────────────────

    public String writeOrder(String distributorId,
                              List<Map<String, Object>> orderLines,
                              String notes) throws Exception {
        if (mockMode) {
            String orderId = "ORD-" + System.currentTimeMillis();
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("order_id",      orderId);
            result.put("distributor_id", distributorId);
            result.put("status",        "PENDING_CONFIRMATION");
            result.put("order_lines",   orderLines);
            result.put("total_lines",   orderLines.size());
            result.put("notes",         notes);
            result.put("created_at",    java.time.LocalDateTime.now().toString());
            result.put("action",        "已创建待确认订单，等待经销商确认");
            result.put("data_source",   "MOCK - ERP未接入，实际未写入");
            log.info("[ERP Mock] 模拟写入订单 {} for 经销商 {}", orderId, distributorId);
            return objectMapper.writeValueAsString(result);
        }

        // 真实写入ERP
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("distributor_id", distributorId);
        body.put("order_lines",    orderLines);
        body.put("notes",          notes);
        body.put("source",         "INFINITY_OS");
        body.put("auto_generated", true);
        return callErpApi(erpBaseUrl + "/orders/create", body);
    }

    // ── 公共HTTP调用 ─────────────────────────────────────────

    private String callErpApi(String url, Map<String, Object> body) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("X-API-Key", erpApiKey);
        headers.set("X-Source", "INFINITY_OS");

        HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                return response.getBody();
            }
            return objectMapper.writeValueAsString(Map.of(
                "error", "ERP返回非200: " + response.getStatusCode(),
                "status", "failed"
            ));
        } catch (Exception e) {
            log.error("[ERP调用失败] URL:{} | {}", url, e.getMessage());
            throw e;
        }
    }
}
