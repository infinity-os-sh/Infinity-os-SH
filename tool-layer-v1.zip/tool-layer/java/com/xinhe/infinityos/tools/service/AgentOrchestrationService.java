// ============================================================
// AgentOrchestrationService.java
// Agent编排服务：第4层的核心执行引擎
//
// 这是整个架构最关键的类：
// 1. 携带工具列表调用Claude
// 2. 检测Claude是否要调用工具
// 3. 执行工具，把结果返回给Claude
// 4. 循环直到Claude给出最终答案
//
// 这个"Agentic Loop"让Agent真正变成自主执行者
// ============================================================
package com.xinhe.infinityos.tools.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xinhe.infinityos.memory.service.AgentMemoryService;
import com.xinhe.infinityos.tools.definition.ToolDefinitions;
import com.xinhe.infinityos.tools.executor.ToolExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AgentOrchestrationService {

    private static final Logger log = LoggerFactory.getLogger(AgentOrchestrationService.class);
    private static final int MAX_TOOL_ROUNDS = 10; // 防止无限循环

    @Autowired private ToolExecutor        toolExecutor;
    @Autowired private AgentMemoryService  memoryService;
    @Autowired private ClaudeApiService    claudeApiService;
    @Autowired private ObjectMapper        objectMapper;

    // ══════════════════════════════════════════════════════════
    // 核心方法：带工具调用的Agent执行
    // ══════════════════════════════════════════════════════════

    /**
     * 执行一次完整的Agent推理（含多轮工具调用）
     *
     * @param agentId       Agent标识（用于选工具集+注入记忆）
     * @param entityId      操作对象ID（门店/经销商）
     * @param userQuestion  用户问题或触发条件
     * @return Agent的最终回答
     */
    public AgentResponse executeAgent(String agentId, String entityId,
                                       String userQuestion) {
        log.info("[Agent启动] {} | 实体:{} | 问题:{}", agentId, entityId, userQuestion);

        // 1. 选择工具集
        List<Map<String, Object>> tools = selectTools(agentId);

        // 2. 构建含记忆的System Prompt
        String basePrompt  = buildBasePrompt(agentId, entityId);
        String fullPrompt  = memoryService.buildPromptWithMemory(agentId, entityId, basePrompt);

        // 3. 初始化对话历史
        List<Map<String, Object>> messages = new ArrayList<>();
        messages.add(Map.of("role", "user", "content", userQuestion));

        // 4. Agentic Loop
        int round = 0;
        while (round < MAX_TOOL_ROUNDS) {
            round++;
            log.info("[Agent轮次] {} | 第{}轮", agentId, round);

            // 调用Claude API（带工具列表）
            ClaudeResponse claudeResp = claudeApiService.callWithTools(
                    fullPrompt, messages, tools);

            if (claudeResp.isError()) {
                return AgentResponse.error(agentId, claudeResp.getErrorMessage());
            }

            // 检查是否需要调用工具
            List<ToolUseBlock> toolUses = claudeResp.getToolUseBlocks();

            if (toolUses.isEmpty()) {
                // Claude给出最终文本回答，循环结束
                String finalAnswer = claudeResp.getTextContent();
                log.info("[Agent完成] {} | {}轮工具调用 | 答案长度:{}", 
                         agentId, round - 1, finalAnswer.length());
                return AgentResponse.success(agentId, finalAnswer, round - 1);
            }

            // 把Claude的回答（含tool_use块）加入对话历史
            messages.add(Map.of(
                "role",    "assistant",
                "content", claudeResp.getRawContent()
            ));

            // 执行所有工具调用，收集结果
            List<Map<String, Object>> toolResults = new ArrayList<>();
            for (ToolUseBlock toolUse : toolUses) {
                log.info("[工具调用] {} | 工具:{}", agentId, toolUse.getName());

                String toolResult = toolExecutor.execute(
                        toolUse.getName(), toolUse.getInput());

                toolResults.add(Map.of(
                    "type",        "tool_result",
                    "tool_use_id", toolUse.getId(),
                    "content",     toolResult
                ));
            }

            // 把工具结果返回给Claude（下一轮继续推理）
            messages.add(Map.of(
                "role",    "user",
                "content", toolResults
            ));
        }

        return AgentResponse.error(agentId, "超过最大工具调用轮次: " + MAX_TOOL_ROUNDS);
    }

    // ══════════════════════════════════════════════════════════
    // 预置场景：常用Agent触发
    // ══════════════════════════════════════════════════════════

    /**
     * 触发蝴蝶效应检测（定时任务或手动触发）
     * 对指定经销商执行全链异常扫描
     */
    public AgentResponse runButterflyCheck(String distributorId) {
        String question = String.format(
            "请对经销商 %s 执行完整的蝴蝶效应检测。" +
            "查询当前库存水位，与历史记忆对比，" +
            "识别是否存在A/B/C三类失真，" +
            "如有异常立即发企业微信预警，" +
            "并将检测结果写入记忆层。",
            distributorId
        );
        return executeAgent("butterfly", distributorId, question);
    }

    /**
     * 触发无菜单推单
     */
    public AgentResponse runOmakasePush(String distributorId) {
        String question = String.format(
            "请为经销商 %s 计算最优补货方案。" +
            "查询当前库存，结合历史记忆中的消化速度和接单率，" +
            "计算各SKU补货量，直接写入ERP生成待确认订单，" +
            "并通过企业微信通知经销商确认。",
            distributorId
        );
        return executeAgent("omakase", distributorId, question);
    }

    /**
     * 触发美顾任务派发（Uber激励）
     */
    public AgentResponse dispatchBeautyAdvisorTasks(String storeId) {
        String question = String.format(
            "为门店 %s 查询今日需要派发的美顾任务。" +
            "查询门店CRM信息和美顾档案，" +
            "根据CB分和AIQL评分分配最合适的美顾，" +
            "创建企业微信任务并设置相应积分奖励。",
            storeId
        );
        return executeAgent("uber_incentive", storeId, question);
    }

    // ══════════════════════════════════════════════════════════
    // 工具 & Prompt 构建
    // ══════════════════════════════════════════════════════════

    private List<Map<String, Object>> selectTools(String agentId) {
        return switch (agentId) {
            case "butterfly"     -> ToolDefinitions.BUTTERFLY_TOOLS;
            case "omakase"       -> ToolDefinitions.OMAKASE_TOOLS;
            case "uber_incentive"-> ToolDefinitions.UBER_TOOLS;
            case "commander"     -> ToolDefinitions.COMMANDER_TOOLS;
            default              -> ToolDefinitions.BUTTERFLY_TOOLS;
        };
    }

    private String buildBasePrompt(String agentId, String entityId) {
        return switch (agentId) {
            case "butterfly" -> String.format("""
                你是欣和SH INFINITY OS的「蝴蝶效应Agent」。
                你的职责是检测IPO0-13全链的库存失真和异常。
                三类失真：A=渠道压货，B=促销扭曲，C=灰市窜货。
                心跳系统：零售层3a满→2a预警，经销商2a满→1a预警。
                当前处理实体ID：%s
                发现问题时：先写记忆，再发企业微信预警。
                用中文简洁回复，结构化输出。
                """, entityId);

            case "omakase" -> String.format("""
                你是欣和SH INFINITY OS的「无菜单推单Agent」(Omakase)。
                你的职责是自动计算经销商补货量并生成订单，不需要人猜。
                推单逻辑：当前库存 + 历史消化速度 + 接单率 + 季节系数。
                当前处理经销商ID：%s
                计算后直接写入ERP，用企业微信通知经销商确认。
                用中文简洁回复。
                """, entityId);

            default -> String.format("""
                你是欣和SH INFINITY OS智能Agent。
                实体ID：%s。使用可用工具查询真实数据后再回答。
                用中文简洁回复。
                """, entityId);
        };
    }

    // ══════════════════════════════════════════════════════════
    // 内部数据类
    // ══════════════════════════════════════════════════════════

    public static class AgentResponse {
        private final String  agentId;
        private final boolean success;
        private final String  answer;
        private final int     toolCallCount;
        private final String  errorMessage;

        private AgentResponse(String agentId, boolean success, String answer,
                               int toolCallCount, String errorMessage) {
            this.agentId       = agentId;
            this.success       = success;
            this.answer        = answer;
            this.toolCallCount = toolCallCount;
            this.errorMessage  = errorMessage;
        }

        public static AgentResponse success(String agentId, String answer, int toolCallCount) {
            return new AgentResponse(agentId, true, answer, toolCallCount, null);
        }

        public static AgentResponse error(String agentId, String errorMessage) {
            return new AgentResponse(agentId, false, null, 0, errorMessage);
        }

        // Getters
        public String  getAgentId()       { return agentId; }
        public boolean isSuccess()         { return success; }
        public String  getAnswer()         { return answer; }
        public int     getToolCallCount()  { return toolCallCount; }
        public String  getErrorMessage()   { return errorMessage; }
    }

    // Claude工具调用块（由ClaudeApiService解析后返回）
    public static class ToolUseBlock {
        private String id;
        private String name;
        private Map<String, Object> input;

        public ToolUseBlock(String id, String name, Map<String, Object> input) {
            this.id = id; this.name = name; this.input = input;
        }
        public String getId()                  { return id; }
        public String getName()                { return name; }
        public Map<String, Object> getInput()  { return input; }
    }
}
