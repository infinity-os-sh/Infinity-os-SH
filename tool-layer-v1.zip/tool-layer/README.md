# INFINITY OS · 第4层调用能力
## 交付物说明 & 集成指南

---

## 架构图

```
前端 INFINITY OS
        ↓
AgentController  (REST API)
        ↓
AgentOrchestrationService  ← 核心：Agentic Loop
    ↙           ↓          ↘
ClaudeApiService  ←→  ToolExecutor
(调Claude)            (路由工具调用)
                      ↙  ↓  ↓  ↘
                   ERP CRM SCM 企微
                    ↕   ↕   ↕   ↕
                   真实业务系统
                         ↕
                   AgentMemoryService
                   (第3层记忆层)
```

---

## 文件清单

```
tool-layer/
├── sql/
│   └── V2__tool_config_and_log.yml    ← 配置+日志表
│
└── java/com/xinhe/infinityos/tools/
    ├── definition/
    │   └── ToolDefinitions.java       ← 20个工具定义（ERP/CRM/SCM/企微/记忆）
    ├── executor/
    │   └── ToolExecutor.java          ← 工具路由器（Claude叫什么就执行什么）
    ├── service/
    │   ├── AgentOrchestrationService.java  ← ⭐核心：Agentic Loop
    │   ├── ClaudeApiService.java           ← Claude API（支持Tool Use）
    │   └── ErpService.java                 ← ERP对接（含Mock模式）
    └── controller/
        └── AgentController.java       ← REST API入口
```

---

## 集成步骤

### Step 1：建日志表（10分钟）
```sql
source V2__tool_config_and_log.yml  -- 执行SQL部分
```

### Step 2：合并配置（10分钟）
将 `application.yml` 中的新增配置合并到现有项目。
所有 `mock-mode: true`，**无需连接任何真实系统即可运行**。

### Step 3：复制Java文件（30分钟）
复制 `tools` 包到现有项目。
确认 `pom.xml` 有 `spring-boot-starter-web` 依赖。

### Step 4：前端调用方式修改（1天）

**现在前端直接调Claude API：**
```javascript
fetch('https://api.anthropic.com/v1/messages', { ... })
```

**改成调后端Agent接口：**
```javascript
fetch('/api/agents/chat', {
  method: 'POST',
  body: JSON.stringify({
    agent_id: 'butterfly',
    entity_id: 'DIST_001',
    question: '今天有没有压货风险？'
  })
})
```

现在Agent会自己查ERP、写记忆、发企微，再把结果返回前端。

---

## Mock模式说明

**所有服务默认 `mock-mode: true`**，意味着：

- ERP查询 → 返回模拟库存数据（格式与真实ERP一致）
- CRM查询 → 返回模拟经销商档案
- 企微推送 → 只打日志，不真实发送
- ERP写订单 → 只打日志，不真实写入

**切换到真实系统只需要：**
1. 填入真实系统地址和API Key
2. 将对应服务的 `mock-mode` 改为 `false`
3. 重启服务

---

## 接通优先级

```
第1优先（1周内）：企业微信推送
→ 改动最小，效果最明显
→ 蝴蝶效应预警直达销售主管手机

第2优先（2-3周）：ERP库存查询
→ Agent从猜库存变成查库存
→ 心跳公式第一次用真实数据运转

第3优先（1个月）：ERP写订单
→ 推单从"建议"变成"生成订单"
→ 无菜单推单Agent真正闭环

第4优先（2个月）：CRM经销商档案
→ 推单个性化程度大幅提升
→ Uber激励Agent精准派单

第5优先（3个月）：SCM + 电商平台
→ 供应链视角完整
→ 全链数据贯通
```

---

## API接口文档

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/agents/chat` | 通用Agent对话（含工具调用） |
| POST | `/api/agents/butterfly/check` | 触发蝴蝶效应检测 |
| POST | `/api/agents/butterfly/batch-check` | 批量检测所有经销商 |
| POST | `/api/agents/omakase/push` | 触发无菜单推单 |
| POST | `/api/agents/uber/dispatch` | 派发美顾任务 |
| GET  | `/api/agents/health` | 工具层连通性检查 |

---

## 验证方法

**启动后立即验证（Mock模式）：**

```bash
# 测试蝴蝶效应检测
curl -X POST http://localhost:8080/api/agents/butterfly/check \
  -H "Content-Type: application/json" \
  -d '{"distributor_id": "DIST_001"}'

# 期望返回：
# {
#   "success": true,
#   "answer": "...（Claude基于Mock ERP数据的分析）...",
#   "tool_calls": 3   ← 说明Agent真的调用了工具
# }
```

`tool_calls > 0` = 第4层工作正常 ✅

---

## 与记忆层的依赖关系

工具层依赖记忆层（第3层），确保先完成：
- `agent_memory_events` 表已建立
- `AgentMemoryService` 已注入并可调用

两层合并后，Agent具备：
- **记忆**：知道历史发生了什么
- **工具**：能查现在的真实数据
- **行动**：能写订单、发通知

这是第5层（自主决策）的完整前提。
