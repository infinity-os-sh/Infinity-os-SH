package com.xinhe.infinityos.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * 企业微信预警推送服务
 * 销速异常 → 自动推送到「上海库存销速预警」群
 */
@Slf4j
@Service
public class WechatWorkAlertService {

    @Value("${wechat-work.alert-webhook}")
    private String webhookUrl;

    @Value("${infinity-os.alert.critical-threshold}")
    private BigDecimal criticalThreshold;

    @Value("${infinity-os.alert.slow-threshold}")
    private BigDecimal slowThreshold;

    @Value("${infinity-os.alert.fast-threshold}")
    private BigDecimal fastThreshold;

    private final WebClient webClient = WebClient.create();

    /**
     * 根据销速状态决定是否发送预警
     */
    public boolean shouldAlert(String velocityStatus) {
        return "CRITICAL".equals(velocityStatus) || "SLOW".equals(velocityStatus)
                || "FAST".equals(velocityStatus);
    }

    /**
     * 发送销速预警
     */
    public void sendVelocityAlert(
            String storeName, String skuName, String salespersonName,
            BigDecimal actualR, BigDecimal targetR, BigDecimal achievementRate,
            BigDecimal daysRemaining, String velocityStatus,
            boolean flagStuffing, boolean flagGrayMarket) {

        String content = buildAlertContent(storeName, skuName, salespersonName,
                actualR, targetR, achievementRate, daysRemaining, velocityStatus,
                flagStuffing, flagGrayMarket);

        sendMarkdown(content);
        log.info("企微预警已发送 | 门店:{} SKU:{} 状态:{}", storeName, skuName, velocityStatus);
    }

    /**
     * 构建企微 Markdown 消息内容
     */
    private String buildAlertContent(
            String storeName, String skuName, String salespersonName,
            BigDecimal actualR, BigDecimal targetR, BigDecimal achievementRate,
            BigDecimal daysRemaining, String velocityStatus,
            boolean flagStuffing, boolean flagGrayMarket) {

        String timeStr = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM/dd HH:mm"));
        String pct = achievementRate.multiply(BigDecimal.valueOf(100))
                .setScale(0, RoundingMode.HALF_UP) + "%";

        StringBuilder sb = new StringBuilder();

        switch (velocityStatus) {
            case "CRITICAL" -> {
                sb.append("# 🔴 销速严重不足\n");
                sb.append("> **需立即跟进**\n\n");
            }
            case "SLOW" -> {
                sb.append("# ⚠️ 销速偏低预警\n");
                sb.append("> 建议今日跟进\n\n");
            }
            case "FAST" -> {
                sb.append("# 🚀 销速超标，势头很好！\n");
                sb.append("> 注意及时补货\n\n");
            }
        }

        sb.append("**门店** · ").append(storeName).append("\n");
        sb.append("**SKU** · ").append(skuName).append("\n");
        sb.append("**实际销速** · <font color=\"");

        if ("FAST".equals(velocityStatus)) sb.append("info");
        else if ("CRITICAL".equals(velocityStatus)) sb.append("warning");
        else sb.append("comment");

        sb.append("\">").append(actualR).append("瓶/天</font>\n");
        sb.append("**目标销速** · ").append(targetR).append("瓶/天\n");
        sb.append("**达成率** · ").append(pct).append("\n");
        sb.append("**可卖天数** · ").append(daysRemaining.setScale(0, RoundingMode.HALF_UP)).append("天\n");
        sb.append("**上报人** · ").append(salespersonName).append("\n");
        sb.append("**时间** · ").append(timeStr).append("\n");

        if (flagStuffing) sb.append("\n> ⚠️ 业务员标记：疑似压货（A类失真）\n");
        if (flagGrayMarket) sb.append("\n> ⚠️ 业务员标记：发现低价或窜货（C类失真）\n");

        if ("CRITICAL".equals(velocityStatus) || "SLOW".equals(velocityStatus)) {
            sb.append("\n**建议排查** · 陈列位置 / 竞品促销 / 门店动销情况");
        } else if ("FAST".equals(velocityStatus)) {
            sb.append("\n**建议补货** · 库存可能不足，建议提前安排");
        }

        return sb.toString();
    }

    /**
     * 发送 Markdown 消息到企微群
     */
    private void sendMarkdown(String content) {
        String body = String.format("""
                {
                    "msgtype": "markdown",
                    "markdown": {
                        "content": "%s"
                    }
                }
                """, content.replace("\"", "\\\"").replace("\n", "\\n"));

        try {
            webClient.post()
                    .uri(webhookUrl)
                    .header("Content-Type", "application/json")
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(String.class)
                    .subscribe(
                            resp -> log.info("企微推送成功: {}", resp),
                            err  -> log.error("企微推送失败: {}", err.getMessage())
                    );
        } catch (Exception e) {
            log.error("企微推送异常: {}", e.getMessage());
        }
    }
}
