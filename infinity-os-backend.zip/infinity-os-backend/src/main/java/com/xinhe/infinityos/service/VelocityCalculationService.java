package com.xinhe.infinityos.service;

import com.xinhe.infinityos.entity.InventoryReport;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 销速计算引擎
 * INFINITY OS 的心脏 —— 计算实际r，对比目标r，判断水位和销速状态
 *
 * 核心公式：
 *   实际r = （上次库存 - 当前库存）÷ 间隔天数
 *   达成率 = 实际r ÷ 目标r × 100%
 *   可卖天数 = 当前库存 ÷ 实际r
 *   水位 = 当前库存 ÷ a（a = 目标r × T）
 */
@Slf4j
@Service
public class VelocityCalculationService {

    /** 销速状态阈值 */
    private static final BigDecimal FAST_THRESHOLD     = new BigDecimal("1.10"); // >110%
    private static final BigDecimal NORMAL_THRESHOLD   = new BigDecimal("0.90"); // 90-110%
    private static final BigDecimal SLOW_THRESHOLD     = new BigDecimal("0.60"); // 60-90%
    // CRITICAL: <60%

    /**
     * 计算销速，填充到上报记录
     *
     * @param report      当前上报记录（已填入库存数量）
     * @param lastReport  上次上报记录（可为null，表示第一次上报）
     * @param targetR     目标日销率（瓶/天），从velocity_target表获取
     * @param periodT     周期天数T，由门店等级决定
     */
    public void calculate(InventoryReport report, InventoryReport lastReport,
                          BigDecimal targetR, int periodT) {

        // ── 1. 计算当前合计库存 ──
        int totalQty = report.getShelfQty()
                + report.getWarehouseQtyCase() * report.getBottlesPerCase();

        // ── 2. 计算实际r ──
        BigDecimal actualR;

        if (lastReport != null && report.getDaysSinceLast() != null
                && report.getDaysSinceLast() > 0) {
            // 有历史记录：用实际消耗量计算
            int lastTotalQty = lastReport.getShelfQty()
                    + lastReport.getWarehouseQtyCase() * lastReport.getBottlesPerCase();
            int consumed = lastTotalQty - totalQty;

            if (consumed > 0) {
                // 正常消耗，计算真实r
                actualR = BigDecimal.valueOf(consumed)
                        .divide(BigDecimal.valueOf(report.getDaysSinceLast()), 2, RoundingMode.HALF_UP);
            } else {
                // 消耗量为负（补货了），用库存÷T估算
                actualR = BigDecimal.valueOf(totalQty)
                        .divide(BigDecimal.valueOf(periodT), 2, RoundingMode.HALF_UP);
                log.info("门店{}库存增加（可能补货），用T估算r={}", report.getStoreId(), actualR);
            }

            report.setLastReportId(lastReport.getId());
            report.setLastReportQty(lastTotalQty);
        } else {
            // 第一次上报：用库存÷T估算
            actualR = BigDecimal.valueOf(totalQty)
                    .divide(BigDecimal.valueOf(periodT), 2, RoundingMode.HALF_UP);
            log.info("门店{}首次上报，用T估算r={}", report.getStoreId(), actualR);
        }

        // ── 3. 计算达成率 ──
        BigDecimal achievementRate = BigDecimal.ZERO;
        if (targetR != null && targetR.compareTo(BigDecimal.ZERO) > 0) {
            achievementRate = actualR.divide(targetR, 4, RoundingMode.HALF_UP);
        }

        // ── 4. 计算可卖天数 ──
        BigDecimal daysRemaining = BigDecimal.ZERO;
        if (actualR.compareTo(BigDecimal.ZERO) > 0) {
            daysRemaining = BigDecimal.valueOf(totalQty)
                    .divide(actualR, 1, RoundingMode.HALF_UP);
        }

        // ── 5. 计算水位 ──
        // a = 目标r × T（一个周期的标准销量）
        // 水位 = 当前库存 ÷ a
        // 3 = 满仓（≥3a），2 = 正常（2a-3a），1 = 预警（1a-2a），0 = 危险（<1a）
        int waterLevel = 0;
        if (targetR != null && targetR.compareTo(BigDecimal.ZERO) > 0) {
            BigDecimal a = targetR.multiply(BigDecimal.valueOf(periodT));
            BigDecimal waterRatio = BigDecimal.valueOf(totalQty).divide(a, 4, RoundingMode.HALF_UP);
            if (waterRatio.compareTo(new BigDecimal("3")) >= 0) waterLevel = 3;
            else if (waterRatio.compareTo(new BigDecimal("2")) >= 0) waterLevel = 2;
            else if (waterRatio.compareTo(BigDecimal.ONE) >= 0) waterLevel = 1;
            else waterLevel = 0;
        }

        // ── 6. 判断销速状态 ──
        String velocityStatus;
        if (achievementRate.compareTo(FAST_THRESHOLD) >= 0) {
            velocityStatus = "FAST";
        } else if (achievementRate.compareTo(NORMAL_THRESHOLD) >= 0) {
            velocityStatus = "NORMAL";
        } else if (achievementRate.compareTo(SLOW_THRESHOLD) >= 0) {
            velocityStatus = "SLOW";
        } else {
            velocityStatus = "CRITICAL";
        }

        // ── 7. 填充结果 ──
        report.setActualR(actualR);
        report.setTargetR(targetR);
        report.setAchievementRate(achievementRate);
        report.setDaysRemaining(daysRemaining);
        report.setWaterLevel(waterLevel);
        report.setVelocityStatus(velocityStatus);

        log.info("销速计算完成 | 门店:{} SKU:{} | r实际:{} r目标:{} 达成率:{}% | 水位:{} 状态:{}",
                report.getStoreId(), report.getSkuId(),
                actualR, targetR,
                achievementRate.multiply(BigDecimal.valueOf(100)).setScale(1, RoundingMode.HALF_UP),
                waterLevel, velocityStatus);
    }

    /**
     * 获取销速状态中文标签
     */
    public String getVelocityLabel(String status) {
        return switch (status) {
            case "FAST"     -> "🚀 销速超标";
            case "NORMAL"   -> "✅ 销速正常";
            case "SLOW"     -> "⚠️ 销速偏低";
            case "CRITICAL" -> "🔴 销速严重不足";
            default         -> "未知";
        };
    }

    /**
     * 生成业务建议文字
     */
    public String generateAdvice(String status, BigDecimal achievementRate,
                                  BigDecimal daysRemaining, int periodT) {
        double rate = achievementRate.multiply(BigDecimal.valueOf(100)).doubleValue();
        double days = daysRemaining.doubleValue();

        return switch (status) {
            case "FAST" -> String.format(
                    "销速超标%.0f%%，势头很好！库存还够%.0f天，建议提前安排补货避免断货。", rate - 100, days);
            case "NORMAL" -> String.format(
                    "销速达标，库存还够%.0f天，正常跟进即可。", days);
            case "SLOW" -> String.format(
                    "销速低于目标%.0f%%，需要关注。检查：陈列位置是否醒目？竞品是否在做促销？", 100 - rate);
            case "CRITICAL" -> String.format(
                    "销速严重不足，只完成目标%.0f%%，需要立即上报区域经理分析原因。", rate);
            default -> "请检查数据是否正常。";
        };
    }

    /**
     * 检测三类失真
     * A类：压货（库存异常高，超过3a，但r低）
     * B类：促销扰动（r异常高，已由业务员手动标记）
     * C类：窜货（价格低于底价，需配合价签识别Agent）
     */
    public boolean detectStuffingAnomaly(BigDecimal actualR, BigDecimal targetR,
                                          int totalQty, int periodT) {
        if (targetR == null || targetR.compareTo(BigDecimal.ZERO) == 0) return false;
        BigDecimal a = targetR.multiply(BigDecimal.valueOf(periodT));
        BigDecimal waterRatio = BigDecimal.valueOf(totalQty).divide(a, 4, RoundingMode.HALF_UP);
        // 库存超过3a 且 达成率低于60%，疑似压货
        return waterRatio.compareTo(new BigDecimal("3")) > 0
                && actualR.divide(targetR, 4, RoundingMode.HALF_UP)
                          .compareTo(SLOW_THRESHOLD) < 0;
    }
}
