package com.xinhe.infinityos.dto;

import lombok.Data;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 库存上报 请求DTO
 * 对应 inventory-v3.html 提交的数据
 */
@Data
public class InventoryReportRequest {

    /** 门店ID（SFA自动带入） */
    @NotNull(message = "门店ID不能为空")
    private Long storeId;

    /** SKU ID（SFA自动带入） */
    @NotNull(message = "SKU ID不能为空")
    private Long skuId;

    /** 业务员ID（企微登录自动获取） */
    @NotNull(message = "业务员ID不能为空")
    private Long salespersonId;

    /** 货架库存（瓶）—— 业务员填写 */
    @NotNull(message = "货架库存不能为空")
    @Min(value = 0, message = "货架库存不能为负数")
    private Integer shelfQty;

    /** 仓库库存（箱）—— 业务员填写 */
    @NotNull(message = "仓库库存不能为空")
    @Min(value = 0, message = "仓库库存不能为负数")
    private Integer warehouseQtyCase;

    /** 货架照片URL（拍照后上传返回的URL） */
    private String photoUrl;

    /** 异常标记：A类压货 */
    private Boolean flagStuffing = false;

    /** 异常标记：B类促销扰动 */
    private Boolean flagPromotion = false;

    /** 异常标记：C类窜货 */
    private Boolean flagGrayMarket = false;

    /** 业务员备注 */
    private String notes;

    /** GPS纬度 */
    private BigDecimal gpsLat;

    /** GPS经度 */
    private BigDecimal gpsLng;
}

/**
 * 库存上报 响应DTO
 */
@Data
class InventoryReportResponse {

    private Long reportId;
    private String reportNo;

    // 销速计算结果
    private BigDecimal actualR;        // 实际销速（瓶/天）
    private BigDecimal targetR;        // 目标销速
    private BigDecimal achievementRate; // 达成率
    private BigDecimal daysRemaining;  // 可卖天数

    // 状态
    private String velocityStatus;     // FAST/NORMAL/SLOW/CRITICAL
    private String velocityLabel;      // 中文标签
    private Integer waterLevel;        // 水位 0-3
    private String advice;             // 建议文字

    private LocalDateTime reportTime;
    private String message;            // 提交成功提示
}

/**
 * 门店销速看板DTO（管理层看板用）
 */
@Data
class StoreDashboardDTO {

    private Long storeId;
    private String storeName;
    private String grade;
    private String district;

    // 最新上报数据
    private BigDecimal latestActualR;
    private BigDecimal targetR;
    private BigDecimal achievementRate;
    private String velocityStatus;
    private BigDecimal daysRemaining;
    private LocalDateTime lastReportTime;

    // 业务员
    private String salespersonName;
}

/**
 * 业务员一本账DTO
 */
@Data
class AccountDTO {

    private Long salespersonId;
    private String salespersonName;
    private String district;
    private String yearMonth;

    // 汇总数据
    private Integer storeCount;        // 负责门店数
    private Integer skuCount;          // SKU数量
    private BigDecimal totalWeightedQty; // 月度加权总目标
    private BigDecimal totalAchievement; // 综合达成率
    private BigDecimal totalIncentive;   // 月度激励金额

    // 明细（每个门店每个SKU）
    private java.util.List<AccountDetailDTO> details;
}

@Data
class AccountDetailDTO {
    private String storeName;
    private String skuName;
    private Integer gradeLevel;
    private BigDecimal incentiveCoef;
    private BigDecimal targetQty;
    private BigDecimal actualQty;
    private BigDecimal achievementRate;
    private BigDecimal weightedQty;
    private BigDecimal incentiveAmount;
}
