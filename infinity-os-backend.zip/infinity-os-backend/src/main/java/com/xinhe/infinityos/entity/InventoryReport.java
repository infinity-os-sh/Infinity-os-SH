package com.xinhe.infinityos.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 库存上报实体
 * 对应数据库表：inventory_report
 */
@Data
@TableName("inventory_report")
public class InventoryReport {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 上报单号（系统生成：IVR+时间戳+随机4位） */
    private String reportNo;

    /** 门店ID */
    private Long storeId;

    /** SKU ID */
    private Long skuId;

    /** 上报业务员ID */
    private Long salespersonId;

    // ── 库存数据（业务员填写）──
    /** 货架库存（瓶） */
    private Integer shelfQty;

    /** 仓库库存（箱） */
    private Integer warehouseQtyCase;

    /** 每箱瓶数（快照） */
    private Integer bottlesPerCase;

    /** 货架照片URL */
    private String photoUrl;

    // ── 销速计算（系统自动）──
    /** 上次上报记录ID */
    private Long lastReportId;

    /** 上次合计库存（快照） */
    private Integer lastReportQty;

    /** 距上次上报天数 */
    private Integer daysSinceLast;

    /** 实际日销率（瓶/天） */
    private BigDecimal actualR;

    /** 目标日销率（快照） */
    private BigDecimal targetR;

    /** 达成率 = 实际r ÷ 目标r */
    private BigDecimal achievementRate;

    /** 库存可卖天数 */
    private BigDecimal daysRemaining;

    // ── 水位状态 ──
    /** 水位：3=充足 2=预警 1=危险 0=断货 */
    private Integer waterLevel;

    /** 销速状态：FAST/NORMAL/SLOW/CRITICAL */
    private String velocityStatus;

    // ── 异常标记 ──
    /** A类失真：压货 */
    private Boolean flagStuffing;

    /** B类失真：促销扰动 */
    private Boolean flagPromotion;

    /** C类失真：窜货/乱价 */
    private Boolean flagGrayMarket;

    /** 业务员备注 */
    private String notes;

    // ── 元数据 ──
    /** 上报时间 */
    private LocalDateTime reportTime;

    /** GPS纬度 */
    private BigDecimal gpsLat;

    /** GPS经度 */
    private BigDecimal gpsLng;

    /** 预警是否已推送 */
    private Boolean alertSent;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createdAt;
}
