package com.xinhe.infinityos.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.xinhe.infinityos.dto.InventoryReportRequest;
import com.xinhe.infinityos.entity.InventoryReport;
import com.xinhe.infinityos.repository.InventoryReportMapper;
import com.xinhe.infinityos.repository.VelocityTargetMapper;
import com.xinhe.infinityos.repository.SkuMapper;
import com.xinhe.infinityos.repository.StoreMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Random;

/**
 * 库存上报业务服务
 * 核心流程：接收上报 → 查上次记录 → 计算销速 → 保存 → 触发预警
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class InventoryReportService {

    private final InventoryReportMapper reportMapper;
    private final VelocityTargetMapper targetMapper;
    private final SkuMapper skuMapper;
    private final StoreMapper storeMapper;
    private final VelocityCalculationService velocityService;
    private final WechatWorkAlertService alertService;

    /**
     * 提交库存上报
     * 主流程：接收 → 查历史 → 计算销速 → 保存 → 预警
     */
    @Transactional
    public InventoryReport submitReport(InventoryReportRequest req) {

        log.info("收到库存上报 | 门店:{} SKU:{} 业务员:{} 货架:{}瓶 仓库:{}箱",
                req.getStoreId(), req.getSkuId(), req.getSalespersonId(),
                req.getShelfQty(), req.getWarehouseQtyCase());

        // ── 1. 构建上报记录 ──
        InventoryReport report = new InventoryReport();
        report.setReportNo(generateReportNo());
        report.setStoreId(req.getStoreId());
        report.setSkuId(req.getSkuId());
        report.setSalespersonId(req.getSalespersonId());
        report.setShelfQty(req.getShelfQty());
        report.setWarehouseQtyCase(req.getWarehouseQtyCase());
        report.setPhotoUrl(req.getPhotoUrl());
        report.setFlagStuffing(Boolean.TRUE.equals(req.getFlagStuffing()));
        report.setFlagPromotion(Boolean.TRUE.equals(req.getFlagPromotion()));
        report.setFlagGrayMarket(Boolean.TRUE.equals(req.getFlagGrayMarket()));
        report.setNotes(req.getNotes());
        report.setGpsLat(req.getGpsLat());
        report.setGpsLng(req.getGpsLng());
        report.setReportTime(LocalDateTime.now());
        report.setAlertSent(false);

        // ── 2. 获取每箱瓶数（从SKU表） ──
        Integer bottlesPerCase = skuMapper.getBottlesPerCase(req.getSkuId());
        report.setBottlesPerCase(bottlesPerCase != null ? bottlesPerCase : 12);

        // ── 3. 查询上次上报记录 ──
        InventoryReport lastReport = getLastReport(req.getStoreId(), req.getSkuId());

        if (lastReport != null) {
            long daysBetween = ChronoUnit.DAYS.between(
                    lastReport.getReportTime(), report.getReportTime());
            report.setDaysSinceLast((int) Math.max(1, daysBetween));
        }

        // ── 4. 获取目标销速（来自树根项目数据） ──
        BigDecimal targetR = targetMapper.getCurrentTargetR(
                req.getStoreId(), req.getSkuId(), LocalDateTime.now().toLocalDate());

        // ── 5. 获取门店等级，确定周期T ──
        String storeGrade = storeMapper.getGradeById(req.getStoreId());
        int periodT = getPeriodT(storeGrade);

        // ── 6. 计算销速（核心） ──
        velocityService.calculate(report, lastReport, targetR, periodT);

        // ── 7. 检测A类失真（压货） ──
        int totalQty = req.getShelfQty() + req.getWarehouseQtyCase() * report.getBottlesPerCase();
        if (!report.getFlagStuffing() && targetR != null) {
            boolean stuffingDetected = velocityService.detectStuffingAnomaly(
                    report.getActualR(), targetR, totalQty, periodT);
            if (stuffingDetected) {
                report.setFlagStuffing(true);
                log.warn("⚠️ 系统检测到A类压货失真 | 门店:{} SKU:{}", req.getStoreId(), req.getSkuId());
            }
        }

        // ── 8. 保存上报记录 ──
        reportMapper.insert(report);
        log.info("上报记录已保存 | ID:{} 实际r:{} 达成率:{}%",
                report.getId(), report.getActualR(),
                report.getAchievementRate() != null ?
                        report.getAchievementRate().multiply(BigDecimal.valueOf(100)).intValue() : 0);

        // ── 9. 触发预警推送 ──
        if (alertService.shouldAlert(report.getVelocityStatus())) {
            try {
                String storeName  = storeMapper.getNameById(req.getStoreId());
                String skuName    = skuMapper.getNameById(req.getSkuId());
                String spName     = reportMapper.getSalespersonName(req.getSalespersonId());

                alertService.sendVelocityAlert(
                        storeName, skuName, spName,
                        report.getActualR(), report.getTargetR(), report.getAchievementRate(),
                        report.getDaysRemaining(), report.getVelocityStatus(),
                        report.getFlagStuffing(), report.getFlagGrayMarket());

                // 标记预警已发送
                report.setAlertSent(true);
                reportMapper.updateById(report);
            } catch (Exception e) {
                log.error("预警推送失败（不影响上报）: {}", e.getMessage());
            }
        }

        return report;
    }

    /**
     * 获取门店最新销速数据（看板用）
     */
    public List<InventoryReport> getStoreDashboard(String city, String grade) {
        return reportMapper.getLatestByCity(city, grade);
    }

    /**
     * 获取业务员一本账数据
     */
    public List<InventoryReport> getSalespersonReports(Long salespersonId, String yearMonth) {
        return reportMapper.selectList(
                new LambdaQueryWrapper<InventoryReport>()
                        .eq(InventoryReport::getSalespersonId, salespersonId)
                        .ge(InventoryReport::getReportTime, yearMonth + "-01 00:00:00")
                        .lt(InventoryReport::getReportTime, getNextMonth(yearMonth) + "-01 00:00:00")
                        .orderByDesc(InventoryReport::getReportTime)
        );
    }

    // ── 工具方法 ──

    private InventoryReport getLastReport(Long storeId, Long skuId) {
        return reportMapper.selectOne(
                new LambdaQueryWrapper<InventoryReport>()
                        .eq(InventoryReport::getStoreId, storeId)
                        .eq(InventoryReport::getSkuId, skuId)
                        .orderByDesc(InventoryReport::getReportTime)
                        .last("LIMIT 1")
        );
    }

    private int getPeriodT(String grade) {
        if (grade == null) return 7;
        return switch (grade) {
            case "S+", "S", "A" -> 7;
            case "B"            -> 14;
            case "C"            -> 21;
            case "D"            -> 30;
            default             -> 7;
        };
    }

    private String generateReportNo() {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMddHHmmss"));
        String rand = String.format("%04d", new Random().nextInt(10000));
        return "IVR" + time + rand;
    }

    private String getNextMonth(String yearMonth) {
        String[] parts = yearMonth.split("-");
        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        if (month == 12) { year++; month = 1; }
        else { month++; }
        return String.format("%04d-%02d", year, month);
    }
}
