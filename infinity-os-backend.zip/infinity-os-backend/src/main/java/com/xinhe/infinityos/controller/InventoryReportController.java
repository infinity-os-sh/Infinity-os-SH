package com.xinhe.infinityos.controller;

import com.xinhe.infinityos.dto.InventoryReportRequest;
import com.xinhe.infinityos.entity.InventoryReport;
import com.xinhe.infinityos.service.InventoryReportService;
import com.xinhe.infinityos.service.VelocityCalculationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 库存上报 REST API
 *
 * 对接 inventory-v3.html 的提交按钮
 * 提供管理看板数据接口
 */
@Slf4j
@RestController
@RequestMapping("/v1/inventory")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")  // TODO: 生产环境限制域名
public class InventoryReportController {

    private final InventoryReportService reportService;
    private final VelocityCalculationService velocityService;

    /**
     * POST /api/v1/inventory/report
     * 业务员提交库存上报
     * 对应 inventory-v3.html 的「提交上报」按钮
     */
    @PostMapping("/report")
    public ResponseEntity<Map<String, Object>> submitReport(
            @Valid @RequestBody InventoryReportRequest request) {

        log.info("收到上报请求 | 门店:{} SKU:{}", request.getStoreId(), request.getSkuId());

        InventoryReport report = reportService.submitReport(request);

        // 构建响应
        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("reportId", report.getId());
        result.put("reportNo", report.getReportNo());

        // 销速计算结果（返回给前端展示）
        result.put("actualR", report.getActualR());
        result.put("targetR", report.getTargetR());
        result.put("achievementRate", report.getAchievementRate());
        result.put("daysRemaining", report.getDaysRemaining());
        result.put("velocityStatus", report.getVelocityStatus());
        result.put("velocityLabel", velocityService.getVelocityLabel(report.getVelocityStatus()));
        result.put("waterLevel", report.getWaterLevel());
        result.put("reportTime", report.getReportTime()
                .format(DateTimeFormatter.ofPattern("MM/dd HH:mm")));

        // 建议文字
        if (report.getActualR() != null && report.getTargetR() != null) {
            String advice = velocityService.generateAdvice(
                    report.getVelocityStatus(), report.getAchievementRate(),
                    report.getDaysRemaining(), 7);
            result.put("advice", advice);
        }

        return ResponseEntity.ok(result);
    }

    /**
     * GET /api/v1/inventory/dashboard?city=上海&grade=S+
     * 上海试点 · 销速看板
     * 管理层实时查看所有门店销速状态
     */
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard(
            @RequestParam(defaultValue = "上海") String city,
            @RequestParam(required = false) String grade) {

        List<InventoryReport> reports = reportService.getStoreDashboard(city, grade);

        // 汇总统计
        long totalStores = reports.size();
        long fastCount    = reports.stream().filter(r -> "FAST".equals(r.getVelocityStatus())).count();
        long normalCount  = reports.stream().filter(r -> "NORMAL".equals(r.getVelocityStatus())).count();
        long slowCount    = reports.stream().filter(r -> "SLOW".equals(r.getVelocityStatus())).count();
        long criticalCount = reports.stream().filter(r -> "CRITICAL".equals(r.getVelocityStatus())).count();
        long alertCount   = reports.stream().filter(r ->
                "SLOW".equals(r.getVelocityStatus()) || "CRITICAL".equals(r.getVelocityStatus())).count();

        Map<String, Object> result = new HashMap<>();
        result.put("city", city);
        result.put("grade", grade);
        result.put("updateTime", LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM/dd HH:mm")));
        result.put("totalStores", totalStores);
        result.put("fastCount", fastCount);
        result.put("normalCount", normalCount);
        result.put("slowCount", slowCount);
        result.put("criticalCount", criticalCount);
        result.put("alertCount", alertCount);
        result.put("stores", reports);

        return ResponseEntity.ok(result);
    }

    /**
     * GET /api/v1/inventory/salesperson/{id}/account?yearMonth=2026-04
     * 业务员一本账
     */
    @GetMapping("/salesperson/{id}/account")
    public ResponseEntity<Map<String, Object>> getSalespersonAccount(
            @PathVariable Long id,
            @RequestParam(defaultValue = "") String yearMonth) {

        if (yearMonth.isEmpty()) {
            yearMonth = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM"));
        }

        List<InventoryReport> reports = reportService.getSalespersonReports(id, yearMonth);

        Map<String, Object> result = new HashMap<>();
        result.put("salespersonId", id);
        result.put("yearMonth", yearMonth);
        result.put("reportCount", reports.size());
        result.put("reports", reports);

        return ResponseEntity.ok(result);
    }

    /**
     * GET /api/v1/inventory/store/{storeId}/sku/{skuId}/context
     * 获取门店+SKU的自动带入数据
     * 供 inventory-v3.html 加载时自动填充门店信息
     */
    @GetMapping("/store/{storeId}/sku/{skuId}/context")
    public ResponseEntity<Map<String, Object>> getStoreSkuContext(
            @PathVariable Long storeId,
            @PathVariable Long skuId) {

        // TODO: 从数据库查询真实数据
        // 当前返回示例数据
        Map<String, Object> result = new HashMap<>();
        result.put("storeId", storeId);
        result.put("skuId", skuId);
        result.put("autoFilled", true);
        result.put("message", "门店和SKU信息已自动带入，只需填写货架和仓库数量");

        return ResponseEntity.ok(result);
    }

    /**
     * GET /api/v1/inventory/health
     * 健康检查
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> result = new HashMap<>();
        result.put("status", "UP");
        result.put("service", "INFINITY OS · 库存上报服务");
        result.put("version", "v1.0");
        result.put("time", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        return ResponseEntity.ok(result);
    }
}
