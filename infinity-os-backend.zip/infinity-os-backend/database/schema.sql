-- ============================================================
-- INFINITY OS · 欣和SH · 数据库建表脚本
-- 数据库：MySQL 8.0+
-- 版本：v1.0 · 2026/04/05
-- ============================================================

CREATE DATABASE IF NOT EXISTS infinity_os CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE infinity_os;

-- ============================================================
-- 1. 门店表
-- ============================================================
CREATE TABLE store (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    store_code  VARCHAR(20)  NOT NULL UNIQUE COMMENT '门店编码',
    store_name  VARCHAR(100) NOT NULL COMMENT '门店名称',
    grade       CHAR(2)      NOT NULL COMMENT '门店等级：S+/S/A/B/C/D',
    district    VARCHAR(50)  COMMENT '区域',
    city        VARCHAR(50)  DEFAULT '上海' COMMENT '城市',
    address     VARCHAR(200) COMMENT '地址',
    latitude    DECIMAL(10,7) COMMENT '纬度',
    longitude   DECIMAL(10,7) COMMENT '经度',
    is_active   TINYINT(1)  DEFAULT 1 COMMENT '是否激活',
    created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_grade (grade),
    INDEX idx_city (city)
) COMMENT='门店信息表';

-- ============================================================
-- 2. SKU表
-- ============================================================
CREATE TABLE sku (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    sku_code        VARCHAR(30)    NOT NULL UNIQUE COMMENT 'SKU编码',
    sku_name        VARCHAR(100)   NOT NULL COMMENT 'SKU名称',
    brand           VARCHAR(30)    COMMENT '品牌：六月鲜/味达美/禾然/葱伴侣/小康',
    spec            VARCHAR(50)    COMMENT '规格：500ml/280ml',
    bottles_per_case INT           DEFAULT 12 COMMENT '每箱瓶数',
    price           DECIMAL(10,2)  COMMENT '零售价',
    cost            DECIMAL(10,2)  COMMENT '生产成本',
    gross_margin    DECIMAL(5,4)   COMMENT '毛利率',
    is_active       TINYINT(1)     DEFAULT 1,
    created_at      DATETIME       DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME       DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) COMMENT='SKU商品表';

-- ============================================================
-- 3. 产品年级表（同一SKU在不同城市年级可以不同）
-- ============================================================
CREATE TABLE sku_grade (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    sku_id          BIGINT       NOT NULL COMMENT '关联SKU',
    city            VARCHAR(50)  NOT NULL COMMENT '城市',
    grade_level     TINYINT      NOT NULL COMMENT '年级：1/2/3/4',
    entry_date      DATE         COMMENT '进入该城市的时间',
    incentive_coef  DECIMAL(4,2) COMMENT '激励系数：2.0/1.5/1.0/0.7',
    cost_rate_min   DECIMAL(5,4) COMMENT '费用率下限',
    cost_rate_max   DECIMAL(5,4) COMMENT '费用率上限',
    target_r        DECIMAL(8,2) COMMENT '目标日销率（瓶/天）',
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_sku_city (sku_id, city),
    FOREIGN KEY (sku_id) REFERENCES sku(id)
) COMMENT='SKU年级表（城市维度）';

-- ============================================================
-- 4. 业务员表
-- ============================================================
CREATE TABLE salesperson (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    employee_no     VARCHAR(20)  NOT NULL UNIQUE COMMENT '工号',
    real_name       VARCHAR(50)  NOT NULL COMMENT '姓名',
    wx_userid       VARCHAR(100) COMMENT '企微userid',
    phone           VARCHAR(20)  COMMENT '手机号',
    district        VARCHAR(50)  COMMENT '负责区域',
    city            VARCHAR(50)  DEFAULT '上海',
    manager_id      BIGINT       COMMENT '上级经理ID',
    is_active       TINYINT(1)   DEFAULT 1,
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (manager_id) REFERENCES salesperson(id)
) COMMENT='业务员表';

-- ============================================================
-- 5. 业务员负责门店关系表
-- ============================================================
CREATE TABLE salesperson_store (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    salesperson_id  BIGINT NOT NULL,
    store_id        BIGINT NOT NULL,
    is_primary      TINYINT(1) DEFAULT 1 COMMENT '是否主责任业务员',
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_sp_store (salesperson_id, store_id),
    FOREIGN KEY (salesperson_id) REFERENCES salesperson(id),
    FOREIGN KEY (store_id) REFERENCES store(id)
) COMMENT='业务员-门店关系表';

-- ============================================================
-- 6. 库存上报表（核心）
-- ============================================================
CREATE TABLE inventory_report (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    report_no           VARCHAR(30)   NOT NULL UNIQUE COMMENT '上报单号',
    store_id            BIGINT        NOT NULL COMMENT '门店ID',
    sku_id              BIGINT        NOT NULL COMMENT 'SKU ID',
    salesperson_id      BIGINT        NOT NULL COMMENT '上报业务员ID',

    -- 库存数据（业务员填写）
    shelf_qty           INT           NOT NULL DEFAULT 0 COMMENT '货架库存（瓶）',
    warehouse_qty_case  INT           NOT NULL DEFAULT 0 COMMENT '仓库库存（箱）',
    warehouse_qty_bottle INT          GENERATED ALWAYS AS (warehouse_qty_case * bottles_per_case) STORED COMMENT '仓库库存（瓶）',
    bottles_per_case    INT           NOT NULL DEFAULT 12 COMMENT '每箱瓶数（快照）',
    total_qty           INT           GENERATED ALWAYS AS (shelf_qty + warehouse_qty_case * bottles_per_case) STORED COMMENT '合计库存（瓶）',

    -- 照片
    photo_url           VARCHAR(500)  COMMENT '货架照片URL',

    -- 销速计算（系统自动）
    last_report_id      BIGINT        COMMENT '上次上报记录ID',
    last_report_qty     INT           COMMENT '上次合计库存（快照）',
    days_since_last     INT           COMMENT '距上次上报天数',
    actual_r            DECIMAL(8,2)  COMMENT '实际日销率（瓶/天）',
    target_r            DECIMAL(8,2)  COMMENT '目标日销率（瓶/天，快照）',
    achievement_rate    DECIMAL(6,4)  COMMENT '达成率（实际r÷目标r）',
    days_remaining      DECIMAL(8,1)  COMMENT '库存可卖天数',

    -- 水位状态
    water_level         TINYINT       COMMENT '水位状态：3=充足/2=预警/1=危险/0=断货',
    velocity_status     VARCHAR(20)   COMMENT '销速状态：FAST/NORMAL/SLOW/CRITICAL',

    -- 异常标记
    flag_stuffing       TINYINT(1)    DEFAULT 0 COMMENT '压货标记（A类失真）',
    flag_promotion      TINYINT(1)    DEFAULT 0 COMMENT '促销扰动（B类失真）',
    flag_gray_market    TINYINT(1)    DEFAULT 0 COMMENT '窜货/乱价（C类失真）',
    notes               VARCHAR(500)  COMMENT '业务员备注',

    -- 元数据
    report_time         DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '上报时间',
    gps_lat             DECIMAL(10,7) COMMENT 'GPS纬度',
    gps_lng             DECIMAL(10,7) COMMENT 'GPS经度',
    alert_sent          TINYINT(1)    DEFAULT 0 COMMENT '预警是否已推送',

    created_at          DATETIME      DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_store_sku (store_id, sku_id),
    INDEX idx_salesperson (salesperson_id),
    INDEX idx_report_time (report_time),
    INDEX idx_velocity_status (velocity_status),
    INDEX idx_alert (alert_sent, velocity_status),
    FOREIGN KEY (store_id) REFERENCES store(id),
    FOREIGN KEY (sku_id) REFERENCES sku(id),
    FOREIGN KEY (salesperson_id) REFERENCES salesperson(id)
) COMMENT='库存上报表（核心数据表）';

-- ============================================================
-- 7. 销速目标表（树根项目目标r）
-- ============================================================
CREATE TABLE velocity_target (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    store_id        BIGINT       NOT NULL,
    sku_id          BIGINT       NOT NULL,
    target_r        DECIMAL(8,2) NOT NULL COMMENT '目标日销率（瓶/天）',
    period_t        INT          NOT NULL COMMENT '周期天数T',
    target_a        DECIMAL(8,2) GENERATED ALWAYS AS (target_r * period_t) STORED COMMENT '目标单周期销量a',
    effective_date  DATE         NOT NULL COMMENT '生效日期',
    expiry_date     DATE         COMMENT '失效日期',
    source          VARCHAR(50)  COMMENT '数据来源：树根项目/测算',
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_store_sku_date (store_id, sku_id, effective_date),
    FOREIGN KEY (store_id) REFERENCES store(id),
    FOREIGN KEY (sku_id) REFERENCES sku(id)
) COMMENT='销速目标表（树根项目数据）';

-- ============================================================
-- 8. 一本账月度汇总表
-- ============================================================
CREATE TABLE account_monthly (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    salesperson_id      BIGINT       NOT NULL,
    year_month          CHAR(7)      NOT NULL COMMENT '年月：2026-04',
    store_id            BIGINT       NOT NULL,
    sku_id              BIGINT       NOT NULL,
    grade_level         TINYINT      COMMENT 'SKU年级',
    incentive_coef      DECIMAL(4,2) COMMENT '激励系数',
    target_qty          INT          COMMENT '月度目标销量',
    actual_qty          INT          COMMENT '月度实际销量（估算）',
    achievement_rate    DECIMAL(6,4) COMMENT '月度达成率',
    weighted_qty        DECIMAL(10,2) COMMENT '加权销量（×年级系数）',
    incentive_base      DECIMAL(8,4) COMMENT '激励基数（元/瓶）',
    incentive_amount    DECIMAL(10,2) COMMENT '月度激励金额',
    report_count        INT          COMMENT '上报次数',
    created_at          DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_sp_month_store_sku (salesperson_id, year_month, store_id, sku_id),
    FOREIGN KEY (salesperson_id) REFERENCES salesperson(id),
    FOREIGN KEY (store_id) REFERENCES store(id),
    FOREIGN KEY (sku_id) REFERENCES sku(id)
) COMMENT='一本账月度汇总';

-- ============================================================
-- 9. 企微预警日志表
-- ============================================================
CREATE TABLE alert_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    report_id       BIGINT       COMMENT '关联上报记录',
    alert_type      VARCHAR(30)  COMMENT '预警类型：SLOW/CRITICAL/FAST/STUFFING/GRAY_MARKET',
    store_name      VARCHAR(100),
    sku_name        VARCHAR(100),
    actual_r        DECIMAL(8,2),
    target_r        DECIMAL(8,2),
    achievement_rate DECIMAL(6,4),
    wx_webhook_url  VARCHAR(500) COMMENT '推送的Webhook地址',
    message_content TEXT         COMMENT '推送内容',
    send_status     VARCHAR(20)  COMMENT 'SUCCESS/FAILED',
    send_time       DATETIME,
    error_msg       VARCHAR(500),
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP
) COMMENT='企微预警推送日志';

-- ============================================================
-- 初始数据：上海试点
-- ============================================================

-- SKU数据
INSERT INTO sku (sku_code, sku_name, brand, spec, bottles_per_case, price, gross_margin) VALUES
('LYX-500', '六月鲜极鲜酱油500ml', '六月鲜', '500ml', 12, 28.90, 0.45),
('LYX-280', '六月鲜极鲜酱油280ml', '六月鲜', '280ml', 12, 18.90, 0.45),
('HR-500',  '禾然有机酱油500ml',   '禾然',   '500ml', 12, 35.90, 0.42),
('WDM-500', '味达美金标酱油500ml', '味达美', '500ml', 12, 15.90, 0.38),
('CBL-200', '葱伴侣200ml',         '葱伴侣', '200ml', 24, 8.90,  0.40);

-- 上海年级配置
INSERT INTO sku_grade (sku_id, city, grade_level, incentive_coef, cost_rate_min, cost_rate_max, target_r) VALUES
(1, '上海', 4, 0.70, 0.15, 0.25, 9.3),  -- 六月鲜500ml 四年级
(2, '上海', 4, 0.70, 0.15, 0.25, 3.5),  -- 六月鲜280ml 四年级
(3, '上海', 2, 1.50, 0.35, 0.45, 1.5),  -- 禾然有机    二年级
(4, '上海', 4, 0.70, 0.15, 0.25, 5.0),  -- 味达美      四年级
(5, '上海', 3, 1.00, 0.25, 0.35, 2.0);  -- 葱伴侣      三年级

-- 上海S+门店样本
INSERT INTO store (store_code, store_name, grade, district, city, latitude, longitude) VALUES
('SH-001', '家乐福古北店',   'S+', '长宁', '上海', 31.2201, 121.3975),
('SH-002', '沃尔玛曲阳店',   'S+', '虹口', '上海', 31.2735, 121.4958),
('SH-003', '大润发联洋店',   'S+', '浦东', '上海', 31.2151, 121.5637),
('SH-004', '永辉超市五角场', 'S+', '杨浦', '上海', 31.3089, 121.5264),
('SH-005', 'Costco闵行店',   'S+', '闵行', '上海', 31.1024, 121.3567),
('SH-006', '麦德龙北蔡店',   'S+', '浦东', '上海', 31.1756, 121.5421),
('SH-007', '家乐福虹桥店',   'S+', '闵行', '上海', 31.1893, 121.3654),
('SH-008', '联华超市淮海店', 'S+', '黄浦', '上海', 31.2167, 121.4672),
('SH-009', '沃尔玛金桥店',   'S+', '浦东', '上海', 31.2298, 121.5876),
('SH-010', '家乐福中山公园', 'S+', '长宁', '上海', 31.2256, 121.4123),
('SH-011', '家乐福五角场',   'S',  '杨浦', '上海', 31.3011, 121.5198),
('SH-012', '永辉超市闵行店', 'S',  '闵行', '上海', 31.1145, 121.3789),
('SH-013', '大润发嘉定店',   'S',  '嘉定', '上海', 31.3756, 121.2654),
('SH-014', '联华超市静安店', 'S',  '静安', '上海', 31.2298, 121.4532);

-- 速速目标（树根项目数据）
INSERT INTO velocity_target (store_id, sku_id, target_r, period_t, effective_date, source)
SELECT s.id, k.id,
    CASE k.sku_code
        WHEN 'LYX-500' THEN 9.3
        WHEN 'LYX-280' THEN 3.5
        WHEN 'HR-500'  THEN 1.5
        WHEN 'WDM-500' THEN 5.0
    END as target_r,
    CASE s.grade WHEN 'S+' THEN 7 WHEN 'S' THEN 7 WHEN 'A' THEN 7 WHEN 'B' THEN 14 ELSE 21 END as period_t,
    '2026-04-01' as effective_date,
    '树根项目' as source
FROM store s, sku k
WHERE s.city = '上海' AND k.sku_code IN ('LYX-500','LYX-280','HR-500','WDM-500');
