# INFINITY OS · 后端代码包
## 欣和SH · Java Spring Boot + MySQL

---

## 技术栈
- **Java 17**
- **Spring Boot 3.2**
- **MyBatis Plus 3.5**
- **MySQL 8.0**
- **Maven**

---

## 文件结构

```
infinity-os-backend/
├── database/
│   └── schema.sql                          ← 第一步：建库建表
├── pom.xml                                 ← Maven依赖
└── src/main/
    ├── resources/
    │   └── application.yml                 ← 配置文件（填入数据库密码）
    └── java/com/xinhe/infinityos/
        ├── controller/
        │   └── InventoryReportController   ← REST API接口
        ├── service/
        │   ├── InventoryReportService      ← 主业务逻辑
        │   ├── VelocityCalculationService  ← 销速计算引擎（核心）
        │   └── WechatWorkAlertService      ← 企微预警推送
        ├── entity/
        │   └── InventoryReport             ← 数据库实体
        └── dto/
            └── InventoryReportDTO          ← API请求/响应对象
```

---

## 快速启动

### 第一步：建库建表
```sql
mysql -u root -p < database/schema.sql
```

### 第二步：修改配置
编辑 `application.yml`：
```yaml
spring.datasource.password: 你的MySQL密码
wechat-work.corp-id: 企微CorpID
wechat-work.agent-id: 企微AgentID
wechat-work.secret: 企微Secret
wechat-work.alert-webhook: 企微群机器人Webhook地址
```

### 第三步：启动服务
```bash
mvn spring-boot:run
```

### 第四步：测试接口
```bash
# 健康检查
curl http://localhost:8080/api/v1/inventory/health

# 提交库存上报
curl -X POST http://localhost:8080/api/v1/inventory/report \
  -H "Content-Type: application/json" \
  -d '{
    "storeId": 1,
    "skuId": 1,
    "salespersonId": 1,
    "shelfQty": 20,
    "warehouseQtyCase": 2
  }'
```

---

## API 接口说明

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/v1/inventory/report | 提交库存上报（接 inventory-v3.html）|
| GET  | /api/v1/inventory/dashboard | 上海试点销速看板 |
| GET  | /api/v1/inventory/salesperson/{id}/account | 业务员一本账 |
| GET  | /api/v1/inventory/store/{id}/sku/{id}/context | 门店自动带入数据 |
| GET  | /api/v1/inventory/health | 健康检查 |

---

## 核心逻辑：销速计算

```
实际r = （上次库存 - 当前库存）÷ 间隔天数
达成率 = 实际r ÷ 目标r × 100%
可卖天数 = 当前库存 ÷ 实际r

销速状态：
  FAST     ≥ 110%  → 🚀 销速超标
  NORMAL   90-110% → ✅ 销速正常
  SLOW     60-90%  → ⚠️ 销速偏低
  CRITICAL < 60%   → 🔴 销速严重不足

三类失真检测：
  A类：库存 > 3a 且 达成率 < 60% → 疑似压货
  B类：业务员手动标记（促销扰动）
  C类：业务员手动标记（窜货/乱价）
```

---

## 对接 inventory-v3.html

修改前端提交代码：
```javascript
// inventory-v3.html 中的 doSubmit() 函数
// 将 TODO 部分替换为：

const response = await fetch('http://你的服务器IP:8080/api/v1/inventory/report', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    storeId: STORE.id,
    skuId: currentSkuId,
    salespersonId: SALESPERSON.id,
    shelfQty: shelf,
    warehouseQtyCase: warehouse,
    flagStuffing: flags.a,
    flagPromotion: flags.b,
    flagGrayMarket: flags.c,
    notes: document.getElementById('note')?.value || ''
  })
});

const result = await response.json();
// result.actualR, result.achievementRate 等自动返回
```

---

## 开发团队待完成

- [ ] `InventoryReportMapper.java` - MyBatis Mapper接口（按项目规范实现）
- [ ] `VelocityTargetMapper.java` - 目标销速查询
- [ ] `SkuMapper.java` / `StoreMapper.java` - 基础数据查询
- [ ] 企微JS-SDK登录（获取业务员userid）
- [ ] 照片上传接口（POST /api/v1/upload/photo）
- [ ] 集成到现有SFA App的WebView

---

## 与现有SFA系统的集成方式

**不需要重写，在现有SFA系统里加入：**

1. 新增数据库表（执行 schema.sql）
2. 把以上Java文件复制到现有SFA项目
3. SFA登录后，将门店信息通过URL参数传给 inventory-v3.html：

```
https://你的域名/inventory-v3.html
  ?storeId=001
  &userId=U123
  &token=xxx
```

4. inventory-v3.html 通过token验证身份，自动带入门店信息
