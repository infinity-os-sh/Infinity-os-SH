# INFINITY OS · 第3层记忆系统
## 交付物说明 & 集成指南

---

## 文件清单

```
memory-layer/
├── sql/
│   └── V1__create_memory_tables.sql          ← 第一步执行：建3张表
│
└── java/com/xinhe/infinityos/memory/
    ├── entity/
    │   └── AgentMemoryEvent.java             ← 事件记忆实体（含画像类注释）
    ├── repository/
    │   └── AgentMemoryRepositories.java      ← 数据库查询接口
    ├── service/
    │   └── AgentMemoryService.java           ← 核心服务：写入+读取+Prompt构建
    └── scheduler/
        └── MemoryMaintenanceScheduler.java   ← 定时维护（含API Controller注释）
```

---

## 集成步骤（Java团队执行）

### Step 1：建表（0.5天）
```sql
-- 直接在现有SFA数据库执行
source V1__create_memory_tables.sql;

-- 验证
SELECT * FROM v_memory_dashboard;
```

### Step 2：添加依赖（已有Spring Boot项目无需额外依赖）
```xml
<!-- pom.xml 确认以下依赖存在 -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-jpa</artifactId>
</dependency>
<dependency>
    <groupId>com.fasterxml.jackson.core</groupId>
    <artifactId>jackson-databind</artifactId>
</dependency>
```

### Step 3：复制Java文件到项目

将 `com.xinhe.infinityos.memory` 包整体复制到现有Spring Boot项目。

确认主Application类开启定时任务：
```java
@SpringBootApplication
@EnableScheduling   // ← 确保这行存在
public class InfinityOsApplication { ... }
```

### Step 4：集成到现有库存上报逻辑（1天）

在现有库存处理Service中注入记忆服务：

```java
@Service
public class InventoryReportService {

    @Autowired
    private AgentMemoryService memoryService;  // ← 注入记忆服务

    public void processInventoryReport(InventoryReport report) {

        // ... 现有的库存处理逻辑 ...

        // 【新增】写入记忆
        double waterLevel = calculateWaterLevel(report);
        if (waterLevel <= 2.0) {
            memoryService.recordLowInventory(
                "store",
                report.getStoreId(),
                report.getStoreName(),
                report.getRActual(),
                waterLevel <= 1.0 ? "1a" : "2a",
                report.getStockShelf(),
                report.getStockWarehouse()
            );
        }
    }
}
```

### Step 5：集成到Claude API调用（1天）

在现有Agent调用逻辑中加入记忆注入：

```java
@Service
public class AgentChatService {

    @Autowired
    private AgentMemoryService memoryService;  // ← 注入

    public String callAgent(String agentId, String entityId,
                            String basePrompt, String userQuestion) {

        // 【新增】构建含记忆的Prompt
        String promptWithMemory = memoryService.buildPromptWithMemory(
                agentId, entityId, basePrompt);

        // 调用Claude API（现有逻辑不变）
        return callClaudeApi(promptWithMemory, userQuestion);
    }
}
```

---

## 验证方法

数据上线后第1天，执行以下SQL验证记忆是否正常写入：

```sql
-- 查看今日事件记忆
SELECT agent_id, entity_name, event_type, severity, created_at
FROM agent_memory_events
WHERE DATE(created_at) = CURDATE()
ORDER BY severity DESC, created_at DESC
LIMIT 20;

-- 查看记忆系统健康
SELECT * FROM v_memory_dashboard;

-- 查看某个经销商的记忆
SELECT event_type, event_data, severity, created_at
FROM agent_memory_events
WHERE entity_id = '你的经销商ID'
ORDER BY created_at DESC
LIMIT 10;
```

---

## 里程碑检查

| 时间 | 检查项 | 通过标准 |
|------|--------|----------|
| 数据上线当天 | 3张表建立 | `SELECT COUNT(*) FROM agent_memory_events` 可执行 |
| 第3天 | 事件写入 | 每天至少有新事件记录 |
| 第7天 | Prompt注入 | 蝴蝶效应Agent回答包含"近X天"历史信息 |
| 第30天 | 预警质量 | 误报率 vs 无记忆版本对比 |

---

## TODO清单（二期）

`AgentMemoryProfile` 实体类和 Repository（文件中有注释版本）：
- [ ] 补全 `AgentMemoryProfile.java`（实体类）
- [ ] 补全 `AgentMemoryProfileRepository.java`
- [ ] 补全 `AgentMemoryDecision.java`（决策记忆）
- [ ] 实现 `MemoryMaintenanceScheduler` 中的3个TODO
- [ ] 实现 `MemoryApiController`（REST接口供前端调用）
- [ ] 风险评分算法（基于事件频率+severity加权）

---

## 最小可行版本（MVP）

如果资源紧张，只做这3件事即可启动记忆层：

1. **建表**：执行 `V1__create_memory_tables.sql`（30分钟）
2. **写入**：在库存上报处理后调用 `recordLowInventory()`（1天）
3. **注入**：蝴蝶效应Agent调用前执行 `buildPromptWithMemory()`（1天）

**总计：约2天，记忆层最小版本上线。**
