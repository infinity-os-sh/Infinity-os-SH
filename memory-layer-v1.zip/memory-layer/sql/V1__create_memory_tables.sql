-- ============================================================
-- INFINITY OS · 第3层记忆系统 · 数据库建表脚本
-- Version: 1.0
-- 执行顺序：直接在现有SFA数据库执行，无依赖冲突
-- ============================================================

-- ── 表1：事件记忆表 ──────────────────────────────────────────
-- 记录每一次Agent检测到的异常事件
-- 短期记忆：7天自动过期 | 中期：保留90天压缩进画像
CREATE TABLE IF NOT EXISTS agent_memory_events (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id        VARCHAR(50)  NOT NULL COMMENT 'Agent标识: butterfly/omakase/calibration等',
    entity_type     VARCHAR(20)  NOT NULL COMMENT '实体类型: store/distributor/sub_dist/sku',
    entity_id       VARCHAR(100) NOT NULL COMMENT '实体ID: 门店编号/经销商编号',
    entity_name     VARCHAR(200) COMMENT '实体名称（冗余，方便查询）',
    event_type      VARCHAR(50)  NOT NULL COMMENT '事件类型: low_inventory/distortion_A/distortion_B/distortion_C/order_pushed/r_drop/r_spike',
    event_data      JSON         NOT NULL COMMENT '事件详细数据，结构见注释',
    severity        TINYINT      NOT NULL DEFAULT 3 COMMENT '紧急程度 1=信息 2=低 3=中 4=高 5=紧急',
    is_resolved     BOOLEAN      NOT NULL DEFAULT FALSE COMMENT '是否已处理',
    resolved_at     DATETIME     COMMENT '处理时间',
    resolved_note   VARCHAR(500) COMMENT '处理备注',
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      DATETIME     NOT NULL COMMENT '短期记忆过期时间，建表时设为 created_at + 7天',
    INDEX idx_entity        (entity_type, entity_id),
    INDEX idx_agent_entity  (agent_id, entity_id),
    INDEX idx_event_type    (event_type),
    INDEX idx_severity      (severity),
    INDEX idx_created       (created_at),
    INDEX idx_expires       (expires_at),
    INDEX idx_unresolved    (is_resolved, severity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent事件记忆表';

-- event_data JSON示例：
-- low_inventory:    {"r_actual": 2.3, "water_level": "1a", "stock_shelf": 12, "stock_warehouse": 5, "threshold": "2a"}
-- distortion_A:     {"type": "channel_stuffing", "distributor_stock": 180, "normal_max": 60, "ratio": 3.0}
-- distortion_B:     {"type": "promo_distortion", "promo_name": "618大促", "lift_ratio": 2.8}
-- distortion_C:     {"type": "gray_market", "price_detected": 14.5, "price_floor": 17.0, "location": "徐汇区"}
-- order_pushed:     {"sku_list": ["六月鲜500ml","六月鲜1L"], "quantities": [24, 12], "total_value": 1680}
-- r_drop:           {"r_before": 3.2, "r_after": 1.8, "drop_pct": 43.75, "possible_cause": "断货"}


-- ── 表2：实体画像表 ──────────────────────────────────────────
-- 每个门店/经销商的完整历史画像（中长期记忆）
CREATE TABLE IF NOT EXISTS agent_memory_profiles (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    entity_type     VARCHAR(20)  NOT NULL COMMENT 'store/distributor/sub_dist',
    entity_id       VARCHAR(100) NOT NULL COMMENT '实体唯一标识',
    entity_name     VARCHAR(200) COMMENT '实体名称',
    city_code       VARCHAR(20)  COMMENT '城市编码',
    grade           VARCHAR(10)  COMMENT '门店等级: S+/S/A/B/C/D',
    channel         VARCHAR(20)  COMMENT '渠道: P1/P2',

    -- 销速记忆
    r_current       DECIMAL(8,3) COMMENT '当前r值（日销量）',
    r_history_90d   JSON         COMMENT '近90天每日r值数组 [{date,r_value,is_valid}]',
    r_avg_30d       DECIMAL(8,3) COMMENT '近30天平均r值',
    r_avg_90d       DECIMAL(8,3) COMMENT '近90天平均r值',
    r_trend         VARCHAR(20)  COMMENT '趋势: rising/stable/declining/volatile',

    -- 库存记忆
    a_value         DECIMAL(8,3) COMMENT '心跳单元a（一个周期T的销量）',
    cycle_days      INT          COMMENT '周转周期T（天）',
    last_water_level VARCHAR(10) COMMENT '上次记录水位: 3a/2a/1a/0',
    low_inventory_count_30d INT DEFAULT 0 COMMENT '近30天低库存次数',

    -- 行为模式记忆
    distortion_history JSON      COMMENT '失真记录汇总 {A_count, B_count, C_count, last_distortion_date}',
    risk_score      INT          COMMENT '风险评分 0-100，越高风险越大',
    risk_factors    JSON         COMMENT '风险因子明细',
    seasonal_pattern JSON        COMMENT '季节性模式 {月份: 系数}',

    -- 决策记忆
    last_order_date DATE         COMMENT '上次推单日期',
    last_order_acceptance BOOLEAN COMMENT '上次推单是否被接受',
    order_acceptance_rate DECIMAL(5,2) COMMENT '历史推单接受率%',
    avg_order_absorption_days INT COMMENT '平均消化推单天数',

    profile_version INT          NOT NULL DEFAULT 1 COMMENT '画像版本号，每次更新+1',
    last_updated    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uk_entity (entity_type, entity_id),
    INDEX idx_city      (city_code),
    INDEX idx_grade     (grade),
    INDEX idx_risk      (risk_score),
    INDEX idx_r_trend   (r_trend),
    INDEX idx_updated   (last_updated)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent实体画像表（中长期记忆）';


-- ── 表3：决策记忆表 ──────────────────────────────────────────
-- 记录每次Agent的决策行为和事后结果（用于自我学习）
CREATE TABLE IF NOT EXISTS agent_memory_decisions (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id        VARCHAR(50)  NOT NULL COMMENT 'Agent标识',
    decision_type   VARCHAR(50)  NOT NULL COMMENT '决策类型: push_order/alert_send/r_calibrate/risk_flag',
    entity_type     VARCHAR(20)  NOT NULL,
    entity_id       VARCHAR(100) NOT NULL,

    -- 决策输入
    input_snapshot  JSON         NOT NULL COMMENT '决策时的完整输入数据快照',
    memory_used     JSON         COMMENT '本次决策使用了哪些记忆条目（id列表）',

    -- 决策输出
    output_action   JSON         NOT NULL COMMENT '执行了什么动作',
    output_summary  VARCHAR(500) COMMENT '决策摘要（中文，方便人工审阅）',
    confidence      DECIMAL(5,2) COMMENT 'Agent置信度 0-100',

    -- 事后评估（延迟回填）
    outcome_status  VARCHAR(20)  COMMENT '结果状态: pending/success/failed/partial',
    outcome_data    JSON         COMMENT '实际结果数据',
    outcome_measured_at DATETIME COMMENT '结果测量时间',
    feedback_score  DECIMAL(5,2) COMMENT '决策质量评分 0-100（系统自动算）',
    feedback_note   VARCHAR(500) COMMENT '人工备注',

    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_agent         (agent_id),
    INDEX idx_entity        (entity_type, entity_id),
    INDEX idx_decision_type (decision_type),
    INDEX idx_outcome       (outcome_status),
    INDEX idx_created       (created_at),
    INDEX idx_pending       (outcome_status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent决策记忆表（自我学习）';


-- ── 初始化视图：记忆健康仪表盘 ──────────────────────────────
CREATE OR REPLACE VIEW v_memory_dashboard AS
SELECT
    '事件记忆'                                      AS memory_type,
    COUNT(*)                                        AS total_count,
    SUM(CASE WHEN severity >= 4 THEN 1 ELSE 0 END) AS high_severity_count,
    SUM(CASE WHEN is_resolved = FALSE THEN 1 ELSE 0 END) AS unresolved_count,
    MIN(created_at)                                 AS earliest_record,
    MAX(created_at)                                 AS latest_record
FROM agent_memory_events
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)

UNION ALL

SELECT
    '实体画像',
    COUNT(*),
    SUM(CASE WHEN risk_score >= 70 THEN 1 ELSE 0 END),
    SUM(CASE WHEN last_updated < DATE_SUB(NOW(), INTERVAL 2 DAY) THEN 1 ELSE 0 END),
    MIN(created_at),
    MAX(last_updated)
FROM agent_memory_profiles

UNION ALL

SELECT
    '决策记忆',
    COUNT(*),
    SUM(CASE WHEN outcome_status = 'failed' THEN 1 ELSE 0 END),
    SUM(CASE WHEN outcome_status = 'pending' THEN 1 ELSE 0 END),
    MIN(created_at),
    MAX(created_at)
FROM agent_memory_decisions
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);


-- ── 定期清理过期短期记忆（可配置为MySQL Event） ──────────────
-- 建议设置为每天凌晨2点执行
-- CREATE EVENT IF NOT EXISTS cleanup_expired_memory
-- ON SCHEDULE EVERY 1 DAY STARTS '2025-01-01 02:00:00'
-- DO
--   DELETE FROM agent_memory_events
--   WHERE expires_at < NOW() AND is_resolved = TRUE;

SELECT '✅ INFINITY OS 记忆层数据库建表完成' AS status;
