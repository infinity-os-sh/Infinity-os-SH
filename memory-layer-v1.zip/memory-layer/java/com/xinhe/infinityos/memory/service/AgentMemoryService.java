// ============================================================
// AgentMemoryService.java
// 记忆层核心服务
// 职责：写入记忆 + 构建prompt上下文 + 更新画像
// ============================================================
package com.xinhe.infinityos.memory.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.xinhe.infinityos.memory.entity.AgentMemoryEvent;
import com.xinhe.infinityos.memory.repository.AgentMemoryEventRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AgentMemoryService {

    private static final Logger log = LoggerFactory.getLogger(AgentMemoryService.class);
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("MM-dd HH:mm");

    @Autowired
    private AgentMemoryEventRepository eventRepo;

    @Autowired
    private ObjectMapper objectMapper;

    // ══════════════════════════════════════════════════════════
    // 1. 记忆写入（每次Agent检测到事件时调用）
    // ══════════════════════════════════════════════════════════

    /**
     * 写入低库存事件
     * 调用时机：库存上报数据处理后，水位低于预警线时
     */
    @Transactional
    public void recordLowInventory(String entityType, String entityId,
                                   String entityName, double rActual,
                                   String waterLevel, int stockShelf,
                                   int stockWarehouse) {
        try {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("r_actual", rActual);
            data.put("water_level", waterLevel);
            data.put("stock_shelf", stockShelf);
            data.put("stock_warehouse", stockWarehouse);
            data.put("threshold", "2a");

            // 判断紧急程度：1a以下=5级，2a以下=4级
            int severity = waterLevel.equals("1a") || waterLevel.equals("0") ? 5 : 4;

            AgentMemoryEvent event = AgentMemoryEvent.create(
                    AgentMemoryEvent.AGENT_BUTTERFLY,
                    entityType, entityId, entityName,
                    AgentMemoryEvent.TYPE_LOW_INVENTORY,
                    objectMapper.writeValueAsString(data),
                    severity
            );
            eventRepo.save(event);
            log.info("[记忆写入] 低库存 | {} | {} | 水位:{} | 货架:{} 仓库:{}",
                    entityId, entityName, waterLevel, stockShelf, stockWarehouse);
        } catch (Exception e) {
            log.error("[记忆写入失败] 低库存 | {}", entityId, e);
        }
    }

    /**
     * 写入失真检测事件（A/B/C三类）
     * 调用时机：蝴蝶效应Agent检测到异常时
     */
    @Transactional
    public void recordDistortion(String entityId, String entityName,
                                 String distortionType, Map<String, Object> details) {
        try {
            String eventType = switch (distortionType) {
                case "A" -> AgentMemoryEvent.TYPE_DISTORTION_A;
                case "B" -> AgentMemoryEvent.TYPE_DISTORTION_B;
                case "C" -> AgentMemoryEvent.TYPE_DISTORTION_C;
                default  -> "distortion_unknown";
            };

            AgentMemoryEvent event = AgentMemoryEvent.create(
                    AgentMemoryEvent.AGENT_BUTTERFLY,
                    "distributor", entityId, entityName,
                    eventType,
                    objectMapper.writeValueAsString(details),
                    4 // 失真默认高优先级
            );
            eventRepo.save(event);
            log.info("[记忆写入] 失真{} | {} | {}", distortionType, entityId, entityName);
        } catch (Exception e) {
            log.error("[记忆写入失败] 失真 | {}", entityId, e);
        }
    }

    /**
     * 写入推单事件
     * 调用时机：无菜单推单Agent发出推单后
     */
    @Transactional
    public void recordOrderPushed(String distributorId, String distributorName,
                                  List<String> skuList, List<Integer> quantities,
                                  double totalValue) {
        try {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("sku_list", skuList);
            data.put("quantities", quantities);
            data.put("total_value", totalValue);
            data.put("pushed_at", LocalDateTime.now().format(FMT));

            AgentMemoryEvent event = AgentMemoryEvent.create(
                    AgentMemoryEvent.AGENT_OMAKASE,
                    "distributor", distributorId, distributorName,
                    AgentMemoryEvent.TYPE_ORDER_PUSHED,
                    objectMapper.writeValueAsString(data),
                    2
            );
            eventRepo.save(event);
            log.info("[记忆写入] 推单 | {} | SKU数:{} | 总值:{}",
                    distributorId, skuList.size(), totalValue);
        } catch (Exception e) {
            log.error("[记忆写入失败] 推单 | {}", distributorId, e);
        }
    }

    /**
     * 写入r值异常变化事件
     * 调用时机：A值校准Agent发现r值显著变化时
     */
    @Transactional
    public void recordRChange(String entityId, String entityName,
                              double rBefore, double rAfter, String possibleCause) {
        try {
            double changePct = Math.abs((rAfter - rBefore) / rBefore * 100);
            String eventType = rAfter < rBefore ?
                    AgentMemoryEvent.TYPE_R_DROP : AgentMemoryEvent.TYPE_R_SPIKE;

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("r_before", rBefore);
            data.put("r_after", rAfter);
            data.put("change_pct", Math.round(changePct * 10.0) / 10.0);
            data.put("possible_cause", possibleCause);

            int severity = changePct > 40 ? 4 : changePct > 20 ? 3 : 2;

            AgentMemoryEvent event = AgentMemoryEvent.create(
                    AgentMemoryEvent.AGENT_CALIBRATION,
                    "store", entityId, entityName,
                    eventType,
                    objectMapper.writeValueAsString(data),
                    severity
            );
            eventRepo.save(event);
        } catch (Exception e) {
            log.error("[记忆写入失败] r值变化 | {}", entityId, e);
        }
    }

    // ══════════════════════════════════════════════════════════
    // 2. 记忆读取与Prompt构建（每次调用Agent前执行）
    // ══════════════════════════════════════════════════════════

    /**
     * 核心方法：为Agent构建包含记忆的完整System Prompt
     *
     * 使用方式：
     *   String prompt = memoryService.buildPromptWithMemory(
     *       "butterfly", "DIST_001", baseSystemPrompt);
     *   // 然后将prompt传给Claude API调用
     */
    public String buildPromptWithMemory(String agentId, String entityId,
                                        String baseSystemPrompt) {
        StringBuilder memory = new StringBuilder();
        memory.append("\n\n【记忆上下文 - 系统自动注入】\n");

        // 近30天事件记忆
        List<AgentMemoryEvent> events = eventRepo.findRecentByEntity(
                entityId, LocalDateTime.now().minusDays(30));

        if (!events.isEmpty()) {
            memory.append("=== 该实体近30天历史事件（").append(events.size()).append("条）===\n");
            events.stream().limit(10).forEach(e -> {
                String icon = getSeverityIcon(e.getSeverity());
                memory.append(icon)
                      .append(" [").append(e.getCreatedAt().format(FMT)).append("] ")
                      .append(translateEventType(e.getEventType()))
                      .append(" | ").append(e.getEntityName())
                      .append(e.getIsResolved() ? " ✓已处理" : " ⚠未处理")
                      .append("\n");
            });

            // 统计低库存发生频率
            long lowInvCount = events.stream()
                    .filter(e -> e.getEventType().equals(AgentMemoryEvent.TYPE_LOW_INVENTORY))
                    .count();
            if (lowInvCount > 0) {
                memory.append("→ 低库存事件近30天共发生 ").append(lowInvCount).append(" 次\n");
            }

            // 统计失真次数
            long distortionCount = events.stream()
                    .filter(e -> e.getEventType().startsWith("distortion"))
                    .count();
            if (distortionCount > 0) {
                memory.append("→ 失真预警近30天共发生 ").append(distortionCount).append(" 次\n");
            }
        } else {
            memory.append("=== 该实体近30天无历史事件记录 ===\n");
        }

        // 未解决高优先级事件提醒
        List<AgentMemoryEvent> unresolved = eventRepo.findUnresolvedHighPriority(
                agentId, LocalDateTime.now().minusDays(7));
        if (!unresolved.isEmpty()) {
            memory.append("\n🔴 当前未处理高优先级事件（").append(unresolved.size()).append("条）：\n");
            unresolved.stream().limit(5).forEach(e ->
                    memory.append("  • ").append(e.getEntityName())
                          .append(" - ").append(translateEventType(e.getEventType()))
                          .append(" [").append(e.getCreatedAt().format(FMT)).append("]\n")
            );
        }

        memory.append("【记忆上下文结束】\n");

        return baseSystemPrompt + memory.toString();
    }

    /**
     * 简化版：只注入事件摘要（token较少，适合快速响应场景）
     */
    public String buildLightMemoryContext(String entityId) {
        List<AgentMemoryEvent> events = eventRepo.findRecentByEntity(
                entityId, LocalDateTime.now().minusDays(7));

        if (events.isEmpty()) return "该实体近7天无异常记录。";

        long unresolvedHigh = events.stream()
                .filter(e -> e.getSeverity() >= 4 && !e.getIsResolved())
                .count();

        return String.format("近7天事件%d条，其中%d条高优先级未处理。最近事件：%s（%s）",
                events.size(),
                unresolvedHigh,
                translateEventType(events.get(0).getEventType()),
                events.get(0).getCreatedAt().format(FMT));
    }

    // ══════════════════════════════════════════════════════════
    // 3. 工具方法
    // ══════════════════════════════════════════════════════════

    private String getSeverityIcon(int severity) {
        return switch (severity) {
            case 5 -> "🔴";
            case 4 -> "🟠";
            case 3 -> "🟡";
            case 2 -> "🔵";
            default -> "⚪";
        };
    }

    private String translateEventType(String eventType) {
        return switch (eventType) {
            case "low_inventory"  -> "低库存预警";
            case "distortion_A"   -> "失真A-渠道压货";
            case "distortion_B"   -> "失真B-促销扭曲";
            case "distortion_C"   -> "失真C-灰市窜货";
            case "order_pushed"   -> "推单已发出";
            case "r_drop"         -> "r值下降";
            case "r_spike"        -> "r值异常上升";
            default               -> eventType;
        };
    }
}
