// ============================================================
// AgentMemoryEvent.java
// 事件记忆实体类
// ============================================================
package com.xinhe.infinityos.memory.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "agent_memory_events")
public class AgentMemoryEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "agent_id", nullable = false, length = 50)
    private String agentId;

    @Column(name = "entity_type", nullable = false, length = 20)
    private String entityType; // store / distributor / sub_dist / sku

    @Column(name = "entity_id", nullable = false, length = 100)
    private String entityId;

    @Column(name = "entity_name", length = 200)
    private String entityName;

    @Column(name = "event_type", nullable = false, length = 50)
    private String eventType;
    // 枚举值：low_inventory / distortion_A / distortion_B / distortion_C
    //         order_pushed / r_drop / r_spike / alert_sent

    @Column(name = "event_data", nullable = false, columnDefinition = "JSON")
    private String eventData; // JSON字符串

    @Column(name = "severity", nullable = false)
    private Integer severity; // 1-5

    @Column(name = "is_resolved", nullable = false)
    private Boolean isResolved = false;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    @Column(name = "resolved_note", length = 500)
    private String resolvedNote;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;

    // ── 工厂方法 ─────────────────────────────────────────────

    public static AgentMemoryEvent create(
            String agentId, String entityType, String entityId,
            String entityName, String eventType, String eventData, int severity) {

        AgentMemoryEvent e = new AgentMemoryEvent();
        e.agentId     = agentId;
        e.entityType  = entityType;
        e.entityId    = entityId;
        e.entityName  = entityName;
        e.eventType   = eventType;
        e.eventData   = eventData;
        e.severity    = severity;
        e.isResolved  = false;
        e.createdAt   = LocalDateTime.now();
        e.expiresAt   = LocalDateTime.now().plusDays(7); // 短期记忆7天
        return e;
    }

    // ── 常用事件类型常量 ─────────────────────────────────────
    public static final String TYPE_LOW_INVENTORY  = "low_inventory";
    public static final String TYPE_DISTORTION_A   = "distortion_A";   // 渠道压货
    public static final String TYPE_DISTORTION_B   = "distortion_B";   // 促销扭曲
    public static final String TYPE_DISTORTION_C   = "distortion_C";   // 灰市窜货
    public static final String TYPE_ORDER_PUSHED   = "order_pushed";
    public static final String TYPE_R_DROP         = "r_drop";
    public static final String TYPE_R_SPIKE        = "r_spike";

    // ── Agent标识常量 ────────────────────────────────────────
    public static final String AGENT_BUTTERFLY     = "butterfly";       // 蝴蝶效应
    public static final String AGENT_OMAKASE       = "omakase";         // 无菜单推单
    public static final String AGENT_CALIBRATION   = "calibration";     // A值校准
    public static final String AGENT_UBER          = "uber_incentive";  // Uber激励

    // Getters & Setters
    public Long getId() { return id; }
    public String getAgentId() { return agentId; }
    public void setAgentId(String agentId) { this.agentId = agentId; }
    public String getEntityType() { return entityType; }
    public void setEntityType(String entityType) { this.entityType = entityType; }
    public String getEntityId() { return entityId; }
    public void setEntityId(String entityId) { this.entityId = entityId; }
    public String getEntityName() { return entityName; }
    public void setEntityName(String entityName) { this.entityName = entityName; }
    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }
    public String getEventData() { return eventData; }
    public void setEventData(String eventData) { this.eventData = eventData; }
    public Integer getSeverity() { return severity; }
    public void setSeverity(Integer severity) { this.severity = severity; }
    public Boolean getIsResolved() { return isResolved; }
    public void setIsResolved(Boolean isResolved) { this.isResolved = isResolved; }
    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }
    public String getResolvedNote() { return resolvedNote; }
    public void setResolvedNote(String resolvedNote) { this.resolvedNote = resolvedNote; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(LocalDateTime expiresAt) { this.expiresAt = expiresAt; }
}


// ============================================================
// AgentMemoryProfile.java
// 实体画像实体类（中长期记忆）
// ============================================================
// package com.xinhe.infinityos.memory.entity;
// （同一文件展示，实际拆分为单独文件）

// @Entity
// @Table(name = "agent_memory_profiles")
// public class AgentMemoryProfile {
//
//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;
//
//     @Column(name = "entity_type", nullable = false, length = 20)
//     private String entityType;
//
//     @Column(name = "entity_id", nullable = false, length = 100)
//     private String entityId;
//
//     @Column(name = "entity_name", length = 200)
//     private String entityName;
//
//     @Column(name = "city_code", length = 20)
//     private String cityCode;
//
//     @Column(name = "grade", length = 10)
//     private String grade; // S+ / S / A / B / C / D
//
//     @Column(name = "channel", length = 20)
//     private String channel; // P1 / P2
//
//     // 销速记忆
//     @Column(name = "r_current", precision = 8, scale = 3)
//     private BigDecimal rCurrent;
//
//     @Column(name = "r_history_90d", columnDefinition = "JSON")
//     private String rHistory90d;
//
//     @Column(name = "r_avg_30d", precision = 8, scale = 3)
//     private BigDecimal rAvg30d;
//
//     @Column(name = "r_avg_90d", precision = 8, scale = 3)
//     private BigDecimal rAvg90d;
//
//     @Column(name = "r_trend", length = 20)
//     private String rTrend; // rising / stable / declining / volatile
//
//     // 库存记忆
//     @Column(name = "a_value", precision = 8, scale = 3)
//     private BigDecimal aValue;
//
//     @Column(name = "cycle_days")
//     private Integer cycleDays;
//
//     @Column(name = "last_water_level", length = 10)
//     private String lastWaterLevel;
//
//     @Column(name = "low_inventory_count_30d")
//     private Integer lowInventoryCount30d = 0;
//
//     // 行为模式记忆
//     @Column(name = "distortion_history", columnDefinition = "JSON")
//     private String distortionHistory;
//
//     @Column(name = "risk_score")
//     private Integer riskScore;
//
//     @Column(name = "risk_factors", columnDefinition = "JSON")
//     private String riskFactors;
//
//     @Column(name = "seasonal_pattern", columnDefinition = "JSON")
//     private String seasonalPattern;
//
//     // 决策记忆
//     @Column(name = "last_order_date")
//     private LocalDate lastOrderDate;
//
//     @Column(name = "last_order_acceptance")
//     private Boolean lastOrderAcceptance;
//
//     @Column(name = "order_acceptance_rate", precision = 5, scale = 2)
//     private BigDecimal orderAcceptanceRate;
//
//     @Column(name = "avg_order_absorption_days")
//     private Integer avgOrderAbsorptionDays;
//
//     @Column(name = "profile_version", nullable = false)
//     private Integer profileVersion = 1;
//
//     @Column(name = "last_updated", nullable = false)
//     private LocalDateTime lastUpdated;
//
//     @Column(name = "created_at", nullable = false)
//     private LocalDateTime createdAt;
//     // ... getters & setters
// }
