// ============================================================
// AgentMemoryEventRepository.java
// ============================================================
package com.xinhe.infinityos.memory.repository;

import com.xinhe.infinityos.memory.entity.AgentMemoryEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AgentMemoryEventRepository extends JpaRepository<AgentMemoryEvent, Long> {

    // ── 核心查询：拉取记忆注入prompt ────────────────────────

    /**
     * 拉取某实体近N天的事件记忆（用于注入Agent prompt）
     */
    @Query("SELECT e FROM AgentMemoryEvent e " +
           "WHERE e.entityId = :entityId " +
           "AND e.createdAt >= :since " +
           "ORDER BY e.severity DESC, e.createdAt DESC")
    List<AgentMemoryEvent> findRecentByEntity(
            @Param("entityId") String entityId,
            @Param("since") LocalDateTime since);

    /**
     * 拉取某Agent处理的近期高优先级事件（severity >= 4）
     */
    @Query("SELECT e FROM AgentMemoryEvent e " +
           "WHERE e.agentId = :agentId " +
           "AND e.severity >= 4 " +
           "AND e.isResolved = false " +
           "AND e.createdAt >= :since " +
           "ORDER BY e.severity DESC, e.createdAt DESC")
    List<AgentMemoryEvent> findUnresolvedHighPriority(
            @Param("agentId") String agentId,
            @Param("since") LocalDateTime since);

    /**
     * 查某实体某类事件近期发生次数（用于判断"第N次出现"）
     */
    @Query("SELECT COUNT(e) FROM AgentMemoryEvent e " +
           "WHERE e.entityId = :entityId " +
           "AND e.eventType = :eventType " +
           "AND e.createdAt >= :since")
    int countByEntityAndType(
            @Param("entityId") String entityId,
            @Param("eventType") String eventType,
            @Param("since") LocalDateTime since);

    /**
     * 查某城市所有高风险门店（批量预警场景）
     */
    @Query("SELECT DISTINCT e.entityId FROM AgentMemoryEvent e " +
           "WHERE e.entityType = 'store' " +
           "AND e.severity >= :minSeverity " +
           "AND e.isResolved = false " +
           "AND e.createdAt >= :since")
    List<String> findHighRiskEntityIds(
            @Param("minSeverity") int minSeverity,
            @Param("since") LocalDateTime since);

    // ── 清理与维护 ────────────────────────────────────────

    /**
     * 清理已过期的已解决短期记忆（定时任务调用）
     */
    @Modifying
    @Query("DELETE FROM AgentMemoryEvent e " +
           "WHERE e.expiresAt < :now AND e.isResolved = true")
    int deleteExpiredResolvedEvents(@Param("now") LocalDateTime now);

    /**
     * 标记某实体所有相关事件为已解决
     */
    @Modifying
    @Query("UPDATE AgentMemoryEvent e SET e.isResolved = true, " +
           "e.resolvedAt = :now, e.resolvedNote = :note " +
           "WHERE e.entityId = :entityId AND e.isResolved = false")
    int resolveAllForEntity(
            @Param("entityId") String entityId,
            @Param("now") LocalDateTime now,
            @Param("note") String note);
}


// ============================================================
// AgentMemoryProfileRepository.java
// ============================================================
// package com.xinhe.infinityos.memory.repository;
//
// @Repository
// public interface AgentMemoryProfileRepository
//         extends JpaRepository<AgentMemoryProfile, Long> {
//
//     Optional<AgentMemoryProfile> findByEntityTypeAndEntityId(
//             String entityType, String entityId);
//
//     List<AgentMemoryProfile> findByRiskScoreGreaterThanEqual(int minRisk);
//
//     List<AgentMemoryProfile> findByCityCodeAndEntityType(
//             String cityCode, String entityType);
//
//     @Query("SELECT p FROM AgentMemoryProfile p " +
//            "WHERE p.rTrend = 'declining' AND p.riskScore >= 60 " +
//            "ORDER BY p.riskScore DESC")
//     List<AgentMemoryProfile> findDecliningHighRisk();
//
//     @Query("SELECT p FROM AgentMemoryProfile p " +
//            "WHERE p.lowInventoryCount30d >= :threshold")
//     List<AgentMemoryProfile> findFrequentlyLowInventory(
//             @Param("threshold") int threshold);
// }


// ============================================================
// AgentMemoryDecisionRepository.java
// ============================================================
// package com.xinhe.infinityos.memory.repository;
//
// @Repository
// public interface AgentMemoryDecisionRepository
//         extends JpaRepository<AgentMemoryDecision, Long> {
//
//     Optional<AgentMemoryDecision> findTopByAgentIdAndEntityIdOrderByCreatedAtDesc(
//             String agentId, String entityId);
//
//     @Query("SELECT AVG(d.feedbackScore) FROM AgentMemoryDecision d " +
//            "WHERE d.agentId = :agentId AND d.outcomeStatus != 'pending' " +
//            "AND d.createdAt >= :since")
//     Double calculateAgentAccuracy(
//             @Param("agentId") String agentId,
//             @Param("since") LocalDateTime since);
//
//     @Query("SELECT d FROM AgentMemoryDecision d " +
//            "WHERE d.outcomeStatus = 'pending' " +
//            "AND d.createdAt < :cutoff")
//     List<AgentMemoryDecision> findPendingOutcomeOverdue(
//             @Param("cutoff") LocalDateTime cutoff);
// }
