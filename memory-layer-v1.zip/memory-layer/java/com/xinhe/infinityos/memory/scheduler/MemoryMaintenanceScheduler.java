// ============================================================
// MemoryMaintenanceScheduler.java
// 定时任务：每日记忆维护
// ============================================================
package com.xinhe.infinityos.memory.scheduler;

import com.xinhe.infinityos.memory.repository.AgentMemoryEventRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Component
public class MemoryMaintenanceScheduler {

    private static final Logger log = LoggerFactory.getLogger(MemoryMaintenanceScheduler.class);

    @Autowired
    private AgentMemoryEventRepository eventRepo;

    // ── 每天凌晨2点：清理过期记忆 ───────────────────────────
    @Scheduled(cron = "0 0 2 * * ?")
    @Transactional
    public void cleanupExpiredMemory() {
        log.info("[记忆维护] 开始清理过期短期记忆...");
        int deleted = eventRepo.deleteExpiredResolvedEvents(LocalDateTime.now());
        log.info("[记忆维护] 清理完成，删除 {} 条过期记录", deleted);
    }

    // ── 每天23:59：汇总当日事件 → 更新实体画像 ───────────────
    @Scheduled(cron = "0 59 23 * * ?")
    @Transactional
    public void updateDailyProfiles() {
        log.info("[记忆维护] 开始更新实体画像...");
        // TODO：
        // 1. 查询今日所有有事件的entity_id
        // 2. 更新 agent_memory_profiles 中对应实体的：
        //    - low_inventory_count_30d
        //    - risk_score（基于事件频率和severity加权）
        //    - r_trend（基于近7天r值方向）
        // 3. profile_version + 1
        log.info("[记忆维护] 实体画像更新完成");
    }

    // ── 每周日凌晨3点：计算周趋势 + 风险评分重算 ────────────
    @Scheduled(cron = "0 0 3 ? * SUN")
    @Transactional
    public void weeklyRiskRecalculation() {
        log.info("[记忆维护] 开始周度风险重算...");
        // TODO：
        // 1. 遍历所有 agent_memory_profiles
        // 2. 基于近90天事件重算risk_score
        // 3. 识别seasonal_pattern（同月份历史均值对比）
        // 4. 标记 r_trend：
        //    - 近7天均值 vs 近30天均值 > +15% → rising
        //    - 差值 < -15% → declining
        //    - 方差高 → volatile
        //    - 其他 → stable
        log.info("[记忆维护] 周度风险重算完成");
    }

    // ── 每月1日凌晨4点：归档压缩历史记忆 ───────────────────
    @Scheduled(cron = "0 0 4 1 * ?")
    @Transactional
    public void monthlyArchive() {
        log.info("[记忆维护] 开始月度归档...");
        // TODO：
        // 将超过90天的已解决事件压缩：
        // 不删除，而是将详细event_data压缩为摘要
        // 保留统计数字，删除原始JSON细节
        log.info("[记忆维护] 月度归档完成");
    }
}


// ============================================================
// MemoryApiController.java
// REST API：供前端INFINITY OS界面调用记忆数据
// ============================================================
// package com.xinhe.infinityos.memory.controller;
//
// @RestController
// @RequestMapping("/api/memory")
// public class MemoryApiController {
//
//     @Autowired
//     private AgentMemoryService memoryService;
//
//     @Autowired
//     private AgentMemoryEventRepository eventRepo;
//
//     /**
//      * GET /api/memory/events/{entityId}
//      * 查询某实体的近期事件记忆
//      */
//     @GetMapping("/events/{entityId}")
//     public ResponseEntity<List<AgentMemoryEvent>> getEntityEvents(
//             @PathVariable String entityId,
//             @RequestParam(defaultValue = "30") int days) {
//
//         List<AgentMemoryEvent> events = eventRepo.findRecentByEntity(
//                 entityId, LocalDateTime.now().minusDays(days));
//         return ResponseEntity.ok(events);
//     }
//
//     /**
//      * GET /api/memory/dashboard
//      * 记忆系统健康仪表盘
//      */
//     @GetMapping("/dashboard")
//     public ResponseEntity<Map<String, Object>> getDashboard() {
//         // 查询 v_memory_dashboard 视图
//         // 返回三类记忆的统计数据
//         return ResponseEntity.ok(Map.of("status", "ok"));
//     }
//
//     /**
//      * POST /api/memory/events/{eventId}/resolve
//      * 标记事件为已处理
//      */
//     @PostMapping("/events/{eventId}/resolve")
//     public ResponseEntity<Void> resolveEvent(
//             @PathVariable Long eventId,
//             @RequestBody Map<String, String> body) {
//         // 更新 is_resolved = true
//         return ResponseEntity.ok().build();
//     }
// }
