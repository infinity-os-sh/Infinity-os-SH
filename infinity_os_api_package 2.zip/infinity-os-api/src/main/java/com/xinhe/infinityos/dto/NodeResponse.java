package com.xinhe.infinityos.dto;

import com.xinhe.infinityos.entity.InfAction;
import com.xinhe.infinityos.entity.InfAlert;
import com.xinhe.infinityos.entity.InfHeartbeat;
import com.xinhe.infinityos.entity.InfNode;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * INFINITY OS · Universal Node Response DTO
 *
 * 前端 GET /api/v1/node/{nodeId} 的响应体
 * 格式固定，不管节点类型，始终返回这个结构
 * 前端 renderNode(response) 直接消费
 */
public class NodeResponse {

    // ── 节点身份 ──────────────────────────────────
    public String id;
    public String type;
    public String name;
    public String brand;
    public String channel;
    public Integer grade;
    public BigDecimal gradeCoeff;
    public Integer tDays;

    // ── 心跳公式 ──────────────────────────────────
    public HeartbeatDTO heartbeat;

    // ── CB 得分 ───────────────────────────────────
    public BigDecimal cbTotal;

    // ── 蝴蝶效应警报 ──────────────────────────────
    public List<AlertDTO> alerts;

    // ── 决策队列 ──────────────────────────────────
    public List<ActionDTO> actions;

    // ── 面包屑导航 ────────────────────────────────
    public List<BreadcrumbItem> breadcrumb;

    // ── 子节点下钻列表 ────────────────────────────
    public List<ChildSummary> children;

    // ── 内部 DTO ──────────────────────────────────

    public static class HeartbeatDTO {
        public BigDecimal aValue;
        public BigDecimal rActual;
        public BigDecimal rTarget;
        public BigDecimal rAchievement;       // 自动计算
        public Integer    inventoryUnits;
        public BigDecimal inventoryA;         // 自动计算
        public String     waterLevel;         // overflow/full/warn/low/empty
        public BigDecimal digestRate;
        public LocalDate  snapshotDate;
        public String     dataSource;
    }

    public static class AlertDTO {
        public Long    alertId;
        public String  type;                  // A/B/C/D
        public String  severity;              // yellow/orange/red
        public Integer ironLawRef;
        public String  title;
        public String  triggeredAt;
    }

    public static class ActionDTO {
        public Long    actionId;
        public String  type;
        public String  agent;
        public String  title;
        public Integer confidencePct;
        public String  impactLevel;           // high/mid/low
        public String  proposedPayload;
    }

    public static class BreadcrumbItem {
        public String id;
        public String name;
        public String type;

        public BreadcrumbItem(String id, String name, String type) {
            this.id = id; this.name = name; this.type = type;
        }
    }

    public static class ChildSummary {
        public String     id;
        public String     name;
        public String     type;
        public BigDecimal rAchievement;
        public String     waterLevel;
        public Long       activeAlertCount;
    }
}
