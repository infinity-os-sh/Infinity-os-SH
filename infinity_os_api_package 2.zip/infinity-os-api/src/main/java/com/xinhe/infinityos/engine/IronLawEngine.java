package com.xinhe.infinityos.engine;

import com.xinhe.infinityos.entity.InfAction;
import com.xinhe.infinityos.entity.InfAlert;
import com.xinhe.infinityos.entity.InfHeartbeat;
import com.xinhe.infinityos.entity.InfNode;
import com.xinhe.infinityos.repository.InfActionRepository;
import com.xinhe.infinityos.repository.InfAlertRepository;
import com.xinhe.infinityos.repository.InfHeartbeatRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * INFINITY OS · 铁律执行引擎
 *
 * 铁律① — 遵循自然 IPO10 价格 < ¥13/瓶 → 立即暂停
 * 铁律③ — 连续两月消化率 < 50% → 蝴蝶效应A类警报 + 暂停推单
 *
 * 调用时机：
 *   - 铁律①：每次 SKU 节点 ipo10_price 更新时调用
 *   - 铁律③：每月最后一天，批处理调用 checkIronLaw3All()
 */
@Component
public class IronLawEngine {

    private static final BigDecimal IRON_LAW_1_PRICE_FLOOR = BigDecimal.valueOf(13.00);
    private static final BigDecimal IRON_LAW_3_DIGEST_FLOOR = BigDecimal.valueOf(0.50);

    @Autowired
    private InfAlertRepository alertRepo;

    @Autowired
    private InfActionRepository actionRepo;

    @Autowired
    private InfHeartbeatRepository heartbeatRepo;

    // ──────────────────────────────────────────────────────────
    // 铁律①：IPO10 价格监控
    // ──────────────────────────────────────────────────────────

    /**
     * 检查铁律①：SKU 的 IPO10 价格是否低于 ¥13
     * 由 NodeService.updateNode() 调用
     */
    public void checkIronLaw1(InfNode node) {
        if (node.getIpo10Price() == null) return;
        if (!InfNode.NodeType.sku.equals(node.getNodeType())) return;

        if (node.getIpo10Price().compareTo(IRON_LAW_1_PRICE_FLOOR) < 0) {
            createAlert(
                node.getNodeId(),
                InfAlert.AlertType.D,
                InfAlert.Severity.red,
                1,
                "铁律①触发：IPO10价格低于¥13",
                String.format("当前 IPO10 价格 ¥%.2f，低于铁律①底线 ¥13.00，系统已自动提交暂停建议。",
                    node.getIpo10Price()),
                String.format("{\"ipo10_price\":%.2f,\"floor\":13.00}", node.getIpo10Price())
            );
            createSuspendAction(node.getNodeId(), "butterfly_agent",
                "铁律①触发：建议立即暂停该SKU销售", 100, InfAction.ImpactLevel.high);
        }
    }

    // ──────────────────────────────────────────────────────────
    // 铁律③：消化率连续两月监控
    // ──────────────────────────────────────────────────────────

    /**
     * 检查单个节点的铁律③
     * 每月底批处理调用
     */
    public void checkIronLaw3(String nodeId) {
        // 取最近两个月的消化率快照
        LocalDate today = LocalDate.now();
        LocalDate firstDayThisMonth  = today.withDayOfMonth(1);
        LocalDate firstDayLastMonth  = firstDayThisMonth.minusMonths(1);
        LocalDate firstDayTwoMonths  = firstDayThisMonth.minusMonths(2);

        List<InfHeartbeat> recentSnapshots = heartbeatRepo
            .findByNodeIdAndSnapshotDateBetweenOrderBySnapshotDateDesc(
                nodeId, firstDayTwoMonths, today);

        if (recentSnapshots.size() < 2) return;

        BigDecimal digestThisMonth = getMonthDigestRate(recentSnapshots, firstDayLastMonth);
        BigDecimal digestLastMonth = getMonthDigestRate(recentSnapshots, firstDayTwoMonths);

        if (digestThisMonth == null || digestLastMonth == null) return;

        boolean thisMonthFail = digestThisMonth.compareTo(IRON_LAW_3_DIGEST_FLOOR) < 0;
        boolean lastMonthFail = digestLastMonth.compareTo(IRON_LAW_3_DIGEST_FLOOR) < 0;

        if (thisMonthFail && lastMonthFail) {
            // 检查是否已有 active 的铁律③警报（避免重复）
            boolean alreadyActive = alertRepo.existsByNodeIdAndIronLawRefAndStatus(
                nodeId, 3, InfAlert.AlertStatus.active);
            if (alreadyActive) return;

            createAlert(
                nodeId,
                InfAlert.AlertType.A,
                InfAlert.Severity.red,
                3,
                "铁律③触发：连续两月消化率低于50%",
                String.format("上月消化率 %.1f%%，本月消化率 %.1f%%，连续两月未达50%%基准线。",
                    digestLastMonth.multiply(BigDecimal.valueOf(100)),
                    digestThisMonth.multiply(BigDecimal.valueOf(100))),
                String.format("{\"digest_this_month\":%.4f,\"digest_last_month\":%.4f,\"threshold\":0.5000}",
                    digestThisMonth, digestLastMonth)
            );

            // 自动暂停所有 pending 补货推单
            autoSuspendPendingReplenish(nodeId);

            // 写入暂停建议到决策队列
            createSuspendAction(nodeId, "butterfly_agent",
                "铁律③触发：建议暂停2周补货，启动溯源调查", 91, InfAction.ImpactLevel.high);
        }
    }

    // ──────────────────────────────────────────────────────────
    // 内部方法
    // ──────────────────────────────────────────────────────────

    private BigDecimal getMonthDigestRate(List<InfHeartbeat> snapshots, LocalDate monthStart) {
        return snapshots.stream()
            .filter(hb -> !hb.getSnapshotDate().isBefore(monthStart)
                       && hb.getSnapshotDate().isBefore(monthStart.plusMonths(1)))
            .filter(hb -> hb.getDigestRate() != null)
            .map(InfHeartbeat::getDigestRate)
            .findFirst()
            .orElse(null);
    }

    private void createAlert(String nodeId, InfAlert.AlertType type, InfAlert.Severity severity,
                             Integer ironLawRef, String title, String desc, String triggerValue) {
        InfAlert alert = new InfAlert();
        alert.setNodeId(nodeId);
        alert.setAlertType(type);
        alert.setSeverity(severity);
        alert.setIronLawRef(ironLawRef);
        alert.setTitle(title);
        alert.setDescription(desc);
        alert.setTriggerValue(triggerValue);
        alert.setTriggeredAt(LocalDateTime.now());
        alertRepo.save(alert);
    }

    private void createSuspendAction(String nodeId, String agent, String title,
                                     int confidence, InfAction.ImpactLevel impact) {
        InfAction action = new InfAction();
        action.setNodeId(nodeId);
        action.setAgentSource(agent);
        action.setActionType(InfAction.ActionType.suspend);
        action.setTitle(title);
        action.setConfidencePct(confidence);
        action.setImpactLevel(impact);
        actionRepo.save(action);
    }

    private void autoSuspendPendingReplenish(String nodeId) {
        // 将该节点所有 pending 的补货推单状态改为 overridden
        List<InfAction> pending = actionRepo.findByNodeIdAndActionTypeAndStatus(
            nodeId, InfAction.ActionType.replenish, InfAction.ActionStatus.pending);
        pending.forEach(a -> {
            a.setStatus(InfAction.ActionStatus.overridden);
            a.setOverrideReason("铁律③自动触发：消化率连续两月低于50%，暂停补货");
            a.setDecidedAt(LocalDateTime.now());
            a.setDecidedBy("iron_law_engine");
        });
        actionRepo.saveAll(pending);
    }
}
