package com.xinhe.infinityos.repository;

import com.xinhe.infinityos.entity.InfHeartbeat;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface InfHeartbeatRepository extends JpaRepository<InfHeartbeat, Long> {

    /** 查最新一条心跳记录 */
    Optional<InfHeartbeat> findTopByNodeIdOrderBySnapshotDateDesc(String nodeId);

    /** 查指定日期的心跳 */
    Optional<InfHeartbeat> findByNodeIdAndSnapshotDate(String nodeId, LocalDate date);

    /** 查时间范围内的心跳（用于铁律③月度消化率计算） */
    List<InfHeartbeat> findByNodeIdAndSnapshotDateBetweenOrderBySnapshotDateDesc(
        String nodeId, LocalDate from, LocalDate to);

    /** 查低水位节点（前端水位预警列表） */
    List<InfHeartbeat> findBySnapshotDateAndWaterLevel(
        LocalDate date, InfHeartbeat.WaterLevel waterLevel);
}
