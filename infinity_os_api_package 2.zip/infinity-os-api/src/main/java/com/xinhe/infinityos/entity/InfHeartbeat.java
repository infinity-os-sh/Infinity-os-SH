package com.xinhe.infinityos.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * INFINITY OS · 心跳快照表
 * 每节点每天一条记录，存 r 值和库存水位
 * r_achievement / inventory_a / water_level 由系统自动计算
 */
@Entity
@Table(name = "inf_heartbeat",
    uniqueConstraints = @UniqueConstraint(
        name = "uk_node_date", columnNames = {"node_id", "snapshot_date"}
    ),
    indexes = @Index(name = "idx_date", columnList = "snapshot_date")
)
public class InfHeartbeat {

    public enum WaterLevel {
        overflow,   // 超库：>3a(store) / >2a(dist) / >1a(sub_dist)  → 铁律③风险
        full,       // 满仓：正常上限
        warn,       // 预警：需要补货关注
        low,        // 低库：临近断货
        empty       // 断货
    }

    public enum DataSource {
        hanxun, dcloud, sfa, wms, manual, calculated
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hb_id")
    private Long hbId;

    @Column(name = "node_id", nullable = false, length = 64)
    private String nodeId;

    @Column(name = "snapshot_date", nullable = false)
    private LocalDate snapshotDate;

    // ── 心跳公式核心 ───────────────────────────
    @Column(name = "a_value", nullable = false, precision = 10, scale = 2)
    private BigDecimal aValue;              // 心跳单元

    @Column(name = "r_actual", nullable = false, precision = 10, scale = 4)
    private BigDecimal rActual;             // 实际日销率，来自汉询

    @Column(name = "r_target", nullable = false, precision = 10, scale = 4)
    private BigDecimal rTarget;             // 目标日销率，来自 inf_node_targets

    @Column(name = "r_achievement", precision = 5, scale = 2)
    private BigDecimal rAchievement;        // 自动计算：rActual / rTarget * 100

    // ── 库存水位 ───────────────────────────────
    @Column(name = "inventory_units", nullable = false)
    private Integer inventoryUnits;         // 实物库存件数

    @Column(name = "inventory_a", precision = 10, scale = 2)
    private BigDecimal inventoryA;          // 自动计算：inventoryUnits / aValue

    @Enumerated(EnumType.STRING)
    @Column(name = "water_level", length = 16)
    private WaterLevel waterLevel;          // 自动判断

    @Column(name = "digest_rate", precision = 5, scale = 4)
    private BigDecimal digestRate;          // 消化率，月底计算：出货/进货

    // ── CB 快照 ────────────────────────────────
    @Column(name = "cb_total", precision = 5, scale = 2)
    private BigDecimal cbTotal;

    @Enumerated(EnumType.STRING)
    @Column(name = "data_source", nullable = false, length = 32)
    private DataSource dataSource;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.computeDerivedFields();
    }

    @PreUpdate
    protected void onUpdate() { this.computeDerivedFields(); }

    /**
     * 在持久化前自动计算 rAchievement / inventoryA
     * waterLevel 由 HeartbeatEngine 计算后注入
     */
    public void computeDerivedFields() {
        if (rActual != null && rTarget != null && rTarget.compareTo(BigDecimal.ZERO) > 0) {
            this.rAchievement = rActual.divide(rTarget, 4, RoundingMode.HALF_UP)
                                       .multiply(BigDecimal.valueOf(100))
                                       .setScale(2, RoundingMode.HALF_UP);
        }
        if (inventoryUnits != null && aValue != null && aValue.compareTo(BigDecimal.ZERO) > 0) {
            this.inventoryA = BigDecimal.valueOf(inventoryUnits)
                                        .divide(aValue, 2, RoundingMode.HALF_UP);
        }
    }

    // ── Getters & Setters ──────────────────────────────────────
    public Long getHbId() { return hbId; }
    public String getNodeId() { return nodeId; }
    public void setNodeId(String nodeId) { this.nodeId = nodeId; }
    public LocalDate getSnapshotDate() { return snapshotDate; }
    public void setSnapshotDate(LocalDate snapshotDate) { this.snapshotDate = snapshotDate; }
    public BigDecimal getAValue() { return aValue; }
    public void setAValue(BigDecimal aValue) { this.aValue = aValue; }
    public BigDecimal getRActual() { return rActual; }
    public void setRActual(BigDecimal rActual) { this.rActual = rActual; }
    public BigDecimal getRTarget() { return rTarget; }
    public void setRTarget(BigDecimal rTarget) { this.rTarget = rTarget; }
    public BigDecimal getRAchievement() { return rAchievement; }
    public Integer getInventoryUnits() { return inventoryUnits; }
    public void setInventoryUnits(Integer inventoryUnits) { this.inventoryUnits = inventoryUnits; }
    public BigDecimal getInventoryA() { return inventoryA; }
    public WaterLevel getWaterLevel() { return waterLevel; }
    public void setWaterLevel(WaterLevel waterLevel) { this.waterLevel = waterLevel; }
    public BigDecimal getDigestRate() { return digestRate; }
    public void setDigestRate(BigDecimal digestRate) { this.digestRate = digestRate; }
    public BigDecimal getCbTotal() { return cbTotal; }
    public void setCbTotal(BigDecimal cbTotal) { this.cbTotal = cbTotal; }
    public DataSource getDataSource() { return dataSource; }
    public void setDataSource(DataSource dataSource) { this.dataSource = dataSource; }
}
