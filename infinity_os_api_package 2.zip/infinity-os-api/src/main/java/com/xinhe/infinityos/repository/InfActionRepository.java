package com.xinhe.infinityos.repository;

import com.xinhe.infinityos.entity.InfAction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InfActionRepository extends JpaRepository<InfAction, Long> {

    List<InfAction> findByNodeIdAndStatusOrderByImpactLevelAscProposedAtDesc(
        String nodeId, InfAction.ActionStatus status);

    List<InfAction> findByNodeIdAndActionTypeAndStatus(
        String nodeId, InfAction.ActionType type, InfAction.ActionStatus status);

    /** 全局待批准队列（首屏决策队列使用），按影响级别+时间排序 */
    List<InfAction> findByStatusOrderByImpactLevelAscProposedAtDesc(
        InfAction.ActionStatus status);

    long countByNodeIdAndStatus(String nodeId, InfAction.ActionStatus status);
}
