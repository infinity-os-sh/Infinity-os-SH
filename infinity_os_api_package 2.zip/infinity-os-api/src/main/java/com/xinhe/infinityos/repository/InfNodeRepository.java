package com.xinhe.infinityos.repository;

import com.xinhe.infinityos.entity.InfNode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface InfNodeRepository extends JpaRepository<InfNode, String> {

    /** 查询直接子节点（下钻第一层） */
    List<InfNode> findByParentIdAndIsActiveTrueOrderByNodeName(String parentId);

    /** 查询某品牌下所有节点 */
    List<InfNode> findByBrandCodeAndIsActiveTrue(String brandCode);

    /** 查询某类型的所有节点 */
    List<InfNode> findByNodeTypeAndIsActiveTrue(InfNode.NodeType nodeType);

    /**
     * 递归查询面包屑路径（从当前节点向上到根节点）
     * 注意：MySQL 8.0+ 支持 WITH RECURSIVE，低版本需在 Service 层循环实现
     */
    @Query(value = """
        WITH RECURSIVE breadcrumb AS (
          SELECT node_id, node_name, node_type, parent_id, 0 AS depth
          FROM inf_nodes WHERE node_id = :nodeId
          UNION ALL
          SELECT n.node_id, n.node_name, n.node_type, n.parent_id, b.depth + 1
          FROM inf_nodes n JOIN breadcrumb b ON n.node_id = b.parent_id
        )
        SELECT * FROM breadcrumb ORDER BY depth DESC
        """, nativeQuery = true)
    List<Object[]> findBreadcrumb(@Param("nodeId") String nodeId);
}
