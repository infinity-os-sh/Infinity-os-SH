package com.xinhe.infinityos.engine;

import com.xinhe.infinityos.entity.InfHeartbeat;
import com.xinhe.infinityos.entity.InfHeartbeat.WaterLevel;
import com.xinhe.infinityos.entity.InfNode;
import com.xinhe.infinityos.entity.InfNode.NodeType;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * INFINITY OS · 心跳计算引擎
 *
 * 核心公式：
 *   a  = 一个完整周转周期 T 内的销售量（心跳单元）
 *   r  = a ÷ T （日销率，全系统通用基准）
 *   水位 = inventory ÷ a → 判断层级（overflow/full/warn/low/empty）
 *
 * 三层水位设计：
 *   零售层（store）    : 满仓=3a,  预警=2a,  补货触发=1a
 *   经销商层（dist）   : 满仓=2a,  预警=1a
 *   二批商层（sub_dist): 严控1:1, 超1a即触发窜货预警
 *
 * 铁律③ 由 IronLawEngine 负责，本引擎只做水位计算
 */
@Component
public class HeartbeatEngine {

    // 水位阈值常量
    private static final BigDecimal THREE_A = BigDecimal.valueOf(3);
    private static final BigDecimal TWO_A   = BigDecimal.valueOf(2);
    private static final BigDecimal ONE_A   = BigDecimal.valueOf(1);

    // 年级激励系数表
    private static final BigDecimal[] GRADE_COEFFS = {
        null,                       // 占位，index 0 不用
        BigDecimal.valueOf(2.0),    // 年级 1 → ×2.0
        BigDecimal.valueOf(1.5),    // 年级 2 → ×1.5
        BigDecimal.valueOf(1.0),    // 年级 3 → ×1.0
        BigDecimal.valueOf(0.7)     // 年级 4 → ×0.7
    };

    /**
     * 计算水位状态
     * @param nodeType  节点类型（决定水位阈值标准）
     * @param inventoryA 当前库存（单位：a）
     * @return WaterLevel 枚举
     */
    public WaterLevel calcWaterLevel(NodeType nodeType, BigDecimal inventoryA) {
        if (inventoryA == null) return WaterLevel.empty;

        switch (nodeType) {
            case store:
                // 零售：3a满仓体系
                if (inventoryA.compareTo(THREE_A) > 0)  return WaterLevel.overflow;
                if (inventoryA.compareTo(THREE_A) >= 0) return WaterLevel.full;
                if (inventoryA.compareTo(TWO_A)   >= 0) return WaterLevel.warn;
                if (inventoryA.compareTo(ONE_A)   >= 0) return WaterLevel.low;
                return WaterLevel.empty;

            case distributor:
                // 经销商：2a满仓体系
                if (inventoryA.compareTo(TWO_A) > 0)  return WaterLevel.overflow;
                if (inventoryA.compareTo(TWO_A) >= 0) return WaterLevel.full;
                if (inventoryA.compareTo(ONE_A) >= 0) return WaterLevel.warn;
                return WaterLevel.low;

            case sub_dist:
                // 二批商：严控1:1，超1a立即触发 overflow（窜货预警）
                if (inventoryA.compareTo(ONE_A) > 0)  return WaterLevel.overflow;
                if (inventoryA.compareTo(ONE_A) >= 0) return WaterLevel.full;
                return WaterLevel.low;

            default:
                // 城市/品牌/SKU 层级：使用通用3a体系
                if (inventoryA.compareTo(THREE_A) > 0)  return WaterLevel.overflow;
                if (inventoryA.compareTo(TWO_A)   >= 0) return WaterLevel.warn;
                if (inventoryA.compareTo(ONE_A)   >= 0) return WaterLevel.low;
                return WaterLevel.empty;
        }
    }

    /**
     * 根据年级查询激励系数
     * @param grade 年级 1-4
     * @return 激励系数，grade 超出范围返回 1.0
     */
    public BigDecimal getGradeCoeff(Integer grade) {
        if (grade == null || grade < 1 || grade > 4) return BigDecimal.ONE;
        return GRADE_COEFFS[grade];
    }

    /**
     * 计算 r 达成率百分比
     */
    public BigDecimal calcAchievement(BigDecimal rActual, BigDecimal rTarget) {
        if (rActual == null || rTarget == null || rTarget.compareTo(BigDecimal.ZERO) == 0) {
            return BigDecimal.ZERO;
        }
        return rActual.divide(rTarget, 4, RoundingMode.HALF_UP)
                      .multiply(BigDecimal.valueOf(100))
                      .setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * 完整填充心跳记录的所有计算字段
     * @param hb       待填充的心跳记录
     * @param nodeType 节点类型（决定水位标准）
     */
    public void fillDerivedFields(InfHeartbeat hb, NodeType nodeType) {
        // 1. r 达成率
        hb.computeDerivedFields();  // 触发 rAchievement + inventoryA 计算

        // 2. 水位判断
        if (hb.getInventoryA() != null) {
            hb.setWaterLevel(calcWaterLevel(nodeType, hb.getInventoryA()));
        }
    }
}
