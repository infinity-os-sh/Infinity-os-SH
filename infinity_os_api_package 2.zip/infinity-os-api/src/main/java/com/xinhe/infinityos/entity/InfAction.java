package com.xinhe.infinityos.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * INFINITY OS · 决策队列表
 * Agent 提出行动建议，等待人工 批准/拒绝/覆盖
 */
@Entity
@Table(name = "inf_actions", indexes = {
    @Index(name = "idx_status_impact", columnList = "status,impact_level"),
    @Index(name = "idx_pending",       columnList = "status,proposed_at")
})
public class InfAction {

    public enum ActionType {
        replenish,      // 补货推单
        suspend,        // 暂停补货
        grade_change,   // 调整年级
        price_check,    // 价格核查
        alert_resolve,  // 警报处置
        custom          // 自定义
    }

    public enum ImpactLevel { high, mid, low }

    public enum ActionStatus {
        pending,        // 等待人工决策
        approved,       // 已批准执行
        rejected,       // 已拒绝
        overridden,     // 已覆盖（人工修改了建议）
        auto_executed   // 系统自动执行（高置信度无需人工）
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "action_id")
    private Long actionId;

    @Column(name = "node_id", nullable = false, length = 64)
    private String nodeId;

    /** 提出建议的 Agent 名称，如 butterfly_agent / omakase_agent */
    @Column(name = "agent_source", nullable = false, length = 64)
    private String agentSource;

    @Enumerated(EnumType.STRING)
    @Column(name = "action_type", nullable = false, length = 32)
    private ActionType actionType;

    @Column(name = "title", nullable = false, length = 256)
    private String title;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    /** Agent 对该建议的置信度，0-100 */
    @Column(name = "confidence_pct", nullable = false)
    private Integer confidencePct;

    @Enumerated(EnumType.STRING)
    @Column(name = "impact_level", nullable = false, length = 8)
    private ImpactLevel impactLevel;

    /**
     * 具体建议参数，JSON 字符串
     * 示例：{"qty":240,"sku_id":"lyx-500ml","reason":"inventory below 1a"}
     */
    @Column(name = "proposed_payload", columnDefinition = "JSON")
    private String proposedPayload;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 24)
    private ActionStatus status = ActionStatus.pending;

    @Column(name = "override_reason", columnDefinition = "TEXT")
    private String overrideReason;

    @Column(name = "proposed_at", nullable = false)
    private LocalDateTime proposedAt;

    @Column(name = "decided_at")
    private LocalDateTime decidedAt;

    /** 操作人工号或 'system' */
    @Column(name = "decided_by", length = 64)
    private String decidedBy;

    @PrePersist
    protected void onCreate() {
        if (this.proposedAt == null) this.proposedAt = LocalDateTime.now();
    }

    // ── Getters & Setters ──────────────────────────────────────
    public Long getActionId() { return actionId; }
    public String getNodeId() { return nodeId; }
    public void setNodeId(String nodeId) { this.nodeId = nodeId; }
    public String getAgentSource() { return agentSource; }
    public void setAgentSource(String agentSource) { this.agentSource = agentSource; }
    public ActionType getActionType() { return actionType; }
    public void setActionType(ActionType actionType) { this.actionType = actionType; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Integer getConfidencePct() { return confidencePct; }
    public void setConfidencePct(Integer confidencePct) { this.confidencePct = confidencePct; }
    public ImpactLevel getImpactLevel() { return impactLevel; }
    public void setImpactLevel(ImpactLevel impactLevel) { this.impactLevel = impactLevel; }
    public String getProposedPayload() { return proposedPayload; }
    public void setProposedPayload(String proposedPayload) { this.proposedPayload = proposedPayload; }
    public ActionStatus getStatus() { return status; }
    public void setStatus(ActionStatus status) { this.status = status; }
    public String getOverrideReason() { return overrideReason; }
    public void setOverrideReason(String overrideReason) { this.overrideReason = overrideReason; }
    public LocalDateTime getProposedAt() { return proposedAt; }
    public LocalDateTime getDecidedAt() { return decidedAt; }
    public void setDecidedAt(LocalDateTime decidedAt) { this.decidedAt = decidedAt; }
    public String getDecidedBy() { return decidedBy; }
    public void setDecidedBy(String decidedBy) { this.decidedBy = decidedBy; }
}
