package com.xinhe.infinityos.repository;

import com.xinhe.infinityos.entity.InfAlert;
import com.xinhe.infinityos.entity.InfAction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface InfAlertRepository extends JpaRepository<InfAlert, Long> {

    List<InfAlert> findByNodeIdAndStatusOrderByTriggeredAtDesc(
        String nodeId, InfAlert.AlertStatus status);

    boolean existsByNodeIdAndIronLawRefAndStatus(
        String nodeId, Integer ironLawRef, InfAlert.AlertStatus status);

    /** 今日全局活跃警报（首屏晨报使用） */
    List<InfAlert> findByStatusOrderBySeverityDescTriggeredAtDesc(InfAlert.AlertStatus status);

    long countByNodeIdAndStatus(String nodeId, InfAlert.AlertStatus status);
}

// ─────────────────────────────────────────────────────────────────
// 文件：InfActionRepository.java（同包，分开部署时拆分）
// ─────────────────────────────────────────────────────────────────
// package com.xinhe.infinityos.repository;
//
// import com.xinhe.infinityos.entity.InfAction;
// import org.springframework.data.jpa.repository.JpaRepository;
// import java.util.List;
//
// public interface InfActionRepository extends JpaRepository<InfAction, Long> { ... }
