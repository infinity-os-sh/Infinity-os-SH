package com.xinhe.infinityos.controller;

import com.xinhe.infinityos.dto.NodeResponse;
import com.xinhe.infinityos.entity.InfAction;
import com.xinhe.infinityos.service.NodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * INFINITY OS · Node Controller
 *
 * 所有前端下钻请求的唯一入口
 * 前端 renderNode(nodeId) → GET /api/v1/node/{nodeId}
 *
 * 端点列表：
 *   GET  /api/v1/node/{nodeId}                 → 获取节点完整数据
 *   POST /api/v1/node/action/{actionId}/approve → 批准决策
 *   POST /api/v1/node/action/{actionId}/reject  → 拒绝决策
 */
@RestController
@RequestMapping("/api/v1/node")
@CrossOrigin(origins = "*")  // 前端 H5 跨域，上线前收紧
public class NodeController {

    @Autowired
    private NodeService nodeService;

    // ──────────────────────────────────────────────────────────
    // GET /api/v1/node/{nodeId}
    // 前端 renderNode() 的唯一数据源
    // ──────────────────────────────────────────────────────────
    @GetMapping("/{nodeId}")
    public ResponseEntity<NodeResponse> getNode(@PathVariable String nodeId) {
        try {
            NodeResponse resp = nodeService.getNode(nodeId);
            return ResponseEntity.ok(resp);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ──────────────────────────────────────────────────────────
    // POST /api/v1/node/action/{actionId}/approve
    // 批准 Agent 建议（理想态界面的「批准执行」按钮）
    // ──────────────────────────────────────────────────────────
    @PostMapping("/action/{actionId}/approve")
    public ResponseEntity<InfAction> approveAction(
            @PathVariable Long actionId,
            @RequestBody Map<String, String> body) {
        String operatorId = body.getOrDefault("operatorId", "unknown");
        InfAction updated = nodeService.approveAction(actionId, operatorId);
        return ResponseEntity.ok(updated);
    }

    // ──────────────────────────────────────────────────────────
    // POST /api/v1/node/action/{actionId}/reject
    // 拒绝 Agent 建议（理想态界面的「✕」或「覆盖」按钮）
    // ──────────────────────────────────────────────────────────
    @PostMapping("/action/{actionId}/reject")
    public ResponseEntity<InfAction> rejectAction(
            @PathVariable Long actionId,
            @RequestBody Map<String, String> body) {
        String operatorId = body.getOrDefault("operatorId", "unknown");
        String reason     = body.getOrDefault("reason", "");
        InfAction updated = nodeService.rejectAction(actionId, operatorId, reason);
        return ResponseEntity.ok(updated);
    }
}
