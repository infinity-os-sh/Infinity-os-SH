package com.xinhe.infinityos.service;

import com.xinhe.infinityos.dto.NodeResponse;
import com.xinhe.infinityos.dto.NodeResponse.*;
import com.xinhe.infinityos.engine.HeartbeatEngine;
import com.xinhe.infinityos.engine.IronLawEngine;
import com.xinhe.infinityos.entity.*;
import com.xinhe.infinityos.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * INFINITY OS · Node Service
 *
 * 核心方法：getNode(nodeId) → NodeResponse
 * 这是前端 renderNode() 调用的唯一后端方法
 * 不管传入什么类型的节点，返回格式始终相同
 */
@Service
public class NodeService {

    @Autowired private InfNodeRepository      nodeRepo;
    @Autowired private InfHeartbeatRepository heartbeatRepo;
    @Autowired private InfAlertRepository     alertRepo;
    @Autowired private InfActionRepository    actionRepo;
    @Autowired private HeartbeatEngine        heartbeatEngine;
    @Autowired private IronLawEngine          ironLawEngine;

    // ──────────────────────────────────────────────────────────
    // 核心：获取节点完整数据（前端 renderNode 的数据源）
    // ──────────────────────────────────────────────────────────

    public NodeResponse getNode(String nodeId) {
        InfNode node = nodeRepo.findById(nodeId)
            .orElseThrow(() -> new RuntimeException("节点不存在：" + nodeId));

        NodeResponse resp = new NodeResponse();

        // 1. 节点身份
        resp.id          = node.getNodeId();
        resp.type        = node.getNodeType().name();
        resp.name        = node.getNodeName();
        resp.brand       = node.getBrandCode();
        resp.channel     = node.getChannelType() != null ? node.getChannelType().name() : null;
        resp.grade       = node.getGrade();
        resp.gradeCoeff  = node.getGrade() != null
                           ? heartbeatEngine.getGradeCoeff(node.getGrade()) : null;
        resp.tDays       = node.getTDays();

        // 2. 心跳数据（取最新快照）
        heartbeatRepo.findTopByNodeIdOrderBySnapshotDateDesc(nodeId)
            .ifPresent(hb -> resp.heartbeat = toHeartbeatDTO(hb));

        // 3. 活跃警报
        resp.alerts = alertRepo
            .findByNodeIdAndStatusOrderByTriggeredAtDesc(nodeId, InfAlert.AlertStatus.active)
            .stream().map(this::toAlertDTO).collect(Collectors.toList());

        // 4. 待批准决策
        resp.actions = actionRepo
            .findByNodeIdAndStatusOrderByImpactLevelAscProposedAtDesc(
                nodeId, InfAction.ActionStatus.pending)
            .stream().map(this::toActionDTO).collect(Collectors.toList());

        // 5. 面包屑（递归向上查父节点）
        resp.breadcrumb = buildBreadcrumb(node);

        // 6. 子节点摘要（下钻列表）
        resp.children = buildChildrenSummary(nodeId);

        return resp;
    }

    // ──────────────────────────────────────────────────────────
    // 决策审批：批准 / 拒绝 / 覆盖
    // ──────────────────────────────────────────────────────────

    public InfAction approveAction(Long actionId, String operatorId) {
        InfAction action = actionRepo.findById(actionId)
            .orElseThrow(() -> new RuntimeException("决策不存在：" + actionId));
        action.setStatus(InfAction.ActionStatus.approved);
        action.setDecidedBy(operatorId);
        action.setDecidedAt(java.time.LocalDateTime.now());
        return actionRepo.save(action);
    }

    public InfAction rejectAction(Long actionId, String operatorId, String reason) {
        InfAction action = actionRepo.findById(actionId)
            .orElseThrow(() -> new RuntimeException("决策不存在：" + actionId));
        action.setStatus(InfAction.ActionStatus.rejected);
        action.setOverrideReason(reason);
        action.setDecidedBy(operatorId);
        action.setDecidedAt(java.time.LocalDateTime.now());
        return actionRepo.save(action);
    }

    // ──────────────────────────────────────────────────────────
    // 内部方法
    // ──────────────────────────────────────────────────────────

    private List<BreadcrumbItem> buildBreadcrumb(InfNode node) {
        List<BreadcrumbItem> crumbs = new ArrayList<>();
        InfNode current = node;
        while (current != null) {
            crumbs.add(0, new BreadcrumbItem(
                current.getNodeId(),
                current.getNodeName(),
                current.getNodeType().name()
            ));
            if (current.getParentId() == null) break;
            current = nodeRepo.findById(current.getParentId()).orElse(null);
        }
        return crumbs;
    }

    private List<ChildSummary> buildChildrenSummary(String parentId) {
        return nodeRepo.findByParentIdAndIsActiveTrueOrderByNodeName(parentId)
            .stream().map(child -> {
                ChildSummary cs = new ChildSummary();
                cs.id   = child.getNodeId();
                cs.name = child.getNodeName();
                cs.type = child.getNodeType().name();
                // 取子节点最新心跳摘要
                heartbeatRepo.findTopByNodeIdOrderBySnapshotDateDesc(child.getNodeId())
                    .ifPresent(hb -> {
                        cs.rAchievement = hb.getRAchievement();
                        cs.waterLevel   = hb.getWaterLevel() != null
                                          ? hb.getWaterLevel().name() : null;
                    });
                cs.activeAlertCount = alertRepo.countByNodeIdAndStatus(
                    child.getNodeId(), InfAlert.AlertStatus.active);
                return cs;
            }).collect(Collectors.toList());
    }

    private HeartbeatDTO toHeartbeatDTO(InfHeartbeat hb) {
        HeartbeatDTO dto = new HeartbeatDTO();
        dto.aValue         = hb.getAValue();
        dto.rActual        = hb.getRActual();
        dto.rTarget        = hb.getRTarget();
        dto.rAchievement   = hb.getRAchievement();
        dto.inventoryUnits = hb.getInventoryUnits();
        dto.inventoryA     = hb.getInventoryA();
        dto.waterLevel     = hb.getWaterLevel() != null ? hb.getWaterLevel().name() : null;
        dto.digestRate     = hb.getDigestRate();
        dto.snapshotDate   = hb.getSnapshotDate();
        dto.dataSource     = hb.getDataSource() != null ? hb.getDataSource().name() : null;
        return dto;
    }

    private AlertDTO toAlertDTO(InfAlert a) {
        AlertDTO dto = new AlertDTO();
        dto.alertId    = a.getAlertId();
        dto.type       = a.getAlertType().name();
        dto.severity   = a.getSeverity().name();
        dto.ironLawRef = a.getIronLawRef();
        dto.title      = a.getTitle();
        dto.triggeredAt = a.getTriggeredAt() != null ? a.getTriggeredAt().toString() : null;
        return dto;
    }

    private ActionDTO toActionDTO(InfAction a) {
        ActionDTO dto = new ActionDTO();
        dto.actionId       = a.getActionId();
        dto.type           = a.getActionType().name();
        dto.agent          = a.getAgentSource();
        dto.title          = a.getTitle();
        dto.confidencePct  = a.getConfidencePct();
        dto.impactLevel    = a.getImpactLevel().name();
        dto.proposedPayload = a.getProposedPayload();
        return dto;
    }
}
