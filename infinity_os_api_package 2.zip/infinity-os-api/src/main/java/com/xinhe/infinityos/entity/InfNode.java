package com.xinhe.infinityos.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * INFINITY OS · 节点注册表
 * 所有实体（品牌/城市/经销商/门店/SKU）的身份与层级
 * parent_id 自引用实现无限下钻
 */
@Entity
@Table(name = "inf_nodes", indexes = {
    @Index(name = "idx_brand",  columnList = "brand_code"),
    @Index(name = "idx_type",   columnList = "node_type"),
    @Index(name = "idx_parent", columnList = "parent_id")
})
public class InfNode {

    public enum NodeType {
        brand, city, district, distributor, sub_dist, store, sku
    }

    public enum ChannelType {
        P1, P2, both
    }

    public enum StoreClass {
        S_PLUS("S+"), S("S"), A("A"), B("B"), C("C"), D("D");
        private final String value;
        StoreClass(String v) { this.value = v; }
        public String getValue() { return value; }
    }

    @Id
    @Column(name = "node_id", length = 64)
    private String nodeId;                  // e.g. "lyx-sh-dist-baocang"

    @Enumerated(EnumType.STRING)
    @Column(name = "node_type", nullable = false)
    private NodeType nodeType;

    @Column(name = "node_name", nullable = false, length = 128)
    private String nodeName;

    @Column(name = "parent_id", length = 64)
    private String parentId;               // 根节点为 NULL

    @Column(name = "brand_code", nullable = false, length = 16)
    private String brandCode;              // lyx / wdm / hr / cbl / xk

    @Enumerated(EnumType.STRING)
    @Column(name = "channel_type")
    private ChannelType channelType = ChannelType.P1;

    @Column(name = "grade")
    private Integer grade;                 // 1-4，仅 SKU 节点有效

    @Column(name = "grade_coeff", precision = 3, scale = 1)
    private BigDecimal gradeCoeff;         // 系统自动填入

    @Column(name = "store_class", length = 8)
    private String storeClass;            // S+/S/A/B/C/D，仅 store 节点

    @Column(name = "t_days", nullable = false)
    private Integer tDays = 30;           // 周转周期天数

    @Column(name = "ipo10_price", precision = 8, scale = 2)
    private BigDecimal ipo10Price;        // 铁律①监控字段，仅 SKU

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() { this.createdAt = LocalDateTime.now(); }

    @PreUpdate
    protected void onUpdate() { this.updatedAt = LocalDateTime.now(); }

    // ── Getters & Setters ──────────────────────────────────────
    public String getNodeId() { return nodeId; }
    public void setNodeId(String nodeId) { this.nodeId = nodeId; }

    public NodeType getNodeType() { return nodeType; }
    public void setNodeType(NodeType nodeType) { this.nodeType = nodeType; }

    public String getNodeName() { return nodeName; }
    public void setNodeName(String nodeName) { this.nodeName = nodeName; }

    public String getParentId() { return parentId; }
    public void setParentId(String parentId) { this.parentId = parentId; }

    public String getBrandCode() { return brandCode; }
    public void setBrandCode(String brandCode) { this.brandCode = brandCode; }

    public ChannelType getChannelType() { return channelType; }
    public void setChannelType(ChannelType channelType) { this.channelType = channelType; }

    public Integer getGrade() { return grade; }
    public void setGrade(Integer grade) { this.grade = grade; }

    public BigDecimal getGradeCoeff() { return gradeCoeff; }
    public void setGradeCoeff(BigDecimal gradeCoeff) { this.gradeCoeff = gradeCoeff; }

    public String getStoreClass() { return storeClass; }
    public void setStoreClass(String storeClass) { this.storeClass = storeClass; }

    public Integer getTDays() { return tDays; }
    public void setTDays(Integer tDays) { this.tDays = tDays; }

    public BigDecimal getIpo10Price() { return ipo10Price; }
    public void setIpo10Price(BigDecimal ipo10Price) { this.ipo10Price = ipo10Price; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }
}
