package com.xinhe.infinityos.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

/**
 * INFINITY OS · 蝴蝶效应警报表
 * A类=渠道压货 / B类=促销扰动 / C类=窜货灰市 / D类=战略覆盖
 */
@Entity
@Table(name = "inf_alerts", indexes = {
    @Index(name = "idx_status",    columnList = "status"),
    @Index(name = "idx_triggered", columnList = "triggered_at")
})
public class InfAlert {

    public enum AlertType { A, B, C, D }

    public enum Severity { yellow, orange, red }

    public enum AlertStatus { active, acknowledged, resolved, overridden }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "alert_id")
    private Long alertId;

    @Column(name = "node_id", nullable = false, length = 64)
    private String nodeId;

    @Enumerated(EnumType.STRING)
    @Column(name = "alert_type", nullable = false, length = 4)
    private AlertType alertType;

    @Enumerated(EnumType.STRING)
    @Column(name = "severity", nullable = false, length = 16)
    private Severity severity;

    /** 关联铁律编号：1/2/3，无关联填 NULL */
    @Column(name = "iron_law_ref")
    private Integer ironLawRef;

    @Column(name = "title", nullable = false, length = 256)
    private String title;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    /** 触发时的数据快照，JSON 字符串，如 {"digest_rate":0.471,"consecutive_months":2} */
    @Column(name = "trigger_value", columnDefinition = "JSON")
    private String triggerValue;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 24)
    private AlertStatus status = AlertStatus.active;

    @Column(name = "triggered_at", nullable = false)
    private LocalDateTime triggeredAt;

    @Column(name = "resolved_at")
    private LocalDateTime resolvedAt;

    @Column(name = "resolved_by", length = 64)
    private String resolvedBy;

    // ── Getters & Setters ──────────────────────────────────────
    public Long getAlertId() { return alertId; }
    public String getNodeId() { return nodeId; }
    public void setNodeId(String nodeId) { this.nodeId = nodeId; }
    public AlertType getAlertType() { return alertType; }
    public void setAlertType(AlertType alertType) { this.alertType = alertType; }
    public Severity getSeverity() { return severity; }
    public void setSeverity(Severity severity) { this.severity = severity; }
    public Integer getIronLawRef() { return ironLawRef; }
    public void setIronLawRef(Integer ironLawRef) { this.ironLawRef = ironLawRef; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getTriggerValue() { return triggerValue; }
    public void setTriggerValue(String triggerValue) { this.triggerValue = triggerValue; }
    public AlertStatus getStatus() { return status; }
    public void setStatus(AlertStatus status) { this.status = status; }
    public LocalDateTime getTriggeredAt() { return triggeredAt; }
    public void setTriggeredAt(LocalDateTime triggeredAt) { this.triggeredAt = triggeredAt; }
    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }
    public String getResolvedBy() { return resolvedBy; }
    public void setResolvedBy(String resolvedBy) { this.resolvedBy = resolvedBy; }
}
