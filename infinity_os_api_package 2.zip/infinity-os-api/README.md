# INFINITY OS · Universal Node API
## 后端团队交接说明

---

### 整体结构

```
src/main/java/com/xinhe/infinityos/
├── entity/
│   ├── InfNode.java          ← 节点注册表（所有实体的身份）
│   ├── InfHeartbeat.java     ← 心跳快照（r值+水位，每日一条）
│   ├── InfAlert.java         ← 蝴蝶效应警报（A/B/C/D四类）
│   └── InfAction.java        ← 决策队列（Agent建议，等待审批）
├── repository/
│   ├── InfNodeRepository.java
│   ├── InfHeartbeatRepository.java
│   ├── InfAlertRepository.java
│   └── InfActionRepository.java
├── engine/
│   ├── HeartbeatEngine.java  ← 水位计算、年级系数、r达成率
│   └── IronLawEngine.java    ← 铁律①③自动触发
├── service/
│   └── NodeService.java      ← 核心：getNode() 返回完整 NodeResponse
├── controller/
│   └── NodeController.java   ← REST 端点
└── dto/
    └── NodeResponse.java     ← 前端响应体（格式固定，所有节点类型通用）
```

---

### 三个接入步骤（按优先级）

**Step 1 — 建表**
在现有数据库执行 `inf_schema.sql`（见 Schema 文档），5张表。

**Step 2 — 业务团队填数据（最紧急）**
在 `inf_node_targets` 表填入每个 SKU 的 `r_target` 和 `grade`。
这是 SAP 数据接入 Step 2 的解锁条件。

**Step 3 — 数据管道接入**

| 数据源 | 目标字段 | 优先级 |
|--------|---------|--------|
| 汉询日销 | `inf_heartbeat.r_actual` | P1 最高 |
| Dcloud库存 | `inf_heartbeat.inventory_units` | P1 |
| SFA上报 | store节点 `inventory_units` | P2 |
| WMS工厂 | brand/sku节点 `inventory_units` | P3 |

---

### 前端调用方式

```javascript
// 前端只需要这一个调用，不管是哪种节点类型
const node = await fetch('/api/v1/node/lyx-sh-dist-baocang')

// 返回的 node 对象包含：
// node.heartbeat    → r值、水位、达成率（直接渲染水位图）
// node.alerts       → 活跃警报列表（蝴蝶效应）
// node.actions      → 待批准决策列表
// node.breadcrumb   → 面包屑路径数组
// node.children     → 子节点列表（点击继续下钻）
```

---

### 铁律自动触发逻辑

| 铁律 | 监控字段 | 触发条件 | 自动动作 |
|------|---------|---------|---------|
| 铁律① | `ipo10_price` | < 13.00 | 写 inf_alerts(D类,red) + 写 inf_actions(suspend) |
| 铁律③ | `digest_rate` | 连续两月 < 0.50 | 写 inf_alerts(A类,red) + 暂停所有pending推单 |

---

### 与现有工程合并说明

本代码包是独立模块，与现有 Spring Boot 工程合并时：
1. 将 `entity/` `repository/` `service/` `controller/` `engine/` `dto/` 目录复制到现有包下
2. 确认 `application.properties` 数据源配置正确
3. 运行 `inf_schema.sql` 建5张新表
4. 不影响现有任何代码

---

*INFINITY OS v1.0 · 2026-04-13*
