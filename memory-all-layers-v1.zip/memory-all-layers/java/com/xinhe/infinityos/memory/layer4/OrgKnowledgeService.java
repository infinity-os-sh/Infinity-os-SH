// ============================================================
// OrgKnowledgeService.java
// 层面四：组织知识记忆服务（组织级）
// 让Agent积累组织知识，越用越聪明
// 某门店反复压货 → 记住这个模式 → 下次直接预警
// ============================================================
package com.xinhe.infinityos.memory.layer4;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class OrgKnowledgeService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // ══ 门店行为模式 ══════════════════════════════════════════

    /**
     * 获取门店的历史行为画像
     * Agent在处理某门店时，先查这个，获得历史上下文
     */
    public Map<String, Object> getStoreProfile(String storeId) {
        try {
            return jdbc.queryForMap(
                "SELECT * FROM store_behavior_patterns WHERE store_id=?", storeId
            );
        } catch (Exception e) {
            return Collections.emptyMap();
        }
    }

    /**
     * 更新门店行为模式（每周定时运行，基于真实数据积累）
     */
    public void updateStorePattern(String storeId, String storeName, String cityId,
                                    String storeTier, Map<String, Object> metrics) {
        try {
            String knownIssuesJson = mapper.writeValueAsString(
                metrics.getOrDefault("known_issues", Collections.emptyList())
            );

            jdbc.update(
                "INSERT INTO store_behavior_patterns(store_id, store_name, city_id, store_tier, " +
                "avg_inventory_level, inventory_volatility, stockout_frequency, overstock_frequency, " +
                "known_issues, observation_months, pattern_confidence) " +
                "VALUES(?,?,?,?,?,?,?,?,?,?,?) " +
                "ON DUPLICATE KEY UPDATE " +
                "avg_inventory_level=VALUES(avg_inventory_level), " +
                "inventory_volatility=VALUES(inventory_volatility), " +
                "stockout_frequency=VALUES(stockout_frequency), " +
                "overstock_frequency=VALUES(overstock_frequency), " +
                "known_issues=VALUES(known_issues), " +
                "observation_months=observation_months+1, " +
                "pattern_confidence=LEAST(0.99, pattern_confidence+0.02), " +
                "last_updated_at=NOW()",
                storeId, storeName, cityId, storeTier,
                metrics.get("avg_inventory_level"),
                metrics.get("inventory_volatility"),
                metrics.get("stockout_frequency"),
                metrics.get("overstock_frequency"),
                knownIssuesJson,
                1,
                0.50
            );
        } catch (Exception e) {
            throw new RuntimeException("更新门店模式失败: " + storeId, e);
        }
    }

    /**
     * 查询高风险门店列表（给蝴蝶效应Agent和零售门店Agent用）
     */
    public List<Map<String, Object>> getHighRiskStores(String cityId) {
        String sql = "SELECT store_id, store_name, store_tier, risk_level, known_issues, " +
                     "overstock_frequency, pattern_confidence " +
                     "FROM store_behavior_patterns " +
                     "WHERE risk_level IN ('high','critical') " +
                     (cityId != null ? "AND city_id=? " : "") +
                     "AND pattern_confidence > 0.5 " +
                     "ORDER BY risk_level DESC, overstock_frequency DESC LIMIT 20";

        return cityId != null
            ? jdbc.queryForList(sql, cityId)
            : jdbc.queryForList(sql);
    }

    // ══ 决策规则库 ════════════════════════════════════════════

    /**
     * 匹配适用的决策规则
     * Agent做决策前先查，看有没有现成的组织经验可以应用
     */
    public List<Map<String, Object>> matchDecisionRules(String category,
                                                          Map<String, Object> context) {
        List<Map<String, Object>> allRules = jdbc.queryForList(
            "SELECT * FROM org_decision_rules " +
            "WHERE is_active=1 AND (rule_category=? OR rule_category='exception') " +
            "AND (expires_at IS NULL OR expires_at > NOW()) " +
            "AND confidence > 0.7 " +
            "ORDER BY confidence DESC, trigger_count DESC",
            category
        );

        // 简单规则匹配：实际项目可以用规则引擎（Drools等）
        List<Map<String, Object>> matched = new ArrayList<>();
        for (Map<String, Object> rule : allRules) {
            try {
                Map<?, ?> conditionJson = mapper.readValue(
                    String.valueOf(rule.get("condition_json")), Map.class
                );
                if (isRuleApplicable(conditionJson, context)) {
                    matched.add(rule);
                    // 更新触发次数
                    jdbc.update(
                        "UPDATE org_decision_rules SET trigger_count=trigger_count+1, " +
                        "last_triggered_at=NOW() WHERE rule_id=?",
                        rule.get("rule_id")
                    );
                }
            } catch (Exception ignored) {}
        }
        return matched;
    }

    /**
     * AI从历史决策中学习，生成新规则
     * 当某个模式被重复验证超过5次时，自动提升为规则
     */
    public void learnNewRule(String agentId, String category, String conditionDesc,
                              Map<String, Object> conditionJson, String actionDesc,
                              Map<String, Object> actionJson, double confidence) {
        try {
            String ruleId = "AI_" + System.currentTimeMillis();
            jdbc.update(
                "INSERT INTO org_decision_rules(rule_id, rule_category, rule_name, " +
                "condition_desc, condition_json, action_desc, action_json, " +
                "source, confidence, created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",
                ruleId, category,
                "AI学习规则·" + agentId + "·" + new java.util.Date(),
                conditionDesc,
                mapper.writeValueAsString(conditionJson),
                actionDesc,
                mapper.writeValueAsString(actionJson),
                "learned", confidence, agentId
            );
        } catch (Exception e) {
            throw new RuntimeException("保存学习规则失败", e);
        }
    }

    // ══ 异常案例库 ════════════════════════════════════════════

    /**
     * 记录异常案例
     */
    public String recordAnomaly(String anomalyType, String entityType, String entityId,
                                  String description, String severity, String detectedBy) {
        String caseId = "CASE_" + System.currentTimeMillis();
        jdbc.update(
            "INSERT INTO anomaly_case_library(case_id, anomaly_type, entity_type, entity_id, " +
            "detected_at, detected_by, description, severity) VALUES(?,?,?,?,NOW(),?,?,?)",
            caseId, anomalyType, entityType, entityId, detectedBy, description, severity
        );

        // 同步更新门店或经销商的known_issues
        if ("store".equals(entityType)) {
            addKnownIssueToStore(entityId, anomalyType);
        } else if ("distributor".equals(entityType)) {
            addKnownIssueToDistributor(entityId, anomalyType);
        }

        return caseId;
    }

    /**
     * 解决异常案例，记录经验
     */
    public void resolveAnomaly(String caseId, String resolvedBy,
                                 String outcome, String lessonsLearned) {
        jdbc.update(
            "UPDATE anomaly_case_library SET resolved_at=NOW(), resolved_by=?, " +
            "resolution_outcome=?, lessons_learned=? WHERE case_id=?",
            resolvedBy, outcome, lessonsLearned, caseId
        );
    }

    /**
     * 相似案例检索：新异常发生时，查历史有没有类似的
     */
    public List<Map<String, Object>> findSimilarCases(String anomalyType, String entityType) {
        return jdbc.queryForList(
            "SELECT case_id, entity_id, description, severity, resolution_outcome, " +
            "lessons_learned, detected_at " +
            "FROM anomaly_case_library " +
            "WHERE anomaly_type=? AND entity_type=? " +
            "AND resolution_outcome IN ('resolved','escalated') " +
            "ORDER BY detected_at DESC LIMIT 5",
            anomalyType, entityType
        );
    }

    // ══ 定时任务：积累组织知识 ════════════════════════════════

    /**
     * 每周一早6点：从事件日志中学习新规则
     * 找出重复出现超过5次且都成功的模式，自动提升为规则
     */
    @Scheduled(cron = "0 0 6 * * MON")
    public void weeklyKnowledgeLearning() {
        // 查找高频成功模式
        List<Map<String, Object>> patterns = jdbc.queryForList(
            "SELECT agent_id, event_type, entity_type, " +
            "COUNT(*) as occurrence, " +
            "SUM(CASE WHEN outcome='success' THEN 1 ELSE 0 END) as success_count " +
            "FROM agent_memory_events " +
            "WHERE created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) " +
            "GROUP BY agent_id, event_type, entity_type " +
            "HAVING occurrence >= 5 AND success_count/occurrence > 0.85 " +
            "ORDER BY success_count/occurrence DESC LIMIT 20"
        );

        for (Map<String, Object> pattern : patterns) {
            // 检查是否已有对应规则
            int existing = jdbc.queryForObject(
                "SELECT COUNT(*) FROM org_decision_rules " +
                "WHERE rule_category=? AND source='learned' AND is_active=1",
                Integer.class, pattern.get("event_type")
            );
            if (existing == 0) {
                // 自动生成候选规则（需人工审批才生效）
                learnNewRule(
                    String.valueOf(pattern.get("agent_id")),
                    String.valueOf(pattern.get("event_type")),
                    pattern.get("agent_id") + "在" + pattern.get("entity_type") +
                    "类实体执行" + pattern.get("event_type") + "，成功率高",
                    Map.of("agent", pattern.get("agent_id"),
                           "event_type", pattern.get("event_type"),
                           "min_occurrence", 5),
                    "由" + pattern.get("agent_id") + "自主执行，无需额外审批",
                    Map.of("auth_level", 0, "agent", pattern.get("agent_id")),
                    Double.parseDouble(String.valueOf(pattern.get("success_count"))) /
                        Double.parseDouble(String.valueOf(pattern.get("occurrence")))
                );
            }
        }
    }

    /**
     * 每月1日：更新门店风险评级
     */
    @Scheduled(cron = "0 0 7 1 * *")
    public void monthlyRiskReassessment() {
        // 超过3次压货记录 → 升级为high风险
        jdbc.update(
            "UPDATE store_behavior_patterns " +
            "SET risk_level = CASE " +
            "  WHEN overstock_frequency > 5 THEN 'critical' " +
            "  WHEN overstock_frequency > 3 THEN 'high' " +
            "  WHEN overstock_frequency > 1 THEN 'medium' " +
            "  ELSE 'low' END " +
            "WHERE observation_months >= 2"
        );
    }

    // ══ 内部工具 ═════════════════════════════════════════════

    private boolean isRuleApplicable(Map<?, ?> condition, Map<String, Object> context) {
        // 简单键值匹配（实际项目建议用Drools或SpEL）
        for (Map.Entry<?, ?> entry : condition.entrySet()) {
            String key = String.valueOf(entry.getKey());
            String value = String.valueOf(entry.getValue());
            Object ctxVal = context.get(key);
            if (ctxVal == null) continue;
            // 支持简单的比较运算符
            if (value.startsWith("<") && ctxVal instanceof Number) {
                if (((Number) ctxVal).doubleValue() >= Double.parseDouble(value.substring(1)))
                    return false;
            } else if (value.startsWith(">") && ctxVal instanceof Number) {
                if (((Number) ctxVal).doubleValue() <= Double.parseDouble(value.substring(1)))
                    return false;
            } else if (!value.equals(String.valueOf(ctxVal))) {
                return false;
            }
        }
        return true;
    }

    private void addKnownIssueToStore(String storeId, String issueType) {
        try {
            String currentJson = jdbc.queryForObject(
                "SELECT known_issues FROM store_behavior_patterns WHERE store_id=?",
                String.class, storeId
            );
            List<String> issues = currentJson != null
                ? mapper.readValue(currentJson, List.class) : new ArrayList<>();
            if (!issues.contains(issueType)) {
                issues.add(issueType);
                jdbc.update(
                    "UPDATE store_behavior_patterns SET known_issues=? WHERE store_id=?",
                    mapper.writeValueAsString(issues), storeId
                );
            }
        } catch (Exception ignored) {}
    }

    private void addKnownIssueToDistributor(String distributorId, String issueType) {
        try {
            String currentJson = jdbc.queryForObject(
                "SELECT incident_history FROM distributor_behavior_patterns WHERE distributor_id=?",
                String.class, distributorId
            );
            List<Map<String, Object>> history = currentJson != null
                ? mapper.readValue(currentJson, List.class) : new ArrayList<>();
            history.add(Map.of("type", issueType, "date",
                new java.text.SimpleDateFormat("yyyy-MM").format(new Date())));
            jdbc.update(
                "UPDATE distributor_behavior_patterns SET incident_history=? WHERE distributor_id=?",
                mapper.writeValueAsString(history), distributorId
            );
        } catch (Exception ignored) {}
    }
}
