// ============================================================
// SharedMemoryService.java
// 层面三：Agent间共享记忆服务（系统级）
// 24个Agent之间的状态总线·Redis实时 + MySQL持久化
// ============================================================
package com.xinhe.infinityos.memory.layer3;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.*;

@Service
public class SharedMemoryService {

    private static final Duration STATE_TTL    = Duration.ofMinutes(15); // 实时状态15分钟
    private static final Duration BROADCAST_TTL = Duration.ofHours(1);  // 广播消息1小时

    @Autowired private RedisTemplate<String, String> redisTemplate;
    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // ══ 状态总线：写入 ══════════════════════════════════════

    /**
     * Agent写入共享状态
     * 例：蝴蝶效应Agent发现上海松江区传导异常
     * writeState("butterfly", "global", null, "butterfly_anomaly_shanghai_songjiang",
     *            Map.of("type","A","level","critical","city","上海","district","松江"))
     */
    public void writeState(String agentId, String scope, String scopeId,
                            String stateKey, Map<String, Object> stateValue) {
        writeState(agentId, scope, scopeId, stateKey, stateValue, "normal", null);
    }

    public void writeState(String agentId, String scope, String scopeId,
                            String stateKey, Map<String, Object> stateValue,
                            String priority, Integer ttlMinutes) {
        try {
            String valueJson = mapper.writeValueAsString(stateValue);

            // 1. Redis写入（实时）
            String redisKey = buildRedisStateKey(scope, scopeId, stateKey);
            redisTemplate.opsForValue().set(redisKey, valueJson,
                ttlMinutes != null ? Duration.ofMinutes(ttlMinutes) : STATE_TTL);

            // 2. MySQL持久化
            jdbc.update(
                "INSERT INTO agent_shared_state(state_key, state_scope, scope_id, agent_source, " +
                "state_value, priority) VALUES(?,?,?,?,?,?) " +
                "ON DUPLICATE KEY UPDATE state_value=VALUES(state_value), " +
                "agent_source=VALUES(agent_source), priority=VALUES(priority), " +
                "updated_at=NOW()",
                stateKey, scope, scopeId, agentId, valueJson, priority
            );

            // 3. 如果是critical级别，自动广播给所有Agent
            if ("critical".equals(priority)) {
                broadcast(agentId, null, "alert", "critical",
                    "系统级警报: " + stateKey,
                    Map.of("stateKey", stateKey, "scope", scope,
                           "scopeId", scopeId != null ? scopeId : "",
                           "value", stateValue));
            }

        } catch (Exception e) {
            throw new RuntimeException("写入共享状态失败: " + stateKey, e);
        }
    }

    // ══ 状态总线：读取 ══════════════════════════════════════

    /**
     * Agent读取共享状态
     * 优先从Redis读取（实时），Redis miss则从MySQL读取
     */
    public Map<String, Object> readState(String scope, String scopeId, String stateKey) {
        try {
            // 1. 先查Redis
            String redisKey = buildRedisStateKey(scope, scopeId, stateKey);
            String cached = redisTemplate.opsForValue().get(redisKey);
            if (cached != null) {
                return mapper.readValue(cached, Map.class);
            }

            // 2. Redis miss → 查MySQL
            String valueJson = jdbc.queryForObject(
                "SELECT state_value FROM agent_shared_state " +
                "WHERE state_key=? AND state_scope=? AND (scope_id=? OR scope_id IS NULL) " +
                "AND (expires_at IS NULL OR expires_at > NOW())",
                String.class, stateKey, scope, scopeId
            );

            // 3. 回写Redis热数据
            if (valueJson != null) {
                redisTemplate.opsForValue().set(redisKey, valueJson, STATE_TTL);
                return mapper.readValue(valueJson, Map.class);
            }
        } catch (Exception ignored) {}
        return null;
    }

    /**
     * 查询某个scope下的所有critical状态（给AIO总指挥用）
     */
    public List<Map<String, Object>> readCriticalStates() {
        return jdbc.queryForList(
            "SELECT state_key, state_scope, scope_id, agent_source, state_value, updated_at " +
            "FROM agent_shared_state " +
            "WHERE priority='critical' " +
            "AND (expires_at IS NULL OR expires_at > NOW()) " +
            "ORDER BY updated_at DESC LIMIT 50"
        );
    }

    // ══ Agent间广播消息 ══════════════════════════════════════

    /**
     * Agent广播消息给其他Agent（或全体）
     * toAgent=null 表示广播给所有Agent
     */
    public void broadcast(String fromAgent, String toAgent,
                           String messageType, String priority,
                           String subject, Map<String, Object> payload) {
        try {
            String payloadJson = mapper.writeValueAsString(payload);

            // MySQL持久化
            jdbc.update(
                "INSERT INTO agent_broadcast_messages(from_agent, to_agent, message_type, " +
                "priority, subject, payload, expires_at) VALUES(?,?,?,?,?,?,?)",
                fromAgent, toAgent, messageType, priority, subject, payloadJson,
                "critical".equals(priority) ? null :
                    new java.sql.Timestamp(System.currentTimeMillis() + 3600000L)
            );

            // Redis推送到目标Agent的消息队列
            String queueKey = toAgent != null
                ? "agent:broadcast:queue:" + toAgent
                : "agent:broadcast:queue:global";
            Map<String, Object> msg = Map.of(
                "from", fromAgent, "type", messageType,
                "priority", priority, "subject", subject, "payload", payload,
                "ts", System.currentTimeMillis()
            );
            redisTemplate.opsForList().rightPush(queueKey, mapper.writeValueAsString(msg));
            redisTemplate.expire(queueKey, BROADCAST_TTL);

        } catch (Exception e) {
            throw new RuntimeException("广播消息失败", e);
        }
    }

    /**
     * Agent拉取自己的未读消息
     */
    public List<Map<String, Object>> pullMessages(String agentId) {
        List<Map<String, Object>> messages = new ArrayList<>();

        // 从Redis拉取（先处理自己的队列，再处理全局广播）
        for (String queueKey : List.of(
            "agent:broadcast:queue:" + agentId,
            "agent:broadcast:queue:global"
        )) {
            String raw;
            while ((raw = redisTemplate.opsForList().leftPop(queueKey)) != null) {
                try {
                    messages.add(mapper.readValue(raw, Map.class));
                } catch (Exception ignored) {}
            }
        }
        return messages;
    }

    // ══ 事件记录 ══════════════════════════════════════════════

    /**
     * Agent记录执行事件（操作完成后调用）
     */
    public Long recordEvent(String agentId, String eventType, String entityType,
                             String entityId, Map<String, Object> eventData,
                             String outcome, Double confidence) {
        try {
            String dataJson = mapper.writeValueAsString(eventData);
            jdbc.update(
                "INSERT INTO agent_memory_events(agent_id, event_type, entity_type, entity_id, " +
                "event_data, outcome, confidence) VALUES(?,?,?,?,?,?,?)",
                agentId, eventType, entityType, entityId, dataJson, outcome, confidence
            );

            // 更新Agent档案的活跃时间
            jdbc.update(
                "UPDATE agent_memory_profiles SET last_active_at=NOW() WHERE agent_id=?", agentId
            );

            return jdbc.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
        } catch (Exception e) {
            throw new RuntimeException("记录事件失败", e);
        }
    }

    // ══ Agent信用分维护 ══════════════════════════════════════

    /**
     * 更新Agent信用分（由auth-boundary调用）
     * correctDecision=true 时信用+1（上限100）
     * correctDecision=false 时信用-5（下限0）
     */
    public void updateAgentCredit(String agentId, boolean correctDecision, String reason) {
        double delta = correctDecision ? 1.0 : -5.0;
        jdbc.update(
            "UPDATE agent_memory_profiles " +
            "SET credit_score = LEAST(100, GREATEST(0, credit_score + ?)), " +
            "    total_decisions = total_decisions + 1, " +
            "    last_active_at = NOW() " +
            "WHERE agent_id=?",
            delta, agentId
        );

        // 记录信用变化事件
        recordEvent(agentId, "credit_update", "system", agentId,
            Map.of("delta", delta, "reason", reason, "correct", correctDecision),
            "success", 1.0);

        // 信用跌破40分自动暂停Agent
        Integer credit = jdbc.queryForObject(
            "SELECT credit_score FROM agent_memory_profiles WHERE agent_id=?", Integer.class, agentId
        );
        if (credit != null && credit < 40) {
            jdbc.update(
                "UPDATE agent_memory_profiles SET current_status='paused' WHERE agent_id=?", agentId
            );
            broadcast("system", null, "alert", "critical",
                "Agent" + agentId + "信用分跌破40·已暂停",
                Map.of("agentId", agentId, "credit", credit, "action", "paused"));
        }
    }

    // ══ Redis锁（防止多Agent同时操作同一实体）═════════════

    public boolean acquireLock(String entityId, String agentId, int ttlSeconds) {
        String lockKey = "agent:lock:" + entityId;
        Boolean acquired = redisTemplate.opsForValue()
            .setIfAbsent(lockKey, agentId, Duration.ofSeconds(ttlSeconds));
        return Boolean.TRUE.equals(acquired);
    }

    public void releaseLock(String entityId) {
        redisTemplate.delete("agent:lock:" + entityId);
    }

    // ══ 内部工具 ═════════════════════════════════════════════

    private String buildRedisStateKey(String scope, String scopeId, String stateKey) {
        return "agent:state:" + scope + ":" + (scopeId != null ? scopeId : "global") + ":" + stateKey;
    }
}
