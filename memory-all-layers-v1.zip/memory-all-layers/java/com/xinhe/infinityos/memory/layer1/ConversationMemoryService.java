// ============================================================
// ConversationMemoryService.java
// 层面一：对话记忆服务（会话级）
// Redis热存储 + MySQL持久化，支持多轮追问
// ============================================================
package com.xinhe.infinityos.memory.layer1;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.*;

@Service
public class ConversationMemoryService {

    private static final int MAX_REDIS_TURNS = 20;       // Redis保存最近20轮
    private static final int SNAPSHOT_EVERY  = 10;       // 每10轮压缩一次
    private static final Duration SESSION_TTL = Duration.ofHours(24);

    @Autowired private RedisTemplate<String, String> redisTemplate;
    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // ── 开始新会话 ───────────────────────────────────────────

    public String startSession(String userId, String agentId) {
        String sessionId = UUID.randomUUID().toString().replace("-", "");

        // MySQL持久化
        jdbc.update(
            "INSERT INTO conv_sessions(session_id, user_id, agent_id) VALUES(?,?,?)",
            sessionId, userId, agentId
        );

        // Redis初始化会话元数据
        String metaKey = "conv:" + sessionId + ":meta";
        Map<String, String> meta = Map.of(
            "userId", userId,
            "agentId", agentId != null ? agentId : "brain",
            "turnCount", "0",
            "startedAt", String.valueOf(System.currentTimeMillis())
        );
        redisTemplate.opsForHash().putAll(metaKey, meta);
        redisTemplate.expire(metaKey, SESSION_TTL);

        return sessionId;
    }

    // ── 添加一轮对话 ─────────────────────────────────────────

    public void addTurn(String sessionId, String role, String content) {
        // 1. 从Redis获取当前轮次
        String metaKey = "conv:" + sessionId + ":meta";
        String turnCountStr = (String) redisTemplate.opsForHash().get(metaKey, "turnCount");
        int turnIndex = turnCountStr != null ? Integer.parseInt(turnCountStr) + 1 : 1;

        // 2. 构建turn对象
        Map<String, Object> turn = new LinkedHashMap<>();
        turn.put("role", role);
        turn.put("content", content);
        turn.put("turnIndex", turnIndex);
        turn.put("timestamp", System.currentTimeMillis());

        // 3. 写入Redis（List右侧追加）
        String turnsKey = "conv:" + sessionId + ":turns";
        try {
            redisTemplate.opsForList().rightPush(turnsKey, mapper.writeValueAsString(turn));
            // 超出20轮则从左侧弹出（滚动窗口）
            if (redisTemplate.opsForList().size(turnsKey) > MAX_REDIS_TURNS) {
                redisTemplate.opsForList().leftPop(turnsKey);
            }
            redisTemplate.expire(turnsKey, SESSION_TTL);
        } catch (Exception e) {
            throw new RuntimeException("Redis写入失败", e);
        }

        // 4. 更新会话元数据
        redisTemplate.opsForHash().put(metaKey, "turnCount", String.valueOf(turnIndex));
        redisTemplate.expire(metaKey, SESSION_TTL);

        // 5. MySQL持久化（异步写，不阻塞主流程）
        persistTurnAsync(sessionId, turnIndex, role, content);

        // 6. 触发快照压缩（每10轮）
        if (turnIndex % SNAPSHOT_EVERY == 0 && "assistant".equals(role)) {
            triggerSnapshot(sessionId, turnIndex);
        }
    }

    // ── 获取上下文（构建传给Claude的messages数组）───────────

    /**
     * 获取当前会话的对话上下文
     * 返回格式：[{"role":"user","content":"..."}, {"role":"assistant","content":"..."}, ...]
     * 自动拼接快照摘要 + 最近N轮实时对话
     */
    public List<Map<String, String>> getContextMessages(String sessionId) {
        List<Map<String, String>> messages = new ArrayList<>();

        // 1. 如果有压缩快照，先加入系统摘要
        String latestSnapshot = getLatestSnapshot(sessionId);
        if (latestSnapshot != null) {
            messages.add(Map.of(
                "role", "user",
                "content", "[之前对话摘要] " + latestSnapshot
            ));
            messages.add(Map.of(
                "role", "assistant",
                "content", "我已了解之前对话的背景，请继续。"
            ));
        }

        // 2. 从Redis获取最近N轮对话
        String turnsKey = "conv:" + sessionId + ":turns";
        List<String> rawTurns = redisTemplate.opsForList().range(turnsKey, 0, -1);
        if (rawTurns != null) {
            for (String rawTurn : rawTurns) {
                try {
                    Map<?, ?> turn = mapper.readValue(rawTurn, Map.class);
                    messages.add(Map.of(
                        "role", String.valueOf(turn.get("role")),
                        "content", String.valueOf(turn.get("content"))
                    ));
                } catch (Exception ignored) {}
            }
        }

        return messages;
    }

    // ── 获取最新快照摘要 ─────────────────────────────────────

    private String getLatestSnapshot(String sessionId) {
        try {
            return jdbc.queryForObject(
                "SELECT summary FROM conv_snapshots WHERE session_id=? ORDER BY snapshot_at DESC LIMIT 1",
                String.class, sessionId
            );
        } catch (Exception e) {
            return null;
        }
    }

    // ── 触发快照压缩（调用Claude API压缩历史对话）───────────

    private void triggerSnapshot(String sessionId, int upToTurn) {
        // 获取需要压缩的对话内容
        List<Map<String, Object>> turns = jdbc.queryForList(
            "SELECT role, content, turn_index FROM conv_turns " +
            "WHERE session_id=? AND turn_index <= ? ORDER BY turn_index",
            sessionId, upToTurn - SNAPSHOT_EVERY  // 压缩较老的那部分
        );
        if (turns.isEmpty()) return;

        // 构建压缩prompt
        StringBuilder dialogText = new StringBuilder();
        for (Map<String, Object> t : turns) {
            dialogText.append(t.get("role")).append(": ").append(t.get("content")).append("\n");
        }

        // 实际调用Claude API压缩（桩实现，Java团队补充）
        // String summary = claudeApiService.summarize(dialogText.toString());
        String summary = "[待实现：调用Claude API压缩此段对话]";

        jdbc.update(
            "INSERT INTO conv_snapshots(session_id, snapshot_at, summary) VALUES(?,?,?) " +
            "ON DUPLICATE KEY UPDATE summary=VALUES(summary)",
            sessionId, upToTurn, summary
        );
    }

    // ── MySQL异步持久化 ──────────────────────────────────────

    private void persistTurnAsync(String sessionId, int turnIndex, String role, String content) {
        // 实际项目使用@Async + 线程池，此处简化为同步
        jdbc.update(
            "INSERT INTO conv_turns(session_id, turn_index, role, content) VALUES(?,?,?,?)",
            sessionId, turnIndex, role, content
        );
        jdbc.update(
            "UPDATE conv_sessions SET turn_count=?, last_active_at=NOW() WHERE session_id=?",
            turnIndex, sessionId
        );
    }

    // ── 结束会话 ─────────────────────────────────────────────

    public void endSession(String sessionId) {
        jdbc.update(
            "UPDATE conv_sessions SET is_active=0 WHERE session_id=?", sessionId
        );
        // Redis数据保留TTL自然过期，不主动删除（可能还在活跃中）
    }

    // ── 工具方法：清理超时会话 ──────────────────────────────

    public int cleanupExpiredSessions() {
        return jdbc.update(
            "UPDATE conv_sessions SET is_active=0 " +
            "WHERE is_active=1 AND last_active_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
        );
    }
}
