// ============================================================
// UserMemoryService.java
// 层面二：跨会话用户记忆服务（用户级）
// 让Agent记住"这个用户之前的偏好和历史"
// ============================================================
package com.xinhe.infinityos.memory.layer2;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class UserMemoryService {

    @Autowired private JdbcTemplate jdbc;
    @Autowired private ObjectMapper mapper;

    // ── 用户登录时：构建个性化上下文 ────────────────────────

    /**
     * 用户打开INFINITY OS时调用
     * 返回个性化系统提示词前缀，注入到所有Agent的system prompt
     */
    public String buildUserContextPrompt(String userId) {
        Map<String, Object> profile = getUserProfile(userId);
        if (profile == null) {
            initUserProfile(userId);
            return "这是该用户第一次使用INFINITY OS。";
        }

        StringBuilder ctx = new StringBuilder();
        ctx.append("【用户上下文】\n");
        ctx.append("用户身份：").append(profile.getOrDefault("user_name", "未知")).append("\n");
        ctx.append("角色：").append(profile.getOrDefault("role", "manager")).append("\n");

        // 关注的城市
        Object cities = profile.get("preferred_cities");
        if (cities != null) {
            ctx.append("重点关注城市：").append(cities).append("\n");
        }

        // 关注的品牌
        Object brands = profile.get("preferred_brands");
        if (brands != null) {
            ctx.append("主要负责品牌：").append(brands).append("\n");
        }

        // 最近3次对话摘要
        List<String> recentConclusions = getRecentConclusions(userId, 3);
        if (!recentConclusions.isEmpty()) {
            ctx.append("近期关注的问题：\n");
            for (int i = 0; i < recentConclusions.size(); i++) {
                ctx.append("  - ").append(recentConclusions.get(i)).append("\n");
            }
        }

        // 当前活跃的关注项
        List<Map<String, Object>> watches = getActiveWatches(userId);
        if (!watches.isEmpty()) {
            ctx.append("持续跟踪中（").append(watches.size()).append("项）：");
            watches.forEach(w -> ctx.append(w.get("entity_name")).append("·"));
            ctx.append("\n");
        }

        return ctx.toString();
    }

    // ── 会话结束时：提取并保存摘要 ──────────────────────────

    /**
     * 对话结束后调用，提取关键信息更新用户档案
     */
    public void saveSessionSummary(String userId, String sessionId,
                                   String summary, List<String> topics,
                                   List<String> cities, List<String> stores) {
        // 保存查询历史
        try {
            jdbc.update(
                "INSERT INTO user_query_history(user_id, session_id, session_date, " +
                "main_topics, queried_cities, queried_stores, key_conclusions) " +
                "VALUES(?,?,CURDATE(),?,?,?,?)",
                userId, sessionId,
                mapper.writeValueAsString(topics),
                mapper.writeValueAsString(cities),
                mapper.writeValueAsString(stores),
                summary
            );

            // 更新用户档案统计
            jdbc.update(
                "UPDATE user_profiles SET total_sessions=total_sessions+1, " +
                "last_login_at=NOW() WHERE user_id=?", userId
            );

            // 自动学习偏好：如果这次查询了新城市，更新preferred_cities
            updatePreferencesFromSession(userId, cities, topics);

        } catch (Exception e) {
            throw new RuntimeException("保存会话摘要失败", e);
        }
    }

    // ── 关注项管理 ───────────────────────────────────────────

    /**
     * 用户说"帮我持续关注这家门店"时调用
     */
    public Long addWatchItem(String userId, String watchType, String entityId,
                              String entityName, String reason, Map<String, Object> alertThreshold) {
        try {
            jdbc.update(
                "INSERT INTO user_watchlist(user_id, watch_type, entity_id, entity_name, " +
                "watch_reason, alert_threshold) VALUES(?,?,?,?,?,?)",
                userId, watchType, entityId, entityName, reason,
                mapper.writeValueAsString(alertThreshold)
            );
            return jdbc.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
        } catch (Exception e) {
            throw new RuntimeException("添加关注项失败", e);
        }
    }

    /**
     * 每日检查关注项，生成需要主动提醒的列表
     */
    public List<Map<String, Object>> checkWatchlistAlerts(String userId) {
        return jdbc.queryForList(
            "SELECT w.*, p.current_status " +
            "FROM user_watchlist w " +
            "LEFT JOIN agent_memory_profiles p ON w.entity_id = p.agent_id " +
            "WHERE w.user_id=? AND w.is_active=1 " +
            "AND (w.last_triggered_at IS NULL OR w.last_triggered_at < DATE_SUB(NOW(), INTERVAL 1 DAY))",
            userId
        );
    }

    // ── 偏好学习 ─────────────────────────────────────────────

    /**
     * 从本次会话自动更新用户偏好
     */
    private void updatePreferencesFromSession(String userId, List<String> cities, List<String> topics) {
        if (cities == null || cities.isEmpty()) return;

        // 查询当前偏好城市
        try {
            String currentCitiesJson = jdbc.queryForObject(
                "SELECT preferred_cities FROM user_profiles WHERE user_id=?", String.class, userId
            );
            List<String> currentCities = currentCitiesJson != null
                ? mapper.readValue(currentCitiesJson, List.class)
                : new ArrayList<>();

            // 合并新城市
            Set<String> merged = new LinkedHashSet<>(currentCities);
            merged.addAll(cities);
            if (merged.size() > 10) {
                // 超过10个城市，保留最近的10个
                List<String> mergedList = new ArrayList<>(merged);
                merged = new LinkedHashSet<>(mergedList.subList(mergedList.size() - 10, mergedList.size()));
            }

            jdbc.update(
                "UPDATE user_profiles SET preferred_cities=? WHERE user_id=?",
                mapper.writeValueAsString(new ArrayList<>(merged)), userId
            );

            // 记录学习日志
            jdbc.update(
                "INSERT INTO user_preference_learning(user_id, preference_key, new_value, " +
                "learned_from) VALUES(?,?,?,?)",
                userId, "preferred_cities",
                mapper.writeValueAsString(new ArrayList<>(merged)), "query_pattern"
            );
        } catch (Exception ignored) {}
    }

    // ── 内部工具方法 ─────────────────────────────────────────

    private Map<String, Object> getUserProfile(String userId) {
        try {
            return jdbc.queryForMap("SELECT * FROM v_user_context WHERE user_id=?", userId);
        } catch (Exception e) {
            return null;
        }
    }

    private void initUserProfile(String userId) {
        jdbc.update(
            "INSERT IGNORE INTO user_profiles(user_id, user_name, role) VALUES(?,?,?)",
            userId, userId, "manager"
        );
    }

    private List<String> getRecentConclusions(String userId, int limit) {
        try {
            return jdbc.queryForList(
                "SELECT key_conclusions FROM user_query_history " +
                "WHERE user_id=? AND key_conclusions IS NOT NULL " +
                "ORDER BY session_date DESC LIMIT ?",
                String.class, userId, limit
            );
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    private List<Map<String, Object>> getActiveWatches(String userId) {
        return jdbc.queryForList(
            "SELECT * FROM user_watchlist WHERE user_id=? AND is_active=1 ORDER BY created_at DESC LIMIT 5",
            userId
        );
    }
}
