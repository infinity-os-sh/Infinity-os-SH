// ============================================================
// MemoryOrchestrator.java
// 四层记忆统一调度器
// 每次Agent调用的统一入口·自动组装四层上下文
// ============================================================
package com.xinhe.infinityos.memory.orchestrator;

import com.xinhe.infinityos.memory.layer1.ConversationMemoryService;
import com.xinhe.infinityos.memory.layer2.UserMemoryService;
import com.xinhe.infinityos.memory.layer3.SharedMemoryService;
import com.xinhe.infinityos.memory.layer4.OrgKnowledgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class MemoryOrchestrator {

    @Autowired private ConversationMemoryService layer1;
    @Autowired private UserMemoryService         layer2;
    @Autowired private SharedMemoryService       layer3;
    @Autowired private OrgKnowledgeService       layer4;

    // ══ 核心方法：构建完整的Agent调用上下文 ══════════════════

    /**
     * Agent收到用户请求时，调用此方法构建完整上下文
     *
     * 返回包含：
     * - systemPrompt：注入四层记忆的系统提示词
     * - conversationHistory：当前会话的对话历史
     * - entityContext：当前操作实体的历史画像
     * - applicableRules：匹配的决策规则
     * - pendingAlerts：来自其他Agent的未读广播
     *
     * 用法：
     * AgentContext ctx = orchestrator.buildContext(userId, sessionId, agentId, entityId, requestData);
     * // 然后将ctx传给Claude API调用
     */
    public AgentContext buildContext(String userId, String sessionId,
                                      String agentId, String entityId,
                                      Map<String, Object> requestData) {

        AgentContext ctx = new AgentContext();

        // ── 层面二：用户偏好上下文 ────────────────────────────
        String userContextPrompt = layer2.buildUserContextPrompt(userId);
        ctx.setUserContextPrompt(userContextPrompt);

        // ── 层面一：对话历史 ──────────────────────────────────
        List<Map<String, String>> conversationHistory = layer1.getContextMessages(sessionId);
        ctx.setConversationHistory(conversationHistory);

        // ── 层面三：来自其他Agent的未读消息 ──────────────────
        List<Map<String, Object>> pendingMessages = layer3.pullMessages(agentId);
        ctx.setPendingMessages(pendingMessages);

        // ── 层面三：全局critical状态 ──────────────────────────
        List<Map<String, Object>> criticalStates = layer3.readCriticalStates();
        ctx.setCriticalStates(criticalStates);

        // ── 层面四：实体历史画像（门店/经销商）───────────────
        if (entityId != null) {
            String entityType = requestData != null
                ? String.valueOf(requestData.getOrDefault("entity_type", "store"))
                : "store";
            if ("store".equals(entityType)) {
                ctx.setEntityProfile(layer4.getStoreProfile(entityId));
            }

            // 相似历史案例
            String anomalyType = requestData != null
                ? String.valueOf(requestData.getOrDefault("anomaly_type", "")) : "";
            if (!anomalyType.isEmpty()) {
                ctx.setSimilarCases(layer4.findSimilarCases(anomalyType, entityType));
            }
        }

        // ── 层面四：匹配的决策规则 ────────────────────────────
        String ruleCategory = requestData != null
            ? String.valueOf(requestData.getOrDefault("rule_category", "inventory")) : "inventory";
        List<Map<String, Object>> rules = layer4.matchDecisionRules(ruleCategory, requestData != null ? requestData : Map.of());
        ctx.setApplicableRules(rules);

        return ctx;
    }

    /**
     * 将AgentContext组装成Claude API的system prompt
     * 调用方在实际发起API请求前调用此方法
     */
    public String buildSystemPrompt(String baseAgentPrompt, AgentContext ctx) {
        StringBuilder prompt = new StringBuilder(baseAgentPrompt);
        prompt.append("\n\n");

        // 层面二：用户偏好
        if (ctx.getUserContextPrompt() != null && !ctx.getUserContextPrompt().isBlank()) {
            prompt.append(ctx.getUserContextPrompt()).append("\n");
        }

        // 层面三：系统级critical警报
        if (ctx.getCriticalStates() != null && !ctx.getCriticalStates().isEmpty()) {
            prompt.append("【⚠️ 系统级警报（").append(ctx.getCriticalStates().size()).append("条）】\n");
            ctx.getCriticalStates().stream().limit(3).forEach(state ->
                prompt.append("  - ").append(state.get("state_key"))
                      .append("：").append(state.get("state_value")).append("\n")
            );
        }

        // 层面三：其他Agent的消息
        if (ctx.getPendingMessages() != null && !ctx.getPendingMessages().isEmpty()) {
            prompt.append("【📡 来自其他Agent的消息（").append(ctx.getPendingMessages().size()).append("条）】\n");
            ctx.getPendingMessages().stream().limit(3).forEach(msg ->
                prompt.append("  - [").append(msg.get("from")).append("] ")
                      .append(msg.get("subject")).append("\n")
            );
        }

        // 层面四：实体历史画像
        if (ctx.getEntityProfile() != null && !ctx.getEntityProfile().isEmpty()) {
            Map<String, Object> profile = ctx.getEntityProfile();
            prompt.append("【📋 实体历史画像】\n");
            if (profile.get("risk_level") != null) {
                prompt.append("  风险等级：").append(profile.get("risk_level")).append("\n");
            }
            if (profile.get("known_issues") != null) {
                prompt.append("  历史问题：").append(profile.get("known_issues")).append("\n");
            }
            if (profile.get("pattern_confidence") != null) {
                prompt.append("  画像置信度：").append(profile.get("pattern_confidence")).append("\n");
            }
        }

        // 层面四：历史相似案例
        if (ctx.getSimilarCases() != null && !ctx.getSimilarCases().isEmpty()) {
            prompt.append("【📚 相似历史案例（").append(ctx.getSimilarCases().size()).append("个）】\n");
            ctx.getSimilarCases().stream().limit(2).forEach(c ->
                prompt.append("  - ").append(c.get("description"))
                      .append("·结果：").append(c.get("resolution_outcome"))
                      .append("·经验：").append(c.get("lessons_learned")).append("\n")
            );
        }

        // 层面四：适用决策规则
        if (ctx.getApplicableRules() != null && !ctx.getApplicableRules().isEmpty()) {
            prompt.append("【📐 组织决策规则（").append(ctx.getApplicableRules().size()).append("条适用）】\n");
            ctx.getApplicableRules().stream().limit(3).forEach(rule ->
                prompt.append("  - [").append(rule.get("rule_name")).append("] ")
                      .append(rule.get("action_desc")).append("\n")
            );
        }

        prompt.append("\n基于以上上下文，请回答用户的问题。");
        return prompt.toString();
    }

    // ══ 对话轮次的写入（统一入口）════════════════════════════

    /**
     * 用户发送消息后调用
     */
    public void onUserMessage(String sessionId, String content) {
        layer1.addTurn(sessionId, "user", content);
    }

    /**
     * Agent回复后调用
     */
    public void onAgentReply(String sessionId, String agentId,
                              String content, Map<String, Object> eventData) {
        layer1.addTurn(sessionId, "assistant", content);

        // 记录到层面三的事件日志
        if (eventData != null && !eventData.isEmpty()) {
            layer3.recordEvent(agentId, "chat_reply", "system", sessionId,
                eventData, "success", 1.0);
        }
    }

    /**
     * 会话结束时调用：保存摘要 + 更新用户档案
     */
    public void onSessionEnd(String userId, String sessionId, String agentId,
                               String summary, List<String> topics,
                               List<String> cities, List<String> stores) {
        layer1.endSession(sessionId);
        layer2.saveSessionSummary(userId, sessionId, summary, topics, cities, stores);
    }

    // ══ 异常事件的统一记录（跨三四层）════════════════════════

    /**
     * 发现异常时调用：同时写层面三（广播）和层面四（案例库）
     */
    public String recordAnomalyWithBroadcast(String agentId, String anomalyType,
                                               String entityType, String entityId,
                                               String description, String severity) {
        // 层面四：记录案例
        String caseId = layer4.recordAnomaly(
            anomalyType, entityType, entityId, description, severity, agentId
        );

        // 层面三：广播给相关Agent
        String priority = "critical".equals(severity) ? "critical" : "high";
        layer3.broadcast(agentId, null, "alert", priority,
            "异常检测·" + anomalyType + "·" + entityId,
            Map.of("caseId", caseId, "anomalyType", anomalyType,
                   "entityType", entityType, "entityId", entityId,
                   "severity", severity, "description", description)
        );

        // 层面三：写入共享状态，其他Agent随时可查
        layer3.writeState(agentId, entityType, entityId,
            "anomaly_" + anomalyType,
            Map.of("caseId", caseId, "type", anomalyType,
                   "severity", severity, "detectedAt", System.currentTimeMillis()),
            priority, "critical".equals(severity) ? null : 60
        );

        return caseId;
    }
}
