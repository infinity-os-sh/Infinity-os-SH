// ============================================================
// AgentContext.java
// 四层记忆组装后的统一上下文数据结构
// ============================================================
package com.xinhe.infinityos.memory.orchestrator;

import java.util.List;
import java.util.Map;

public class AgentContext {

    // 层面二：用户个性化上下文（注入system prompt）
    private String userContextPrompt;

    // 层面一：当前会话对话历史（传给messages数组）
    private List<Map<String, String>> conversationHistory;

    // 层面三：来自其他Agent的未读广播消息
    private List<Map<String, Object>> pendingMessages;

    // 层面三：当前系统级critical状态
    private List<Map<String, Object>> criticalStates;

    // 层面四：当前操作实体的历史画像
    private Map<String, Object> entityProfile;

    // 层面四：相似历史案例
    private List<Map<String, Object>> similarCases;

    // 层面四：适用的决策规则
    private List<Map<String, Object>> applicableRules;

    // ── Getters & Setters ────────────────────────────────────
    public String getUserContextPrompt() { return userContextPrompt; }
    public void setUserContextPrompt(String v) { this.userContextPrompt = v; }

    public List<Map<String, String>> getConversationHistory() { return conversationHistory; }
    public void setConversationHistory(List<Map<String, String>> v) { this.conversationHistory = v; }

    public List<Map<String, Object>> getPendingMessages() { return pendingMessages; }
    public void setPendingMessages(List<Map<String, Object>> v) { this.pendingMessages = v; }

    public List<Map<String, Object>> getCriticalStates() { return criticalStates; }
    public void setCriticalStates(List<Map<String, Object>> v) { this.criticalStates = v; }

    public Map<String, Object> getEntityProfile() { return entityProfile; }
    public void setEntityProfile(Map<String, Object> v) { this.entityProfile = v; }

    public List<Map<String, Object>> getSimilarCases() { return similarCases; }
    public void setSimilarCases(List<Map<String, Object>> v) { this.similarCases = v; }

    public List<Map<String, Object>> getApplicableRules() { return applicableRules; }
    public void setApplicableRules(List<Map<String, Object>> v) { this.applicableRules = v; }
}
