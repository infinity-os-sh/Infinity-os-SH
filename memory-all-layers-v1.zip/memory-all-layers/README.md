# INFINITY OS · 四层记忆系统 v1.0
## 完整交付包

---

## 文件清单

```
memory-all-layers/
├── sql/
│   ├── V1__layer1_conversation_memory.sql   ← 层面一·3张表+1个视图·对话记忆
│   ├── V2__layer2_user_memory.sql           ← 层面二·4张表+1个视图·用户记忆
│   ├── V3__layer3_shared_memory.sql         ← 层面三·5张表+1个视图·Agent共享记忆·含24个Agent初始化
│   └── V4__layer4_org_knowledge.sql         ← 层面四·5张表+1个视图·组织知识·含4条预设规则
│
└── java/com/xinhe/infinityos/memory/
    ├── layer1/ConversationMemoryService.java ← 层面一·Redis热存储+MySQL持久化·多轮追问
    ├── layer2/UserMemoryService.java         ← 层面二·跨会话偏好·关注项·自动学习
    ├── layer3/SharedMemoryService.java       ← 层面三·状态总线·广播·信用分·分布式锁
    ├── layer4/OrgKnowledgeService.java       ← 层面四·门店画像·规则库·案例库·每周自学习
    └── orchestrator/
        ├── MemoryOrchestrator.java           ← ⭐统一调度器·四层组装·单一入口
        └── AgentContext.java                 ← 上下文数据结构
```

---

## 四层对照表

| 层面 | 是什么 | 存储 | 典型场景 |
|------|--------|------|---------|
| 层面一·对话记忆 | 这轮对话说了什么 | Redis（热）+ MySQL（冷） | 用户问"那个最差的"，Agent知道指什么 |
| 层面二·用户记忆 | 这个人历史偏好 | MySQL | 上周关注上海，这周回来还知道 |
| 层面三·Agent共享 | 24个Agent的共同信息 | Redis（实时）+ MySQL（持久） | 蝴蝶效应发现异常，总指挥和推单Agent同步知道 |
| 层面四·组织知识 | 越跑越聪明的经验积累 | MySQL | 某门店反复压货，下次直接预警 |

---

## 数据库表总览（17张表 + 4个视图）

### 层面一（3张表 + 1个视图）
- `conv_sessions` — 会话主表
- `conv_turns` — 对话轮次明细
- `conv_snapshots` — 历史压缩快照
- `v_active_sessions` — 活跃会话视图

### 层面二（4张表 + 1个视图）
- `user_profiles` — 用户档案
- `user_query_history` — 每会话摘要
- `user_watchlist` — 持续关注项
- `user_preference_learning` — 偏好学习日志
- `v_user_context` — 用户回访上下文视图

### 层面三（5张表 + 1个视图）
- `agent_shared_state` — 共享状态总线
- `agent_memory_events` — 事件日志
- `agent_memory_decisions` — 决策记录
- `agent_broadcast_messages` — Agent间广播
- `agent_memory_profiles` — Agent档案（含24个Agent初始数据）
- `v_agent_system_health` — 系统健康视图

### 层面四（5张表 + 1个视图）
- `store_behavior_patterns` — 门店行为画像
- `distributor_behavior_patterns` — 经销商画像
- `org_decision_rules` — 决策规则库（含4条预设规则）
- `city_market_knowledge` — 城市市场知识
- `anomaly_case_library` — 异常案例库
- `v_org_knowledge_health` — 知识健康视图

---

## Redis Key设计规范

```
# 层面一·对话记忆
conv:{sessionId}:turns        → List·最近20轮对话JSON·TTL 24小时
conv:{sessionId}:meta         → Hash·会话元数据·TTL 24小时

# 层面三·Agent共享
agent:state:{scope}:{scopeId}:{key}    → String·实时状态JSON·TTL 15分钟
agent:broadcast:queue:{agentId}        → List·待处理消息·TTL 1小时
agent:broadcast:queue:global           → List·全体广播·TTL 1小时
agent:lock:{entityId}                  → String·分布式锁·TTL 30秒（默认）
```

---

## 集成步骤

### Step 1：建表（1小时）
```sql
-- 按顺序执行，有外键依赖
source V1__layer1_conversation_memory.sql;
source V2__layer2_user_memory.sql;
source V3__layer3_shared_memory.sql;
source V4__layer4_org_knowledge.sql;

-- 验证
SELECT * FROM v_agent_system_health;          -- 应看到24个Agent
SELECT COUNT(*) FROM org_decision_rules;      -- 应为4条预设规则
```

### Step 2：复制Java包（30分钟）
将 `memory` 包复制到现有Spring Boot项目，确保已有：
- `spring-boot-starter-data-redis`
- `spring-boot-starter-jdbc`
- Jackson ObjectMapper Bean

### Step 3：在每次Agent调用前插入记忆组装（核心集成点）

```java
// 原来：直接构建system prompt调用Claude API
String systemPrompt = "你是经销商全链Agent...";
List<Map<String,String>> messages = List.of(Map.of("role","user","content",userInput));

// 现在：先通过MemoryOrchestrator组装四层上下文
AgentContext ctx = memoryOrchestrator.buildContext(
    userId, sessionId, "distributor", distributorId,
    Map.of("rule_category", "channel", "entity_type", "distributor")
);

// 自动把四层记忆注入system prompt
String enrichedSystemPrompt = memoryOrchestrator.buildSystemPrompt(
    "你是经销商全链Agent...", ctx  // 基础prompt + 四层记忆上下文
);

// 用带记忆的对话历史调用Claude API
List<Map<String,String>> messages = ctx.getConversationHistory();
// 追加当前用户输入
messages.add(Map.of("role","user","content",userInput));

// 记录用户消息到层面一
memoryOrchestrator.onUserMessage(sessionId, userInput);

// 调用Claude API...（省略）

// 记录Agent回复到层面一
memoryOrchestrator.onAgentReply(sessionId, "distributor", agentReply, Map.of());
```

### Step 4：会话开始/结束钩子（15分钟）
```java
// 用户打开INFINITY OS
String sessionId = conversationMemoryService.startSession(userId, agentId);

// 用户关闭/超时
memoryOrchestrator.onSessionEnd(
    userId, sessionId, agentId,
    "用户查询了上海经销商库存状况，发现3家低于1a",
    List.of("库存水位","经销商健康"), List.of("上海"), List.of()
);
```

### Step 5：异常发现时的统一记录（10分钟）
```java
// 蝴蝶效应Agent发现异常
String caseId = memoryOrchestrator.recordAnomalyWithBroadcast(
    "butterfly",       // 发现者
    "stuffing",        // 异常类型（A类压货）
    "distributor",     // 实体类型
    "DIST_SH_001",     // 实体ID
    "上海松江经销商库存异常增加，超过正常水位3倍，疑似渠道压货",
    "high"             // 严重程度
);
// 自动：写入案例库 + 广播给所有Agent + 写入共享状态总线
```

---

## 与现有模块的依赖关系

```
四层记忆系统
    ↑ 被调用
auth-boundary-v1   → 读取agent_memory_profiles.credit_score（Agent信用分）
                   → 读取agent_memory_events（古德哈特检测·㉒维度）
                   → 读取agent_memory_decisions（新颖情境检测·⑮维度）

tool-layer-v1      → 每次工具调用前先执行auth-boundary
                   → auth-boundary完成后组装四层记忆上下文
                   → 再调用Claude API
```

---

## 定时任务清单

| 任务 | 频次 | 说明 |
|------|------|------|
| `ConversationMemoryService.cleanupExpiredSessions()` | 每小时 | 清理超时会话 |
| `OrgKnowledgeService.weeklyKnowledgeLearning()` | 每周一6:00 | 从事件日志提炼新规则 |
| `OrgKnowledgeService.monthlyRiskReassessment()` | 每月1日7:00 | 重新评估门店风险等级 |

---

## 各Service接口（需Java团队补充实现的桩类）

```
layer1:
  ClaudeApiService.summarize(text)   → 调用Claude API压缩对话历史（已有桩）

layer2:
  无需额外依赖，直接依赖JDBC

layer3:
  无需额外依赖，RedisTemplate + JDBC

layer4:
  无需额外依赖，JDBC
```

---

## MVP最小实现（如果资源紧张）

优先顺序：
1. **层面一 + 层面三** → 3天工作量 → 让Agent从失忆变成有记忆
2. **层面四的store_behavior_patterns** → 1天 → 让门店画像开始积累
3. **层面二** → 1天 → 个性化用户体验
4. **层面四全部** → 等真实数据上线后自然成长

**重要：层面四在没有真实SFA数据时是空的容器，等数据上线后自动开始积累。不要等数据完整再建表——先建好，数据来了自然填满。**
