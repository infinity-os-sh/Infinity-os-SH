-- ============================================================
-- 层面四：组织知识记忆（组织级）
-- 让Agent积累组织知识，越用越聪明
-- 某门店反复出现压货 → Agent记住这个模式 → 下次直接预警
-- ============================================================

-- 门店行为模式库：积累每个门店的历史行为规律
CREATE TABLE store_behavior_patterns (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    store_id        VARCHAR(64) NOT NULL,
    store_name      VARCHAR(128),
    city_id         VARCHAR(64),
    store_tier      ENUM('S+','S','A','B','C','D'),
    -- 库存行为
    avg_inventory_level DECIMAL(5,2),                      -- 通常保持几倍a的库存
    inventory_volatility ENUM('stable','moderate','volatile'),
    stockout_frequency  DECIMAL(4,2),                      -- 月均断货天数
    overstock_frequency DECIMAL(4,2),                      -- 月均压货天数
    -- 补货行为
    avg_replenishment_cycle INT,                           -- 平均补货周期（天）
    order_day_preference    JSON,                          -- ["Monday","Wednesday"]·倾向哪天下单
    -- 异常历史
    known_issues    JSON,                                  -- ["price_violation","gray_market","fake_stockout"]
    risk_level      ENUM('low','medium','high','critical') DEFAULT 'low',
    -- 统计
    observation_months INT NOT NULL DEFAULT 0,            -- 观测了多少个月
    pattern_confidence DECIMAL(4,2),                      -- 模式置信度
    last_updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_store (store_id),
    INDEX idx_city_tier (city_id, store_tier),
    INDEX idx_risk (risk_level),
    INDEX idx_issues ((CAST(known_issues AS CHAR(256))))
) COMMENT='门店行为模式库·越用越懂每家门店';

-- 经销商画像库：积累每个经销商的经营规律
CREATE TABLE distributor_behavior_patterns (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    distributor_id  VARCHAR(64) NOT NULL UNIQUE,
    distributor_name VARCHAR(128),
    city_id         VARCHAR(64),
    tier            ENUM('S','A','B','C','D'),
    -- 财务行为
    payment_punctuality ENUM('excellent','good','average','poor'),-- 回款守时度
    avg_monthly_purchase DECIMAL(12,2),                   -- 月均进货额
    purchase_volatility  ENUM('stable','seasonal','volatile'),
    -- 库存行为
    stuffing_risk   ENUM('none','low','medium','high'),    -- 压货风险等级
    gray_market_risk ENUM('none','low','medium','high'),   -- 窜货风险
    -- 历史事件
    incident_history JSON,                                 -- [{"type":"stuffing","date":"2025-03","amount":50000}]
    channel_health  ENUM('healthy','warning','critical') DEFAULT 'healthy',
    last_anomaly_at DATETIME,
    observation_months INT NOT NULL DEFAULT 0,
    pattern_confidence DECIMAL(4,2),
    last_updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_city (city_id),
    INDEX idx_channel_health (channel_health),
    INDEX idx_stuffing_risk (stuffing_risk)
) COMMENT='经销商画像库·积累渠道健康规律';

-- 组织决策规则库：从历史决策中提炼出的业务规则
CREATE TABLE org_decision_rules (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    rule_id         VARCHAR(64) NOT NULL UNIQUE,           -- 规则唯一标识
    rule_category   ENUM('inventory','promotion','pricing','channel','exception') NOT NULL,
    rule_name       VARCHAR(128) NOT NULL,
    -- 规则内容
    condition_desc  VARCHAR(512) NOT NULL,                 -- 触发条件（自然语言）
    condition_json  JSON NOT NULL,                         -- 触发条件（结构化）
    action_desc     VARCHAR(512) NOT NULL,                 -- 应采取的行动
    action_json     JSON NOT NULL,
    -- 规则来源和可信度
    source          ENUM('manual','learned','ai_generated') NOT NULL,
    confidence      DECIMAL(4,2) NOT NULL DEFAULT 0.80,
    validation_count INT NOT NULL DEFAULT 0,               -- 被验证正确的次数
    violation_count INT NOT NULL DEFAULT 0,                -- 被证明错误的次数
    -- 规则治理
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    created_by      VARCHAR(64),
    approved_by     VARCHAR(64),
    last_triggered_at DATETIME,
    trigger_count   INT NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      DATETIME,                              -- 规则有效期（null=永久）
    INDEX idx_category_active (rule_category, is_active),
    INDEX idx_confidence (confidence),
    INDEX idx_trigger (trigger_count DESC)
) COMMENT='组织决策规则库·从历史中提炼的业务规则';

-- 预设核心业务规则
INSERT INTO org_decision_rules (rule_id, rule_category, rule_name, condition_desc, condition_json, action_desc, action_json, source, confidence) VALUES
('R001', 'inventory', 'S+门店低于2a紧急补货', 
 'S+门店货架库存低于2a（心跳单元）时触发补货预警',
 '{"store_tier":"S+","inventory_ratio":"<2","metric":"shelf_stock"}',
 '立即通知业务员，当日完成补货，同时通知经销商备货',
 '{"action":"alert","priority":"high","assignee":"field_rep","deadline_hours":24}',
 'manual', 0.98),
('R002', 'channel', '二批商库存超1a压货预警',
 'P2路径二批商库存超过1a，可能存在渠道压货或窜货风险',
 '{"channel":"P2","inventory_ratio":">1","role":"sub_distributor"}',
 '触发蝴蝶效应Agent检测，核实是否为A类压货失真，通知区域经理',
 '{"action":"butterfly_check","butterfly_mode":"A","notify":"area_manager"}',
 'manual', 0.95),
('R003', 'pricing', '底价保护红线',
 '任何渠道发现六月鲜售价低于¥17时触发价格保护',
 '{"brand":"六月鲜","price_threshold":17,"direction":"below"}',
 '立即记录违规门店，通知经销商整改，严重时暂停供货',
 '{"action":"record_violation","notify":"distributor","escalate_if":"repeat"}',
 'manual', 1.00),
('R004', 'inventory', '经销商库存跌破1a自动推单',
 '经销商月末库存低于1a时，无菜单推单Agent自动计算补货量',
 '{"role":"distributor","inventory_ratio":"<1","timing":"month_end_check"}',
 '无菜单推单Agent计算SKU组合和补货量，发起审批流程',
 '{"action":"omakase_order","auth_required":"fast_track"}',
 'manual', 0.92);

-- 城市市场知识库：积累每个城市的市场规律
CREATE TABLE city_market_knowledge (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    city_id         VARCHAR(64) NOT NULL UNIQUE,
    city_name       VARCHAR(64) NOT NULL,
    tier            ENUM('S+','S','A','B','C') NOT NULL,   -- 城市战略级别
    -- 市场特征
    market_maturity ENUM('emerging','growing','mature','declining') DEFAULT 'emerging',
    key_seasons     JSON,                                  -- ["春节","端午"]·销量高峰节假日
    competitor_intensity ENUM('low','medium','high'),
    -- 六月鲜在当地的情况
    current_store_count INT DEFAULT 0,
    penetration_rate    DECIMAL(5,2),                     -- 家庭渗透率%
    avg_r_value         DECIMAL(6,4),                     -- 平均日销率
    brand_grade_mix     JSON,                             -- {"grade1":30,"grade2":45,"grade3":25}·年级分布
    -- 市场洞察
    local_insights  TEXT,                                  -- 经验积累的本地化知识
    risk_factors    JSON,                                  -- ["强竞品","价格敏感","渠道分散"]
    opportunities   JSON,                                  -- ["高端超市布点少","餐饮渗透低"]
    last_updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_tier (tier),
    INDEX idx_maturity (market_maturity)
) COMMENT='城市市场知识库·每个城市的经验积累';

-- 异常案例库：历史异常事件的完整记录和处置结果
CREATE TABLE anomaly_case_library (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    case_id         VARCHAR(64) NOT NULL UNIQUE,
    anomaly_type    ENUM('stuffing','gray_market','price_violation','stockout','fake_data','butterfly') NOT NULL,
    entity_type     ENUM('store','distributor','city') NOT NULL,
    entity_id       VARCHAR(64) NOT NULL,
    -- 案例详情
    detected_at     DATETIME NOT NULL,
    detected_by     VARCHAR(64) NOT NULL,                  -- 哪个Agent发现的
    description     TEXT NOT NULL,
    severity        ENUM('low','medium','high','critical') NOT NULL,
    -- 处置过程
    resolution_steps JSON,                                 -- 处置步骤数组
    resolved_at     DATETIME,
    resolved_by     VARCHAR(64),
    resolution_outcome ENUM('resolved','escalated','false_positive','ongoing'),
    -- 学习价值
    lessons_learned TEXT,                                  -- 这个案例教会了系统什么
    pattern_tag     VARCHAR(128),                          -- 模式标签，用于相似案例匹配
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_type_entity (anomaly_type, entity_type),
    INDEX idx_entity (entity_id),
    INDEX idx_detected (detected_at),
    INDEX idx_pattern (pattern_tag)
) COMMENT='异常案例库·历史案例是最好的老师';

-- 视图：组织知识健康度概览
CREATE VIEW v_org_knowledge_health AS
SELECT
    (SELECT COUNT(*) FROM store_behavior_patterns WHERE pattern_confidence > 0.7) AS mature_store_profiles,
    (SELECT COUNT(*) FROM store_behavior_patterns) AS total_store_profiles,
    (SELECT COUNT(*) FROM distributor_behavior_patterns WHERE pattern_confidence > 0.7) AS mature_dist_profiles,
    (SELECT COUNT(*) FROM org_decision_rules WHERE is_active = 1) AS active_rules,
    (SELECT COUNT(*) FROM org_decision_rules WHERE source = 'learned') AS ai_learned_rules,
    (SELECT COUNT(*) FROM anomaly_case_library WHERE resolved_at IS NOT NULL) AS resolved_cases,
    (SELECT COUNT(*) FROM anomaly_case_library WHERE resolution_outcome = 'false_positive') AS false_positives,
    (SELECT AVG(pattern_confidence) FROM store_behavior_patterns WHERE pattern_confidence IS NOT NULL) AS avg_store_confidence,
    NOW() AS generated_at;
