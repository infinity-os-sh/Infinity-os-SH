-- ============================================================
-- 层面三：Agent间共享记忆（系统级）
-- 让24个Agent之间共享信息
-- 蝴蝶效应Agent发现传导异常，AIO总指挥和无菜单推单Agent都能知道
-- ============================================================

-- Agent共享状态总线：任何Agent写入，所有Agent可读
CREATE TABLE agent_shared_state (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    state_key       VARCHAR(128) NOT NULL,                 -- 状态键，唯一标识
    state_scope     ENUM('global','city','store','distributor','brand') NOT NULL DEFAULT 'global',
    scope_id        VARCHAR(64),                           -- 对应城市/门店/经销商ID
    agent_source    VARCHAR(64) NOT NULL,                  -- 谁写入的
    state_value     JSON NOT NULL,                         -- 状态内容
    priority        ENUM('normal','warning','critical') NOT NULL DEFAULT 'normal',
    expires_at      DATETIME,                              -- null=永久
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_state_key_scope (state_key, state_scope, scope_id),
    INDEX idx_scope_priority (state_scope, priority),
    INDEX idx_source (agent_source),
    INDEX idx_expires (expires_at)
) COMMENT='Agent共享状态总线·任何Agent写入·所有Agent可读';

-- Agent执行事件日志：每次Agent执行动作后记录
CREATE TABLE agent_memory_events (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id        VARCHAR(64) NOT NULL,
    event_type      VARCHAR(64) NOT NULL,                  -- alert/action/calculation/recommendation
    entity_type     ENUM('store','distributor','city','brand','system') NOT NULL,
    entity_id       VARCHAR(64),
    event_data      JSON NOT NULL,                         -- 事件详细内容
    outcome         ENUM('success','failure','partial','pending') NOT NULL DEFAULT 'pending',
    confidence      DECIMAL(4,2),
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    -- 关联
    session_id      VARCHAR(64),                           -- 触发此事件的会话（如有）
    parent_event_id BIGINT,                                -- 链式事件（A触发B）
    INDEX idx_agent_type (agent_id, event_type),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_created (created_at),
    INDEX idx_outcome (outcome)
) COMMENT='Agent执行事件日志·全链可追溯';

-- Agent决策记录：重要决策单独存储供学习和审计
CREATE TABLE agent_memory_decisions (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id        VARCHAR(64) NOT NULL,
    decision_type   VARCHAR(64) NOT NULL,                  -- push_order/send_alert/recommend
    entity_id       VARCHAR(64) NOT NULL,
    reasoning       TEXT NOT NULL,                         -- 为什么这样决定（推理链路）
    decision_data   JSON NOT NULL,                         -- 决定内容
    auth_level      TINYINT NOT NULL DEFAULT 0,            -- 授权级别（来自auth-boundary）
    approved_by     VARCHAR(64),                           -- 人工审批者（如需要）
    approved_at     DATETIME,
    execution_result JSON,                                 -- 执行后的结果
    feedback_score  TINYINT,                               -- 人工反馈评分 1-5
    feedback_reason ENUM('data_wrong','logic_wrong','timing_wrong','correct','excellent'),
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_agent_type (agent_id, decision_type),
    INDEX idx_entity (entity_id),
    INDEX idx_created (created_at),
    INDEX idx_feedback (feedback_score)
) COMMENT='Agent决策记录·供信用分计算和学习';

-- Agent间消息广播：Agent主动通知其他Agent
CREATE TABLE agent_broadcast_messages (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    from_agent      VARCHAR(64) NOT NULL,
    to_agent        VARCHAR(64),                           -- null=广播给所有Agent
    message_type    ENUM('alert','data_update','request','response','sync') NOT NULL,
    priority        ENUM('low','normal','high','critical') NOT NULL DEFAULT 'normal',
    subject         VARCHAR(128) NOT NULL,
    payload         JSON NOT NULL,
    is_read         TINYINT(1) NOT NULL DEFAULT 0,
    read_at         DATETIME,
    expires_at      DATETIME,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_to_agent_read (to_agent, is_read),
    INDEX idx_from_agent (from_agent),
    INDEX idx_priority (priority, is_read),
    INDEX idx_expires (expires_at)
) COMMENT='Agent间消息广播·蝴蝶效应发现异常通知AIO';

-- Agent状态档案：每个Agent的当前运行状态
CREATE TABLE agent_memory_profiles (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id        VARCHAR(64) NOT NULL UNIQUE,
    agent_name      VARCHAR(128) NOT NULL,
    current_status  ENUM('active','paused','error','maintenance') NOT NULL DEFAULT 'active',
    credit_score    DECIMAL(5,2) NOT NULL DEFAULT 80.00,   -- 信用分，auth-boundary使用
    total_decisions INT NOT NULL DEFAULT 0,
    correct_rate    DECIMAL(4,2),                          -- 历史正确率
    last_active_at  DATETIME,
    current_focus   JSON,                                  -- 当前正在处理的实体列表
    known_patterns  JSON,                                  -- 该Agent学到的关键模式
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (current_status),
    INDEX idx_credit (credit_score)
) COMMENT='Agent状态档案·credit_score供auth-boundary使用';

-- 初始化24个Agent的档案
INSERT INTO agent_memory_profiles (agent_id, agent_name, credit_score) VALUES
('aio_commander',     'AIO总指挥',      80.00),
('production',        '生产供应',        80.00),
('distributor',       '经销商全链',      80.00),
('sub_distributor',   '二批商',         80.00),
('retail_store',      '零售门店',        80.00),
('consumer_deep',     '消费者深度',      80.00),
('food_service',      '餐饮渠道',        80.00),
('butterfly',         '蝴蝶效应',        80.00),
('omakase',           '无菜单推单',      80.00),
('a_calibration',     'A值校准',        80.00),
('uber_incentive',    'Uber激励',       80.00),
('shelf_recognition', '货架识别',        80.00),
('inventory_report',  '库存上报',        80.00),
('price_tag',         '价签识别',        80.00),
('prism',             'PRISM精准选点',   80.00),
('xiaohongshu',       '小红书种草棒',    80.00),
('douyin',            '抖音爆发棒',      80.00),
('ecommerce',         '电商转化棒',      80.00),
('o2o',               'O2O即时棒',      80.00),
('warehouse_member',  '仓储会员棒',      80.00),
('hypermarket',       '大卖场棒',        80.00),
('community',         '社区超市棒',      80.00),
('brand_advisor',     '品牌AI顾问',      80.00),
('fresh_advisor',     '鲜生顾问',        80.00);

-- Redis Key设计（注释说明）
-- KEY: agent:state:{scope}:{scope_id}     → Hash，实时状态
-- KEY: agent:broadcast:queue:{agent_id}  → List，待处理消息队列
-- KEY: agent:lock:{entity_id}            → String，防止多Agent同时操作同一实体
-- TTL: 状态15分钟，广播消息1小时

-- 视图：全局系统健康状态
CREATE VIEW v_agent_system_health AS
SELECT
    p.agent_id,
    p.agent_name,
    p.current_status,
    p.credit_score,
    p.total_decisions,
    p.correct_rate,
    -- 最近1小时的活跃度
    (SELECT COUNT(*) FROM agent_memory_events e
     WHERE e.agent_id = p.agent_id
     AND e.created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)) AS events_last_hour,
    -- 未读广播消息数
    (SELECT COUNT(*) FROM agent_broadcast_messages m
     WHERE (m.to_agent = p.agent_id OR m.to_agent IS NULL)
     AND m.is_read = 0
     AND (m.expires_at IS NULL OR m.expires_at > NOW())) AS unread_messages,
    p.last_active_at
FROM agent_memory_profiles p;
