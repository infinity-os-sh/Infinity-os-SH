-- ============================================================
-- 层面二：跨会话用户记忆（用户级）
-- 让Agent记住"这个用户之前的偏好和历史"
-- 上周关注上海，这周回来还知道
-- ============================================================

-- 用户档案表：每个INFINITY OS用户一行
CREATE TABLE user_profiles (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         VARCHAR(64) NOT NULL UNIQUE,
    user_name       VARCHAR(64),
    role            ENUM('admin','manager','director','field') NOT NULL DEFAULT 'manager',
    -- 关注偏好
    preferred_cities        JSON,          -- ["上海","成都","北京"]·最关注的城市
    preferred_brands        JSON,          -- ["六月鲜","味达美"]
    preferred_channels      JSON,          -- ["S+","S","KA"]
    preferred_metrics       JSON,          -- ["r值","库存水位","铺货率"]
    -- 行为统计
    total_sessions          INT NOT NULL DEFAULT 0,
    total_queries           INT NOT NULL DEFAULT 0,
    avg_session_length      DECIMAL(5,1),                  -- 平均每次对话几轮
    last_login_at           DATETIME,
    -- 个性化设置
    alert_sensitivity       ENUM('low','medium','high') DEFAULT 'medium',
    report_format           ENUM('brief','detailed','visual') DEFAULT 'brief',
    language_pref           ENUM('zh','mixed') DEFAULT 'zh',
    created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id)
) COMMENT='用户档案·跨会话偏好';

-- 用户查询历史摘要：每次会话结束后提取关键信息
CREATE TABLE user_query_history (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         VARCHAR(64) NOT NULL,
    session_id      VARCHAR(64) NOT NULL,
    session_date    DATE NOT NULL,
    -- 这次会话的主题提取
    main_topics     JSON,                  -- ["上海库存","S+门店","蝴蝶效应"]
    queried_cities  JSON,
    queried_stores  JSON,
    queried_agents  JSON,
    -- 决策/结论摘要（AI提取）
    key_conclusions TEXT,                  -- "发现上海松江区3家S+门店库存低于2a"
    actions_taken   JSON,                  -- 用户基于AI建议做了什么动作
    session_summary TEXT,                  -- 整个会话的100字摘要
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_date (user_id, session_date),
    INDEX idx_user_session (user_id, session_id)
) COMMENT='用户查询历史·每会话一条摘要';

-- 用户关注的持续跟踪项：用户说"帮我持续关注这个"
CREATE TABLE user_watchlist (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         VARCHAR(64) NOT NULL,
    watch_type      ENUM('store','distributor','city','metric','agent') NOT NULL,
    entity_id       VARCHAR(64) NOT NULL,                  -- 具体的门店/经销商/城市ID
    entity_name     VARCHAR(128),
    watch_reason    VARCHAR(256),                          -- "上周库存异常，需要持续跟踪"
    alert_threshold JSON,                                  -- {"metric":"r_value","below":0.8}
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_triggered_at DATETIME,
    trigger_count   INT NOT NULL DEFAULT 0,
    INDEX idx_user_watch (user_id, is_active),
    INDEX idx_watch_entity (watch_type, entity_id)
) COMMENT='用户持续关注项·下次登录主动提醒';

-- 用户偏好学习日志：自动从行为中学习偏好
CREATE TABLE user_preference_learning (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id         VARCHAR(64) NOT NULL,
    preference_key  VARCHAR(64) NOT NULL,                  -- "preferred_city","report_depth"
    old_value       VARCHAR(256),
    new_value       VARCHAR(256) NOT NULL,
    confidence      DECIMAL(4,2),                          -- 0-1，学习置信度
    evidence_count  INT NOT NULL DEFAULT 1,                -- 基于多少次观察
    learned_from    VARCHAR(64),                           -- "query_pattern","explicit_setting"
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_pref (user_id, preference_key),
    INDEX idx_created (created_at)
) COMMENT='偏好学习日志·自动从行为推断偏好';

-- 视图：用户回访时的个性化上下文
CREATE VIEW v_user_context AS
SELECT
    p.user_id,
    p.user_name,
    p.role,
    p.preferred_cities,
    p.preferred_brands,
    p.alert_sensitivity,
    -- 最近3次会话摘要
    (SELECT JSON_ARRAYAGG(h.key_conclusions)
     FROM user_query_history h
     WHERE h.user_id = p.user_id
     ORDER BY h.session_date DESC LIMIT 3) AS recent_conclusions,
    -- 当前活跃的关注项数量
    (SELECT COUNT(*) FROM user_watchlist w
     WHERE w.user_id = p.user_id AND w.is_active = 1) AS active_watches,
    p.last_login_at,
    p.total_sessions
FROM user_profiles p;
