-- ============================================================
-- 层面一：Agent对话记忆（会话级）
-- 让Agent记住"这轮对话里前面说了什么"，支持多轮追问
-- ============================================================

-- 会话主表：每次用户打开INFINITY OS开启一个session
CREATE TABLE conv_sessions (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_id      VARCHAR(64) NOT NULL UNIQUE,          -- UUID，前端生成
    user_id         VARCHAR(64) NOT NULL,                  -- 操作用户
    agent_id        VARCHAR(64),                           -- 对话的Agent（null=战略大脑）
    started_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_active_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active       TINYINT(1) NOT NULL DEFAULT 1,
    turn_count      INT NOT NULL DEFAULT 0,
    context_summary TEXT,                                  -- 每10轮自动压缩摘要
    INDEX idx_session_id (session_id),
    INDEX idx_user_active (user_id, is_active),
    INDEX idx_last_active (last_active_at)
) COMMENT='对话会话主表';

-- 对话轮次表：每一次问答存一行
CREATE TABLE conv_turns (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_id      VARCHAR(64) NOT NULL,
    turn_index      INT NOT NULL,                          -- 会话内第几轮（从1开始）
    role            ENUM('user','assistant') NOT NULL,
    content         TEXT NOT NULL,
    token_count     INT,                                   -- 用于管理上下文窗口
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    -- 结构化提取字段（从对话中解析出的关键实体）
    mentioned_stores    JSON,                              -- ["STORE_001","STORE_002"]
    mentioned_products  JSON,                              -- ["六月鲜500ml"]
    mentioned_cities    JSON,                              -- ["上海","成都"]
    intent_type     VARCHAR(64),                           -- query/command/alert/analysis
    INDEX idx_session_turn (session_id, turn_index),
    INDEX idx_session_created (session_id, created_at),
    FOREIGN KEY (session_id) REFERENCES conv_sessions(session_id) ON DELETE CASCADE
) COMMENT='对话轮次明细';

-- 会话快照：每10轮压缩一次，避免上下文过长
CREATE TABLE conv_snapshots (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_id      VARCHAR(64) NOT NULL,
    snapshot_at     INT NOT NULL,                          -- 压缩到第几轮
    summary         TEXT NOT NULL,                         -- 压缩后的摘要
    key_entities    JSON,                                  -- 本段对话涉及的核心实体
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_session_snapshot (session_id, snapshot_at)
) COMMENT='对话压缩快照·避免上下文爆炸';

-- Redis Key设计（注释说明，不需要建表）
-- KEY: conv:{session_id}:turns        → List，存最近20轮的JSON
-- KEY: conv:{session_id}:meta         → Hash，session基本信息
-- TTL: 24小时不活跃自动清除
-- 策略: Redis存热数据（最近20轮），超出部分写MySQL持久化

-- 视图：最近活跃会话概览
CREATE VIEW v_active_sessions AS
SELECT
    s.session_id,
    s.user_id,
    s.agent_id,
    s.turn_count,
    s.last_active_at,
    COUNT(t.id) AS total_turns,
    MAX(t.content) AS last_message
FROM conv_sessions s
LEFT JOIN conv_turns t ON s.session_id = t.session_id AND t.role = 'user'
WHERE s.is_active = 1
  AND s.last_active_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
GROUP BY s.session_id
ORDER BY s.last_active_at DESC;
