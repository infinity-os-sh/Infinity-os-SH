// ============================================================
// AuthBoundaryController.java
// REST API：前端调用·Agent提交申请·审批人操作
// ============================================================
package com.xinhe.infinityos.auth.service;

import com.xinhe.infinityos.auth.config.AuthRequest;
import com.xinhe.infinityos.auth.config.AuthDecision;
import com.xinhe.infinityos.auth.engine.AuthorizationEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthBoundaryController {

    @Autowired
    private AuthorizationEngine authEngine;

    // ── Agent提交授权申请 ─────────────────────────────────────
    /**
     * POST /api/auth/evaluate
     * Agent在执行任何操作前必须先调用此接口
     * 返回：是否自主执行 OR 需要谁审批 OR 硬性禁止
     */
    @PostMapping("/evaluate")
    public ResponseEntity<Map<String, Object>> evaluate(
            @RequestBody AuthRequest request) {

        AuthDecision decision = authEngine.evaluate(request);

        Map<String, Object> resp = new java.util.LinkedHashMap<>();
        resp.put("final_level",       decision.getFinalLevel());
        resp.put("can_execute",       decision.isAutonomous());
        resp.put("hard_blocked",      decision.isHardBlocked());
        resp.put("plain_reason",      decision.getPlainReason());
        resp.put("required_approver", decision.getRequiredApprover());
        resp.put("deadline",          decision.getDeadline());
        resp.put("urgency",           decision.getUrgencyLevel());
        resp.put("dimension_scores",  decision.getDimensionScores());
        resp.put("mergeable",         decision.isMergeable());

        // 如果自主执行·返回执行令牌
        if (decision.isAutonomous()) {
            resp.put("execution_token", generateToken(request));
        }

        return ResponseEntity.ok(resp);
    }

    // ── 审批人操作：批准 ─────────────────────────────────────
    /**
     * POST /api/auth/approve/{requestId}
     * 审批人点击"批准"按钮调用
     * 强制记录责任人（第㉓维度）
     */
    @PostMapping("/approve/{requestId}")
    public ResponseEntity<Map<String, Object>> approve(
            @PathVariable String requestId,
            @RequestBody Map<String, String> body) {

        String approverId = body.get("approver_id");
        // TODO:
        // 1. 验证approverId有权审批此请求
        // 2. 检查审批疲劳（第⑪维度）
        // 3. 更新auth_approval_queue status='approved'
        // 4. 记录责任归属（第㉓维度）
        // 5. 触发实际执行（调用对应的业务Service）
        // 6. 7天后安排outcome回访任务

        return ResponseEntity.ok(Map.of(
            "status", "approved",
            "request_id", requestId,
            "message", "已批准·责任人记录：" + approverId
        ));
    }

    // ── 审批人操作：拒绝（必须选择原因）────────────────────
    /**
     * POST /api/auth/reject/{requestId}
     * 第⑱维度：拒绝时必须选择原因类别·支撑学习闭环
     */
    @PostMapping("/reject/{requestId}")
    public ResponseEntity<Map<String, Object>> reject(
            @PathVariable String requestId,
            @RequestBody Map<String, String> body) {

        String reason = body.get("reason"); // data_error/timing/amount/external/other
        String detail = body.get("detail");
        String rejecterId = body.get("rejecter_id");

        // 原因必填验证
        if (reason == null || reason.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error", "拒绝原因必填·请选择：data_error/timing/amount/external/other",
                "hint", "此数据用于改进Agent判断质量"
            ));
        }

        // TODO:
        // 1. 更新auth_approval_queue status='rejected' reject_reason=reason
        // 2. 触发Agent信用分更新逻辑
        // 3. 根据原因类别触发对应的学习流程：
        //    data_error → 触发数据质量检查
        //    timing → 记录最优推单时机学习样本
        //    amount → 触发推单量自动下调
        //    external → 不影响Agent评分

        return ResponseEntity.ok(Map.of(
            "status", "rejected",
            "reason_recorded", reason,
            "learning_triggered", true
        ));
    }

    // ── 7天后结果回访 ─────────────────────────────────────────
    /**
     * POST /api/auth/outcome/{requestId}
     * 7天后自动回访·评估决策质量（第⑱维度）
     */
    @PostMapping("/outcome/{requestId}")
    public ResponseEntity<Map<String, Object>> recordOutcome(
            @PathVariable String requestId,
            @RequestBody Map<String, Object> body) {

        String outcomeStatus = (String) body.get("outcome_status"); // success/partial/failed
        // TODO:
        // 1. 更新outcome_status和outcome_data
        // 2. 计算feedback_score：
        //    success = 100分
        //    partial = 60分
        //    failed  = 20分
        // 3. 触发Agent信用分重新计算

        return ResponseEntity.ok(Map.of(
            "status", "outcome_recorded",
            "feedback_score_updated", true
        ));
    }

    // ── 紧急状态管理 ─────────────────────────────────────────
    /**
     * POST /api/auth/emergency/activate
     * T.San手动宣布紧急状态（第⑲维度）
     */
    @PostMapping("/emergency/activate")
    public ResponseEntity<Map<String, Object>> activateEmergency(
            @RequestBody Map<String, String> body) {

        String reason = body.get("reason");
        String scope  = body.getOrDefault("scope", "global");

        // TODO: INSERT INTO auth_environment_status ...

        return ResponseEntity.ok(Map.of(
            "status", "emergency_activated",
            "scope", scope,
            "message", "所有" + scope + "范围内的自动操作已暂停"
        ));
    }

    /**
     * POST /api/auth/emergency/deactivate
     * 解除紧急状态·必须人工操作（第⑲维度）
     */
    @PostMapping("/emergency/deactivate")
    public ResponseEntity<Map<String, Object>> deactivateEmergency(
            @RequestBody Map<String, String> body) {

        // TODO:
        // 1. 执行系统自检（接口正常·数据一致性正常）
        // 2. 通过后更新auth_environment_status is_active=FALSE
        // 3. 设置24小时观察期（期间所有操作降一级）
        // 4. 记录解除人和时间

        return ResponseEntity.ok(Map.of(
            "status", "emergency_deactivated",
            "observation_period_hours", 24,
            "message", "紧急状态已解除·进入24小时观察期"
        ));
    }

    // ── 规则管理 ─────────────────────────────────────────────
    /**
     * PUT /api/auth/rules/{ruleId}
     * 修改授权规则·自动记录变更日志（第⑯维度）
     */
    @PutMapping("/rules/{ruleId}")
    public ResponseEntity<Map<String, Object>> updateRule(
            @PathVariable Long ruleId,
            @RequestBody Map<String, Object> body) {

        String changeReason = (String) body.get("change_reason");
        String changedBy    = (String) body.get("changed_by");

        // changeReason必填
        if (changeReason == null || changeReason.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of(
                "error", "修改原因必填",
                "hint", "所有规则变更必须说明原因，防止规则被无意中蚕食"
            ));
        }

        // 降低审批要求时需要额外审批
        Object newLevel = body.get("base_auth_level");
        if (newLevel != null) {
            // TODO: 查询当前level·如果新值 < 当前值（降低要求）
            //       必须有approved_by字段 + 设置30天观察期
        }

        // TODO: 更新auth_operation_rules + 记录auth_rule_governance_log

        return ResponseEntity.ok(Map.of(
            "status", "rule_updated",
            "change_logged", true,
            "message", "规则已更新·变更日志已记录"
        ));
    }

    // ── 授权健康仪表盘 ───────────────────────────────────────
    /**
     * GET /api/auth/health
     * 返回授权系统整体健康状态
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> getHealth() {
        // TODO: 查询 v_auth_system_health 视图
        return ResponseEntity.ok(Map.of(
            "system_status",   "operational",
            "pending_approvals", 0,
            "overdue_approvals", 0,
            "active_conflicts",  0,
            "suspended_agents",  0,
            "emergency_active",  false,
            "rule_count",        16,
            "rule_limit",        25
        ));
    }

    private String generateToken(AuthRequest request) {
        return "exec_" + System.currentTimeMillis() + "_" + request.getAgentId();
    }
}
