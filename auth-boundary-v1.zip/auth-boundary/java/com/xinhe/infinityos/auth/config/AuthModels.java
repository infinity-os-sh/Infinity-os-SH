// ============================================================
// AuthRequest.java · AuthDecision.java · AuthResult枚举
// 授权请求与决定数据模型
// ============================================================
package com.xinhe.infinityos.auth.config;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;

// ── AuthRequest：Agent提交的授权申请 ──────────────────────────
public class AuthRequest {

    // 基本信息
    private String       agentId;          // Agent标识
    private String       operationType;    // 操作类型（对应auth_operation_rules）
    private String       entityId;         // 操作对象ID
    private String       entityName;       // 操作对象名称
    private String       reporterId;       // 数据上报人ID（用于⑫对抗检测）

    // 业务数据
    private BigDecimal   amount;           // 涉及金额
    private String       operationDataJson;// 操作完整数据（JSON）
    private Double       confidence;       // Agent置信度 0-100

    // 时间窗口（第⑥维度）
    private Integer      windowHours;      // 操作时间窗口（多少小时内有效）

    // 影响范围（第③维度）
    private Integer      cityCount;        // 涉及城市数
    private Integer      storeCount;       // 涉及门店数

    // 内部标记（引擎设置·不由Agent填写）
    private boolean      mergeable;        // 是否可以合并审批（⑪维度）
    private boolean      noveltyDetected;  // 是否检测到新颖情境（⑮维度）

    // Getters & Setters
    public String  getAgentId()           { return agentId; }
    public void    setAgentId(String v)   { this.agentId = v; }
    public String  getOperationType()     { return operationType; }
    public void    setOperationType(String v) { this.operationType = v; }
    public String  getEntityId()          { return entityId; }
    public void    setEntityId(String v)  { this.entityId = v; }
    public String  getEntityName()        { return entityName; }
    public void    setEntityName(String v){ this.entityName = v; }
    public String  getReporterId()        { return reporterId; }
    public void    setReporterId(String v){ this.reporterId = v; }
    public BigDecimal getAmount()         { return amount; }
    public void    setAmount(BigDecimal v){ this.amount = v; }
    public String  getOperationDataJson() { return operationDataJson; }
    public void    setOperationDataJson(String v) { this.operationDataJson = v; }
    public Double  getConfidence()        { return confidence; }
    public void    setConfidence(Double v){ this.confidence = v; }
    public Integer getWindowHours()       { return windowHours; }
    public void    setWindowHours(Integer v) { this.windowHours = v; }
    public Integer getCityCount()         { return cityCount; }
    public void    setCityCount(Integer v){ this.cityCount = v; }
    public Integer getStoreCount()        { return storeCount; }
    public void    setStoreCount(Integer v){ this.storeCount = v; }
    public boolean isMergeable()          { return mergeable; }
    public void    setMergeable(boolean v){ this.mergeable = v; }
    public boolean isNoveltyDetected()    { return noveltyDetected; }
    public void    setNoveltyDetected(boolean v) { this.noveltyDetected = v; }

    // 工厂方法：快速构建常用请求
    public static AuthRequest forOrder(String agentId, String distributorId,
                                        BigDecimal amount) {
        AuthRequest req = new AuthRequest();
        req.setAgentId(agentId);
        req.setEntityId(distributorId);
        req.setAmount(amount);
        req.setOperationType(amount.compareTo(new BigDecimal("10000")) < 0
                ? "push_order_s"
                : amount.compareTo(new BigDecimal("50000")) < 0
                ? "push_order_m" : "push_order_l");
        return req;
    }

    public static AuthRequest forAlert(String agentId, String entityId) {
        AuthRequest req = new AuthRequest();
        req.setAgentId(agentId);
        req.setEntityId(entityId);
        req.setOperationType("push_wechat_alert");
        req.setAmount(BigDecimal.ZERO);
        return req;
    }
}


// ── AuthDecision：引擎返回的授权决定 ──────────────────────────
class AuthDecision {

    private int              finalLevel;        // 最终授权级别
    private String           plainReason;       // 人话原因（第㉑维度）
    private String           requiredApprover;  // 需要谁审批
    private LocalDateTime    deadline;          // 审批截止时间
    private Map<String,Object> dimensionScores; // 各维度评分明细
    private int              urgencyLevel;      // 紧急程度
    private boolean          mergeable;         // 是否可合并审批
    private DecisionStatus   status;            // 决定状态

    // 决定状态枚举
    public enum DecisionStatus {
        AUTONOMOUS,  // 自主执行
        NEED_APPROVAL, // 需要审批
        HARD_BLOCKED,  // 硬性禁止
        CONFLICT,      // 跨Agent冲突
        SCALE_BLOCKED  // 规模协同熔断
    }

    // 静态工厂方法
    public static AuthDecision hardBlock(String mainReason, String detail) {
        AuthDecision d = new AuthDecision();
        d.finalLevel  = 5;
        d.plainReason = mainReason + "。" + detail;
        d.status      = DecisionStatus.HARD_BLOCKED;
        return d;
    }

    public static AuthDecision conflict(String reason, String detail) {
        AuthDecision d = new AuthDecision();
        d.finalLevel  = 5;
        d.plainReason = reason + "。" + detail;
        d.status      = DecisionStatus.CONFLICT;
        return d;
    }

    public static AuthDecision blocked(String reason, String detail) {
        AuthDecision d = new AuthDecision();
        d.finalLevel  = 5;
        d.plainReason = reason + "。" + detail;
        d.status      = DecisionStatus.SCALE_BLOCKED;
        return d;
    }

    // Getters & Setters
    public int    getFinalLevel()          { return finalLevel; }
    public void   setFinalLevel(int v)     { this.finalLevel = v; }
    public String getPlainReason()         { return plainReason; }
    public void   setPlainReason(String v) { this.plainReason = v; }
    public String getRequiredApprover()    { return requiredApprover; }
    public void   setRequiredApprover(String v) { this.requiredApprover = v; }
    public LocalDateTime getDeadline()     { return deadline; }
    public void   setDeadline(LocalDateTime v) { this.deadline = v; }
    public Map<String,Object> getDimensionScores() { return dimensionScores; }
    public void   setDimensionScores(Map<String,Object> v) { this.dimensionScores = v; }
    public int    getUrgencyLevel()        { return urgencyLevel; }
    public void   setUrgencyLevel(int v)  { this.urgencyLevel = v; }
    public boolean isMergeable()           { return mergeable; }
    public void   setMergeable(boolean v) { this.mergeable = v; }
    public DecisionStatus getStatus()      { return status; }
    public void   setStatus(DecisionStatus v) { this.status = v; }
    public boolean isAutonomous()  { return finalLevel == 0; }
    public boolean isHardBlocked() { return status == DecisionStatus.HARD_BLOCKED; }
}


// ── 各服务返回结果类（桩类·供Java团队实现） ──────────────────

class AgentCreditResult {
    private double creditScore;
    private int    authLevelModifier;
    private boolean suspended;
    private String suspensionReason;
    public double  getCreditScore()       { return creditScore; }
    public int     getAuthLevelModifier() { return authLevelModifier; }
    public boolean isSuspended()          { return suspended; }
    public String  getSuspensionReason()  { return suspensionReason; }
}

class DataQualityResult {
    private double completenessRate;
    private double qualityScore;
    private int    authLevelModifier;
    public double getCompletenessRate() { return completenessRate; }
    public double getQualityScore()     { return qualityScore; }
    public int    getAuthLevelModifier(){ return authLevelModifier; }
}

class FatigueResult {
    private int fatigueLevel;
    public boolean isSevere()  { return fatigueLevel >= 3; }
    public boolean isMedium()  { return fatigueLevel == 2; }
    public int     getLevel()  { return fatigueLevel; }
}

class AdversarialResult {
    private boolean highRisk;
    private String  riskLevel;
    private String  anomalyDescription;
    public boolean isHighRisk()             { return highRisk; }
    public String  getRiskLevel()           { return riskLevel; }
    public String  getAnomalyDescription()  { return anomalyDescription; }
}

class NoveltyResult {
    private boolean novel;
    private double  similarityScore;
    public boolean isNovel()            { return novel; }
    public double  getSimilarityScore() { return similarityScore; }
}

class GoodhartResult {
    private boolean suspicious;
    private String  description;
    public boolean isSuspicious() { return suspicious; }
    public String  getDescription(){ return description; }
}

class ScaleSyncResult {
    private boolean blocked;
    private double  syncRate;
    public boolean isBlocked()   { return blocked; }
    public double  getSyncRate() { return syncRate; }
}
