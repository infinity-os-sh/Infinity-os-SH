// ============================================================
// AuthorizationEngine.java
// 授权边界核心引擎·26维度综合评估
// ============================================================
package com.xinhe.infinityos.auth.engine;

import com.xinhe.infinityos.auth.config.AuthConfig;
import com.xinhe.infinityos.auth.service.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Component
public class AuthorizationEngine {

    private static final Logger log = LoggerFactory.getLogger(AuthorizationEngine.class);

    @Autowired private AgentCreditService       agentCreditService;
    @Autowired private DataQualityService       dataQualityService;
    @Autowired private EnvironmentStatusService environmentService;
    @Autowired private FatigueMonitorService    fatigueService;
    @Autowired private NoveltyDetectionService  noveltyService;
    @Autowired private ScaleSyncMonitorService  scaleService;
    @Autowired private ComplianceService        complianceService;
    @Autowired private AdversarialMonitorService adversarialService;
    @Autowired private GoodhartMonitorService   goodhartService;

    // ── 授权级别常量 ──────────────────────────────────────────
    public static final int AUTH_AUTONOMOUS     = 0; // 自主执行
    public static final int AUTH_FAST_TRACK     = 1; // 快速通道（2小时内确认）
    public static final int AUTH_MANAGER        = 2; // 主管审批（当天）
    public static final int AUTH_DIRECTOR       = 3; // 总监审批（48小时）
    public static final int AUTH_FULL_HUMAN     = 4; // 完全人工
    public static final int AUTH_HARD_BLOCK     = 5; // 硬性禁止

    // ══════════════════════════════════════════════════════════
    // 核心方法：综合评估26维度·返回最终授权决定
    // ══════════════════════════════════════════════════════════

    public AuthDecision evaluate(AuthRequest request) {
        log.info("[授权评估] Agent:{} | 操作:{} | 实体:{} | 金额:{}",
                request.getAgentId(), request.getOperationType(),
                request.getEntityId(), request.getAmount());

        Map<String, Object> dimensionScores = new LinkedHashMap<>();
        int finalLevel = AUTH_AUTONOMOUS;
        List<String> reasons = new ArrayList<>();
        List<String> hardBlocks = new ArrayList<>();

        // ══ 第一组：硬性否决检查（一票否决）══════════════════

        // ⑤ 操作类型硬性禁止（关系操作）
        if (complianceService.isHardBlocked(request.getOperationType())) {
            return AuthDecision.hardBlock(
                "该操作类型属于关系操作·永远需要人工执行",
                "此操作涉及经销商关系/信用/合同等，Agent只能提供分析依据，不能自主执行");
        }

        // ⑭ 合规法律边界检查
        String complianceViolation = complianceService.checkCompliance(request);
        if (complianceViolation != null) {
            return AuthDecision.hardBlock(
                "触碰法律合规红线",
                complianceViolation + "·需要人工处理并留存记录");
        }

        // ⑩ 系统级异常·完全暂停
        if (environmentService.isSystemEmergency()) {
            return AuthDecision.hardBlock(
                "系统异常期·所有自动操作暂停",
                "当前系统检测到异常状态，所有自动执行已暂停，请人工处理");
        }

        // ⑧ 数据严重缺失·暂停执行
        DataQualityResult dqr = dataQualityService.assess(request.getEntityId());
        if (dqr.getCompletenessRate() < 80.0) {
            return AuthDecision.hardBlock(
                "数据完整率" + dqr.getCompletenessRate() + "%·低于80%阈值",
                "当前数据质量不足以支持自动决策，请先确认数据完整性");
        }

        // ══ 第二组：基础授权级别计算（①②③④⑤）══════════════

        // ① 金额维度
        int amountLevel = calculateAmountLevel(request.getAmount());
        dimensionScores.put("①金额", Map.of("level", amountLevel,
                "amount", request.getAmount()));
        finalLevel = Math.max(finalLevel, amountLevel);

        // ② 可逆性
        boolean reversible = isReversible(request.getOperationType());
        if (!reversible) {
            finalLevel = Math.max(finalLevel, AUTH_MANAGER);
            reasons.add("操作不可逆");
        }
        dimensionScores.put("②可逆性", reversible ? "可逆" : "不可逆");

        // ③ 影响范围
        int scopeLevel = calculateScopeLevel(request);
        if (scopeLevel >= 3) finalLevel = Math.max(finalLevel, AUTH_DIRECTOR);
        else if (scopeLevel == 2) finalLevel = Math.max(finalLevel, AUTH_MANAGER);
        dimensionScores.put("③影响范围", Map.of("scope", scopeLevel));

        // ④ Agent置信度
        if (request.getConfidence() != null) {
            if (request.getConfidence() < 70.0) {
                finalLevel = Math.max(finalLevel, AUTH_FAST_TRACK);
                reasons.add("Agent置信度仅" + request.getConfidence() + "%");
            }
        }
        dimensionScores.put("④置信度", request.getConfidence());

        // ⑤ 操作类型基础级别（已在硬性检查中处理硬块·此处处理软约束）
        int opBaseLevel = getOperationBaseLevel(request.getOperationType());
        finalLevel = Math.max(finalLevel, opBaseLevel);
        dimensionScores.put("⑤操作类型基础级别", opBaseLevel);

        // ══ 第三组：动态修正（⑥⑦⑧⑨⑩）══════════════════════

        // ⑥ 时间敏感性（紧急时降低授权要求·快速通道）
        int urgency = calculateUrgency(request);
        if (urgency == 1 && finalLevel > AUTH_FAST_TRACK) {
            finalLevel = Math.max(AUTH_AUTONOMOUS, finalLevel - 1);
            reasons.add("紧急情况·授权级别降一级加速处理");
        } else if (urgency == 3) {
            finalLevel = Math.min(AUTH_HARD_BLOCK, finalLevel + 1);
        }
        dimensionScores.put("⑥时间敏感性", urgency == 1 ? "紧急" : urgency == 2 ? "正常" : "非紧急");

        // ⑦ Agent历史信用
        AgentCreditResult credit = agentCreditService.getCredit(request.getAgentId());
        finalLevel = Math.max(AUTH_AUTONOMOUS,
                Math.min(AUTH_HARD_BLOCK,
                        finalLevel + credit.getAuthLevelModifier()));
        if (credit.isSuspended()) {
            return AuthDecision.hardBlock(
                    "Agent已被暂停自主操作权限",
                    credit.getSuspensionReason());
        }
        dimensionScores.put("⑦Agent信用分", credit.getCreditScore());

        // ⑧ 数据质量修正
        finalLevel = Math.max(AUTH_AUTONOMOUS,
                Math.min(AUTH_HARD_BLOCK,
                        finalLevel + Math.abs(dqr.getAuthLevelModifier())));
        dimensionScores.put("⑧数据质量分", dqr.getQualityScore());

        // ⑨ 连锁影响评估
        int cascadeNodes = getCascadeNodes(request.getOperationType());
        if (cascadeNodes > 5) finalLevel = Math.max(finalLevel, AUTH_MANAGER);
        else if (cascadeNodes >= 3) finalLevel = Math.max(finalLevel, AUTH_FAST_TRACK);
        dimensionScores.put("⑨连锁节点数", cascadeNodes);

        // ⑩ 外部环境状态
        int envModifier = environmentService.getAuthModifier(request.getEntityId());
        finalLevel = Math.max(AUTH_AUTONOMOUS,
                Math.min(AUTH_HARD_BLOCK, finalLevel + envModifier));
        if (envModifier > 0) {
            reasons.add(environmentService.getActiveStatusDescription(request.getEntityId()));
        }
        dimensionScores.put("⑩环境修正", envModifier);

        // ══ 第四组：体系有效性检查（⑪⑫⑬⑮）══════════════════

        // ⑪ 审批疲劳检查
        String targetApprover = resolveApprover(finalLevel);
        if (targetApprover != null) {
            FatigueResult fatigue = fatigueService.checkFatigue(targetApprover);
            if (fatigue.isSevere()) {
                // 审批人已严重疲劳·升级给上一层
                finalLevel = Math.min(AUTH_HARD_BLOCK, finalLevel + 1);
                reasons.add("审批人今日已超审批上限·自动升级");
            } else if (fatigue.isMedium()) {
                // 合并同类审批（不升级·但标记需要合并处理）
                request.setMergeable(true);
            }
        }
        dimensionScores.put("⑪审批疲劳", targetApprover != null ?
                fatigueService.checkFatigue(targetApprover).getLevel() : "N/A");

        // ⑫ 对抗性输入检查
        AdversarialResult adversarial = adversarialService.check(
                request.getEntityId(), request.getReporterId());
        if (adversarial.isHighRisk()) {
            finalLevel = Math.max(finalLevel, AUTH_MANAGER);
            reasons.add("数据可信度预警：" + adversarial.getAnomalyDescription());
        }
        dimensionScores.put("⑫对抗风险", adversarial.getRiskLevel());

        // ⑬ 跨Agent冲突检查（异步·冲突时两个操作都暂停）
        boolean hasConflict = checkAndRegisterConflict(request);
        if (hasConflict) {
            return AuthDecision.conflict(
                    "检测到跨Agent矛盾建议·两个操作均已暂停等待仲裁",
                    "AIO总指挥Agent正在仲裁中，结果将通过企微推送");
        }

        // ⑮ 新颖情境检测
        NoveltyResult novelty = noveltyService.detect(
                request.getAgentId(), request.getEntityId());
        if (novelty.isNovel()) {
            finalLevel = AUTH_FULL_HUMAN;
            reasons.add("新颖情境：相似度仅" + novelty.getSimilarityScore() +
                    "%·Agent经验有限");
        }
        dimensionScores.put("⑮新颖情境相似度", novelty.getSimilarityScore());

        // ══ 第五组：基础假设有效性（㉒㉖）══════════════════════

        // ㉒ 古德哈特定律·数据操纵检测
        GoodhartResult goodhart = goodhartService.check(request);
        if (goodhart.isSuspicious()) {
            finalLevel = Math.max(finalLevel, AUTH_MANAGER);
            reasons.add("指标异常：" + goodhart.getDescription());
        }

        // ㉖ 规模协同效应·防止同时操作
        if (request.getOperationType().startsWith("push_order")) {
            ScaleSyncResult scale = scaleService.checkAndRegister(request);
            if (scale.isBlocked()) {
                return AuthDecision.blocked(
                        "全国同类操作同步率已达" + scale.getSyncRate() + "%·触发协同熔断",
                        "超过20%城市同时执行相同操作，请稍后重试或人工审批");
            }
        }

        // ══ 生成最终决定 ══════════════════════════════════════

        String plainReason = buildPlainReason(request, finalLevel, reasons);
        String approver    = resolveApprover(finalLevel);
        LocalDateTime deadline = calculateDeadline(finalLevel, urgency);

        AuthDecision decision = new AuthDecision();
        decision.setFinalLevel(finalLevel);
        decision.setPlainReason(plainReason);
        decision.setRequiredApprover(approver);
        decision.setDeadline(deadline);
        decision.setDimensionScores(dimensionScores);
        decision.setUrgencyLevel(urgency);
        decision.setMergeable(request.isMergeable());

        log.info("[授权结果] 级别:{} | 审批人:{} | 原因:{}",
                levelName(finalLevel), approver, plainReason);

        return decision;
    }

    // ══════════════════════════════════════════════════════════
    // 维度计算辅助方法
    // ══════════════════════════════════════════════════════════

    private int calculateAmountLevel(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) == 0)
            return AUTH_AUTONOMOUS;
        double amt = amount.doubleValue();
        if (amt < 10000)  return AUTH_FAST_TRACK;
        if (amt < 50000)  return AUTH_MANAGER;
        if (amt < 200000) return AUTH_DIRECTOR;
        return AUTH_FULL_HUMAN;
    }

    private boolean isReversible(String operationType) {
        Set<String> irreversible = Set.of(
                "push_order_xl", "change_distributor",
                "personnel_change", "price_adjustment");
        return !irreversible.contains(operationType);
    }

    private int calculateScopeLevel(AuthRequest request) {
        if (request.getCityCount() == null || request.getCityCount() <= 1) return 1;
        if (request.getCityCount() <= 10) return 2;
        if (request.getCityCount() <= 50) return 3;
        return 4;
    }

    private int getOperationBaseLevel(String operationType) {
        Map<String, Integer> baseLevels = Map.of(
                "read_inventory",    AUTH_AUTONOMOUS,
                "write_memory",      AUTH_AUTONOMOUS,
                "push_wechat_alert", AUTH_AUTONOMOUS,
                "push_order_s",      AUTH_FAST_TRACK,
                "dispatch_ba_single",AUTH_AUTONOMOUS,
                "dispatch_ba_batch", AUTH_MANAGER,
                "push_order_m",      AUTH_MANAGER,
                "push_order_l",      AUTH_DIRECTOR,
                "push_order_xl",     AUTH_FULL_HUMAN
        );
        return baseLevels.getOrDefault(operationType, AUTH_MANAGER);
    }

    private int calculateUrgency(AuthRequest request) {
        if (request.getWindowHours() != null) {
            if (request.getWindowHours() < 4)  return 1; // 紧急
            if (request.getWindowHours() > 48) return 3; // 非紧急
        }
        return 2; // 正常
    }

    private int getCascadeNodes(String operationType) {
        Map<String, Integer> cascadeMap = Map.of(
                "push_order_s", 3, "push_order_m", 4,
                "push_order_l", 5, "push_order_xl", 7,
                "update_credit", 6, "push_wechat_alert", 1,
                "write_memory", 1, "dispatch_ba_single", 2
        );
        return cascadeMap.getOrDefault(operationType, 2);
    }

    private String resolveApprover(int level) {
        return switch (level) {
            case AUTH_FAST_TRACK -> "salesperson";
            case AUTH_MANAGER    -> "city_manager";
            case AUTH_DIRECTOR   -> "director";
            case AUTH_FULL_HUMAN, AUTH_HARD_BLOCK -> "tsan";
            default              -> null;
        };
    }

    private LocalDateTime calculateDeadline(int level, int urgency) {
        int hours = switch (level) {
            case AUTH_FAST_TRACK -> urgency == 1 ? 1 : 2;
            case AUTH_MANAGER    -> urgency == 1 ? 4 : 24;
            case AUTH_DIRECTOR   -> 48;
            default              -> 72;
        };
        return LocalDateTime.now().plusHours(hours);
    }

    private boolean checkAndRegisterConflict(AuthRequest request) {
        // 查询是否有其他Agent在同一实体同一时间窗口给出相反建议
        // 具体实现由ConflictDetectionService处理
        return false; // 简化实现
    }

    private String buildPlainReason(AuthRequest request, int level, List<String> reasons) {
        // 第㉑维度：可解释性·生成人话原因
        if (level == AUTH_AUTONOMOUS) return "所有条件符合·Agent自主执行";

        StringBuilder sb = new StringBuilder();
        if (!reasons.isEmpty()) {
            sb.append("主要原因：").append(reasons.get(0));
            if (reasons.size() > 1) {
                sb.append("；次要原因：").append(reasons.get(1));
            }
        }

        // 告诉用户如何绕过（如果可以的话）
        if (level == AUTH_FAST_TRACK && request.getAmount() != null) {
            BigDecimal threshold = new BigDecimal("10000");
            if (request.getAmount().compareTo(threshold) > 0) {
                sb.append("。如需自主执行·可将金额调整至¥10,000以下");
            }
        }

        return sb.toString();
    }

    private String levelName(int level) {
        return switch (level) {
            case AUTH_AUTONOMOUS  -> "自主";
            case AUTH_FAST_TRACK  -> "快速通道";
            case AUTH_MANAGER     -> "主管审批";
            case AUTH_DIRECTOR    -> "总监审批";
            case AUTH_FULL_HUMAN  -> "完全人工";
            case AUTH_HARD_BLOCK  -> "硬性禁止";
            default               -> "未知";
        };
    }
}
