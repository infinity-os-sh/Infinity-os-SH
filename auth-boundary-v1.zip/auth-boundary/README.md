# INFINITY OS · 授权边界系统 v1.0
## 26维度完整交付包

---

## 文件清单

```
auth-boundary/
├── sql/
│   └── V1__create_auth_boundary_tables.sql   ← 13张表 + 2个视图
│
└── java/com/xinhe/infinityos/auth/
    ├── engine/
    │   └── AuthorizationEngine.java          ← ⭐核心引擎：26维度综合评估
    ├── config/
    │   └── AuthModels.java                   ← 数据模型：Request/Decision
    ├── monitor/
    │   └── AuthBoundaryScheduler.java        ← 9个定时维护任务
    └── service/
        └── AuthBoundaryController.java       ← REST API：评估/审批/规则管理
```

---

## 26个维度分组说明

### 第一组·单次决策风险（①-⑤）
| 维度 | 实现位置 | 核心逻辑 |
|------|---------|---------|
| ① 金额 | `calculateAmountLevel()` | <1万自主·<5万主管·<20万总监·>20万人工 |
| ② 可逆性 | `isReversible()` | 不可逆操作最低主管审批 |
| ③ 影响范围 | `calculateScopeLevel()` | 跨城市→总监·全国→人工 |
| ④ 置信度 | 直接判断 | <70%降一级 |
| ⑤ 操作类型 | `auth_operation_rules`表 | 关系操作硬性禁止 |

### 第二组·环境与执行者（⑥-⑩）
| 维度 | 实现位置 | 核心逻辑 |
|------|---------|---------|
| ⑥ 时间敏感性 | `calculateUrgency()` | 紧急(<4h)→降一级·非紧急→升一级 |
| ⑦ Agent信用 | `auth_agent_credit`表 | 信用>85→升·<40→暂停 |
| ⑧ 数据质量 | `auth_data_quality`表 | 完整率<80%→硬性禁止 |
| ⑨ 连锁影响 | `getCascadeNodes()` | >5节点→主管审批 |
| ⑩ 外部环境 | `auth_environment_status`表 | 战略事件/系统异常→修正级别 |

### 第三组·体系有效性（⑪-⑮）
| 维度 | 实现位置 | 核心逻辑 |
|------|---------|---------|
| ⑪ 审批疲劳 | `auth_fatigue_monitor`表 | 超上限→升级·连续批准→标记合并 |
| ⑫ 对抗防御 | `auth_adversarial_monitor`表 | 数据操纵检测→升级审批 |
| ⑬ 冲突仲裁 | `auth_agent_conflicts`表 | 矛盾建议→两边暂停→总指挥仲裁 |
| ⑭ 法律合规 | `auth_compliance_boundaries`表 | 4条硬性禁区 |
| ⑮ 新颖情境 | `auth_novelty_detection`表 | 相似度<30%→完全人工 |

### 第四组·体系自我维护（⑯-㉑）
| 维度 | 实现位置 | 核心逻辑 |
|------|---------|---------|
| ⑯ 规则治理 | `auth_rule_governance_log`表 | 每次修改留痕·降低要求需双签 |
| ⑰ 能力退化 | `auth_human_capability`表 | 月度手动决策配额·季度断网演习 |
| ⑱ 反馈质量 | 拒绝时强制选原因 | 5类原因→驱动学习闭环 |
| ⑲ 紧急模式 | `emergencyActivate/Deactivate` | 自动进入·人工解除·24小时观察期 |
| ⑳ 外部方授权 | `auth_compliance_boundaries` | 经销商/外包美顾/IT团队隔离规则 |
| ㉑ 可解释性 | `buildPlainReason()` | 每次决定输出人话原因+如何改变 |

### 第五组·基础假设有效性（㉒-㉖）
| 维度 | 实现位置 | 核心逻辑 |
|------|---------|---------|
| ㉒ 古德哈特 | `dailyGoodhartCheck()` | 指标操纵模式检测·每日运行 |
| ㉓ 责任真空 | 审批时强制记录责任人 | 批准=承担责任·留完整链路 |
| ㉔ 规则熵增 | 季度规则审查 | 总量上限25条·超限必须清理 |
| ㉕ 价值观张力 | `auth_compliance_boundaries` | 长期关系/品牌定位保护区 |
| ㉖ 规模协同 | `auth_scale_sync_monitor`表 | 同类操作>20%城市同时→熔断 |

---

## 集成步骤

### Step 1：建表（1小时）
```sql
source V1__create_auth_boundary_tables.sql;
-- 验证：SELECT * FROM v_auth_system_health;
```

### Step 2：复制Java包（30分钟）
将 `auth` 包复制到现有项目，实现各 Service 接口的桩类。

### Step 3：在现有Agent调用前插入授权检查（1天）
```java
// 原来：直接调用
erpService.writeOrder(distributorId, orderLines, notes);

// 现在：先评估授权
AuthRequest req = AuthRequest.forOrder("omakase", distributorId, amount);
AuthDecision decision = authEngine.evaluate(req);

if (decision.isAutonomous()) {
    // 自主执行
    erpService.writeOrder(distributorId, orderLines, notes);
} else if (decision.isHardBlocked()) {
    // 通知用户：无法执行+原因
    wechatService.pushAlert(managerId, "alert", "操作受限", decision.getPlainReason(), null);
} else {
    // 创建审批任务·等待人工确认
    approvalQueueService.create(req, decision);
    wechatService.pushApprovalRequest(decision.getRequiredApprover(), req, decision);
}
```

### Step 4：配置企微审批按钮（0.5天）
在企微消息中添加"批准/拒绝"按钮，点击后调用：
- `POST /api/auth/approve/{requestId}`
- `POST /api/auth/reject/{requestId}`（强制选择原因）

### Step 5：验证（1天）
```bash
# 测试自主执行
curl -X POST /api/auth/evaluate \
  -d '{"agent_id":"butterfly","operation_type":"push_wechat_alert","entity_id":"STORE_001","amount":0}'
# 期望：can_execute=true

# 测试硬性禁止
curl -X POST /api/auth/evaluate \
  -d '{"agent_id":"omakase","operation_type":"update_credit","entity_id":"DIST_001"}'
# 期望：hard_blocked=true

# 测试审批流程
curl -X POST /api/auth/evaluate \
  -d '{"agent_id":"omakase","operation_type":"push_order_m","entity_id":"DIST_001","amount":30000}'
# 期望：final_level=2（主管审批）·plain_reason包含具体原因
```

---

## 各服务接口（需Java团队实现）

以下Service类需要Java团队根据业务逻辑实现：

```
AgentCreditService       → 查询auth_agent_credit表
DataQualityService       → 查询auth_data_quality表
EnvironmentStatusService → 查询auth_environment_status表
FatigueMonitorService    → 查询auth_fatigue_monitor表
NoveltyDetectionService  → 查询agent_memory_profiles（来自记忆层）
ScaleSyncMonitorService  → 查询auth_scale_sync_monitor表
ComplianceService        → 查询auth_compliance_boundaries表
AdversarialMonitorService→ 查询auth_adversarial_monitor表
GoodhartMonitorService   → 分析agent_memory_events中的上报模式
```

---

## 与其他模块的依赖关系

```
授权边界系统
    ↓ 依赖
记忆层（memory-layer-v1.zip）
    agent_memory_profiles  → 新颖情境检测
    agent_memory_events    → 古德哈特指标监测
    agent_memory_decisions → Agent信用分计算

    ↓ 输入给
调用层（tool-layer-v1.zip）
    AgentOrchestrationService中的每次工具调用
    必须先通过AuthorizationEngine.evaluate()
    才能进入Agentic Loop
```

---

## MVP最小实现（如果资源有限）

如果需要快速上线，优先实现以下7个最关键的维度：

1. **⑤ 操作类型硬性禁止** → 关系操作永远禁止
2. **① 金额分级** → 最基础的风险控制
3. **⑭ 法律合规** → 不能触碰的红线
4. **⑬ 冲突仲裁** → 防止矛盾操作同时执行
5. **⑲ 紧急模式** → 出问题时的紧急开关
6. **㉑ 可解释性** → 让用户理解为什么
7. **⑪ 审批疲劳** → 防止人工审批名存实亡

**这7个维度·Java团队3天工作量·覆盖最高风险场景。**
其余19个维度可在运营中逐步补充。
