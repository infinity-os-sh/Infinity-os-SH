-- ============================================================
-- INFINITY OS · 授权边界系统 · 完整数据库建表脚本
-- 覆盖26个维度·5个维度组
-- Version: 1.0
-- ============================================================

-- ── 表1：操作授权规则表 ──────────────────────────────────────
-- 定义每类操作的基础授权级别（第①-⑤维度）
CREATE TABLE IF NOT EXISTS auth_operation_rules (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    operation_type  VARCHAR(50)  NOT NULL COMMENT '操作类型标识',
    operation_name  VARCHAR(100) NOT NULL COMMENT '操作名称（中文）',
    operation_group VARCHAR(30)  NOT NULL COMMENT '操作分组: read/write/execute/relation',
    amount_min      DECIMAL(12,2) DEFAULT 0    COMMENT '金额下限（含）',
    amount_max      DECIMAL(12,2) DEFAULT NULL COMMENT '金额上限（不含）·NULL=无上限',
    reversible      BOOLEAN      NOT NULL DEFAULT TRUE  COMMENT '是否可逆',
    scope_level     TINYINT      NOT NULL DEFAULT 1     COMMENT '影响范围 1=单店 2=单城市 3=跨城市 4=全国',
    base_auth_level TINYINT      NOT NULL COMMENT '基础授权级别 0=自主 1=快速通道 2=主管审批 3=总监审批 4=完全人工',
    hard_block      BOOLEAN      NOT NULL DEFAULT FALSE COMMENT '是否硬性禁止Agent执行',
    compliance_note VARCHAR(500) COMMENT '合规说明（第⑭维度）',
    cascade_nodes   INT          DEFAULT 0 COMMENT '预估连锁影响节点数（第⑨维度）',
    rule_owner      VARCHAR(50)  NOT NULL COMMENT '规则负责人',
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      DATETIME     COMMENT '规则失效日期（NULL=永久有效）',
    created_reason  VARCHAR(500) NOT NULL COMMENT '创建原因（防止规则熵增·第㉔维度）',
    INDEX idx_operation (operation_type),
    INDEX idx_group     (operation_group),
    INDEX idx_expires   (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作授权规则表';

-- 初始化核心操作规则
INSERT INTO auth_operation_rules
(operation_type, operation_name, operation_group, amount_min, amount_max,
 reversible, scope_level, base_auth_level, hard_block, cascade_nodes, rule_owner, created_reason) VALUES

-- 读操作·永远自主
('read_inventory',    '查询库存数据',   'read',    0, NULL, TRUE,  1, 0, FALSE, 0, 'SYSTEM', '读操作无写入风险·永远自主'),
('read_crm',          '查询CRM档案',    'read',    0, NULL, TRUE,  1, 0, FALSE, 0, 'SYSTEM', '读操作无写入风险·永远自主'),
('read_erp',          '查询ERP数据',    'read',    0, NULL, TRUE,  1, 0, FALSE, 0, 'SYSTEM', '读操作无写入风险·永远自主'),
('generate_report',   '生成分析报告',   'read',    0, NULL, TRUE,  1, 0, FALSE, 0, 'SYSTEM', '输出内容不触发任何系统操作'),

-- 写操作·记忆层·自主
('write_memory',      '写入记忆层',     'write',   0, NULL, TRUE,  1, 0, FALSE, 1, 'SYSTEM', '记忆层写入可随时修正·风险低'),
('push_wechat_alert', '发送企微预警',   'write',   0, NULL, TRUE,  2, 0, FALSE, 1, 'SYSTEM', '通知类操作·人可忽略·自主发送'),

-- 执行操作·推单·分级
('push_order_s',      '推单·小额',      'execute', 0,    10000, TRUE,  1, 1, FALSE, 3, 'T.SAN', '小额推单快速通道·业务员2小时确认'),
('push_order_m',      '推单·中额',      'execute', 10000, 50000, TRUE, 2, 2, FALSE, 4, 'T.SAN', '中额需主管审批·影响范围扩大'),
('push_order_l',      '推单·大额',      'execute', 50000,200000, TRUE, 3, 3, FALSE, 5, 'T.SAN', '大额需总监审批'),
('push_order_xl',     '推单·超大额',    'execute', 200000,NULL, FALSE, 4, 4, FALSE, 7, 'T.SAN', '超大额完全人工·不可逆风险'),

-- 执行操作·美顾任务
('dispatch_ba_single','派发美顾任务·单店','execute',0, NULL, TRUE,  1, 0, FALSE, 2, 'T.SAN', '单店任务自主派发·低风险'),
('dispatch_ba_batch', '派发美顾任务·批量','execute',0, NULL, TRUE,  2, 2, FALSE, 4, 'T.SAN', '批量派发影响范围大·需经理确认'),

-- 关系操作·完全人工
('update_credit',     '修改经销商信用评级','relation',0,NULL,FALSE,2, 4, TRUE, 6, 'T.SAN', '信用评级影响长期关系·永远人工'),
('change_distributor','经销商关系变更',  'relation',0, NULL, FALSE, 3, 4, TRUE, 8, 'T.SAN', '合同级别操作·永远人工'),
('price_adjustment',  '价格体系调整',   'relation',0, NULL, FALSE, 4, 4, TRUE, 9, 'T.SAN', '涉及价格法合规·永远人工'),
('personnel_change',  '人员晋降级',     'relation',0, NULL, FALSE, 2, 4, TRUE, 5, 'T.SAN', '劳动法相关·永远人工');


-- ── 表2：Agent信用档案表 ──────────────────────────────────────
-- 记录每个Agent的历史准确率（第⑦维度）
CREATE TABLE IF NOT EXISTS auth_agent_credit (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id            VARCHAR(50)   NOT NULL COMMENT 'Agent标识',
    agent_name          VARCHAR(100)  NOT NULL COMMENT 'Agent名称',
    credit_score        DECIMAL(5,2)  NOT NULL DEFAULT 80.0 COMMENT '信用分 0-100',
    total_decisions     INT           NOT NULL DEFAULT 0 COMMENT '累计决策次数',
    approved_count      INT           NOT NULL DEFAULT 0 COMMENT '被批准次数',
    rejected_count      INT           NOT NULL DEFAULT 0 COMMENT '被拒绝次数',
    overturned_count    INT           NOT NULL DEFAULT 0 COMMENT '被推翻次数（批准后证明错误）',
    rejection_reasons   JSON          COMMENT '拒绝原因统计 {data_error:N, timing:N, amount:N, external:N, other:N}',
    auth_level_modifier TINYINT       NOT NULL DEFAULT 0 COMMENT '授权级别修正值 -1=降一级 0=不变 +1=升一级',
    is_suspended        BOOLEAN       NOT NULL DEFAULT FALSE COMMENT '是否暂停自主操作',
    suspension_reason   VARCHAR(300)  COMMENT '暂停原因',
    online_since        DATETIME      NOT NULL COMMENT '上线时间',
    last_evaluated      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_agent (agent_id),
    INDEX idx_credit (credit_score),
    INDEX idx_suspended (is_suspended)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent信用档案表';

-- 初始化Agent信用档案
INSERT INTO auth_agent_credit
(agent_id, agent_name, credit_score, online_since) VALUES
('butterfly',     '蝴蝶效应Agent',  80.0, NOW()),
('omakase',       '无菜单推单Agent', 80.0, NOW()),
('calibration',   'A值校准Agent',   80.0, NOW()),
('uber_incentive','Uber激励Agent',   80.0, NOW()),
('commander',     'AIO总指挥Agent',  80.0, NOW()),
('shelf_scan',    '货架识别Agent',   80.0, NOW()),
('prism',         'PRISM选点Agent',  80.0, NOW());


-- ── 表3：数据质量追踪表 ──────────────────────────────────────
-- 记录每个实体的数据质量状态（第⑧维度）
CREATE TABLE IF NOT EXISTS auth_data_quality (
    id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
    entity_type         VARCHAR(20)  NOT NULL COMMENT 'store/distributor',
    entity_id           VARCHAR(100) NOT NULL COMMENT '实体ID',
    reporter_id         VARCHAR(100) NOT NULL COMMENT '数据上报人ID',
    last_report_time    DATETIME     NOT NULL COMMENT '最后上报时间',
    data_freshness_hrs  INT          NOT NULL COMMENT '数据新鲜度（小时）',
    completeness_rate   DECIMAL(5,2) NOT NULL COMMENT '完整率 0-100%',
    reporter_credit     VARCHAR(5)   NOT NULL DEFAULT 'B' COMMENT '上报人信用 A/B/C/D',
    error_count_30d     INT          NOT NULL DEFAULT 0 COMMENT '近30天上报错误次数',
    anomaly_count_30d   INT          NOT NULL DEFAULT 0 COMMENT '近30天异常标记次数',
    quality_score       DECIMAL(5,2) GENERATED ALWAYS AS (
        CASE
            WHEN data_freshness_hrs <= 24 AND completeness_rate >= 95 AND reporter_credit = 'A' THEN 100
            WHEN data_freshness_hrs <= 24 AND completeness_rate >= 80 THEN 80
            WHEN data_freshness_hrs <= 72 AND completeness_rate >= 80 THEN 60
            WHEN data_freshness_hrs <= 72 THEN 40
            ELSE 20
        END
    ) STORED COMMENT '综合质量分（自动计算）',
    auth_level_modifier TINYINT GENERATED ALWAYS AS (
        CASE
            WHEN quality_score >= 80 THEN 0
            WHEN quality_score >= 60 THEN -1
            ELSE -2
        END
    ) STORED COMMENT '授权级别修正（自动计算）',
    last_updated        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_entity (entity_type, entity_id),
    INDEX idx_quality   (quality_score),
    INDEX idx_freshness (data_freshness_hrs)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据质量追踪表';


-- ── 表4：审批任务队列表 ──────────────────────────────────────
-- 管理所有待审批操作（含审批疲劳防护·第⑪维度）
CREATE TABLE IF NOT EXISTS auth_approval_queue (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id      VARCHAR(100) NOT NULL UNIQUE COMMENT '请求唯一ID',
    agent_id        VARCHAR(50)  NOT NULL COMMENT '发起Agent',
    operation_type  VARCHAR(50)  NOT NULL COMMENT '操作类型',
    entity_id       VARCHAR(100) NOT NULL COMMENT '操作对象实体ID',
    entity_name     VARCHAR(200) COMMENT '实体名称',

    -- 操作详情
    operation_data  JSON         NOT NULL COMMENT '操作完整数据',
    amount          DECIMAL(12,2) DEFAULT 0 COMMENT '涉及金额',

    -- 授权计算结果（26维度综合）
    final_auth_level TINYINT     NOT NULL COMMENT '最终授权级别',
    auth_reasons    JSON         NOT NULL COMMENT '各维度评分明细',
    plain_reason    VARCHAR(500) NOT NULL COMMENT '人话解释（第㉑维度）',
    confidence      DECIMAL(5,2) COMMENT 'Agent置信度',

    -- 审批人分配
    required_approver_role VARCHAR(30) COMMENT '需要审批的角色',
    assigned_approver_id   VARCHAR(100) COMMENT '分配给的审批人',
    approver_daily_count   INT DEFAULT 0 COMMENT '该审批人今日已审批数量',

    -- 时间管理（第⑥维度）
    urgency_level   TINYINT      NOT NULL DEFAULT 2 COMMENT '紧急程度 1=紧急<4h 2=正常 3=非紧急',
    deadline        DATETIME     NOT NULL COMMENT '审批截止时间',
    escalate_to     VARCHAR(100) COMMENT '超时升级给谁',
    escalated       BOOLEAN      NOT NULL DEFAULT FALSE,

    -- 状态流转
    status          VARCHAR(20)  NOT NULL DEFAULT 'pending'
                    COMMENT 'pending/approved/rejected/expired/cancelled/conflict',
    approved_at     DATETIME,
    rejected_at     DATETIME,
    reject_reason   VARCHAR(20)  COMMENT '拒绝原因分类: data_error/timing/amount/external/other',
    reject_detail   VARCHAR(500) COMMENT '拒绝详情',

    -- 责任链（第㉓维度）
    responsibility_owner VARCHAR(100) COMMENT '本次决策责任人',
    responsibility_note  VARCHAR(300) COMMENT '责任说明',

    -- 反馈追踪（第⑱维度）
    outcome_status  VARCHAR(20)  COMMENT 'pending_outcome/success/partial/failed',
    outcome_data    JSON         COMMENT '7天后回访结果',
    feedback_score  DECIMAL(5,2) COMMENT '决策质量评分',

    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_status        (status),
    INDEX idx_approver      (assigned_approver_id, status),
    INDEX idx_deadline      (deadline),
    INDEX idx_entity        (entity_id),
    INDEX idx_agent         (agent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='审批任务队列表';


-- ── 表5：跨Agent冲突记录表 ──────────────────────────────────
-- 处理多Agent同时给出矛盾建议（第⑬维度）
CREATE TABLE IF NOT EXISTS auth_agent_conflicts (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    conflict_id     VARCHAR(100) NOT NULL UNIQUE COMMENT '冲突唯一ID',
    entity_id       VARCHAR(100) NOT NULL COMMENT '冲突涉及的实体',
    entity_name     VARCHAR(200),

    -- 冲突双方
    agent_a_id      VARCHAR(50)  NOT NULL COMMENT 'Agent A',
    agent_a_action  VARCHAR(50)  NOT NULL COMMENT 'Agent A的建议操作',
    agent_a_reason  TEXT         COMMENT 'Agent A的推理链路',
    agent_b_id      VARCHAR(50)  NOT NULL COMMENT 'Agent B',
    agent_b_action  VARCHAR(50)  NOT NULL COMMENT 'Agent B的建议操作',
    agent_b_reason  TEXT         COMMENT 'Agent B的推理链路',

    conflict_type   VARCHAR(30)  NOT NULL COMMENT 'opposite_direction/timing/amount',
    arbiter_id      VARCHAR(50)  COMMENT '仲裁Agent（通常是commander）',
    arbiter_decision VARCHAR(50) COMMENT '仲裁决定',
    arbiter_reason  TEXT         COMMENT '仲裁理由',
    escalated_to_human BOOLEAN   NOT NULL DEFAULT FALSE,
    human_decision  VARCHAR(200) COMMENT '人工最终决定',
    status          VARCHAR(20)  NOT NULL DEFAULT 'detected'
                    COMMENT 'detected/arbitrating/escalated/resolved',
    resolved_at     DATETIME,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_entity  (entity_id),
    INDEX idx_status  (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='跨Agent冲突记录表';


-- ── 表6：外部环境状态表 ──────────────────────────────────────
-- 实时记录影响授权级别的外部状态（第⑩维度）
CREATE TABLE IF NOT EXISTS auth_environment_status (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    status_type     VARCHAR(30)  NOT NULL COMMENT '状态类型',
    scope           VARCHAR(30)  NOT NULL DEFAULT 'global' COMMENT 'global/city/entity',
    scope_id        VARCHAR(100) COMMENT '城市ID或实体ID（scope非global时）',
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,
    auth_modifier   TINYINT      NOT NULL COMMENT '授权级别修正 -2/-1/0/+1（正值=更严格）',
    description     VARCHAR(300) NOT NULL COMMENT '状态描述',
    auto_resolve    BOOLEAN      NOT NULL DEFAULT FALSE COMMENT '是否自动解除',
    resolve_at      DATETIME     COMMENT '自动解除时间',
    triggered_by    VARCHAR(100) NOT NULL COMMENT '触发来源',
    activated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at     DATETIME,

    INDEX idx_active (is_active),
    INDEX idx_type   (status_type),
    INDEX idx_scope  (scope, scope_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='外部环境状态表';

-- 状态类型参考值：
-- system_error       系统异常·API报错连续>30分钟
-- strategy_event     战略事件活跃·D. 战略扰动中
-- seasonal_stock     季节性备货期（春节/618/双11）
-- emergency          T.San手动宣布紧急状态
-- new_city           新城市上线前30天保护期
-- data_quality_low   数据完整率<80%
-- competitor_promo   竞品大促应对期


-- ── 表7：审批疲劳监控表 ──────────────────────────────────────
-- 防止审批疲劳稀释人工监督（第⑪维度）
CREATE TABLE IF NOT EXISTS auth_fatigue_monitor (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    approver_id     VARCHAR(100) NOT NULL COMMENT '审批人ID',
    approver_role   VARCHAR(30)  NOT NULL COMMENT '角色: salesperson/manager/director/tsan',
    date            DATE         NOT NULL COMMENT '统计日期',
    approved_count  INT          NOT NULL DEFAULT 0 COMMENT '已审批数量',
    daily_limit     INT          NOT NULL COMMENT '每日上限',
    consecutive_approve_count INT DEFAULT 0 COMMENT '连续未拒绝的批准次数',
    avg_review_time_sec INT      COMMENT '平均审核时长（秒）',
    fatigue_level   TINYINT GENERATED ALWAYS AS (
        CASE
            WHEN approved_count >= daily_limit THEN 3  -- 严重疲劳
            WHEN approved_count >= daily_limit * 0.8 THEN 2  -- 中度疲劳
            WHEN consecutive_approve_count >= 8 THEN 2  -- 连续批准异常
            WHEN avg_review_time_sec < 5 THEN 2  -- 审核太快·可能没有认真看
            ELSE 1  -- 正常
        END
    ) STORED COMMENT '疲劳级别 1=正常 2=中度 3=严重',
    UNIQUE KEY uk_approver_date (approver_id, date),
    INDEX idx_fatigue (fatigue_level, date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='审批疲劳监控表';

-- 每日审批上限配置
-- salesperson:  5条/天
-- manager:     10条/天
-- director:     3条/天
-- tsan:         5条/天（战略级）


-- ── 表8：对抗性输入监控表 ──────────────────────────────────
-- 检测故意操纵数据的行为（第⑫维度）
CREATE TABLE IF NOT EXISTS auth_adversarial_monitor (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    entity_id       VARCHAR(100) NOT NULL COMMENT '被监控实体',
    entity_type     VARCHAR(20)  NOT NULL,
    reporter_id     VARCHAR(100) NOT NULL COMMENT '上报人ID',
    anomaly_type    VARCHAR(50)  NOT NULL COMMENT '异常类型',
    anomaly_detail  JSON         NOT NULL COMMENT '异常详情',
    severity        TINYINT      NOT NULL COMMENT '严重程度 1-5',
    auto_action     VARCHAR(50)  COMMENT '系统自动处置',
    human_review    BOOLEAN      NOT NULL DEFAULT FALSE COMMENT '是否需要人工复查',
    reviewed        BOOLEAN      NOT NULL DEFAULT FALSE,
    review_result   VARCHAR(20)  COMMENT 'confirmed/false_alarm',
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_reporter (reporter_id),
    INDEX idx_entity   (entity_id),
    INDEX idx_severity (severity),
    INDEX idx_review   (human_review, reviewed)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='对抗性输入监控表';

-- 异常类型参考：
-- inventory_increase_without_restock  库存增加但无补货记录
-- always_perfect_data                 数据永远整齐完美·疑似伪造
-- ai_shelf_mismatch                   上报数据与货架识别差异>20%
-- consecutive_threshold_gaming        连续多次数据恰好在达标线上方
-- cross_reporter_inconsistency        同一门店不同上报人数据严重矛盾


-- ── 表9：规则治理日志表 ──────────────────────────────────────
-- 记录规则变更历史·防止规则被蚕食（第⑯维度）
CREATE TABLE IF NOT EXISTS auth_rule_governance_log (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    rule_table      VARCHAR(50)  NOT NULL COMMENT '被修改的规则表',
    rule_id         BIGINT       NOT NULL COMMENT '被修改的规则ID',
    change_type     VARCHAR(20)  NOT NULL COMMENT 'create/modify/delete/freeze',
    field_changed   VARCHAR(100) COMMENT '修改了哪个字段',
    old_value       TEXT         COMMENT '修改前的值',
    new_value       TEXT         COMMENT '修改后的值',
    change_reason   VARCHAR(500) NOT NULL COMMENT '修改原因（必填）',
    changed_by      VARCHAR(100) NOT NULL COMMENT '修改人',
    approved_by     VARCHAR(100) COMMENT '审批人（降低审批要求时必须有）',
    change_risk     VARCHAR(10)  NOT NULL DEFAULT 'low' COMMENT '变更风险 low/medium/high',
    frozen_until    DATETIME     COMMENT '观察期结束时间（降低要求时设置30天观察期）',
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_table   (rule_table),
    INDEX idx_changed (changed_by, created_at),
    INDEX idx_risk    (change_risk)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='规则治理日志表（防止规则熵增）';


-- ── 表10：人工能力追踪表 ──────────────────────────────────────
-- 防止人的判断能力退化（第⑰维度）
CREATE TABLE IF NOT EXISTS auth_human_capability (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    person_id       VARCHAR(100) NOT NULL COMMENT '人员ID',
    person_role     VARCHAR(30)  NOT NULL,
    month           DATE         NOT NULL COMMENT '统计月份（取每月1日）',

    -- 手动决策追踪
    manual_decisions_required INT NOT NULL DEFAULT 3 COMMENT '本月要求手动决策次数',
    manual_decisions_done     INT NOT NULL DEFAULT 0 COMMENT '实际完成手动决策次数',
    manual_decision_accuracy  DECIMAL(5,2) COMMENT '手动决策准确率（对比最终结果）',

    -- 断网演习结果
    drill_participated  BOOLEAN  DEFAULT NULL COMMENT '是否参加了本季度断网演习',
    drill_score         DECIMAL(5,2) COMMENT '断网演习评分',

    -- 能力趋势
    capability_trend    VARCHAR(10) COMMENT 'improving/stable/declining',
    alert_sent          BOOLEAN  NOT NULL DEFAULT FALSE COMMENT '是否已发出退化预警',

    UNIQUE KEY uk_person_month (person_id, month),
    INDEX idx_trend (capability_trend)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='人工能力追踪表（防止技能退化）';


-- ── 表11：合规边界清单表 ──────────────────────────────────────
-- 法律合规的硬性禁区（第⑭维度）
CREATE TABLE IF NOT EXISTS auth_compliance_boundaries (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    boundary_code   VARCHAR(50)  NOT NULL UNIQUE,
    law_reference   VARCHAR(100) NOT NULL COMMENT '相关法律法规',
    description     VARCHAR(300) NOT NULL COMMENT '禁区描述',
    forbidden_operations JSON    NOT NULL COMMENT '禁止的操作类型列表',
    required_human_record BOOLEAN NOT NULL DEFAULT TRUE COMMENT '是否需要人工处理留痕',
    legal_risk_level VARCHAR(10) NOT NULL COMMENT 'high/critical',
    last_reviewed   DATE         NOT NULL COMMENT '最后法务审查日期',
    next_review     DATE         NOT NULL COMMENT '下次审查日期',
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='合规边界清单表';

INSERT INTO auth_compliance_boundaries
(boundary_code, law_reference, description, forbidden_operations,
 legal_risk_level, last_reviewed, next_review) VALUES
('ANTI_MONOPOLY_PRICE',
 '《反垄断法》·《反不正当竞争法》',
 'Agent不能以算法方式强制执行区域统一定价·底价保护只能建议不能执行',
 '["auto_enforce_floor_price","region_price_lockdown","competitor_price_response_auto"]',
 'critical', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 6 MONTH)),

('FOOD_SAFETY_HANDLING',
 '《食品安全法》',
 '近效期/食品安全相关操作必须有人工确认记录·Agent不能自动处置',
 '["auto_dispose_near_expiry","auto_recall_initiation","safety_alert_suppress"]',
 'critical', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 6 MONTH)),

('LABOR_LAW_SALARY',
 '《劳动合同法》·《工资支付暂行规定》',
 '激励系统计算结果不能直接触发发薪·必须经HR人工审核',
 '["auto_salary_payment","auto_incentive_settlement","auto_deduct_penalty"]',
 'high', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 6 MONTH)),

('PERSONAL_DATA_PROTECTION',
 '《个人信息保护法》',
 '美顾CB分·位置数据·行为数据不能跨目的使用·每次调用必须记录业务目的',
 '["cross_purpose_ba_data","export_personal_data","share_ba_data_external"]',
 'high', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 6 MONTH));


-- ── 表12：新颖情境检测表 ──────────────────────────────────────
-- 识别Agent经验范围之外的新情境（第⑮维度）
CREATE TABLE IF NOT EXISTS auth_novelty_detection (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    agent_id        VARCHAR(50)  NOT NULL,
    entity_id       VARCHAR(100) NOT NULL,
    detected_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    similarity_score DECIMAL(5,2) NOT NULL COMMENT '与历史记忆的相似度 0-100',
    novelty_signals JSON         NOT NULL COMMENT '触发新颖性检测的信号列表',
    history_count   INT          NOT NULL COMMENT '该实体在记忆层的历史记录数',
    agent_confidence_variance DECIMAL(5,2) COMMENT '不同分析框架下置信度方差',
    auto_action     VARCHAR(50)  NOT NULL COMMENT '系统自动降级操作',
    protection_until DATETIME    COMMENT '保护期截止时间',
    is_active       BOOLEAN      NOT NULL DEFAULT TRUE,

    INDEX idx_agent  (agent_id),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='新颖情境检测表';


-- ── 表13：规模协同监控表 ──────────────────────────────────────
-- 防止全国Agent同时做出相同决策（第㉖维度）
CREATE TABLE IF NOT EXISTS auth_scale_sync_monitor (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    time_window     DATETIME     NOT NULL COMMENT '时间窗口（每15分钟一个窗口）',
    operation_type  VARCHAR(50)  NOT NULL,
    city_count      INT          NOT NULL COMMENT '同类操作涉及的城市数',
    total_cities    INT          NOT NULL DEFAULT 337 COMMENT '总城市数',
    sync_rate       DECIMAL(5,2) GENERATED ALWAYS AS (city_count / total_cities * 100) STORED
                    COMMENT '同步率%',
    is_blocked      BOOLEAN      NOT NULL DEFAULT FALSE COMMENT '是否已触发熔断',
    block_reason    VARCHAR(300),
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_window (time_window, operation_type),
    INDEX idx_blocked (is_blocked)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='规模协同监控表（防止算法协同效应）';

-- ── 责任追踪视图 ──────────────────────────────────────────────
CREATE OR REPLACE VIEW v_auth_responsibility_chain AS
SELECT
    q.request_id,
    q.operation_type,
    q.entity_name,
    q.amount,
    q.status,
    q.responsibility_owner,
    q.plain_reason,
    q.reject_reason,
    q.feedback_score,
    q.outcome_status,
    a.agent_name,
    a.credit_score AS agent_credit,
    q.created_at,
    q.approved_at
FROM auth_approval_queue q
LEFT JOIN auth_agent_credit a ON q.agent_id = a.agent_id;

-- ── 授权健康仪表盘视图 ──────────────────────────────────────
CREATE OR REPLACE VIEW v_auth_system_health AS
SELECT
    '待审批积压' AS metric,
    COUNT(*) AS value,
    CASE WHEN COUNT(*) > 20 THEN '⚠️ 积压' ELSE '✅ 正常' END AS status
FROM auth_approval_queue WHERE status = 'pending'
UNION ALL
SELECT '逾期未审批', COUNT(*),
    CASE WHEN COUNT(*) > 5 THEN '🔴 严重' ELSE '✅ 正常' END
FROM auth_approval_queue WHERE status = 'pending' AND deadline < NOW()
UNION ALL
SELECT '活跃冲突', COUNT(*),
    CASE WHEN COUNT(*) > 0 THEN '⚠️ 有冲突' ELSE '✅ 无冲突' END
FROM auth_agent_conflicts WHERE status != 'resolved'
UNION ALL
SELECT '系统级异常', COUNT(*),
    CASE WHEN COUNT(*) > 0 THEN '🔴 异常' ELSE '✅ 正常' END
FROM auth_environment_status WHERE status_type = 'system_error' AND is_active = TRUE
UNION ALL
SELECT '暂停Agent数', COUNT(*),
    CASE WHEN COUNT(*) > 2 THEN '⚠️ 多Agent暂停' ELSE '✅ 正常' END
FROM auth_agent_credit WHERE is_suspended = TRUE;

SELECT '✅ INFINITY OS 授权边界系统数据库建表完成 · 13张表 · 2个视图' AS status;
