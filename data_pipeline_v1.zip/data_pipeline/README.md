# INFINITY OS · 数据接入包 V1.0

**给:郭工 + Tech Lead**

把欣和现有的1422张表 → 接入INFINITY OS的6张核心表

---

## 📦 包内容

```
data_pipeline/
├── README.md                       ← 本文档
├── docs/
│   └── 数据接入对接文档.md          ← 6部分详细文档(必读)
└── scripts/
    ├── hanxun_etl.py               ← 汉询日销ETL
    ├── dcloud_etl.py               ← Dcloud库存ETL
    ├── data_quality_check.py       ← 6项数据质量验证
    └── init_test_data.py           ← 模拟数据生成(测试用)
```

---

## 🚀 3步落地

### Step 1 · 阅读对接文档(30分钟)
```
打开 docs/数据接入对接文档.md
重点看:
  · Part 1 · 汉询字段映射(rixiao → r_actual)
  · Part 2 · Dcloud字段映射(stock_qty → inventory)
  · Part 5 · 郭工/IT的6件事
```

### Step 2 · 测试环境验证(1天)
```bash
# 用模拟数据先跑通整个流程
python scripts/init_test_data.py --days 30 --nodes 100

# 验证数据质量
python scripts/data_quality_check.py

# 测试Agent能跑通
curl -X POST http://localhost:8080/api/agent/calibrate
```

### Step 3 · 真实数据接入(2-3天)
```bash
# 1. 配置.env(填真实DB连接)
HANXUN_URL=mysql+pymysql://infinity_readonly:xxx@hanxun-host:3306/hanxun
DCLOUD_URL=mysql+pymysql://infinity_readonly:xxx@dcloud-host:3306/dcloud

# 2. 试跑(dry-run · 不入库)
python scripts/hanxun_etl.py --date 2026-04-21 --dry-run
python scripts/dcloud_etl.py --date 2026-04-21 --dry-run

# 3. 正式跑(写入)
python scripts/hanxun_etl.py --date 2026-04-21
python scripts/dcloud_etl.py --date 2026-04-21

# 4. 数据质量验证
python scripts/data_quality_check.py --date 2026-04-21

# 5. 配置Linux cron
echo "0 4 * * * cd /opt/infinity_os && python scripts/hanxun_etl.py" >> /etc/crontab
echo "30 4 * * * cd /opt/infinity_os && python scripts/dcloud_etl.py" >> /etc/crontab
echo "0 5 * * * cd /opt/infinity_os && python scripts/data_quality_check.py --strict" >> /etc/crontab
```

---

## 🎯 完整时间线

```
凌晨04:00 → 汉询ETL  (读rixiao · 写r_actual)
凌晨04:30 → Dcloud ETL (读库存 · 更新inventory + water_level)
凌晨05:00 → 数据质量验证
凌晨06:00 → A值校准Agent ★(本包不含·见Python版主项目)
凌晨07:00 → 蝴蝶效应Agent
凌晨08:00 → Omakase推单Agent
```

**任何上游延迟 · 下游自动等(misfire_grace_time=1小时)**

---

## ⚠️ 关键风险

| 风险 | 影响 | 缓解 |
|------|------|------|
| 汉询表名/字段名不一致 | ETL报错 | 文档第1.1节字段映射表·与郭工逐字确认 |
| Dcloud库存数据延迟 | 水位不准 | 自动重试3次·失败报警 |
| 节点编码对不上 | 数据丢失 | dry-run时打印未映射节点 |
| 数据量爆炸 | 性能问题 | 批量写入1000条/批·有上限保护 |

---

## 📞 常见问题

### Q1 · 没有汉询/Dcloud真实账号怎么办?

```
用 init_test_data.py 生成模拟数据
模拟数据包含:
  · 100个节点(30经销商+70门店)
  · 5个SKU
  · 30天历史
  · 5%随机断货 + 2%随机促销 → 可以测试三重验证算法
```

### Q2 · ETL运行多久?

```
预估:
  · 汉询ETL  (50万条/天):  约5-10分钟
  · Dcloud ETL (5万条/天):  约2-3分钟
  · 数据验证:                 约1-2分钟
  
总计 < 15分钟 · 留足时间给06:00校准
```

### Q3 · 字段对应不上怎么办?

```
1. 不要硬猜
2. 联系郭工·拿汉询/Dcloud真实表结构
3. 更新 docs/数据接入对接文档.md
4. 重新跑dry-run验证
```

---

**FROM:** DS  
**TO:** 郭工 + Tech Lead  
**2026-04-22**
