"""
数据质量验证脚本

每天ETL完成后运行 · 6项检查
不通过 → 报警 + 不让校准Agent启动

使用:
  python data_quality_check.py [--date YYYY-MM-DD] [--strict]

参数:
  --date    · 检查日期(默认昨天)
  --strict  · 严格模式·任何P0/P1失败立即exit(1)
"""
import argparse
import sys
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Optional
import pandas as pd
from sqlalchemy import create_engine, text
from loguru import logger


INFINITY_OS_URL = "mysql+pymysql://infinity:CHANGE_ME@localhost:3306/infinity_os"


# ============ DTO ============

@dataclass
class CheckResult:
    """单项检查结果"""
    check_name: str
    severity: str  # P0/P1/P2/P3
    passed: bool
    message: str
    details: dict = field(default_factory=dict)


@dataclass
class QualityReport:
    """质量验证总报告"""
    target_date: date
    overall_passed: bool = True
    p0_failed: int = 0
    p1_failed: int = 0
    p2_failed: int = 0
    p3_failed: int = 0
    results: list[CheckResult] = field(default_factory=list)


# ============ 主流程 ============

def run_quality_checks(target_date: date, strict: bool = False) -> QualityReport:
    """运行6项质量检查"""
    logger.info("=" * 50)
    logger.info(f"数据质量验证开始 · 日期: {target_date} · strict={strict}")
    logger.info("=" * 50)
    
    report = QualityReport(target_date=target_date)
    engine = create_engine(INFINITY_OS_URL, pool_pre_ping=True)
    
    # 6项检查
    checks = [
        check_completeness,
        check_timeliness,
        check_value_range,
        check_node_mapping,
        check_consistency,
        check_trend,
    ]
    
    for check_fn in checks:
        try:
            result = check_fn(engine, target_date)
            report.results.append(result)
            
            if not result.passed:
                if result.severity == "P0":
                    report.p0_failed += 1
                    report.overall_passed = False
                elif result.severity == "P1":
                    report.p1_failed += 1
                    if strict:
                        report.overall_passed = False
                elif result.severity == "P2":
                    report.p2_failed += 1
                else:
                    report.p3_failed += 1
                
                logger.warning(f"⚠️ [{result.severity}] {result.check_name}: {result.message}")
            else:
                logger.info(f"✅ {result.check_name}: {result.message}")
        
        except Exception as e:
            logger.error(f"❌ 检查 {check_fn.__name__} 异常: {e}")
            report.overall_passed = False
    
    engine.dispose()
    
    # 总结
    logger.info("=" * 50)
    logger.info("数据质量验证完成")
    logger.info(f"  总体通过: {report.overall_passed}")
    logger.info(f"  P0失败: {report.p0_failed}")
    logger.info(f"  P1失败: {report.p1_failed}")
    logger.info(f"  P2失败: {report.p2_failed}")
    logger.info(f"  P3失败: {report.p3_failed}")
    logger.info("=" * 50)
    
    return report


# ============ 6项检查 ============

def check_completeness(engine, target_date: date) -> CheckResult:
    """
    检查1 · 数据完整性
    标准:头部100节点·100%有数据
    """
    sql = text("""
        SELECT 
            COUNT(DISTINCT n.id) AS total_top_nodes,
            COUNT(DISTINCT h.node_id) AS nodes_with_data
        FROM inf_nodes n
        LEFT JOIN inf_heartbeat h 
            ON h.node_id = n.id AND h.data_date = :target_date
        WHERE n.node_type IN ('DISTRIBUTOR', 'STORE')
          AND n.status = 1
        ORDER BY n.id
        LIMIT 100
    """)
    
    with engine.connect() as conn:
        result = conn.execute(sql, {"target_date": target_date}).fetchone()
        total = result[0] if result else 0
        with_data = result[1] if result else 0
    
    coverage = (with_data / total * 100) if total > 0 else 0
    passed = coverage == 100
    
    return CheckResult(
        check_name="完整性 · 头部100节点覆盖",
        severity="P0",
        passed=passed,
        message=f"覆盖率 {coverage:.1f}% ({with_data}/{total})",
        details={"coverage_pct": coverage}
    )


def check_timeliness(engine, target_date: date) -> CheckResult:
    """
    检查2 · 数据时效性
    标准:95%数据延迟≤1天
    """
    sql = text("""
        SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN DATEDIFF(CURDATE(), data_date) <= 1 THEN 1 ELSE 0 END) AS fresh
        FROM inf_heartbeat
        WHERE data_date = :target_date
    """)
    
    with engine.connect() as conn:
        result = conn.execute(sql, {"target_date": target_date}).fetchone()
        total = result[0] if result else 0
        fresh = result[1] if result else 0
    
    fresh_rate = (fresh / total * 100) if total > 0 else 0
    passed = fresh_rate >= 95
    
    return CheckResult(
        check_name="时效性 · T+1占比",
        severity="P1",
        passed=passed,
        message=f"T+1占比 {fresh_rate:.1f}% (要求≥95%)",
        details={"fresh_rate": fresh_rate}
    )


def check_value_range(engine, target_date: date) -> CheckResult:
    """
    检查3 · 数值合理性
    标准:99%数据合理(0 ≤ r ≤ 10000)
    """
    sql = text("""
        SELECT 
            COUNT(*) AS total,
            SUM(CASE WHEN r_actual >= 0 AND r_actual <= 10000 THEN 1 ELSE 0 END) AS reasonable
        FROM inf_heartbeat
        WHERE data_date = :target_date
    """)
    
    with engine.connect() as conn:
        result = conn.execute(sql, {"target_date": target_date}).fetchone()
        total = result[0] if result else 0
        reasonable = result[1] if result else 0
    
    rate = (reasonable / total * 100) if total > 0 else 0
    passed = rate >= 99
    
    return CheckResult(
        check_name="合理性 · r值范围",
        severity="P1",
        passed=passed,
        message=f"合理率 {rate:.2f}% (要求≥99%)",
        details={"reasonable_rate": rate}
    )


def check_node_mapping(engine, target_date: date) -> CheckResult:
    """
    检查4 · 关联完整性
    标准:所有node_id都能在inf_nodes中找到
    """
    sql = text("""
        SELECT COUNT(*) AS orphan
        FROM inf_heartbeat h
        LEFT JOIN inf_nodes n ON n.id = h.node_id
        WHERE h.data_date = :target_date
          AND n.id IS NULL
    """)
    
    with engine.connect() as conn:
        result = conn.execute(sql, {"target_date": target_date}).fetchone()
        orphan = result[0] if result else 0
    
    passed = orphan == 0
    
    return CheckResult(
        check_name="关联完整 · node_id是否都存在",
        severity="P0",
        passed=passed,
        message=f"孤儿数据 {orphan} 条",
        details={"orphan_count": orphan}
    )


def check_consistency(engine, target_date: date) -> CheckResult:
    """
    检查5 · 数据一致性
    标准:r × t = a · 100%一致
    """
    sql = text("""
        SELECT COUNT(*) AS inconsistent
        FROM inf_heartbeat
        WHERE data_date = :target_date
          AND ABS(r_actual * t_period - a_unit) > 0.01
    """)
    
    with engine.connect() as conn:
        result = conn.execute(sql, {"target_date": target_date}).fetchone()
        inconsistent = result[0] if result else 0
    
    passed = inconsistent == 0
    
    return CheckResult(
        check_name="一致性 · a = r × t",
        severity="P1",
        passed=passed,
        message=f"不一致 {inconsistent} 条",
        details={"inconsistent_count": inconsistent}
    )


def check_trend(engine, target_date: date) -> CheckResult:
    """
    检查6 · 趋势合理性
    标准:与昨天相比·总r值变化<50%
    """
    sql = text("""
        SELECT 
            (SELECT AVG(r_actual) FROM inf_heartbeat WHERE data_date = :target_date) AS today_avg,
            (SELECT AVG(r_actual) FROM inf_heartbeat WHERE data_date = :prev_date) AS yesterday_avg
    """)
    
    prev_date = target_date - timedelta(days=1)
    
    with engine.connect() as conn:
        result = conn.execute(sql, {
            "target_date": target_date,
            "prev_date": prev_date
        }).fetchone()
        today_avg = float(result[0]) if result and result[0] else 0
        yesterday_avg = float(result[1]) if result and result[1] else 0
    
    if yesterday_avg == 0:
        return CheckResult(
            check_name="趋势合理 · 与昨日对比",
            severity="P2",
            passed=True,
            message="无昨日数据·跳过对比",
        )
    
    change_ratio = abs(today_avg - yesterday_avg) / yesterday_avg
    passed = change_ratio < 0.5
    
    return CheckResult(
        check_name="趋势合理 · 与昨日对比",
        severity="P2",
        passed=passed,
        message=f"r均值变化 {change_ratio*100:.1f}% (要求<50%) · 今日={today_avg:.1f} 昨日={yesterday_avg:.1f}",
        details={"change_ratio": change_ratio}
    )


# ============ CLI ============

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="数据质量验证")
    parser.add_argument(
        "--date",
        type=lambda s: datetime.strptime(s, "%Y-%m-%d").date(),
        default=date.today() - timedelta(days=1),
    )
    parser.add_argument("--strict", action="store_true", help="P1失败也退出")
    args = parser.parse_args()
    
    report = run_quality_checks(args.date, args.strict)
    
    if not report.overall_passed:
        logger.error("❌ 数据质量验证失败 · 不允许Agent启动")
        sys.exit(1)
    
    logger.info("✅ 数据质量验证通过 · Agent可以启动")
    sys.exit(0)
