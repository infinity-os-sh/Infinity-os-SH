"""
汉询数据接入ETL · Python脚本

每天凌晨04:00运行 · 从汉询读昨日日销 → 写入inf_heartbeat

Spec: .kiro/specs/data-import-hanxun/

使用:
  python hanxun_etl.py [--date YYYY-MM-DD] [--dry-run]

参数:
  --date     · 指定日期(默认昨天)
  --dry-run  · 只打印不写库
"""
import argparse
import sys
import time
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Optional
import pandas as pd
from sqlalchemy import create_engine, text
from loguru import logger


# ============ 配置 ============

# 汉询数据源(只读)
HANXUN_URL = "mysql+pymysql://infinity_readonly:CHANGE_ME@hanxun-host:3306/hanxun"

# INFINITY OS主数据库
INFINITY_OS_URL = "mysql+pymysql://infinity:CHANGE_ME@localhost:3306/infinity_os"


# ============ 主流程 ============

def run_etl(target_date: date, dry_run: bool = False) -> dict:
    """
    运行ETL主流程
    
    Args:
        target_date: 目标日期(读哪一天的数据)
        dry_run: 是否只打印不入库
    
    Returns:
        ETL报告(读取数·成功数·失败数·耗时)
    """
    start_time = time.time()
    logger.info("=" * 50)
    logger.info(f"汉询ETL开始 · 数据日期: {target_date} · dry_run={dry_run}")
    logger.info("=" * 50)
    
    report = {
        "target_date": str(target_date),
        "rows_read": 0,
        "rows_mapped": 0,
        "rows_unmapped": 0,
        "rows_invalid": 0,
        "rows_written": 0,
        "duration_ms": 0,
        "dry_run": dry_run,
    }
    
    try:
        # Step 1 · 从汉询读取数据
        df = read_from_hanxun(target_date)
        report["rows_read"] = len(df)
        logger.info(f"📥 从汉询读取 {len(df)} 条")
        
        if len(df) == 0:
            logger.warning("⚠️ 汉询无数据 · 退出")
            return report
        
        # Step 2 · 节点映射 · store_code → node_id
        df_mapped = map_to_node_id(df)
        report["rows_mapped"] = len(df_mapped)
        report["rows_unmapped"] = len(df) - len(df_mapped)
        logger.info(f"🔗 映射成功 {len(df_mapped)} 条 · 失败 {report['rows_unmapped']} 条")
        
        if report["rows_unmapped"] > 0:
            unmapped_codes = df[~df.index.isin(df_mapped.index)]['store_code'].unique()
            logger.warning(f"  未映射的store_code(前10): {list(unmapped_codes[:10])}")
        
        # Step 3 · 数据清洗 + 校验
        df_clean = clean_and_validate(df_mapped)
        report["rows_invalid"] = len(df_mapped) - len(df_clean)
        logger.info(f"🧹 清洗后 {len(df_clean)} 条 · 异常 {report['rows_invalid']} 条")
        
        # Step 4 · 转换为INFINITY OS格式
        df_target = transform_to_heartbeat(df_clean)
        
        # Step 5 · 写入inf_heartbeat
        if dry_run:
            logger.info("🧪 dry-run模式·跳过写库")
            logger.info(f"   将写入 {len(df_target)} 条")
            logger.info(f"   样本前3条:\n{df_target.head(3)}")
        else:
            written = write_to_infinity_os(df_target)
            report["rows_written"] = written
            logger.info(f"💾 写入 {written} 条")
        
    except Exception as e:
        logger.error(f"❌ ETL失败: {e}")
        raise
    
    finally:
        report["duration_ms"] = int((time.time() - start_time) * 1000)
        logger.info("=" * 50)
        logger.info(f"汉询ETL完成 · 耗时 {report['duration_ms']}ms")
        logger.info(f"  读取:    {report['rows_read']}")
        logger.info(f"  映射成功: {report['rows_mapped']}")
        logger.info(f"  写入:    {report['rows_written']}")
        logger.info("=" * 50)
    
    return report


# ============ 子函数 ============

def read_from_hanxun(target_date: date) -> pd.DataFrame:
    """从汉询读取指定日期的日销数据"""
    engine = create_engine(HANXUN_URL, pool_pre_ping=True)
    
    sql = text("""
        SELECT 
            store_code,
            product_code AS sku_code,
            rixiao AS r_actual,
            sale_date AS data_date,
            unit
        FROM daily_sales
        WHERE sale_date = :target_date
    """)
    
    df = pd.read_sql(sql, engine, params={"target_date": target_date})
    engine.dispose()
    return df


def map_to_node_id(df: pd.DataFrame) -> pd.DataFrame:
    """JOIN inf_nodes · 把store_code映射到node_id"""
    engine = create_engine(INFINITY_OS_URL, pool_pre_ping=True)
    
    nodes = pd.read_sql(
        "SELECT id AS node_id, node_code, node_type FROM inf_nodes WHERE status = 1",
        engine
    )
    engine.dispose()
    
    # 内连接 · 没匹配的丢弃
    merged = df.merge(
        nodes,
        left_on='store_code',
        right_on='node_code',
        how='inner'
    )
    return merged


def clean_and_validate(df: pd.DataFrame) -> pd.DataFrame:
    """数据清洗 + 合理性校验"""
    # 1. r_actual为空·剔除
    df = df.dropna(subset=['r_actual'])
    
    # 2. r_actual为负·剔除
    df = df[df['r_actual'] >= 0]
    
    # 3. r_actual过大(>10000)·剔除·疑似数据错误
    df = df[df['r_actual'] <= 10000]
    
    # 4. sku_code为空·剔除
    df = df[df['sku_code'].notna() & (df['sku_code'] != '')]
    
    return df


def transform_to_heartbeat(df: pd.DataFrame) -> pd.DataFrame:
    """转换为inf_heartbeat格式"""
    DEFAULT_T_PERIOD = 7
    
    result = pd.DataFrame({
        'node_id': df['node_id'],
        'sku_code': df['sku_code'],
        'r_actual': df['r_actual'],
        't_period': DEFAULT_T_PERIOD,
        'a_unit': df['r_actual'] * DEFAULT_T_PERIOD,
        # inventory_actual + water_level 由Dcloud ETL之后填
        # 这里先填0·后续被Dcloud ETL覆盖
        'inventory_actual': 0,
        'water_level': 0,
        'water_status': 'EMPTY',
        'data_date': df['data_date'],
        'data_source': 'HANXUN',
        'quality_score': 100,
    })
    return result


def write_to_infinity_os(df: pd.DataFrame) -> int:
    """写入inf_heartbeat · upsert方式(同node+sku+date更新)"""
    engine = create_engine(INFINITY_OS_URL, pool_pre_ping=True)
    
    # 用INSERT ... ON DUPLICATE KEY UPDATE
    # 因为有 uk_node_sku_date 唯一索引
    written = 0
    batch_size = 1000
    
    with engine.begin() as conn:
        for i in range(0, len(df), batch_size):
            batch = df.iloc[i:i+batch_size]
            for _, row in batch.iterrows():
                sql = text("""
                    INSERT INTO inf_heartbeat 
                        (node_id, sku_code, r_actual, t_period, a_unit, 
                         inventory_actual, water_level, water_status, 
                         data_date, data_source, quality_score)
                    VALUES 
                        (:node_id, :sku_code, :r_actual, :t_period, :a_unit,
                         :inventory_actual, :water_level, :water_status,
                         :data_date, :data_source, :quality_score)
                    ON DUPLICATE KEY UPDATE
                        r_actual = VALUES(r_actual),
                        a_unit = VALUES(a_unit),
                        data_source = VALUES(data_source)
                """)
                conn.execute(sql, dict(row))
                written += 1
            
            if i % 10000 == 0 and i > 0:
                logger.info(f"  已写入 {i}/{len(df)}")
    
    engine.dispose()
    return written


# ============ CLI ============

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="汉询ETL · 接入日销数据")
    parser.add_argument(
        "--date",
        type=lambda s: datetime.strptime(s, "%Y-%m-%d").date(),
        default=date.today() - timedelta(days=1),
        help="目标日期(默认昨天)"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只打印不入库"
    )
    args = parser.parse_args()
    
    try:
        report = run_etl(args.date, args.dry_run)
        sys.exit(0)
    except Exception as e:
        logger.error(f"ETL执行失败: {e}")
        sys.exit(1)
