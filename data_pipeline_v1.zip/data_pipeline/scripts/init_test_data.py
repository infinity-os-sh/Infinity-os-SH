"""
模拟数据生成脚本 · 测试用

在没有真实汉询/Dcloud之前·用这个脚本生成测试数据
让Agent能立刻跑起来·不必等数据接入

使用:
  python init_test_data.py [--days 30] [--nodes 100]

参数:
  --days   · 生成多少天历史数据(默认30天)
  --nodes  · 生成多少个测试节点(默认100)
"""
import argparse
import random
from datetime import date, timedelta
from decimal import Decimal
import pandas as pd
from sqlalchemy import create_engine, text
from loguru import logger


INFINITY_OS_URL = "mysql+pymysql://infinity:CHANGE_ME@localhost:3306/infinity_os"


def generate_test_data(days: int = 30, num_nodes: int = 100):
    """生成测试数据"""
    logger.info(f"生成测试数据: {days}天 × {num_nodes}节点")
    
    engine = create_engine(INFINITY_OS_URL, pool_pre_ping=True)
    
    # Step 1 · 创建节点
    nodes = create_test_nodes(engine, num_nodes)
    logger.info(f"✅ 创建 {len(nodes)} 个测试节点")
    
    # Step 2 · 创建SKU列表
    skus = ["LYX500", "LYX1000", "LYX380", "LYX150", "WDM500"]  # 5个测试SKU
    
    # Step 3 · 生成每天的心跳数据
    end_date = date.today() - timedelta(days=1)
    start_date = end_date - timedelta(days=days)
    
    total_records = 0
    current_date = start_date
    
    while current_date <= end_date:
        records = []
        for node in nodes:
            for sku in skus:
                # 生成"看起来真实"的r值
                base_r = random.uniform(5, 50)  # 基础日销
                noise = random.uniform(-2, 2)   # 噪声
                r = max(0, base_r + noise)
                
                # 偶尔模拟断货(5%)
                if random.random() < 0.05:
                    r = 0
                
                # 偶尔模拟促销(2%)
                if random.random() < 0.02:
                    r = base_r * 3
                
                t = 7
                a = round(r * t, 2)
                
                # 模拟库存
                inventory = round(a * random.uniform(0.5, 3.5), 2)
                water_level = round(inventory / a, 2) if a > 0 else 0
                
                # 状态判断
                if water_level <= 0:
                    status = "EMPTY"
                elif water_level >= 2:
                    status = "FULL"
                elif water_level >= 1:
                    status = "WARN"
                else:
                    status = "LOW"
                
                records.append({
                    "node_id": node["id"],
                    "sku_code": sku,
                    "r_actual": round(r, 2),
                    "t_period": t,
                    "a_unit": a,
                    "inventory_actual": inventory,
                    "water_level": water_level,
                    "water_status": status,
                    "data_date": current_date,
                    "data_source": "MANUAL_TEST",
                    "quality_score": 100,
                })
        
        # 批量写入
        df = pd.DataFrame(records)
        df.to_sql("inf_heartbeat", engine, if_exists="append", index=False)
        total_records += len(records)
        
        if current_date.day == 1 or current_date == end_date:
            logger.info(f"  {current_date}: 写入 {len(records)} 条 · 累计 {total_records}")
        
        current_date += timedelta(days=1)
    
    engine.dispose()
    
    logger.info(f"✅ 测试数据生成完成 · 总计 {total_records} 条")


def create_test_nodes(engine, num: int) -> list[dict]:
    """创建测试节点(经销商 + 门店混合)"""
    cities = ["上海", "北京", "广州", "深圳", "杭州", "成都", "武汉", "西安"]
    grades = ["A", "B", "C", "D"]
    
    nodes_to_insert = []
    
    # 30%经销商
    for i in range(int(num * 0.3)):
        nodes_to_insert.append({
            "node_code": f"DIST_TEST_{i:03d}",
            "node_type": "DISTRIBUTOR",
            "node_name": f"测试经销商_{i}",
            "ipo_stage": 3,
            "city": random.choice(cities),
            "city_grade": random.choice(grades),
            "path": "P1",
            "status": 1,
        })
    
    # 70%门店
    for i in range(int(num * 0.7)):
        nodes_to_insert.append({
            "node_code": f"STORE_TEST_{i:03d}",
            "node_type": "STORE",
            "node_name": f"测试门店_{i}",
            "ipo_stage": 9,
            "city": random.choice(cities),
            "city_grade": random.choice(grades),
            "path": "P1",
            "status": 1,
        })
    
    df = pd.DataFrame(nodes_to_insert)
    df.to_sql("inf_nodes", engine, if_exists="append", index=False)
    
    # 读回id
    with engine.connect() as conn:
        result = conn.execute(text("""
            SELECT id, node_code FROM inf_nodes 
            WHERE node_code LIKE 'DIST_TEST_%' OR node_code LIKE 'STORE_TEST_%'
        """))
        return [{"id": row[0], "code": row[1]} for row in result]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="生成测试数据")
    parser.add_argument("--days", type=int, default=30)
    parser.add_argument("--nodes", type=int, default=100)
    args = parser.parse_args()
    
    generate_test_data(args.days, args.nodes)
