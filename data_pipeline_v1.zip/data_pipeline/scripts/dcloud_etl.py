"""
Dcloud库存接入ETL · Python脚本

每天凌晨04:30运行(在汉询ETL之后)
从Dcloud读当前库存 → 更新inf_heartbeat的inventory_actual + water_level

Spec: .kiro/specs/data-import-dcloud/

使用:
  python dcloud_etl.py [--date YYYY-MM-DD] [--dry-run]
"""
import argparse
import sys
import time
from datetime import date, datetime, timedelta
from decimal import Decimal
import pandas as pd
from sqlalchemy import create_engine, text
from loguru import logger


# ============ 配置 ============

DCLOUD_URL = "mysql+pymysql://infinity_readonly:CHANGE_ME@dcloud-host:3306/dcloud"
INFINITY_OS_URL = "mysql+pymysql://infinity:CHANGE_ME@localhost:3306/infinity_os"


# 水位状态阈值(从heartbeat.py复用)
WATER_THRESHOLDS = {
    "STORE": {"overflow": 3.5, "full": 2.0, "warn": 1.0},
    "DISTRIBUTOR": {"overflow": 2.5, "full": 1.0, "warn": 0.3},
    "SUB_DIST": {"overflow": 1.2, "full": 0.8, "warn": 0.3},
}


def determine_water_status(water_level: float, node_type: str) -> str:
    """判断水位状态(与heartbeat.py保持一致)"""
    if water_level <= 0:
        return "EMPTY"
    
    thresholds = WATER_THRESHOLDS.get(node_type, WATER_THRESHOLDS["STORE"])
    
    if water_level > thresholds["overflow"]:
        return "OVERFLOW"
    if water_level >= thresholds["full"]:
        return "FULL"
    if water_level > thresholds["warn"]:
        return "WARN"
    return "LOW"


# ============ 主流程 ============

def run_etl(target_date: date, dry_run: bool = False) -> dict:
    """
    Dcloud ETL主流程
    
    与汉询ETL不同:
      · 汉询ETL是INSERT(新增r_actual行)
      · Dcloud ETL是UPDATE(更新已有行的inventory_actual + water_level)
      
    依赖:汉询ETL必须先跑完 · inf_heartbeat必须有当天的r_actual行
    """
    start_time = time.time()
    logger.info("=" * 50)
    logger.info(f"Dcloud ETL开始 · 数据日期: {target_date} · dry_run={dry_run}")
    logger.info("=" * 50)
    
    report = {
        "target_date": str(target_date),
        "rows_read": 0,
        "rows_mapped": 0,
        "rows_unmapped": 0,
        "rows_updated": 0,
        "rows_no_match": 0,
        "duration_ms": 0,
    }
    
    try:
        # Step 1 · 从Dcloud读取库存
        df = read_from_dcloud(target_date)
        report["rows_read"] = len(df)
        logger.info(f"📥 从Dcloud读取 {len(df)} 条")
        
        if len(df) == 0:
            logger.warning("⚠️ Dcloud无数据 · 退出")
            return report
        
        # Step 2 · 节点映射 · vendor_code → node_id
        df_mapped = map_to_node_id(df)
        report["rows_mapped"] = len(df_mapped)
        report["rows_unmapped"] = len(df) - len(df_mapped)
        logger.info(f"🔗 映射成功 {len(df_mapped)} 条")
        
        # Step 3 · 加载当天的heartbeat数据(从汉询ETL写入的) · JOIN获取a_unit
        df_with_a = enrich_with_a_unit(df_mapped, target_date)
        report["rows_no_match"] = len(df_mapped) - len(df_with_a)
        logger.info(f"🔗 关联a_unit成功 {len(df_with_a)} 条 · 无r数据 {report['rows_no_match']} 条")
        
        # Step 4 · 计算水位 + 状态
        df_calc = calculate_water_level(df_with_a)
        
        # Step 5 · UPDATE inf_heartbeat
        if dry_run:
            logger.info("🧪 dry-run模式·跳过更新")
            logger.info(f"   将更新 {len(df_calc)} 条")
            logger.info(f"   样本前3条:\n{df_calc.head(3)}")
        else:
            updated = update_inventory(df_calc, target_date)
            report["rows_updated"] = updated
            logger.info(f"💾 更新 {updated} 条")
    
    except Exception as e:
        logger.error(f"❌ Dcloud ETL失败: {e}")
        raise
    
    finally:
        report["duration_ms"] = int((time.time() - start_time) * 1000)
        logger.info("=" * 50)
        logger.info(f"Dcloud ETL完成 · 耗时 {report['duration_ms']}ms")
        logger.info(f"  读取:    {report['rows_read']}")
        logger.info(f"  更新:    {report['rows_updated']}")
        logger.info("=" * 50)
    
    return report


# ============ 子函数 ============

def read_from_dcloud(target_date: date) -> pd.DataFrame:
    """从Dcloud读取库存数据(取每个vendor+sku最新一条)"""
    engine = create_engine(DCLOUD_URL, pool_pre_ping=True)
    
    sql = text("""
        SELECT 
            vendor_code,
            matnr AS sku_code,
            stock_qty AS inventory_actual,
            update_time
        FROM (
            SELECT 
                vendor_code, matnr, stock_qty, update_time,
                ROW_NUMBER() OVER (
                    PARTITION BY vendor_code, matnr 
                    ORDER BY update_time DESC
                ) AS rn
            FROM wm_stock_matnr
            WHERE DATE(update_time) <= :target_date
        ) t
        WHERE rn = 1
    """)
    
    df = pd.read_sql(sql, engine, params={"target_date": target_date})
    engine.dispose()
    return df


def map_to_node_id(df: pd.DataFrame) -> pd.DataFrame:
    """JOIN inf_nodes · vendor_code → node_id + node_type"""
    engine = create_engine(INFINITY_OS_URL, pool_pre_ping=True)
    
    nodes = pd.read_sql(
        "SELECT id AS node_id, node_code, node_type FROM inf_nodes WHERE status = 1",
        engine
    )
    engine.dispose()
    
    merged = df.merge(
        nodes,
        left_on='vendor_code',
        right_on='node_code',
        how='inner'
    )
    return merged


def enrich_with_a_unit(df: pd.DataFrame, target_date: date) -> pd.DataFrame:
    """
    关联当天的a_unit
    必须汉询ETL已经先写入r_actual + a_unit
    """
    engine = create_engine(INFINITY_OS_URL, pool_pre_ping=True)
    
    sql = """
        SELECT node_id, sku_code, r_actual, a_unit
        FROM inf_heartbeat
        WHERE data_date = %s
    """
    hb_today = pd.read_sql(sql, engine, params=(target_date,))
    engine.dispose()
    
    merged = df.merge(
        hb_today,
        on=['node_id', 'sku_code'],
        how='inner'
    )
    return merged


def calculate_water_level(df: pd.DataFrame) -> pd.DataFrame:
    """计算水位 + 状态"""
    df = df.copy()
    
    # 水位 = inventory ÷ a
    df['water_level'] = df.apply(
        lambda row: round(float(row['inventory_actual']) / float(row['a_unit']), 2)
        if float(row['a_unit']) > 0 else 0,
        axis=1
    )
    
    # 状态
    df['water_status'] = df.apply(
        lambda row: determine_water_status(row['water_level'], row['node_type']),
        axis=1
    )
    
    return df


def update_inventory(df: pd.DataFrame, target_date: date) -> int:
    """UPDATE inf_heartbeat的inventory + water_level + water_status"""
    engine = create_engine(INFINITY_OS_URL, pool_pre_ping=True)
    
    updated = 0
    with engine.begin() as conn:
        for _, row in df.iterrows():
            sql = text("""
                UPDATE inf_heartbeat
                SET inventory_actual = :inventory_actual,
                    water_level = :water_level,
                    water_status = :water_status,
                    data_source = CONCAT(data_source, '+DCLOUD')
                WHERE node_id = :node_id
                  AND sku_code = :sku_code
                  AND data_date = :data_date
            """)
            result = conn.execute(sql, {
                "inventory_actual": float(row['inventory_actual']),
                "water_level": float(row['water_level']),
                "water_status": row['water_status'],
                "node_id": int(row['node_id']),
                "sku_code": row['sku_code'],
                "data_date": target_date,
            })
            updated += result.rowcount
    
    engine.dispose()
    return updated


# ============ CLI ============

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Dcloud库存ETL")
    parser.add_argument(
        "--date",
        type=lambda s: datetime.strptime(s, "%Y-%m-%d").date(),
        default=date.today() - timedelta(days=1),
    )
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    
    try:
        report = run_etl(args.date, args.dry_run)
        sys.exit(0)
    except Exception as e:
        logger.error(f"ETL执行失败: {e}")
        sys.exit(1)
